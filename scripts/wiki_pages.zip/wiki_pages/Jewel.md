# Jewel

Jewels

Tooltip

Jewels are items that can be socketed into Jewel Sockets on the Passive Skill Tree to grant bonuses. Basic Jewels simply grant you the listed stats, while some other kinds of Jewel can have more complicated effects, such as modifying other Passive Skills within a certain radius.

**Jewels** are items that can be placed into allocated [Jewel Sockets](/wiki/Jewel_Socket "Jewel Socket") in the [Passive Skill Tree](/wiki/Passive_Skill_Tree "Passive Skill Tree"), and can be removed or replaced at no cost. They can grant various stats or modify the effects of other passive skills in its radius. Time-lost jewels drop exclusively from the [Trial of the Sekhemas](/wiki/Trial_of_the_Sekhemas "Trial of the Sekhemas").

## Mechanics

Jewels are craftable, but can only have a maximum of four affixes instead of the usual six, though [corrupted](/wiki/Corrupted "Corrupted") jewels can have up to five. Jewels generally do not have level or stat requirements.

Jewels can be socketed or removed from jewel sockets freely. Passive respec points are not required to do so.

Jewels may have a designated radius (small, medium, or large). These indicate how large of an area the jewel's modifiers will affect on the passive skill tree if it has modifiers that modify or depend on other passive skills. This radius can be modified through affixes.

It is possible to leave a jewel in an unallocated jewel socket; however, doing so will disable the jewel's effects. The jewel can still be removed, but another jewel cannot be placed into an unallocated jewel socket.

The modifiers jewels can roll depend on the jewel's base type. The colour of jewel determines the modifier's thematic alignments, while whether it is a regular jewel or a time-lost jewel determines if it rolls regular or radius affixes.

### Jewel limits

Historic Jewels

Tooltip

You can only have one Historic Jewel socketed.

Most [unique jewels](/wiki/Unique_jewel "Unique jewel") have a jewel limit, allowing that many copies of that jewel to be socketed.

Additionally, only one **Historic** jewel can be socketed in a character's passive tree at a time. [Heroic Tragedy](/wiki/Heroic_Tragedy "Heroic Tragedy") and [Undying Hate](/wiki/Undying_Hate "Undying Hate") are the only Historic jewels in the game currently.

## Jewel types

Basic Jewel

Tooltip

Basic Jewels do not affect nodes in a radius.
Basic Jewels are Rubies, Emeralds, Sapphires and Diamonds.

Jewels come in two varieties: regular jewels and time-lost jewels. Regular jewels provide various generic stats. Time-lost jewels do not inherently provide any stats, but will instead modify other passive skills in its radius.

* [Ruby](/wiki/Ruby "Ruby")
* [Emerald](/wiki/Emerald "Emerald")
* [Sapphire](/wiki/Sapphire "Sapphire")
* [Time-Lost Ruby](/wiki/Time-Lost_Ruby "Time-Lost Ruby")
* [Time-Lost Emerald](/wiki/Time-Lost_Emerald "Time-Lost Emerald")
* [Time-Lost Sapphire](/wiki/Time-Lost_Sapphire "Time-Lost Sapphire")

These jewel bases do not normally drop, and can only be obtained as [unique items](/wiki/Unique_item "Unique item").

* [Diamond](/wiki/Diamond "Diamond")
* [Time-Lost Diamond](/wiki/Time-Lost_Diamond "Time-Lost Diamond")
* [Timeless Jewel](/wiki/Timeless_Jewel "Timeless Jewel")

## Unique jewels

Main article: [List of unique jewels](/wiki/List_of_unique_jewels "List of unique jewels")

| Item |  | Stats | Additional drop restrictions |
| --- | --- | --- | --- |
| [Against the Darkness](/wiki/Against_the_Darkness "Against the Darkness") | 1 | | <2 random jewel modifiers> | | --- | | +(2-3)% to [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance")  ---  +(2-4)% to [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance")  ---  [Gain](/wiki/Gain "Gain") (2-4)% of Damage as Extra [Chaos](/wiki/Chaos "Chaos") Damage  ---  [Gain](/wiki/Gain "Gain") (2-4)% of Damage as Extra [Cold](/wiki/Cold "Cold") Damage  ---  [Gain](/wiki/Gain "Gain") (2-4)% of Damage as Extra [Fire](/wiki/Fire "Fire") Damage  ---  [Gain](/wiki/Gain "Gain") (2-4)% of Damage as Extra [Lightning](/wiki/Lightning "Lightning") Damage  ---  +(2-4)% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance")  ---  (4-6)% reduced [Freeze](/wiki/Freeze "Freeze") Duration on you  ---  (4-6)% reduced [Ignite](/wiki/Ignite "Ignite") Duration on you  ---  +8 to maximum Life  ---  +8 to maximum Mana  ---  +(2-4)% to [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance")  ---  +1% to [Maximum Chaos Resistance](/wiki/Maximum_Chaos_Resistance/edit?redlink=1 "Maximum Chaos Resistance (page does not exist)")  ---  +1% to [Maximum Cold Resistance](/wiki/Maximum_Cold_Resistance "Maximum Cold Resistance")  ---  +1% to [Maximum Fire Resistance](/wiki/Maximum_Fire_Resistance "Maximum Fire Resistance")  ---  +1% to [Maximum Lightning Resistance](/wiki/Maximum_Lightning_Resistance "Maximum Lightning Resistance")  ---  (2-3)% increased [Dexterity](/wiki/Dexterity "Dexterity")  ---  (2-3)% increased [Intelligence](/wiki/Intelligence "Intelligence")  ---  (2-3)% increased [Strength](/wiki/Strength "Strength")  ---  (4-6)% reduced [Shock](/wiki/Shock "Shock") duration on you  ---  +(8-12) to [Spirit](/wiki/Spirit "Spirit") | | *Drops from [Zarokh, the Eternal](/wiki/Zarokh,_the_Eternal "Zarokh, the Eternal") when completing a run using [The Desperate Alliance](/wiki/The_Desperate_Alliance "The Desperate Alliance").* |
| [Controlled Metamorphosis](/wiki/Controlled_Metamorphosis "Controlled Metamorphosis") | 1 | Only affects Passives in (Very Small-Massive) Ring Passives in Radius can be Allocated without being connected to your tree -(20-5)% to all [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") | *Drops from [Xesht, We That Are One](/wiki/Xesht,_We_That_Are_One "Xesht, We That Are One").* |
| [Flesh Crucible](/wiki/Flesh_Crucible "Flesh Crucible") | 1 | <Keystone Passive Skill>   | <Random stat penalty> | | --- | | (20-10)% less Damage  ---  (20-10)% less [Defences](/wiki/Defences "Defences")  ---  (20-10)% less maximum Life  ---  (20-10)% less maximum Mana  ---  (20-10)% less Movement Speed  ---  (20-10)% less [Spirit](/wiki/Spirit "Spirit") |  *Corrupted* | *Can drop from Atziri's Vault in [Atziri's Temple](/wiki/Atziri%27s_Temple "Atziri's Temple") after defeating [Atziri, the Red Queen](/wiki/Atziri,_the_Red_Queen "Atziri, the Red Queen").* |
| [From Nothing](/wiki/From_Nothing "From Nothing") | 1 | Passives in Radius of <Keystone> can be Allocated without being connected to your tree*Corrupted* | *Drops from [The King in the Mists](/wiki/The_King_in_the_Mists "The King in the Mists") at the [Crux of Nothingness](/wiki/Crux_of_Nothingness "Crux of Nothingness").* |
| [Grand Spectrum](/wiki/Grand_Spectrum_(Emerald) "Grand Spectrum (Emerald)") | 1 | 2% increased [Spirit](/wiki/Spirit "Spirit") per socketed Grand Spectrum | *Obtained from a "Gold Spectrum Cache" chest in the [Trial of the Sekhemas](/wiki/Trial_of_the_Sekhemas "Trial of the Sekhemas").* |
| [Grand Spectrum](/wiki/Grand_Spectrum_(Ruby) "Grand Spectrum (Ruby)") | 1 | 2% increased Maximum Life per socketed Grand Spectrum | *Obtained from a "Gold Spectrum Cache" chest in the [Trial of the Sekhemas](/wiki/Trial_of_the_Sekhemas "Trial of the Sekhemas").* |
| [Grand Spectrum](/wiki/Grand_Spectrum_(Sapphire) "Grand Spectrum (Sapphire)") | 1 | +6% to all [Elemental Resistances](/wiki/Elemental_Resistance/edit?redlink=1 "Elemental Resistance (page does not exist)") per socketed Grand Spectrum | *Obtained from a "Gold Spectrum Cache" chest in the [Trial of the Sekhemas](/wiki/Trial_of_the_Sekhemas "Trial of the Sekhemas").* |
| [Heart of the Well](/wiki/Heart_of_the_Well "Heart of the Well") | 1 | <Custom Desecrated prefix> <Custom Desecrated prefix> <Custom Desecrated suffix> <Custom Desecrated suffix>   | <List of mods> | | --- | | (5-10)% chance to [Aggravate](/wiki/Aggravate "Aggravate") [Bleeding](/wiki/Bleeding "Bleeding") on targets you [Hit](/wiki/Hit "Hit") with [Attacks](/wiki/Attack "Attack")  ---  (5-8)% increased [Attack](/wiki/Attack "Attack") Speed while a [Rare or Unique](/wiki/Rarity "Rarity") Enemy is in your [Presence](/wiki/Presence "Presence")  ---  (40-60)% increased [Armour](/wiki/Armour "Armour") from Equipped Body Armour  ---  (30-50)% chance to [Pierce](/wiki/Pierce "Pierce") an Enemy  ---  (10-15)% chance when a [Charm](/wiki/Charm "Charm") is used to use another Charm without consuming Charges  ---  [Charms](/wiki/Charm "Charm") applied to you have (15-25)% increased Effect  ---  Recover (5-10)% of maximum Mana when a [Charm](/wiki/Charm "Charm") is used  ---  (15-25)% increased [Culling Strike](/wiki/Culling_Strike "Culling Strike") Threshold  ---  [Gain](/wiki/Gain "Gain") (9-15)% of Damage as Extra [Lightning](/wiki/Lightning "Lightning") Damage  ---  [Gain](/wiki/Gain "Gain") (7-13)% of Damage as Extra [Chaos](/wiki/Chaos "Chaos") Damage  ---  [Gain](/wiki/Gain "Gain") (9-15)% of Damage as Extra [Fire](/wiki/Fire "Fire") Damage  ---  [Gain](/wiki/Gain "Gain") (9-15)% of Damage as Extra [Cold](/wiki/Cold "Cold") Damage  ---  (15-25)% increased Damage while your [Companion](/wiki/Companion "Companion") is in your [Presence](/wiki/Presence "Presence")  ---  (15-25)% increased [Exposure](/wiki/Exposure "Exposure") Effect  ---  (40-60)% increased [Evasion](/wiki/Evasion "Evasion") Rating from Equipped Body Armour  ---  Regenerate (1-1.5)% of maximum Life per Second if you've used a Life [Flask](/wiki/Flask "Flask") in the past 10 seconds  ---  (10-18)% increased [Cooldown Recovery Rate](/wiki/Cooldown_Recovery_Rate "Cooldown Recovery Rate")  ---  (40-60)% increased [Ice Crystal](/wiki/Ice_Crystal "Ice Crystal") Life  ---  (4-8)% increased [Skill Speed](/wiki/Skill_Speed "Skill Speed")  ---  (15-25)% chance for [Lightning](/wiki/Lightning "Lightning") Damage with [Hits](/wiki/Hit "Hit") to be [Lucky](/wiki/Lucky "Lucky")  ---  (8-16)% increased Mana Cost [Efficiency](/wiki/Efficiency "Efficiency")  ---  (20-30)% increased Mana Regeneration Rate while moving  ---  +1% to all [Maximum Elemental Resistances](/wiki/Maximum_Resistance "Maximum Resistance")  ---  (40-60)% increased [Energy Shield](/wiki/Energy_Shield "Energy Shield") from Equipped Body Armour  ---  [Minions](/wiki/Minion "Minion") gain (10-15)% of their maximum Life as Extra maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield")  ---  [Minions](/wiki/Minion "Minion") Regenerate (1-3)% of maximum Life per second  ---  [Minions](/wiki/Minion "Minion") [Revive](/wiki/Reviving_Minions "Reviving Minions") (5-10)% faster  ---  (8-15)% of Leech is Instant  ---  (5-10)% of Physical Damage prevented [Recouped](/wiki/Recoup "Recoup") as Life  ---  (8-14)% increased speed of [Recoup](/wiki/Recoup "Recoup") Effects  ---  Recover (2-4)% of maximum Life on Killing a [Poisoned](/wiki/Poison "Poison") Enemy  ---  (10-15)% increased Skill Effect Duration  ---  +(2-4)% to Thorns [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance  ---  Gain [Physical](/wiki/Physical "Physical") [Thorns](/wiki/Thorns "Thorns") damage equal to (4-6)% of [Item Armour](/wiki/Defences "Defences") on [Equipped](/wiki/Equipped/edit?redlink=1 "Equipped (page does not exist)") Body Armour  ---  (6-12)% chance for [Trigger](/wiki/Trigger "Trigger") skills to refund half of [Energy](/wiki/Energy "Energy") Spent  ---  (4-8)% increased chance to inflict [Ailments](/wiki/Ailments "Ailments")  ---  Gain additional [Ailment Threshold](/wiki/Ailment_Threshold "Ailment Threshold") equal to (4-10)% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield")  ---  (5-10)% chance to inflict [Bleeding](/wiki/Bleeding "Bleeding") on [Hit](/wiki/Hit "Hit")  ---  (5-10)% chance to [Poison](/wiki/Poison "Poison") on [Hit](/wiki/Hit "Hit")  ---  (4-8)% increased [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance  ---  (6-12)% increased [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus")  ---  (2-3)% of Damage is taken from Mana before Life  ---  [Debuffs](/wiki/Debuff "Debuff") on you expire (4-8)% faster  ---  [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") deal damage (2-4)% faster  ---  (4-8)% increased [Flask](/wiki/Flask "Flask") Effect Duration  ---  Gain (1-2) [Rage](/wiki/Rage "Rage") when [Hit](/wiki/Hit "Hit") by an Enemy  ---  (2-3)% increased [Cooldown Recovery Rate](/wiki/Cooldown_Recovery_Rate "Cooldown Recovery Rate")  ---  (6-12)% increased [Elemental Ailment Threshold](/wiki/Ailment "Ailment")  ---  (2-3)% increased [Attack](/wiki/Attack "Attack") Speed  ---  (2-3)% increased Cast Speed  ---  (4-8)% increased [Flask](/wiki/Flask "Flask") Charges gained  ---  (5-10)% increased [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold")  ---  (2-3)% of Skill Mana Costs [Converted](/wiki/Stat_conversion "Stat conversion") to Life Costs  ---  (2-3)% of Damage taken [Recouped](/wiki/Recoup "Recoup") as Life  ---  (6-12)% increased Life Regeneration rate  ---  Recover (1-2)% of maximum Mana on Kill  ---  (4-8)% increased Mana Regeneration Rate  ---  +1% to [Maximum Cold Resistance](/wiki/Maximum_Cold_Resistance "Maximum Cold Resistance")  ---  +1% to [Maximum Fire Resistance](/wiki/Maximum_Fire_Resistance "Maximum Fire Resistance")  ---  Recover (1-2)% of maximum Life on Kill  ---  +1% to [Maximum Lightning Resistance](/wiki/Maximum_Lightning_Resistance "Maximum Lightning Resistance")  ---  [Minions](/wiki/Minion "Minion") have (2-3)% increased [Attack](/wiki/Attack "Attack") and Cast Speed  ---  [Minions](/wiki/Minion "Minion") have (6-12)% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance")  ---  [Minions](/wiki/Minion "Minion") have +(3-4)% to all Elemental [Resistances](/wiki/Resistances "Resistances")  ---  [Minions](/wiki/Minion "Minion") have (3-12)% additional [Physical](/wiki/Physical "Physical") Damage Reduction  ---  (1-2)% increased Movement Speed  ---  Gain 1 [Rage](/wiki/Rage "Rage") on [Melee](/wiki/Melee "Melee") [Hit](/wiki/Hit "Hit")  ---  (3-8)% increased Skill Effect Duration  ---  (10-5)% reduced [Slowing](/wiki/Slow "Slow") Potency of [Debuffs](/wiki/Debuff "Debuff") on You  ---  (4-8)% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for [Spells](/wiki/Spell "Spell")  ---  (6-12)% increased [Critical Spell Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus")  ---  (6-12)% increased [Stun](/wiki/Stun "Stun") Buildup  ---  Gain additional [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") equal to (4-10)% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") | | *Drops from [Lichborn exiles](/wiki/Rogue_exile "Rogue exile") in [Abyss](/wiki/Abyss "Abyss") encounters.* |
| [Heroic Tragedy](/wiki/Heroic_Tragedy "Heroic Tragedy") | 1 | Remembering (100-8000) songworthy deeds by the line of (Vorana-Medved-Olroth) Passives in radius are Conquered by the Kalguur Historic | *Drops from [Olroth, Origin of the Fall](/wiki/Olroth,_Origin_of_the_Fall "Olroth, Origin of the Fall").* |
| [Megalomaniac](/wiki/Megalomaniac "Megalomaniac") | 1 | Allocates <2-3 random notable passive skills>*Corrupted* | *Drops in the [Simulacrum](/wiki/Simulacrum_(encounter) "Simulacrum (encounter)").* |
| [Prism of Belief](/wiki/Prism_of_Belief "Prism of Belief") | 1 | +(1-3) to Level of all <Random skill> Skills*Corrupted* | *Drops from [The Arbiter of Ash](/wiki/The_Arbiter_of_Ash "The Arbiter of Ash").* |
| [The Adorned](/wiki/The_Adorned "The Adorned") | 1 | (0-150)% increased Effect of Jewel Socket Passive Skills containing [Corrupted](/wiki/Corrupted "Corrupted") [Magic](/wiki/Magic "Magic") [Jewels](/wiki/Jewels "Jewels")*Corrupted* | *Drops from [The Trialmaster](/wiki/The_Trialmaster "The Trialmaster").* |
| [Undying Hate](/wiki/Undying_Hate "Undying Hate") | 1 | Glorifying the defilement of (79-30977) souls in tribute to (Amanamu-Ulaman-Kurgal-Tecrod-Kulemak) Passives in radius are Conquered by the Abyssals Desecration makes this item Unstable Historic <Can gain 0-4 custom [Desecrated Modifiers](/wiki/Desecrated_Modifier "Desecrated Modifier")> (Hidden) | *Drops from [Vessel of Kulemak](/wiki/Vessel_of_Kulemak "Vessel of Kulemak").* |

## Related passive skills

The following [passive skills](/wiki/Passive_skill "Passive skill") are related to jewels:

### Ascendancy passive skills

| Ascendancy Class | Name | Stats |
| --- | --- | --- |
| [Disciple of Varashta](/wiki/Disciple_of_Varashta "Disciple of Varashta") | [Baryanic Leylines](/wiki/Baryanic_Leylines "Baryanic Leylines") | Non-[Unique](/wiki/Unique "Unique") Time-Lost [Jewels](/wiki/Jewels "Jewels") have 40% increased radius [[1]](/wiki/Passive_Skill:AscendancySorceress3Notable6 "Passive Skill:AscendancySorceress3Notable6") |
| [Lich](/wiki/Lich "Lich") | [Crystalline Phylactery](/wiki/Crystalline_Phylactery "Crystalline Phylactery") | 100% increased Effect of the Socketed Jewel Can Socket a [non-Unique](/wiki/Rarity "Rarity") [Basic Jewel](/wiki/Basic_Jewel/edit?redlink=1 "Basic Jewel (page does not exist)") into the Phylactery 50% more Mana Cost of Skills if you have no [Energy Shield](/wiki/Energy_Shield "Energy Shield") [[1]](/wiki/Passive_Skill:AscendancyWitch3Notable1 "Passive Skill:AscendancyWitch3Notable1") |
