# Sceptre

Sceptres

Tooltip

Sceptres are [One-Handed](/wiki/One-Handed "One-Handed") weapons that require [Strength](/wiki/Strength "Strength") and [Intelligence](/wiki/Intelligence "Intelligence") to equip. Sceptres can be equipped in your main hand or off hand, but you cannot [Dual Wield](/wiki/Dual_wielding "Dual wielding") two Sceptres.

Sceptres cannot be used to [Attack](/wiki/Attack "Attack") and do not grant bonuses to [Spellcasting](/wiki/Spell "Spell"). Instead, they grant additional [Spirit](/wiki/Spirit "Spirit") and can provide bonuses to your [Allies](/wiki/Allies "Allies").

**Sceptre** is an [item class](/wiki/Item_class "Item class") of one-handed [weapons](/wiki/Weapons "Weapons") that require [strength](/wiki/Strength "Strength") and [intelligence](/wiki/Intelligence "Intelligence") to equip. They have no local attack stats, and instead roll modifiers that affect [allies](/wiki/Allies "Allies"). Sceptres also grant base [spirit](/wiki/Spirit "Spirit") and can roll modifiers affecting spirit. Some Sceptres may grant [minion](/wiki/Minion "Minion") skills or roll modifiers more specific to minions.

A sceptre's level and strength/intelligence requirement is based on the level of its [granted skill](/wiki/Granted_skill "Granted skill") implicit.

## Mechanics

It is not possible to [dual wield](/wiki/Dual_wield "Dual wield") two sceptres. They can be equipped in either the main hand or off-hand, but not both.

* If equipped in the main hand, the off-hand slot can only be equipped with an [off hand](/wiki/Off_hand "Off hand") (a [shield](/wiki/Shield "Shield") or [focus](/wiki/Focus "Focus")), not another weapon.
* If equipped in the off-hand, the main hand can be any other one-handed weapon (or a [talisman](/wiki/Talisman "Talisman") if [Primal Hunger](/wiki/Primal_Hunger "Primal Hunger") is allocated). This does not count as dual-wielding.

## List of sceptres

Main article: [List of sceptres](/wiki/List_of_sceptres "List of sceptres")

| Item |  |  |  | Stats | Granted skills |
| --- | --- | --- | --- | --- | --- |
| [Rattling Sceptre](/wiki/Rattling_Sceptre "Rattling Sceptre") | 1 | 0 | 0 | — | Grants Skill: Level (1-20) [Skeletal Warrior Minion](/wiki/Skeletal_Warrior "Skeletal Warrior") |
| [Stoic Sceptre](/wiki/Stoic_Sceptre "Stoic Sceptre") | 6 | 0 | 0 | — | Grants Skill: Level (3-20) [Discipline](/wiki/Discipline "Discipline") |
| [Omen Sceptre](/wiki/Omen_Sceptre "Omen Sceptre") | 16 | 0 | 0 | — | Grants Skill: Level (5-20) [Malice](/wiki/Malice "Malice") |
| [Shrine Sceptre](/wiki/Shrine_Sceptre_(Cold) "Shrine Sceptre (Cold)") | 26 | 0 | 0 | — | Grants Skill: Level (7-20) [Purity of Ice](/wiki/Purity_of_Ice "Purity of Ice") |
| [Shrine Sceptre](/wiki/Shrine_Sceptre_(Fire) "Shrine Sceptre (Fire)") | 26 | 0 | 0 | — | Grants Skill: Level (7-20) [Purity of Fire](/wiki/Purity_of_Fire "Purity of Fire") |
| [Shrine Sceptre](/wiki/Shrine_Sceptre_(Lightning) "Shrine Sceptre (Lightning)") | 26 | 0 | 0 | — | Grants Skill: Level (7-20) [Purity of Lightning](/wiki/Purity_of_Lightning "Purity of Lightning") |
| [Wrath Sceptre](/wiki/Wrath_Sceptre "Wrath Sceptre") | 49 | 0 | 0 | — | Grants Skill: Level (12-20) [Fulmination](/wiki/Fulmination "Fulmination") |

## List of unique sceptres

Main article: [List of unique sceptres](/wiki/List_of_unique_sceptres "List of unique sceptres")

| Item |  |  |  | Stats | Granted skills |
| --- | --- | --- | --- | --- | --- |
| [The Dark Defiler](/wiki/The_Dark_Defiler "The Dark Defiler") | 1 | 0 | 0 | +(20-30) to maximum Mana +(5-10) to [Intelligence](/wiki/Intelligence "Intelligence") (10-30)% increased Mana Regeneration Rate [Gain](/wiki/Gain "Gain") 5% of Damage as [Chaos](/wiki/Chaos "Chaos") Damage per Undead [Minion](/wiki/Minion "Minion") | Grants Skill: Level (1-20) [Skeletal Warrior Minion](/wiki/Skeletal_Warrior "Skeletal Warrior") |
| [Font of Power](/wiki/Font_of_Power "Font of Power") | 16 | 0 | 0 | (30-50)% increased [Spirit](/wiki/Spirit "Spirit") +(40-60) to maximum Mana (20-30)% increased Mana Regeneration Rate When a Party Member in your [Presence](/wiki/Presence "Presence") Casts a [Spell](/wiki/Spell "Spell"), you [Sacrifice](/wiki/Sacrifice_(keyword) "Sacrifice (keyword)") 20% of Mana and they [Leech that Mana](/wiki/Mana_Leech "Mana Leech") | Grants Skill: Level (5-20) [Malice](/wiki/Malice "Malice") |
| [Guiding Palm of the Eye](/wiki/Guiding_Palm_of_the_Eye "Guiding Palm of the Eye") | 65 | 32 | 80 | [Gain](/wiki/Gain "Gain") 25% of Damage as Extra [Cold](/wiki/Cold "Cold") Damage [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") deal (15-23) to (28-35) added [Attack](/wiki/Attack "Attack") [Cold](/wiki/Cold "Cold") Damage 50% of your Base Life Regeneration is granted to [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") +(20-30) to [Intelligence](/wiki/Intelligence "Intelligence") 25% increased [Light Radius](/wiki/Light_Radius "Light Radius") Grants effect of [Guided Freezing Shrine](/wiki/Guided_Freezing_Shrine "Guided Freezing Shrine") | Grants Skill: Level (15-20) [Purity of Ice](/wiki/Purity_of_Ice "Purity of Ice") |
| [Guiding Palm of the Heart](/wiki/Guiding_Palm_of_the_Heart "Guiding Palm of the Heart") | 65 | 32 | 80 | [Gain](/wiki/Gain "Gain") 25% of Damage as Extra [Fire](/wiki/Fire "Fire") Damage [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") deal (15-23) to (28-35) added [Attack](/wiki/Attack "Attack") [Fire](/wiki/Fire "Fire") Damage 50% of your Base Life Regeneration is granted to [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") +(20-30) to [Strength](/wiki/Strength "Strength") 25% increased [Light Radius](/wiki/Light_Radius "Light Radius") Grants effect of [Guided Meteoric Shrine](/wiki/Guided_Meteoric_Shrine/edit?redlink=1 "Guided Meteoric Shrine (page does not exist)") | Grants Skill: Level (15-20) [Purity of Fire](/wiki/Purity_of_Fire "Purity of Fire") |
| [Guiding Palm of the Mind](/wiki/Guiding_Palm_of_the_Mind "Guiding Palm of the Mind") | 65 | 32 | 80 | [Gain](/wiki/Gain "Gain") 25% of Damage as Extra [Lightning](/wiki/Lightning "Lightning") Damage [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") deal 1 to (56-70) added [Attack](/wiki/Attack "Attack") [Lightning](/wiki/Lightning "Lightning") Damage 50% of your Base Life Regeneration is granted to [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") +(20-30) to [Dexterity](/wiki/Dexterity "Dexterity") 25% increased [Light Radius](/wiki/Light_Radius "Light Radius") Grants effect of [Guided Tempest Shrine](/wiki/Guided_Tempest_Shrine/edit?redlink=1 "Guided Tempest Shrine (page does not exist)") | Grants Skill: Level (15-20) [Purity of Lightning](/wiki/Purity_of_Lightning "Purity of Lightning") |
| [Palm of the Dreamer](/wiki/Palm_of_the_Dreamer "Palm of the Dreamer") | 65 | 32 | 80 | [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") deal (13-17) to (25-37) added [Attack](/wiki/Attack "Attack") [Chaos](/wiki/Chaos "Chaos") Damage +(7-13) to all [Attributes](/wiki/Attributes "Attributes") 23% reduced [Light Radius](/wiki/Light_Radius "Light Radius") (-13-13)% increased Skill Effect Duration [Gain](/wiki/Gain "Gain") 27% of Damage as Extra [Chaos](/wiki/Chaos "Chaos") Damage Grants effect of [Dreaming Gloom Shrine](/wiki/Dreaming_Gloom_Shrine/edit?redlink=1 "Dreaming Gloom Shrine (page does not exist)")*Corrupted* | Grants Skill: Level (15-20) [Impurity](/wiki/Impurity "Impurity") |
| [Sacred Flame](/wiki/Sacred_Flame "Sacred Flame") | 78 | 42 | 106 | [Gain](/wiki/Gain "Gain") (40-60)% of Damage as Extra [Fire](/wiki/Fire "Fire") Damage [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") [Gain](/wiki/Gain "Gain") (20-30)% of Damage as Extra Fire Damage [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") Regenerate (2-3)% of their Maximum Life per second Enemies in your [Presence](/wiki/Presence "Presence") Resist [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") based on their Lowest [Resistance](/wiki/Resistance "Resistance") | Grants Skill: Level (18-20) [Purity of Fire](/wiki/Purity_of_Fire "Purity of Fire") |
