# Dodge roll

**Dodge roll** is a [movement](/wiki/Movement "Movement") skill that is possessed by default on all [characters](/wiki/Character "Character"). It does not require a skill gem slot, and has a dedicated keybind `space` by default. Holding the dodge roll button will cause your character to [sprint](/wiki/Sprint "Sprint").

## Mechanics

* Dodge roll has no cooldown or cost by default.
* Dodge roll moves the player 3.7 metres in a direction.
* Dodge roll cannot be used to cross gaps or crossable terrain obstacles (e.g. small fences) or move between different elevations.
* Dodge roll reduces the player's character size to 0 units during the skill animation. This allows the user to roll through enemies if there is a small gap between them, but they can still get stuck if completely surrounded.
* Certain small monsters can get pushed away by the player while dodge rolling.
* The first half of the roll animation avoids damage (grants i-frames) from projectiles and non-AoE attacks, and can be used to cancel almost any animation except another roll.
* Rolling covers more initial distance but travels the same total distance as base [movement speed](/wiki/Movement_speed "Movement speed") (walking/running) over its entire duration. Roll speed is affected by movement speed. Compared to regular movement, it allows for quicker reactions against hazards but is not an overall speed boost.

:   * Modifiers to dodge roll distance (e.g. [Surefooted Sigil](/wiki/Surefooted_Sigil "Surefooted Sigil")) do not increase the time it takes to complete the dodge roll, but instead cause it to cover a larger distance in the same time. It is effectively a speed multiplier for dodge roll overall.

* Dodge roll's animation cannot be modified by [skill speed](/wiki/Skill_speed "Skill speed"). However, it is affected by [action speed](/wiki/Action_speed "Action speed").
* Dodge roll will forcibly cancel most skills. Skills stop spending mana or other costs if cancelled.
* Rolling while [shapeshifted](/wiki/Shapeshift "Shapeshift") will usually morph you out of the transformation, though this can be negated in some cases. Dodge roll does not revert shapeshift in [towns](/wiki/Town "Town").
  + [Demon Form](/wiki/Demon_Form "Demon Form") does not get reverted; instead, it replaces dodge roll with a dash.

### Modifying dodge roll

Certain skills and passives can modify Dodge roll or change its functions entirely.

* The [Bulwark](/wiki/Bulwark "Bulwark") keystone removes the damage avoidance granted during a dodge roll, but grants consistent [damage reduction](/wiki/Damage_reduction "Damage reduction") while dodge rolling.
* The [Unwavering Stance](/wiki/Unwavering_Stance "Unwavering Stance") [keystone](/wiki/Keystone "Keystone") disables dodge roll entirely, but grants immunity to [light stun](/wiki/Light_stun "Light stun").
* [Blink](/wiki/Blink "Blink") is a [persistent](/wiki/Persistent "Persistent") [buff](/wiki/Buff "Buff") skill that changes your dodge roll into a teleport spell with a cooldown and no longer count as dodge roll.
* The [Future-Past](/wiki/Future-Past "Future-Past") buff skill from [Hinekora's Sight](/wiki/Hinekora%27s_Sight "Hinekora's Sight") prevents dodge roll from avoiding damage while you have Foresight, but getting hit while dodge rolling with Foresight will restore your [life](/wiki/Life "Life") to full and briefly prevent death afterwards.

## Related skill gems

| Gem | Tier |
| --- | --- |
| [Blink](/wiki/Blink "Blink") | *8* |
| [Cast on Dodge](/wiki/Cast_on_Dodge "Cast on Dodge") | *14* |
| [Lingering Illusion](/wiki/Lingering_Illusion "Lingering Illusion") | *8* |
| [Trail of Caltrops](/wiki/Trail_of_Caltrops "Trail of Caltrops") | *8* |
| [Mirage Archer](/wiki/Mirage_Archer "Mirage Archer") | *8* |
| [Void Illusion](/wiki/Void_Illusion "Void Illusion") | *0* |
| [Future-Past](/wiki/Future-Past "Future-Past") | *0* |
| [Blink](/wiki/Blink_(Sands_of_Silk) "Blink (Sands of Silk)") | *0* |
| [Black Powder Blitz](/wiki/Black_Powder_Blitz "Black Powder Blitz") | *0* |

## Related unique items

These unique items have effects related to Dodge Roll:

| Item | Base item |  | Stats |
| --- | --- | --- | --- |
| [Surefooted Sigil](/wiki/Surefooted_Sigil "Surefooted Sigil") | [Jade Amulet](/wiki/Jade_Amulet "Jade Amulet") | 8 | +(10-15) to [Dexterity](/wiki/Dexterity "Dexterity")+(40-60) to maximum Life +(5-15) to [Dexterity](/wiki/Dexterity "Dexterity") +1 metre to Dodge Roll distance 50% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") if you've Dodge Rolled [Recently](/wiki/Recently "Recently") |
| [Ghostmarch](/wiki/Ghostmarch "Ghostmarch") | [Threaded Shoes](/wiki/Threaded_Shoes "Threaded Shoes") | 16 | (100-150)% increased [Evasion](/wiki/Evasion "Evasion") and [Energy Shield](/wiki/Energy_Shield "Energy Shield") +(30-50) to maximum Mana +(17-23)% to [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance") Dodge Roll passes through Enemies 15% increased Movement Speed |
| [Ab Aeterno](/wiki/Ab_Aeterno "Ab Aeterno") | [Grand Cuisses](/wiki/Grand_Cuisses "Grand Cuisses") | 65 | (15-30)% increased Movement Speed (100-150)% increased [Armour](/wiki/Armour "Armour"), [Evasion](/wiki/Evasion "Evasion") and [Energy Shield](/wiki/Energy_Shield "Energy Shield") Dodge Roll avoids all [Hits](/wiki/Hit "Hit") 10% less Movement and [Skill Speed](/wiki/Skill_Speed "Skill Speed") per Dodge Roll in the past 20 seconds |
| [Lioneye's Glare](/wiki/Lioneye%27s_Glare "Lioneye's Glare") | [Heavy Bow](/wiki/Heavy_Bow "Heavy Bow") | 65 | (150-240)% increased [Physical](/wiki/Physical "Physical") Damage +(300-500) to [Accuracy](/wiki/Accuracy "Accuracy") Rating 10% increased [Attack](/wiki/Attack "Attack") Speed +(20-30) to [Dexterity](/wiki/Dexterity "Dexterity") +2 metres to Dodge Roll distance if you haven't Dodge Rolled [Recently](/wiki/Recently "Recently") -1 metre to Dodge Roll distance if you've Dodge Rolled [Recently](/wiki/Recently "Recently") Barrageable [Attacks](/wiki/Attack "Attack") with this Bow [Repeat](/wiki/Repeat "Repeat") +2 times if no enemies are in your [Presence](/wiki/Presence "Presence") |

## Related passive skills

The following [passive skills](/wiki/Passive_skill "Passive skill") are related to dodge roll:

| Name | Stats |
| --- | --- |
| [Catlike Agility](/wiki/Catlike_Agility "Catlike Agility") | 25% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") 40% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") if you've Dodge Rolled [Recently](/wiki/Recently "Recently") 3% reduced Movement Speed Penalty from using Skills while moving [[1]](/wiki/Passive_Skill:Evasion39 "Passive Skill:Evasion39") |
| [Slippery Ice](/wiki/Slippery_Ice/edit?redlink=1 "Slippery Ice (page does not exist)") | 25% reduced Effect of [Chill](/wiki/Chill "Chill") on you [Unaffected](/wiki/Unaffected "Unaffected") by [Chill](/wiki/Chill "Chill") during Dodge Roll [[1]](/wiki/Passive_Skill:Freeze~and~chill~mitigation10 "Passive Skill:Freeze~and~chill~mitigation10") |
| [Tactical Retreat](/wiki/Tactical_Retreat/edit?redlink=1 "Tactical Retreat (page does not exist)") | 10% increased Movement Speed while [Surrounded](/wiki/Surrounded "Surrounded") +0.5 metres to Dodge Roll distance while [Surrounded](/wiki/Surrounded "Surrounded") [[1]](/wiki/Passive_Skill:Being~surrounded21 "Passive Skill:Being~surrounded21") |

### Ascendancy passive skills

The following [Ascendancy passive skills](/wiki/Ascendancy_passive_skill "Ascendancy passive skill") are related to dodge roll:

| Ascendancy Class | Name | Stats |
| --- | --- | --- |
| [Acolyte of Chayula](/wiki/Acolyte_of_Chayula "Acolyte of Chayula") | [Grasp of the Void](/wiki/Grasp_of_the_Void "Grasp of the Void") | Grants Skill: [Void Illusion](/wiki/Void_Illusion "Void Illusion") [[1]](/wiki/Passive_Skill:AscendancyMonk3Notable8 "Passive Skill:AscendancyMonk3Notable8") |

### Keystones

The following [Keystones](/wiki/Keystone "Keystone") are related to dodge roll:

| Name | Stats |
| --- | --- |
| [Bulwark](/wiki/Bulwark "Bulwark") | Dodge Roll cannot Avoid Damage Take 30% less [Damage from Hits](/wiki/Hit "Hit") while Dodge Rolling [[1]](/wiki/Passive_Skill:Passive~keystone~bulwark "Passive Skill:Passive~keystone~bulwark") |
| [Unwavering Stance](/wiki/Unwavering_Stance "Unwavering Stance") | Cannot be [Light Stunned](/wiki/Light_Stun "Light Stun") Cannot Dodge Roll or Sprint [[1]](/wiki/Passive_Skill:Passive~keystone~unwavering~stance~ "Passive Skill:Passive~keystone~unwavering~stance~") |
