# Damage type

Damage Types

Tooltip

The damage types are [Physical](/wiki/Physical "Physical"), [Fire](/wiki/Fire_Damage "Fire Damage"), [Cold](/wiki/Cold_Damage "Cold Damage"), [Lightning](/wiki/Lightning_Damage "Lightning Damage") and [Chaos](/wiki/Chaos_Damage "Chaos Damage").

**Damage types** refer to one of the five types of damage dealt by skills:

* [Fire](/wiki/Fire "Fire")
* [Cold](/wiki/Cold "Cold")
* [Lightning](/wiki/Lightning "Lightning")
* [Physical](/wiki/Physical "Physical")
* [Chaos](/wiki/Chaos "Chaos")

Fire, Cold, and Lightning are collectively referred to as [elemental damage](/wiki/Elemental_damage "Elemental damage").

See also:

* [Conversion](/wiki/Conversion "Conversion")
* [Damage taken as](/wiki/Damage_taken_as "Damage taken as")/[Damage shift](/wiki/Damage_shift/edit?redlink=1 "Damage shift (page does not exist)")
