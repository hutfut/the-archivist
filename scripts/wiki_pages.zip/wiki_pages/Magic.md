# Magic

Redirect to:

* [Rarity#Magic](/wiki/Rarity#Magic "Rarity")
