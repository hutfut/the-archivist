# Trigger

Triggered Skills

Tooltip

Many effects can cause a Skill to Trigger. A Triggered Skill occurs immediately, without an attack or cast time, and usually targets the cause of the trigger. Triggering a Skill does not count as using it.

If multiple methods of Triggering a skill attempt to apply to the same skill, that skill will be disabled.

**Trigger** is a [skill](/wiki/Skill "Skill") behavior that causes a skill's effect to occur during certain conditions, instantly without the need of manually casting socketed skills.

Triggers may come from the skill itself, unleashing a secondary skill if its conditions are satisfied, or they can be triggered by the [meta](/wiki/Meta "Meta") skill they are socketed into, if it has enough [energy](/wiki/Energy "Energy").

## Related skills

A list of [skills](/wiki/Skill "Skill") with the Trigger [gem tag](/wiki/Gem_tag "Gem tag"):

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [His Winnowing Flame](/wiki/His_Winnowing_Flame "His Winnowing Flame") | *0* |  |  |  |
| [Lightning Bolt](/wiki/Lightning_Bolt_(Choir_of_the_Storm) "Lightning Bolt (Choir of the Storm)") | *0* |  |  |  |
| [Spark](/wiki/Spark_(Earthbound) "Spark (Earthbound)") | *0* |  |  |  |
| [Abyssal Apparition](/wiki/Abyssal_Apparition "Abyssal Apparition") | *0* |  |  |  |
| [Ancestral Spirits](/wiki/Ancestral_Spirits "Ancestral Spirits") | *0* |  |  |  |
| [Apocalypse](/wiki/Apocalypse "Apocalypse") | *0* |  |  |  |
| [Bursting Fen Toad](/wiki/Bursting_Fen_Toad "Bursting Fen Toad") | *0* |  |  |  |
| [Chaotic Surge](/wiki/Chaotic_Surge "Chaotic Surge") | *0* |  |  |  |
| [Elemental Expression](/wiki/Elemental_Expression "Elemental Expression") | *0* |  |  |  |
| [Elemental Storm](/wiki/Elemental_Storm "Elemental Storm") | *0* |  |  |  |
| [Elemental Surge](/wiki/Elemental_Surge "Elemental Surge") | *0* |  |  |  |
| [Gemini Surge](/wiki/Gemini_Surge "Gemini Surge") | *0* |  |  |  |
| [Shred](/wiki/Shred "Shred") | *0* |  |  |  |
| [Temper Weapon](/wiki/Temper_Weapon "Temper Weapon") | *0* |  |  |  |
| [Valako's Charge](/wiki/Valako%27s_Charge "Valako's Charge") | *0* |  |  |  |
| [Escape Shot](/wiki/Escape_Shot "Escape Shot") | *1* |  |  |  |
| [Pounce](/wiki/Pounce "Pounce") | *3* |  |  |  |
| [Infernal Cry](/wiki/Infernal_Cry "Infernal Cry") | *3* |  |  |  |
| [Ice-Tipped Arrows](/wiki/Ice-Tipped_Arrows "Ice-Tipped Arrows") | *5* |  |  |  |
| [Bloodhound's Mark](/wiki/Bloodhound%27s_Mark "Bloodhound's Mark") | *9* |  |  |  |
| [Fortifying Cry](/wiki/Fortifying_Cry "Fortifying Cry") | *9* |  |  |  |
| [Shattering Palm](/wiki/Shattering_Palm "Shattering Palm") | *11* |  |  |  |
| [Lunar Blessing](/wiki/Lunar_Blessing "Lunar Blessing") | *13* |  |  |  |
| [Walking Calamity](/wiki/Walking_Calamity "Walking Calamity") | *13* |  |  |  |
| [Ancestral Cry](/wiki/Ancestral_Cry "Ancestral Cry") | *13* |  |  |  |

### Persistent skills

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Spellslinger](/wiki/Spellslinger "Spellslinger") | *0* |  |  |  |
| [Cast on Block](/wiki/Cast_on_Block "Cast on Block") | *0* |  |  |  |
| [Cast on Charm Use](/wiki/Cast_on_Charm_Use "Cast on Charm Use") | *0* |  |  |  |
| [Fire Spell on Hit](/wiki/Fire_Spell_on_Hit "Fire Spell on Hit") | *0* |  |  |  |
| [Mirage Deadeye](/wiki/Mirage_Deadeye "Mirage Deadeye") | *0* |  |  |  |
| [Thundergod's Wrath](/wiki/Thundergod%27s_Wrath "Thundergod's Wrath") | *0* |  |  |  |
| [Void Illusion](/wiki/Void_Illusion "Void Illusion") | *0* |  |  |  |
| [Wind Dancer](/wiki/Wind_Dancer "Wind Dancer") | *4* |  |  |  |
| [Magma Barrier](/wiki/Magma_Barrier "Magma Barrier") | *4* |  |  |  |
| [Mirage Archer](/wiki/Mirage_Archer "Mirage Archer") | *8* |  |  |  |
| [Trail of Caltrops](/wiki/Trail_of_Caltrops "Trail of Caltrops") | *8* |  |  |  |
| [Cast on Minion Death](/wiki/Cast_on_Minion_Death "Cast on Minion Death") | *8* |  |  |  |
| [Barrier Invocation](/wiki/Barrier_Invocation "Barrier Invocation") | *8* |  |  |  |
| [Elemental Invocation](/wiki/Elemental_Invocation "Elemental Invocation") | *8* |  |  |  |
| [Cast on Critical](/wiki/Cast_on_Critical "Cast on Critical") | *14* |  |  |  |
| [Cast on Elemental Ailment](/wiki/Cast_on_Elemental_Ailment "Cast on Elemental Ailment") | *14* |  |  |  |
| [Cast on Dodge](/wiki/Cast_on_Dodge "Cast on Dodge") | *14* |  |  |  |
| [Reaper's Invocation](/wiki/Reaper%27s_Invocation "Reaper's Invocation") | *14* |  |  |  |

## Related support gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Doedre's Undoing](/wiki/Doedre%27s_Undoing "Doedre's Undoing") | *0* |  |  |  |
| [Hayoxi's Fulmination](/wiki/Hayoxi%27s_Fulmination "Hayoxi's Fulmination") | *0* |  |  |  |
| [Ixchel's Torment](/wiki/Ixchel%27s_Torment "Ixchel's Torment") | *0* |  |  |  |
| [Xibaqua's Rending](/wiki/Xibaqua%27s_Rending "Xibaqua's Rending") | *0* |  |  |  |
| [Tawhoa's Tending](/wiki/Tawhoa%27s_Tending "Tawhoa's Tending") | *0* |  |  |  |
| [Coursing Current](/wiki/Coursing_Current "Coursing Current") | *1* |  |  |  |
| [Creeping Chill](/wiki/Creeping_Chill "Creeping Chill") | *1* |  |  |  |
| [Impending Doom](/wiki/Impending_Doom "Impending Doom") | *1* |  |  |  |
| [Armour Explosion](/wiki/Armour_Explosion "Armour Explosion") | *1* |  |  |  |
| [Battershout](/wiki/Battershout "Battershout") | *1* |  |  |  |
| [Stomping Ground](/wiki/Stomping_Ground "Stomping Ground") | *1* |  |  |  |
| [Bursting Plague](/wiki/Bursting_Plague "Bursting Plague") | *2* |  |  |  |
| [Frozen Spite](/wiki/Frozen_Spite "Frozen Spite") | *2* |  |  |  |
| [Accelerated Growth I](/wiki/Accelerated_Growth_I "Accelerated Growth I") | *2* |  |  |  |
| [Bone Shrapnel](/wiki/Bone_Shrapnel "Bone Shrapnel") | *2* |  |  |  |
| [Fiery Death](/wiki/Fiery_Death "Fiery Death") | *2* |  |  |  |
| [Living Lightning I](/wiki/Living_Lightning_I "Living Lightning I") | *2* |  |  |  |
| [Mana Flare](/wiki/Mana_Flare "Mana Flare") | *2* |  |  |  |
| [Crater](/wiki/Crater "Crater") | *2* |  |  |  |
| [Fan The Flames I](/wiki/Fan_The_Flames_I "Fan The Flames I") | *2* |  |  |  |
| [Skittering Stone I](/wiki/Skittering_Stone_I "Skittering Stone I") | *2* |  |  |  |
| [Volcanic Eruption](/wiki/Volcanic_Eruption "Volcanic Eruption") | *2* |  |  |  |
| [Caltrops](/wiki/Caltrops "Caltrops") | *3* |  |  |  |
| [Poison Spores](/wiki/Poison_Spores "Poison Spores") | *3* |  |  |  |
| [Electromagnetism](/wiki/Electromagnetism "Electromagnetism") | *3* |  |  |  |
| [Elemental Discharge](/wiki/Elemental_Discharge "Elemental Discharge") | *3* |  |  |  |
| [Energy Retention](/wiki/Energy_Retention "Energy Retention") | *3* |  |  |  |
| [Fluke](/wiki/Fluke "Fluke") | *3* |  |  |  |
| [Static Shocks](/wiki/Static_Shocks "Static Shocks") | *3* |  |  |  |
| [Deadly Resolve](/wiki/Deadly_Resolve "Deadly Resolve") | *3* |  |  |  |
| [Haemocrystals](/wiki/Haemocrystals "Haemocrystals") | *3* |  |  |  |
| [Quill Burst](/wiki/Quill_Burst "Quill Burst") | *3* |  |  |  |
| [Burning Inscription](/wiki/Burning_Inscription "Burning Inscription") | *4* |  |  |  |
| [Living Lightning II](/wiki/Living_Lightning_II "Living Lightning II") | *4* |  |  |  |
| [Fan The Flames II](/wiki/Fan_The_Flames_II "Fan The Flames II") | *4* |  |  |  |
| [Skittering Stone II](/wiki/Skittering_Stone_II "Skittering Stone II") | *4* |  |  |  |
| [Charged Mark](/wiki/Charged_Mark "Charged Mark") | *5* |  |  |  |
| [Accelerated Growth II](/wiki/Accelerated_Growth_II "Accelerated Growth II") | *5* |  |  |  |
| [Catalysing Elements](/wiki/Catalysing_Elements "Catalysing Elements") | *5* |  |  |  |
| [Brambleslam](/wiki/Brambleslam "Brambleslam") | *5* |  |  |  |

## Related unique items

| Item | Base item | Item class |  | Stats |
| --- | --- | --- | --- | --- |
| [Dusk Vigil](/wiki/Dusk_Vigil "Dusk Vigil") | [Ashen Staff](/wiki/Ashen_Staff "Ashen Staff") | *[Staff](/wiki/Staff "Staff")* | 1 | [Gain](/wiki/Gain "Gain") (30-50)% of Damage as Extra [Fire](/wiki/Fire "Fire") Damage (80-120)% increased [Spell](/wiki/Spell "Spell") Damage Gain (5-10) Life per enemy killed 25% increased Mana Regeneration Rate Trigger Ember Fusillade Skill on casting a [Spell](/wiki/Spell "Spell") |
| [Earthbound](/wiki/Earthbound "Earthbound") | [Voltaic Staff](/wiki/Voltaic_Staff "Voltaic Staff") | *[Staff](/wiki/Staff "Staff")* | 1 | (80-120)% increased [Spell](/wiki/Spell "Spell") Damage (10-20)% increased Cast Speed (20-30)% increased Mana Regeneration Rate Trigger Spark Skill on killing a [Shocked](/wiki/Shock "Shock") Enemy (20-40)% increased chance to [Shock](/wiki/Shock "Shock") |
| [Grip of Kulemak](/wiki/Grip_of_Kulemak "Grip of Kulemak") | [Abyssal Signet](/wiki/Abyssal_Signet "Abyssal Signet") | *[Ring](/wiki/Ring "Ring")* | 1 | Inflict [Abyssal Wasting](/wiki/Abyssal_Wasting/edit?redlink=1 "Abyssal Wasting (page does not exist)") on [Hit](/wiki/Hit "Hit")(30-20)% reduced [Presence](/wiki/Presence "Presence") Area of Effect (30-20)% reduced [Light Radius](/wiki/Light_Radius "Light Radius")   | <Can gain 0-4 custom [Desecrated Modifiers](/wiki/Desecrated_Modifier "Desecrated Modifier")> (Hidden) | | --- | | (60-100)% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Abyssal Wasting](/wiki/Abyssal_Wasting/edit?redlink=1 "Abyssal Wasting (page does not exist)") you inflict  ---  [Abyssal Wasting](/wiki/Abyssal_Wasting/edit?redlink=1 "Abyssal Wasting (page does not exist)") you inflict has Infinite Duration  ---  [Abyssal Wasting](/wiki/Abyssal_Wasting/edit?redlink=1 "Abyssal Wasting (page does not exist)") also applies -(8-6)% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance")  ---  +(20-30)% of [Armour](/wiki/Armour "Armour") also applies to [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage")  ---  [Gain](/wiki/Gain "Gain") (8-12)% of Damage as Extra [Fire](/wiki/Fire "Fire") Damage  ---  (20-10)% faster [Curse](/wiki/Curse "Curse") Activation  ---  +(20-25) to [Spirit](/wiki/Spirit "Spirit") while you have at least 200 [Strength](/wiki/Strength "Strength")  ---  (20-30)% increased [Ignite](/wiki/Ignite "Ignite") [Magnitude](/wiki/Magnitude "Magnitude")  ---  (30-40)% increased [Armour](/wiki/Armour "Armour")  ---  (15-25)% increased Area of Effect of [Curses](/wiki/Curse "Curse")  ---  [Debuffs](/wiki/Debuff "Debuff") you inflict have (12-20)% increased [Slow Magnitude](/wiki/Slow_Magnitude_Modifier/edit?redlink=1 "Slow Magnitude Modifier (page does not exist)")  ---  (6-10)% increased [Spirit](/wiki/Spirit "Spirit")  ---  (4-6)% increased [Strength](/wiki/Strength "Strength")  ---  +1 to Maximum [Endurance Charges](/wiki/Endurance_Charge "Endurance Charge")  ---  Hits against you have (20-30)% reduced [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus")  ---  (20-10)% reduced [Slowing](/wiki/Slow "Slow") Potency of [Debuffs](/wiki/Debuff "Debuff") on You  ---  (10-16)% increased Skill Effect Duration  ---  (6-10)% increased [Spirit](/wiki/Spirit "Spirit") [Reservation](/wiki/Reservation "Reservation") [Efficiency](/wiki/Efficiency "Efficiency") of Skills  ---  (30-50)% increased [Thorns](/wiki/Thorns "Thorns") damage if you've consumed an [Endurance Charge](/wiki/Endurance_Charge "Endurance Charge") [Recently](/wiki/Recently "Recently")  ---  You and [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") have +(17-23)% to [Chaos](/wiki/Chaos "Chaos") Resistance  ---  You and [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") have (10-14)% increased [Cooldown Recovery Rate](/wiki/Cooldown_Recovery_Rate "Cooldown Recovery Rate")  ---  (30-40)% increased [Accuracy](/wiki/Accuracy "Accuracy") Rating against Enemies affected by [Abyssal Wasting](/wiki/Abyssal_Wasting/edit?redlink=1 "Abyssal Wasting (page does not exist)")  ---  (20-30)% of Mana [Leeched](/wiki/Leech "Leech") from targets affected by [Abyssal Wasting](/wiki/Abyssal_Wasting/edit?redlink=1 "Abyssal Wasting (page does not exist)") is Instant  ---  [Abyssal Wasting](/wiki/Abyssal_Wasting/edit?redlink=1 "Abyssal Wasting (page does not exist)") also applies -(8-6)% to [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance")  ---  (20-30)% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Chill](/wiki/Chill "Chill") you inflict  ---  (25-40)% increased [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance  ---  [Gain](/wiki/Gain "Gain") (8-12)% of Damage as Extra [Cold](/wiki/Cold "Cold") Damage  ---  (10-14)% of Damage is taken from Mana before Life  ---  Recover (3-5)% of your maximum Mana when an Enemy dies in your [Presence](/wiki/Presence "Presence")  ---  (15-25)% [faster start of Energy Shield Recharge](/wiki/Energy_Shield "Energy Shield")  ---  +(20-25) to [Spirit](/wiki/Spirit "Spirit") while you have at least 200 [Intelligence](/wiki/Intelligence "Intelligence")  ---  Gain [Arcane Surge](/wiki/Arcane_Surge "Arcane Surge") when a [Minion](/wiki/Minion "Minion") Dies  ---  (30-40)% increased maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield")  ---  (4-6)% increased [Intelligence](/wiki/Intelligence "Intelligence")  ---  [Spell](/wiki/Spell "Spell") Skills have (9-18)% increased Area of Effect  ---  (40-60)% increased Mana Regeneration Rate while [Surrounded](/wiki/Surrounded "Surrounded")  ---  (5-10)% increased maximum Mana  ---  +1 to Maximum [Power Charges](/wiki/Power_Charge "Power Charge")  ---  [Meta](/wiki/Meta "Meta") Skills gain (10-16)% increased [Energy](/wiki/Energy "Energy")  ---  2% increased Cast Speed per 20 [Spirit](/wiki/Spirit "Spirit")  ---  (10-20)% increased Cost [Efficiency](/wiki/Efficiency "Efficiency") of Skills if you've consumed a [Power Charge](/wiki/Power_Charge "Power Charge") [Recently](/wiki/Recently "Recently")  ---  Triggered [Spells](/wiki/Spell "Spell") deal (25-40)% increased [Spell](/wiki/Spell "Spell") Damage  ---  You and [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") have (11-16)% increased Cast Speed  ---  (30-40)% increased chance to inflict [Ailments](/wiki/Ailments "Ailments") against Enemies affected by [Abyssal Wasting](/wiki/Abyssal_Wasting/edit?redlink=1 "Abyssal Wasting (page does not exist)")  ---  (20-30)% of Life [Leeched](/wiki/Leech "Leech") from targets affected by [Abyssal Wasting](/wiki/Abyssal_Wasting/edit?redlink=1 "Abyssal Wasting (page does not exist)") is Instant  ---  [Abyssal Wasting](/wiki/Abyssal_Wasting/edit?redlink=1 "Abyssal Wasting (page does not exist)") also applies -(8-6)% to [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance")  ---  Projectiles have (40-50)% chance for an additional Projectile when [Forking](/wiki/Fork "Fork")  ---  (15-25)% increased [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus")  ---  [Gain](/wiki/Gain "Gain") (8-12)% of Damage as Extra [Lightning](/wiki/Lightning "Lightning") Damage  ---  Recover (2-3)% of your maximum Life when an Enemy dies in your [Presence](/wiki/Presence "Presence")  ---  Gain [Deflection Rating](/wiki/Deflect "Deflect") equal to (10-20)% of [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating")  ---  +(20-25) to [Spirit](/wiki/Spirit "Spirit") while you have at least 200 [Dexterity](/wiki/Dexterity "Dexterity")  ---  Gain [Onslaught](/wiki/Onslaught "Onslaught") for 4 seconds when a [Minion](/wiki/Minion "Minion") Dies  ---  (9-18)% increased Area of Effect for [Attacks](/wiki/Attack "Attack")  ---  (4-6)% increased [Dexterity](/wiki/Dexterity "Dexterity")  ---  (30-40)% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating")  ---  (20-30)% increased amount of Life [Leeched](/wiki/Leech "Leech") if you've consumed a [Frenzy Charge](/wiki/Frenzy_Charge "Frenzy Charge") [Recently](/wiki/Recently "Recently")  ---  (30-40)% increased Life Regeneration rate while [Surrounded](/wiki/Surrounded "Surrounded")  ---  +1 to Maximum [Frenzy Charges](/wiki/Frenzy_Charge "Frenzy Charge")  ---  (5-10)% increased maximum Life  ---  1% increased [Attack](/wiki/Attack "Attack") Speed per 20 [Spirit](/wiki/Spirit "Spirit")  ---  [Projectiles](/wiki/Projectile "Projectile") have (10-16)% chance to [Chain](/wiki/Chain "Chain") an additional time from terrain  ---  (15-25)% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Shock](/wiki/Shock "Shock") you inflict  ---  You and [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") have (20-28)% increased [Accuracy](/wiki/Accuracy "Accuracy") Rating  ---  You and [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") have (7-12)% increased [Attack](/wiki/Attack "Attack") Speed | |
| [Heart of the Well](/wiki/Heart_of_the_Well "Heart of the Well") | [Diamond](/wiki/Diamond "Diamond") | *[Jewel](/wiki/Jewel "Jewel")* | 1 | <Custom Desecrated prefix> <Custom Desecrated prefix> <Custom Desecrated suffix> <Custom Desecrated suffix>   | <List of mods> | | --- | | (5-10)% chance to [Aggravate](/wiki/Aggravate "Aggravate") [Bleeding](/wiki/Bleeding "Bleeding") on targets you [Hit](/wiki/Hit "Hit") with [Attacks](/wiki/Attack "Attack")  ---  (5-8)% increased [Attack](/wiki/Attack "Attack") Speed while a [Rare or Unique](/wiki/Rarity "Rarity") Enemy is in your [Presence](/wiki/Presence "Presence")  ---  (40-60)% increased [Armour](/wiki/Armour "Armour") from Equipped Body Armour  ---  (30-50)% chance to [Pierce](/wiki/Pierce "Pierce") an Enemy  ---  (10-15)% chance when a [Charm](/wiki/Charm "Charm") is used to use another Charm without consuming Charges  ---  [Charms](/wiki/Charm "Charm") applied to you have (15-25)% increased Effect  ---  Recover (5-10)% of maximum Mana when a [Charm](/wiki/Charm "Charm") is used  ---  (15-25)% increased [Culling Strike](/wiki/Culling_Strike "Culling Strike") Threshold  ---  [Gain](/wiki/Gain "Gain") (9-15)% of Damage as Extra [Lightning](/wiki/Lightning "Lightning") Damage  ---  [Gain](/wiki/Gain "Gain") (7-13)% of Damage as Extra [Chaos](/wiki/Chaos "Chaos") Damage  ---  [Gain](/wiki/Gain "Gain") (9-15)% of Damage as Extra [Fire](/wiki/Fire "Fire") Damage  ---  [Gain](/wiki/Gain "Gain") (9-15)% of Damage as Extra [Cold](/wiki/Cold "Cold") Damage  ---  (15-25)% increased Damage while your [Companion](/wiki/Companion "Companion") is in your [Presence](/wiki/Presence "Presence")  ---  (15-25)% increased [Exposure](/wiki/Exposure "Exposure") Effect  ---  (40-60)% increased [Evasion](/wiki/Evasion "Evasion") Rating from Equipped Body Armour  ---  Regenerate (1-1.5)% of maximum Life per Second if you've used a Life [Flask](/wiki/Flask "Flask") in the past 10 seconds  ---  (10-18)% increased [Cooldown Recovery Rate](/wiki/Cooldown_Recovery_Rate "Cooldown Recovery Rate")  ---  (40-60)% increased [Ice Crystal](/wiki/Ice_Crystal "Ice Crystal") Life  ---  (4-8)% increased [Skill Speed](/wiki/Skill_Speed "Skill Speed")  ---  (15-25)% chance for [Lightning](/wiki/Lightning "Lightning") Damage with [Hits](/wiki/Hit "Hit") to be [Lucky](/wiki/Lucky "Lucky")  ---  (8-16)% increased Mana Cost [Efficiency](/wiki/Efficiency "Efficiency")  ---  (20-30)% increased Mana Regeneration Rate while moving  ---  +1% to all [Maximum Elemental Resistances](/wiki/Maximum_Resistance "Maximum Resistance")  ---  (40-60)% increased [Energy Shield](/wiki/Energy_Shield "Energy Shield") from Equipped Body Armour  ---  [Minions](/wiki/Minion "Minion") gain (10-15)% of their maximum Life as Extra maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield")  ---  [Minions](/wiki/Minion "Minion") Regenerate (1-3)% of maximum Life per second  ---  [Minions](/wiki/Minion "Minion") [Revive](/wiki/Reviving_Minions "Reviving Minions") (5-10)% faster  ---  (8-15)% of Leech is Instant  ---  (5-10)% of Physical Damage prevented [Recouped](/wiki/Recoup "Recoup") as Life  ---  (8-14)% increased speed of [Recoup](/wiki/Recoup "Recoup") Effects  ---  Recover (2-4)% of maximum Life on Killing a [Poisoned](/wiki/Poison "Poison") Enemy  ---  (10-15)% increased Skill Effect Duration  ---  +(2-4)% to Thorns [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance  ---  Gain [Physical](/wiki/Physical "Physical") [Thorns](/wiki/Thorns "Thorns") damage equal to (4-6)% of [Item Armour](/wiki/Defences "Defences") on [Equipped](/wiki/Equipped/edit?redlink=1 "Equipped (page does not exist)") Body Armour  ---  (6-12)% chance for Trigger skills to refund half of [Energy](/wiki/Energy "Energy") Spent  ---  (4-8)% increased chance to inflict [Ailments](/wiki/Ailments "Ailments")  ---  Gain additional [Ailment Threshold](/wiki/Ailment_Threshold "Ailment Threshold") equal to (4-10)% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield")  ---  (5-10)% chance to inflict [Bleeding](/wiki/Bleeding "Bleeding") on [Hit](/wiki/Hit "Hit")  ---  (5-10)% chance to [Poison](/wiki/Poison "Poison") on [Hit](/wiki/Hit "Hit")  ---  (4-8)% increased [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance  ---  (6-12)% increased [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus")  ---  (2-3)% of Damage is taken from Mana before Life  ---  [Debuffs](/wiki/Debuff "Debuff") on you expire (4-8)% faster  ---  [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") deal damage (2-4)% faster  ---  (4-8)% increased [Flask](/wiki/Flask "Flask") Effect Duration  ---  Gain (1-2) [Rage](/wiki/Rage "Rage") when [Hit](/wiki/Hit "Hit") by an Enemy  ---  (2-3)% increased [Cooldown Recovery Rate](/wiki/Cooldown_Recovery_Rate "Cooldown Recovery Rate")  ---  (6-12)% increased [Elemental Ailment Threshold](/wiki/Ailment "Ailment")  ---  (2-3)% increased [Attack](/wiki/Attack "Attack") Speed  ---  (2-3)% increased Cast Speed  ---  (4-8)% increased [Flask](/wiki/Flask "Flask") Charges gained  ---  (5-10)% increased [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold")  ---  (2-3)% of Skill Mana Costs [Converted](/wiki/Stat_conversion "Stat conversion") to Life Costs  ---  (2-3)% of Damage taken [Recouped](/wiki/Recoup "Recoup") as Life  ---  (6-12)% increased Life Regeneration rate  ---  Recover (1-2)% of maximum Mana on Kill  ---  (4-8)% increased Mana Regeneration Rate  ---  +1% to [Maximum Cold Resistance](/wiki/Maximum_Cold_Resistance "Maximum Cold Resistance")  ---  +1% to [Maximum Fire Resistance](/wiki/Maximum_Fire_Resistance "Maximum Fire Resistance")  ---  Recover (1-2)% of maximum Life on Kill  ---  +1% to [Maximum Lightning Resistance](/wiki/Maximum_Lightning_Resistance "Maximum Lightning Resistance")  ---  [Minions](/wiki/Minion "Minion") have (2-3)% increased [Attack](/wiki/Attack "Attack") and Cast Speed  ---  [Minions](/wiki/Minion "Minion") have (6-12)% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance")  ---  [Minions](/wiki/Minion "Minion") have +(3-4)% to all Elemental [Resistances](/wiki/Resistances "Resistances")  ---  [Minions](/wiki/Minion "Minion") have (3-12)% additional [Physical](/wiki/Physical "Physical") Damage Reduction  ---  (1-2)% increased Movement Speed  ---  Gain 1 [Rage](/wiki/Rage "Rage") on [Melee](/wiki/Melee "Melee") [Hit](/wiki/Hit "Hit")  ---  (3-8)% increased Skill Effect Duration  ---  (10-5)% reduced [Slowing](/wiki/Slow "Slow") Potency of [Debuffs](/wiki/Debuff "Debuff") on You  ---  (4-8)% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for [Spells](/wiki/Spell "Spell")  ---  (6-12)% increased [Critical Spell Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus")  ---  (6-12)% increased [Stun](/wiki/Stun "Stun") Buildup  ---  Gain additional [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") equal to (4-10)% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") | |
| [Corpsewade](/wiki/Corpsewade "Corpsewade") | [Iron Greaves](/wiki/Iron_Greaves "Iron Greaves") | *[Boots](/wiki/Boots "Boots")* | 11 | 10% increased Movement Speed (30-50)% increased [Armour](/wiki/Armour "Armour") +(5-10) to [Strength](/wiki/Strength "Strength") Trigger Decompose every 1.2 metres travelled |
| [The Dancing Dervish](/wiki/The_Dancing_Dervish "The Dancing Dervish") | [Scimitar](/wiki/Scimitar "Scimitar") | *[One Hand Sword](/wiki/One_Hand_Sword "One Hand Sword")* | 16 | Triggers Level 15 Manifest Dancing Dervishes on Rampage Cannot be used while Manifested Manifested Dancing Dervishes die when Rampage ends [Melee](/wiki/Melee "Melee") Hits count as Rampage Kills Rampage |
| [Double Vision](/wiki/Double_Vision "Double Vision") | [Dyad Crossbow](/wiki/Dyad_Crossbow "Dyad Crossbow") | *[Crossbow](/wiki/Crossbow "Crossbow")* | 20 | Loads an additional boltAdds (14-21) to (25-37) [Physical](/wiki/Physical "Physical") Damage +5% to [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance When you reload, triggers Gemini Surge to alternately gain (2-6) [Cold Surges](/wiki/Elemental_Surges "Elemental Surges") or (2-6) [Fire Surges](/wiki/Elemental_Surges "Elemental Surges") (15-25)% increased Reload Speed |
| [Collapsing Horizon](/wiki/Collapsing_Horizon "Collapsing Horizon") | [Wyrm Quarterstaff](/wiki/Wyrm_Quarterstaff "Wyrm Quarterstaff") | *[Quarterstaff](/wiki/Quarterstaff "Quarterstaff")* | 65 | 100% increased [Elemental](/wiki/Elemental "Elemental") Damage with [Attacks](/wiki/Attack "Attack") +(5-10)% to [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance +(2-4) to Level of all [Elemental](/wiki/Elemental "Elemental") Skills Trigger skills refund half of [Energy](/wiki/Energy "Energy") spent |
| [Spire of Ire](/wiki/Spire_of_Ire "Spire of Ire") | [Helix Spear](/wiki/Helix_Spear "Helix Spear") | *[Spear](/wiki/Spear "Spear")* | 65 | (15-20)% increased [Attack](/wiki/Attack "Attack") Speed [Leeches](/wiki/Leech "Leech") (10-20)% of [Physical](/wiki/Physical "Physical") Damage as Life Adds (167-201) to (267-333) [Chaos](/wiki/Chaos "Chaos") damage When you Consume a [Charge](/wiki/Charge "Charge") Trigger Chaotic Surge to gain 2 [Chaos Surges](/wiki/Elemental_Surges "Elemental Surges") [Life Leech](/wiki/Life_Leech "Life Leech") recovers based on your [Chaos](/wiki/Chaos "Chaos") damage instead of [Physical](/wiki/Physical "Physical") damage |
| [Choir of the Storm](/wiki/Choir_of_the_Storm "Choir of the Storm") | [Jade Amulet](/wiki/Jade_Amulet "Jade Amulet") | *[Amulet](/wiki/Amulet "Amulet")* | 72 | +(10-15) to [Dexterity](/wiki/Dexterity "Dexterity")+(50-100)% to [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance") [Critical Hits](/wiki/Critical_Hit "Critical Hit") [Ignore](/wiki/Ignoring_Resistances "Ignoring Resistances") Enemy Monster [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance") Trigger Lightning Bolt Skill on [Critical Hit](/wiki/Critical_Hit "Critical Hit") |

## Related passive skills

The following [passive skills](/wiki/Passive_skill "Passive skill") are related to trigger:

| Name | Stats |
| --- | --- |
| [Triggered Spell Damage](/wiki/Triggered_Spell_Damage/edit?redlink=1 "Triggered Spell Damage (page does not exist)") | Triggered [Spells](/wiki/Spell "Spell") deal 14% increased [Spell](/wiki/Spell "Spell") Damage [[1]](/wiki/Passive_Skill:Triggers6 "Passive Skill:Triggers6") [[2]](/wiki/Passive_Skill:Triggers25~ "Passive Skill:Triggers25~") [[3]](/wiki/Passive_Skill:Triggers24~ "Passive Skill:Triggers24~") [[4]](/wiki/Passive_Skill:Triggers10 "Passive Skill:Triggers10") [[5]](/wiki/Passive_Skill:Triggers1 "Passive Skill:Triggers1")  ---  Triggered [Spells](/wiki/Spell "Spell") deal 16% increased [Spell](/wiki/Spell "Spell") Damage [[3]](/wiki/Passive_Skill:Triggers4 "Passive Skill:Triggers4") [[4]](/wiki/Passive_Skill:Triggers2 "Passive Skill:Triggers2") |
| [Dynamism](/wiki/Dynamism/edit?redlink=1 "Dynamism (page does not exist)") | 40% increased Damage if you've Triggered a Skill [Recently](/wiki/Recently "Recently") [Meta](/wiki/Meta "Meta") Skills gain 15% increased [Energy](/wiki/Energy "Energy") [[1]](/wiki/Passive_Skill:Triggers18 "Passive Skill:Triggers18") |
| [Energise](/wiki/Energise/edit?redlink=1 "Energise (page does not exist)") | 25% chance for Trigger skills to refund half of [Energy](/wiki/Energy "Energy") Spent [[1]](/wiki/Passive_Skill:Triggers16 "Passive Skill:Triggers16") |
| [Escalating Mayhem](/wiki/Escalating_Mayhem/edit?redlink=1 "Escalating Mayhem (page does not exist)") | 10% increased Damage for each [Hazard](/wiki/Hazard "Hazard") triggered [Recently](/wiki/Recently "Recently"), up to 50% [[1]](/wiki/Passive_Skill:Hazards3 "Passive Skill:Hazards3") |
| [Evocational Practitioner](/wiki/Evocational_Practitioner/edit?redlink=1 "Evocational Practitioner (page does not exist)") | [Meta](/wiki/Meta "Meta") Skills gain 25% increased [Energy](/wiki/Energy "Energy") if you've dealt a [Critical](/wiki/Critical "Critical") [Hit](/wiki/Hit "Hit") [Recently](/wiki/Recently "Recently") 25% increased [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance if you've Triggered a Skill [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Monkelemental6 "Passive Skill:Monkelemental6") |
| [Invocated Efficiency](/wiki/Invocated_Efficiency/edit?redlink=1 "Invocated Efficiency (page does not exist)") | Triggered [Spells](/wiki/Spell "Spell") deal 40% increased [Spell](/wiki/Spell "Spell") Damage 10% increased Mana Cost [Efficiency](/wiki/Efficiency "Efficiency") [[1]](/wiki/Passive_Skill:Triggers17 "Passive Skill:Triggers17") |

### Paths Not Taken passive skills

The following passive skills are exclusive the [Oracle](/wiki/Oracle "Oracle") with [The Unseen Path](/wiki/The_Unseen_Path "The Unseen Path") allocated:

| Name | Stats |
| --- | --- |
| [Power of the Storm](/wiki/Power_of_the_Storm "Power of the Storm") | 50% increased Damage if you've Triggered a Skill [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Oracle~energy~gain3 "Passive Skill:Oracle~energy~gain3") |

### Ascendancy passive skills

The following [Ascendancy passive skills](/wiki/Ascendancy_passive_skill "Ascendancy passive skill") are related to trigger:

| Ascendancy Class | Name | Stats |
| --- | --- | --- |
| [Invoker](/wiki/Invoker "Invoker") | [Triggered Spell Damage](/wiki/Triggered_Spell_Damage/edit?redlink=1 "Triggered Spell Damage (page does not exist)") | Triggered [Spells](/wiki/Spell "Spell") deal 16% increased [Spell](/wiki/Spell "Spell") Damage [[1]](/wiki/Passive_Skill:AscendancyMonk2Small10~ "Passive Skill:AscendancyMonk2Small10~") |
| [Invoker](/wiki/Invoker "Invoker") | [...and Scatter Them to the Winds](/wiki/...and_Scatter_Them_to_the_Winds "...and Scatter Them to the Winds") | Grants Skill: [Elemental Expression](/wiki/Elemental_Expression "Elemental Expression") Trigger Elemental Expression on [Melee](/wiki/Melee "Melee") [Critical Hit](/wiki/Critical_Hit "Critical Hit") [[1]](/wiki/Passive_Skill:AscendancyMonk2Notable7~ "Passive Skill:AscendancyMonk2Notable7~") |
| [Stormweaver](/wiki/Stormweaver "Stormweaver") | [Tempest Caller](/wiki/Tempest_Caller "Tempest Caller") | Grants Skill: [Elemental Storm](/wiki/Elemental_Storm "Elemental Storm") Trigger Elemental Storm on [Critical Hit](/wiki/Critical_Hit "Critical Hit") with [Spells](/wiki/Spell "Spell") [[1]](/wiki/Passive_Skill:AscendancySorceress1Notable3 "Passive Skill:AscendancySorceress1Notable3") |

### Keystones

The following [Keystones](/wiki/Keystone "Keystone") are related to trigger:

| Name | Stats |
| --- | --- |
| [Ritual Cadence](/wiki/Ritual_Cadence "Ritual Cadence") | [Invocation](/wiki/Invocation "Invocation") Skills instead Trigger [Spells](/wiki/Spell "Spell") every 2 seconds [Invocation](/wiki/Invocation "Invocation") Skills cannot gain [Energy](/wiki/Energy "Energy") while Triggering [Spells](/wiki/Spell "Spell") [Invoked](/wiki/Invoke "Invoke") Spells consume 50% less [Energy](/wiki/Energy "Energy") [[1]](/wiki/Passive_Skill:Passive~keystone~auto~invocation "Passive Skill:Passive~keystone~auto~invocation") |
