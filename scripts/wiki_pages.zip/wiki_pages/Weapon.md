# Weapon

**Weapons** are a category of [equipment](/wiki/Equipment "Equipment") that are equipped to deal [damage](/wiki/Damage "Damage") with [attacks](/wiki/Attacks "Attacks") or provide various [modifiers](/wiki/Affix/edit?redlink=1 "Affix (page does not exist)") that modify a character's damage.

## Weapon sets

Characters can equip two [one-handed weapons](/wiki/One-handed_weapon "One-handed weapon") ([dual wielding](/wiki/Dual_wielding "Dual wielding")), a [one-handed weapon](/wiki/One-handed_weapon "One-handed weapon") and an [off-hand](/wiki/Off-hand "Off-hand"), or a [two-handed weapon](/wiki/Two-handed_weapon "Two-handed weapon"). Weapons can only be equipped directly into the [off-hand](/wiki/Off-hand "Off-hand") slot while [dual wielding](/wiki/Dual_wielding "Dual wielding"). Additionally, [Bows](/wiki/Bow "Bow") can be equipped with a [quiver](/wiki/Quiver "Quiver").

Characters can equip [two sets of weapons](/wiki/Weapon_set "Weapon set"), and switch between them through a keybind for [weapon swapping](/wiki/Weapon_swap "Weapon swap"). Each of your [skills](/wiki/Skill "Skill") can be assigned one or both specific [weapon sets](/wiki/Weapon_set "Weapon set"); if a skill is assigned to the opposite [weapon set](/wiki/Weapon_set "Weapon set") only, [weapon set](/wiki/Weapon_set "Weapon set") is swapped automatically when using that [skill](/wiki/Skill "Skill"). It is possible to lock one weapon to be used on both sets.

## Martial weapons

Martial Weapons

Tooltip

Martial Weapons can be used to [Attack](/wiki/Attack "Attack"). [Axes](/wiki/Axe "Axe"), [Bows](/wiki/Bow "Bow"), [Claws](/wiki/Claws "Claws"), [Crossbows](/wiki/Crossbow "Crossbow"), [Daggers](/wiki/Dagger "Dagger"), [Flails](/wiki/Flail "Flail"), [Maces](/wiki/Mace "Mace"), [Quarterstaves](/wiki/Quarterstaves "Quarterstaves"), [Spears](/wiki/Spear "Spear"), [Swords](/wiki/Sword "Sword"), and [Talismans](/wiki/Talisman "Talisman") are Martial Weapons.

**Martial weapons** are weapons that are used to [attack](/wiki/Attack "Attack") with directly. Martial weapons have base [physical damage](/wiki/Physical_damage "Physical damage") or [elemental damage](/wiki/Elemental_damage "Elemental damage"), [critical hit chance](/wiki/Critical_hit#Critical_hit_chance "Critical hit"), and [attack time](/wiki/Attack_speed "Attack speed"). These can be directly modified with [local](/wiki/Local "Local") modifiers. Additionally, each [melee](/wiki/Melee "Melee") weapon [item class](/wiki/Item_class "Item class") (except [talismans](/wiki/Talisman "Talisman")) has an innate weapon range, which determines the [distance](/wiki/Distance "Distance") from which they can physically [strike](/wiki/Strike "Strike") enemies.

### Weapon range

Martial weapons have the following base ranges:

| Item class | Range |
| --- | --- |
| Dagger | 1.0 |
| Flail | 1.1 |
| One Hand Axe | 1.1 |
| One Hand Mace | 1.1 |
| One Hand Sword | 1.1 |
| Talisman | 1.2 |
| Two Hand Axe | 1.3 |
| Two Hand Mace | 1.3 |
| Two Hand Sword | 1.3 |
| Quarterstaff | 1.3 |
| Spear | 1.5 |
| Bow | 12.0 |
| Crossbow | 12.0 |

## Caster weapons

Caster Weapon

Tooltip

Caster Weapons are Sceptres, Staves and Wands.

**Caster weapons** are weapons that give bonuses to [spells](/wiki/Spell "Spell") or [minions](/wiki/Minion "Minion") and are not used to attack with. All caster weapons come with an inherent skill. They also have different pools of modifiers that suit their archetypes.

[Wands](/wiki/Wand "Wand"), [staves](/wiki/Staff "Staff"), and [sceptres](/wiki/Sceptre "Sceptre") are caster weapons.

## Traps

[Traps](/wiki/Trap "Trap") have no base attack stats and cannot be used to attack directly. [Traps](/wiki/Trap "Trap") are used exclusively for Trap skills and have stats that determine the [trap](/wiki/Trap "Trap")'s arming time and type of detonation (Manual or Proximity).

## Summary

| Weapon class | H | Type | Dual Wield | Off-hand | [Strength](/wiki/Strength "Strength") | [Dexterity](/wiki/Dexterity "Dexterity") | [Intelligence](/wiki/Intelligence "Intelligence") |
| --- | --- | --- | --- | --- | --- | --- | --- |
| [Maces](/wiki/Mace "Mace") | 1/2 | Martial |  | Mace, Shield/Buckler/Foci, Sceptre | 100% | 0% | 0% |
| [Axes](/wiki/Axe "Axe") | 1/2 | Martial |  | Axe, Shield/Buckler/Foci, Sceptre | 75% | 25% | 0% |
| [Flails](/wiki/Flail "Flail") | 1 | Martial |  | Shield/Buckler/Foci, Sceptre | 75% | 0% | 25% |
| [Swords](/wiki/Sword "Sword") | 1/2 | Martial |  | Sword, Shield/Buckler/Foci, Sceptre | 50% | 50% | 0% |
| [Crossbows](/wiki/Crossbow "Crossbow") | 2 | Martial |  | — | 50% | 50% | 0% |
| [Sceptres](/wiki/Sceptre "Sceptre") | 1 | Caster |  | Shield/Buckler/Foci | 50% | 0% | 50% |
| [Spears](/wiki/Spear "Spear") | 1 | Martial |  | Shield/Buckler/Foci, Sceptre | 25% | 75% | 0% |
| [Bows](/wiki/Bow "Bow") | 2 | Martial |  | Quiver only | 0% | 100% | 0% |
| [Quarterstaves](/wiki/Quarterstaff "Quarterstaff") | 2 | Martial |  | — | 0% | 75% | 25% |
| [Daggers](/wiki/Dagger "Dagger") | 1 | Martial |  | Dagger, Shield/Buckler/Foci, Sceptre | 0% | 50% | 50% |
| [Traps](/wiki/Trap "Trap") | 2 | Trap |  | — | 0% | 50% | 50% |
| [Talismans](/wiki/Talisman "Talisman") | 2 | Martial |  | Sceptrea | 75% | 0% | 25% |
| [Wands](/wiki/Wand "Wand") | 1 | Caster |  | Shield/Buckler/Foci, Sceptre | 0% | 0% | 100% |
| [Staves](/wiki/Staff "Staff") | 2 | Caster |  | Focib | 0% | 0% | 100% |

a Requires [Lord of the Wilds](/wiki/Lord_of_the_Wilds "Lord of the Wilds")

b Requires [Instruments of Power](/wiki/Instruments_of_Power "Instruments of Power")

## Trivia

[Claws](/wiki/Claw "Claw") were originally planned to return as the main weapon of the [Huntress](/wiki/Huntress "Huntress"), but was scrapped during development.[[1]](#cite_note-1) Several unique claws from [Path of Exile 1](/wiki/Path_of_Exile_1 "Path of Exile 1") have been added as [unique gloves](/wiki/List_of_unique_gloves "List of unique gloves") instead.
