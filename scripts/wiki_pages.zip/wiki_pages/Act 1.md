# Act 1

Example overworld map of Act 1

Example underground map of Act 1

**Act One** is [Path of Exile 2](/wiki/Path_of_Exile_2 "Path of Exile 2")'s first storyline [act](/wiki/Act "Act"), taking place in the region of [Ogham](/wiki/Ogham "Ogham"). In this act, the exile washes up on [the riverbank](/wiki/The_Riverbank "The Riverbank") after escaping a death sentence, and find their way to the [Clearfell Encampment](/wiki/Clearfell_Encampment "Clearfell Encampment"). They go on to travel through the Graveyard of the Eternals and Ogham Village to find and defeat [Count Geonor](/wiki/Count_Geonor "Count Geonor"), before following [the Countess](/wiki/The_Countess "The Countess") and [the Beast](/wiki/The_Beast "The Beast")'s trail to the deserts of [Act 2](/wiki/Act_2 "Act 2").

## Quests

* [Reaching Clearfell](/wiki/Reaching_Clearfell "Reaching Clearfell")
* [Treacherous Ground](/wiki/Treacherous_Ground "Treacherous Ground")
* [The Hunt Begins](/wiki/The_Hunt_Begins "The Hunt Begins") (optional)
* [Cracks in the Earth](/wiki/Cracks_in_the_Earth "Cracks in the Earth") (optional)
* [Secrets in the Dark](/wiki/Secrets_in_the_Dark "Secrets in the Dark")
* [The Mysterious Shade](/wiki/The_Mysterious_Shade "The Mysterious Shade")
* [Sorrow Among Stones](/wiki/Sorrow_Among_Stones "Sorrow Among Stones")
* [The Trail of Corruption](/wiki/The_Trail_of_Corruption "The Trail of Corruption")
* [Ominous Altars](/wiki/Ominous_Altars "Ominous Altars") (optional)
* [The Lost Lute](/wiki/The_Lost_Lute "The Lost Lute") (optional)
* [Finding the Forge](/wiki/Finding_the_Forge "Finding the Forge") (optional)
* [The Mad Wolf of Ogham](/wiki/The_Mad_Wolf_of_Ogham "The Mad Wolf of Ogham")

## Progression

|  |  |  |
| --- | --- | --- |
|  |  | [The Riverbank](/wiki/The_Riverbank "The Riverbank") 1  Boss: [The Bloated Miller](/wiki/The_Bloated_Miller "The Bloated Miller") |
|  |  | ↕ |  |
|  |  | [Clearfell Encampment](/wiki/Clearfell_Encampment "Clearfell Encampment") |  |
|  |  | ↕ |  |
|  |  | [Clearfell](/wiki/Clearfell "Clearfell") 2  Boss: [Beira of the Rotten Pack](/wiki/Beira_of_the_Rotten_Pack "Beira of the Rotten Pack") | ↔ | [Mud Burrow](/wiki/Mud_Burrow "Mud Burrow") 3  Boss: [The Devourer](/wiki/The_Devourer "The Devourer") |
|  |  | ↕ |  |
|  |  | [The Grelwood](/wiki/The_Grelwood "The Grelwood") 4  Boss: [The Brambleghast](/wiki/The_Brambleghast "The Brambleghast") | ↔ | [The Red Vale](/wiki/The_Red_Vale "The Red Vale") 5  Boss: [The Rust King](/wiki/The_Rust_King "The Rust King") |
|  |  | ↕ |  |
|  |  | [The Grim Tangle](/wiki/The_Grim_Tangle "The Grim Tangle") 6  Boss: [The Rotten Druid](/wiki/The_Rotten_Druid "The Rotten Druid") |
|  |  | ↕ |  |
| [Tomb of the Consort](/wiki/Tomb_of_the_Consort "Tomb of the Consort") 8/9[[a]](#cite_note-Level_8-9-1)  Boss: [Asinia, the Praetor's Consort](/wiki/Asinia,_the_Praetor%27s_Consort "Asinia, the Praetor's Consort") | ↔ | [Cemetery of the Eternals](/wiki/Cemetery_of_the_Eternals "Cemetery of the Eternals") 7  Boss: [Lachlann of Endless Lament](/wiki/Lachlann_of_Endless_Lament "Lachlann of Endless Lament") | ↔ | [Mausoleum of the Praetor](/wiki/Mausoleum_of_the_Praetor "Mausoleum of the Praetor") 8/9[[a]](#cite_note-Level_8-9-1)  Boss: [Draven, the Eternal Praetor](/wiki/Draven,_the_Eternal_Praetor "Draven, the Eternal Praetor") |  |
|  |  | ↕ |  |
|  |  | [Hunting Grounds](/wiki/Hunting_Grounds "Hunting Grounds") 10  Boss: [The Crowbell](/wiki/The_Crowbell "The Crowbell") | ↔ | [Freythorn](/wiki/Freythorn "Freythorn") 11  Boss: [The King in the Mists](/wiki/The_King_in_the_Mists_(Freythorn) "The King in the Mists (Freythorn)") |  |
|  |  | ↕ |  |
|  |  | [Ogham Farmlands](/wiki/Ogham_Farmlands "Ogham Farmlands") 12 |  |
|  |  | ↕ |  |
|  |  | [Ogham Village](/wiki/Ogham_Village "Ogham Village") 13  Boss: [The Executioner](/wiki/The_Executioner "The Executioner") |
|  |  | ↓ |  |
|  |  | [The Manor Ramparts](/wiki/The_Manor_Ramparts "The Manor Ramparts") 14 |
|  |  | ↕ |  |
|  |  | [Ogham Manor](/wiki/Ogham_Manor "Ogham Manor") 15  Boss: [Candlemass, the Living Rite](/wiki/Candlemass,_the_Living_Rite "Candlemass, the Living Rite") Act Boss: [Count Geonor](/wiki/Count_Geonor "Count Geonor") |

## Notes

1. ↑ [1.0](#cite_ref-Level_8-9_1-0) [1.1](#cite_ref-Level_8-9_1-1) Entering the 'Tomb of the Consort' first will cause the 'Mausoleum of the Praetor' to be area level 9, and vice versa. Creating a new instance will cause the first area entered to regenerate with an area level of 9 instead of 8.
