# Blood Mage

Blood Mage

[Witch](/wiki/Witch "Witch")

|  |  |
| --- | --- |
|  | **Your search for power took you on a journey inwards.** |

Official artwork of the Blood Mage.

**Blood Mage** is an [Ascendancy class](/wiki/Ascendancy_class "Ascendancy class") for the [Witch](/wiki/Witch "Witch").

## Overview

The Blood Mage puts her [Life](/wiki/Life "Life") on the line in exchange for power. The Blood Mage must take [Sanguimancy](/wiki/Sanguimancy "Sanguimancy") as her first skill, causing skills to have a life cost on top of mana cost, but also causing killed monsters to drop [Life Remnants](/wiki/Life_Remnants "Life Remnants") that recover life which can [Overflow](/wiki/Overflow "Overflow"). From there on, she gains access to passives that grant powerful bonuses to [Critical Hits](/wiki/Critical_Hit "Critical Hit") and life-based defenses and recovery, the ability to have elemental damage to scale [Bleeding](/wiki/Bleeding "Bleeding"), [curses](/wiki/Curse "Curse") that reserve enemy life and prevent life regeneration, and turning life flask charges into a source of damage.

## Passive skills

### Minor skills

This class has the following minor passive skills:

| Name | Stats |
| --- | --- |
| [Bleed on Critical Chance](/wiki/Bleed_on_Critical_Chance/edit?redlink=1 "Bleed on Critical Chance (page does not exist)") | 15% chance to inflict [Bleeding](/wiki/Bleeding "Bleeding") on [Critical Hit](/wiki/Critical_Hit "Critical Hit") [[1]](/wiki/Passive_Skill:AscendancyWitch2Small4~ "Passive Skill:AscendancyWitch2Small4~") |
| [Curse Effect](/wiki/Curse_Effect/edit?redlink=1 "Curse Effect (page does not exist)") | 6% increased [Curse](/wiki/Curse "Curse") [Magnitudes](/wiki/Magnitude "Magnitude") [[1]](/wiki/Passive_Skill:AscendancyWitch2Small5 "Passive Skill:AscendancyWitch2Small5") |
| [Life](/wiki/Life_(passive_skill) "Life (passive skill)") | 3% increased maximum Life [[1]](/wiki/Passive_Skill:AscendancyWitch2Small3 "Passive Skill:AscendancyWitch2Small3") [[2]](/wiki/Passive_Skill:AscendancyWitch2Small7 "Passive Skill:AscendancyWitch2Small7") [[3]](/wiki/Passive_Skill:AscendancyWitch2Small8 "Passive Skill:AscendancyWitch2Small8") |
| [Life Flasks](/wiki/Life_Flasks/edit?redlink=1 "Life Flasks (page does not exist)") | 15% increased Life [Flask](/wiki/Flask "Flask") Charges gained [[1]](/wiki/Passive_Skill:AscendancyWitch2Small9 "Passive Skill:AscendancyWitch2Small9") |
| [Life Leech](/wiki/Life_Leech "Life Leech") | 12% increased amount of Life [Leeched](/wiki/Leech "Leech") [[1]](/wiki/Passive_Skill:AscendancyWitch2Small6 "Passive Skill:AscendancyWitch2Small6") |
| [Spell Critical Chance](/wiki/Spell_Critical_Chance/edit?redlink=1 "Spell Critical Chance (page does not exist)") | 12% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for [Spells](/wiki/Spell "Spell") [[1]](/wiki/Passive_Skill:AscendancyWitch2Small1 "Passive Skill:AscendancyWitch2Small1") [[2]](/wiki/Passive_Skill:AscendancyWitch2Small2 "Passive Skill:AscendancyWitch2Small2") |

### Notable skills

This class has the following notable passive skills:

| Skill | Modifiers | Prerequisite | Preceding Passive |
| --- | --- | --- | --- |
| [Sanguimancy](/wiki/Sanguimancy "Sanguimancy") | Grants Skill: [Life Remnants](/wiki/Life_Remnants "Life Remnants") Skills gain a Base Life Cost equal to Base Mana Cost | — | — |
| [Sunder the Flesh](/wiki/Sunder_the_Flesh "Sunder the Flesh") | Base [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for [Spells](/wiki/Spell "Spell") is 15% | [Sanguimancy](/wiki/Sanguimancy "Sanguimancy") | [Spell Critical Chance](/wiki/Spell_Critical_Chance_(ascendancy_passive_skill) "Spell Critical Chance (ascendancy passive skill)") |
| [Gore Spike](/wiki/Gore_Spike "Gore Spike") | 1% increased [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus") per 50 current Life | [Sunder the Flesh](/wiki/Sunder_the_Flesh "Sunder the Flesh") | [Spell Critical Chance](/wiki/Spell_Critical_Chance_(ascendancy_passive_skill) "Spell Critical Chance (ascendancy passive skill)") |
| [Vitality Siphon](/wiki/Vitality_Siphon "Vitality Siphon") | 10% of [Spell](/wiki/Spell "Spell") Damage [Leeched as Life](/wiki/Life_Leech "Life Leech") | [Sanguimancy](/wiki/Sanguimancy "Sanguimancy") | [Life Leech](/wiki/Life_Leech_(ascendancy_passive_skill) "Life Leech (ascendancy passive skill)") |
| [Blood Barbs](/wiki/Blood_Barbs "Blood Barbs") | [Bleeding](/wiki/Bleeding "Bleeding") you inflict on [Cursed](/wiki/Curse "Curse") targets is [Aggravated](/wiki/Aggravated_Bleeding "Aggravated Bleeding") [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") also [Contributes](/wiki/Contributes "Contributes") to [Bleeding](/wiki/Bleeding "Bleeding") [Magnitude](/wiki/Magnitude "Magnitude") | [Sanguimancy](/wiki/Sanguimancy "Sanguimancy") | [Bleed on Critical Chance](/wiki/Bleed_on_Critical_Chance_(ascendancy_passive_skill) "Bleed on Critical Chance (ascendancy passive skill)") |
| [Sanguine Tides](/wiki/Sanguine_Tides "Sanguine Tides") | Gain 1 Life [Flask](/wiki/Flask "Flask") Charge per 4% Life spent On [Hitting](/wiki/Hit "Hit") an Enemy while a Life [Flask](/wiki/Flask "Flask") is at full Charges, 40% of its Charges are consumed [Gain](/wiki/Gain "Gain") 1% of damage as [Physical](/wiki/Physical "Physical") damage for 3 seconds per Charge consumed this way 50% less Life Recovery from [Flasks](/wiki/Flask "Flask") | [Sanguimancy](/wiki/Sanguimancy "Sanguimancy") | [Critical Chance](/wiki/Critical_Chance_(ascendancy_passive_skill) "Critical Chance (ascendancy passive skill)") |
| [Whispers of the Flesh](/wiki/Whispers_of_the_Flesh "Whispers of the Flesh") | Targets [Cursed](/wiki/Curse "Curse") by you have at least 15% of Life [Reserved](/wiki/Reservation "Reservation") Targets [Cursed](/wiki/Curse "Curse") by you have 100% reduced Life Regeneration Rate | [Sanguimancy](/wiki/Sanguimancy "Sanguimancy") | [Curse Effect](/wiki/Curse_Effect_(ascendancy_passive_skill) "Curse Effect (ascendancy passive skill)") |
| [Grasping Wounds](/wiki/Grasping_Wounds "Grasping Wounds") | 25% of Life Loss from [Hits](/wiki/Hit "Hit") is prevented, then that much Life is lost over 4 seconds instead | [Sanguimancy](/wiki/Sanguimancy "Sanguimancy") | [Life](/wiki/Life_(ascendancy_passive_skill) "Life (ascendancy passive skill)") |
| [Crimson Power](/wiki/Crimson_Power "Crimson Power") | Gain additional maximum Life equal to 100% of the [Item Energy Shield](/wiki/Defences "Defences") on [Equipped](/wiki/Equipped/edit?redlink=1 "Equipped (page does not exist)") Body Armour | [Grasping Wounds](/wiki/Grasping_Wounds "Grasping Wounds") | [Life](/wiki/Life_(ascendancy_passive_skill) "Life (ascendancy passive skill)") |
