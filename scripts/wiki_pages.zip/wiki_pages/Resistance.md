# Resistance

Resistances

Tooltip

Resistances reduce damage taken of the corresponding damage type — [Fire](/wiki/Fire_Damage "Fire Damage"), [Cold](/wiki/Cold_Damage "Cold Damage"), [Lightning](/wiki/Lightning_Damage "Lightning Damage") or [Chaos](/wiki/Chaos_Damage "Chaos Damage") — up to a [Maximum](/wiki/Maximum_Resistance "Maximum Resistance"). [Fire](/wiki/Fire_Damage "Fire Damage"), [Cold](/wiki/Cold_Damage "Cold Damage") and [Lightning](/wiki/Lightning_Damage "Lightning Damage") Resistances are Elemental Resistances. Resistances can be improved with Equipment, Passives & Quest items.

Your Elemental Resistances are lowered as you progress through the game. Elemental Resistances are a vital defensive tool, and should be one of the first things to check if you're having difficulty surviving.

Maximum Resistances

Tooltip

The default maximum for [Elemental](/wiki/Elemental "Elemental") or [Chaos](/wiki/Chaos_Damage "Chaos Damage") resistances is 75%. Maximum resistances cannot be raised above 90%.

Overcapped Resistance

Tooltip

Overcapped Resistance is the amount of a Resistance you have in excess of your [Maximum Resistance](/wiki/Maximum_Resistance "Maximum Resistance") for that damage type.

**Resistance** is a form of [damage reduction](/wiki/Damage_reduction "Damage reduction") that reduces [damage](/wiki/Damage "Damage") of a particular type by a percentage. Players and enemies all have a resistance stat to each of [Fire](/wiki/Fire "Fire"), [Cold](/wiki/Cold "Cold"), [Lightning](/wiki/Lightning "Lightning") and [Chaos](/wiki/Chaos "Chaos") damage, and these are raised or lowered independently. Increases to "Elemental Resistance" are applied to fire, cold and lightning but not chaos.

Resistance has a default value of 0, where it does not affect the damage taken. Maximum resistances are soft capped at 75% by default but can be increased to a hard cap of 90%. Resistance can go into the negatives, which increases damage taken.

[Characters](/wiki/Character "Character") receive a -10% penalty to elemental resistance approximately around the end of each [act](/wiki/Act "Act") up until [Act 4](/wiki/Act_4 "Act 4"). During the [Interludes](/wiki/Interludes "Interludes"), elemental resistance penalties are applied by [area level](/wiki/Area_level "Area level"). By [endgame](/wiki/Endgame "Endgame"), the cumulative penalty is -60% to all elemental resistances.

Honour Resistance is a stat used exclusively in [Trial of the Sekhemas](/wiki/Trial_of_the_Sekhemas "Trial of the Sekhemas"), and is calculated the same way.

## Mechanics

### Calculation

* F
  i
  n
  a
  l
  D
  a
  m
  a
  g
  e
  =
  D
  ∗
  (
  100
  −
  R
  )

  /
  100
  \color [rgb]{0.6392156862745098,0.5529411764705883,0.42745098039215684}FinalDamage=D\*(100-R)/100

Example: being hit by 1000 fire damage, with a fire resistance of 30%, means you would take:

* 1000
  ∗
  (
  100
  −
  30
  )

  /
  100
  =
  1000
  ∗
  0.7
  =
  700
  \color [rgb]{0.6392156862745098,0.5529411764705883,0.42745098039215684}1000\*(100-30)/100=1000\*0.7=700
   damage.

The higher your resistance gets, the more effective an increase in resistance feels in reducing damage taken. This makes increases to maximum resistance a particularly valuable stat. Going into the other direction however it means that loosing 10% resistance at a high resistance level will mean a more dramatic increase in damage taken than loosing 10% resistance at low resistance levels.

Example:

* After increasing your resistance from 0% to 10 %, a hit with a 1000 base damage will deal

  1000
  ∗
  (
  100
  −
  10
  )

  /
  100
  =
  1000
  ∗
  0.9
  =
  900
  \color [rgb]{0.6392156862745098,0.5529411764705883,0.42745098039215684}1000\*(100-10)/100=1000\*0.9=900
   damage, which is equal to a 10% damage reduction being felt.

* In contrary, an increase from 60% elemental resistance (

  1000
  ∗
  (
  100
  −
  60
  )

  /
  100
  =
  1000
  ∗
  0.4
  =
  400
  \color [rgb]{0.6392156862745098,0.5529411764705883,0.42745098039215684}1000\*(100-60)/100=1000\*0.4=400
   damage) to 70% resistance (

  1000
  ∗
  (
  100
  −
  70
  )

  /
  100
  =
  1000
  ∗
  0.3
  =
  300
  \color [rgb]{0.6392156862745098,0.5529411764705883,0.42745098039215684}1000\*(100-70)/100=1000\*0.3=300
   damage), while still just subtracting another 100 damage from the initial hit, reduces the effective damage taken from 400 Damage at 60% to 300 Damage at 70%, meaning the felt reduction of damage is not 10%, but 25%.

### Elemental Exposure

Main article: [Exposure](/wiki/Exposure "Exposure")

**Exposure** is a debuff applied to the player or an enemy that reduces their elemental resistance (by default -20% for 4 seconds), which can result in negative resistance values.

### Curses

Main article: [Curses](/wiki/Curses "Curses")

[Elemental Weakness](/wiki/Elemental_Weakness "Elemental Weakness") and [Despair](/wiki/Despair "Despair") applies a [curse](/wiki/Curse "Curse") debuff which lowers elemental or chaos resistance, respectively. Curses can stack with exposure and other debuffs that lower resistance, but there is a default curse limit of one. Note that debuffs from both exposure and curses affect uncapped resistance, regardless of maximum resistance.

Example: A player with 150% uncapped fire resistance and a maximum resistance of 75% would have their effective resistance unchanged after being hit with with -40% from the flammability curse, since the remaining 110% is still enough to reach maximum resistance.

### Inverted resistance

Certain effects (e.g. [Rakiata's Flow](/wiki/Rakiata%27s_Flow "Rakiata's Flow")) treat resistance values as if it were inverted. This is equivalent to multiplying the target's resistance value by -1. For example, if a target had 60% fire resistance, it would be treated as having -60% fire resistance. Conversely, negative resistances will be inverted into positive resistances, which can result in damage loss.

### Resistance penetration

Main article: [Penetration](/wiki/Penetration "Penetration")

Having **Penetration** in a damage type reduces the effective resistance of enemies you damage with that type, thus increasing the damage they take. It stacks with exposure and curse debuffs, but is applied last and is only effective against positive resistances; it has no effect once the effective resistance is 0 or negative. In exchange, it affects both maximum resistance and uncapped resistance.

### Ignore resistance

Effects which cause damage to ignore enemy resistances will calculate damage as if the enemy had 0% of the ignored resistance, and ignores any further modifications to resistances. It does not affect the actual resistance, and does not interact with stats that care about the specific resistance value.

## Elemental resistance penalties

Elemental resistance penalties apply as the player progresses further into the game. During the [campaign](/wiki/Campaign "Campaign"), each subsequent act imposes a greater penalty. During the [interludes](/wiki/Interlude "Interlude") and [endgame](/wiki/Endgame "Endgame"), resistance penalties are applied based on the [area level](/wiki/Area_level "Area level").

| Point of progression | Penalty |
| --- | --- |
| Act 2 | −10% |
| Act 3 | −20% |
| Act 4 | −30% |
| Area level 54-59 (Interlude) | −40% |
| Area level 60-64 (Interlude) | −50% |
| Area level 65+ (Endgame) | −60% |

## Quest rewards

The following quest rewards modify resistances:

| Source | Location | Effect |
| --- | --- | --- |
| [Head of the Winter Wolf](/wiki/Head_of_the_Winter_Wolf "Head of the Winter Wolf") *([Beira of the Rotten Pack](/wiki/Beira_of_the_Rotten_Pack "Beira of the Rotten Pack"))* | [Clearfell](/wiki/Clearfell "Clearfell") ([Act 1](/wiki/Act_1 "Act 1")) | +10% to Cold Resistance |
| Sisters of Garukhan | [The Spires of Deshar](/wiki/The_Spires_of_Deshar "The Spires of Deshar") ([Act 2](/wiki/Act_2 "Act 2")) | +10% to Lightning Resistance |
| [The Flame Core](/wiki/The_Flame_Core "The Flame Core") *([Blackjaw, the Remnant](/wiki/Blackjaw,_the_Remnant "Blackjaw, the Remnant"))* | [Jiquani's Machinarium](/wiki/Jiquani%27s_Machinarium "Jiquani's Machinarium") ([Act 3](/wiki/Act_3 "Act 3")) | +10% to Fire Resistance |
| [Fire Tattoo of Ngamahu](/wiki/Fire_Tattoo_of_Ngamahu "Fire Tattoo of Ngamahu") | [Halls of the Dead](/wiki/Halls_of_the_Dead "Halls of the Dead") ([Act 4](/wiki/Act_4 "Act 4")) | +5% to Fire Resistance |
| [Cold Tattoo of Tasalio](/wiki/Cold_Tattoo_of_Tasalio "Cold Tattoo of Tasalio") | [Halls of the Dead](/wiki/Halls_of_the_Dead "Halls of the Dead") ([Act 4](/wiki/Act_4 "Act 4")) | +5% to Cold Resistance |
| [Lightning Tattoo of Tawhoa](/wiki/Lightning_Tattoo_of_Tawhoa "Lightning Tattoo of Tawhoa") | [Halls of the Dead](/wiki/Halls_of_the_Dead "Halls of the Dead") ([Act 4](/wiki/Act_4 "Act 4")) | +5% to Lightning Resistance |
| Seven Pillars - Tabana's Boon | [Qimah](/wiki/Qimah "Qimah") ([Interlude 2](/wiki/Interlude_2 "Interlude 2")) | +5% to Elemental Resistances *(Can be changed)* |
| Seven Pillars - Alima's Disgrace | [Qimah](/wiki/Qimah "Qimah") ([Interlude 2](/wiki/Interlude_2 "Interlude 2")) | 5% increased Experience Gain 15% reduced Global Defences 20% reduced Presence Area of Effect 12% reduced Cooldown Recovery Rate 5% reduced Attributes 3% reduced Movement Speed -5% to Elemental Resistances *(Can be changed)* |

## Skills

Skills that are related to resistances:

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Elemental Weakness](/wiki/Elemental_Weakness "Elemental Weakness") | *7* |  |  |  |
| [Despair](/wiki/Despair "Despair") | *9* |  |  |  |
| [Oil Barrage](/wiki/Oil_Barrage "Oil Barrage") | *9* |  |  |  |
| [Oil Grenade](/wiki/Oil_Grenade "Oil Grenade") | *9* |  |  |  |

### Persistent skills

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Impurity](/wiki/Impurity "Impurity") | *0* |  |  |  |
| [Purity of Fire](/wiki/Purity_of_Fire "Purity of Fire") | *0* |  |  |  |
| [Purity of Ice](/wiki/Purity_of_Ice "Purity of Ice") | *0* |  |  |  |
| [Purity of Lightning](/wiki/Purity_of_Lightning "Purity of Lightning") | *0* |  |  |  |
| [Dread Banner](/wiki/Dread_Banner "Dread Banner") | *14* |  |  |  |

## Support gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Rakiata's Flow](/wiki/Rakiata%27s_Flow "Rakiata's Flow") | *0* |  |  |  |
| [Elemental Army](/wiki/Elemental_Army "Elemental Army") | *1* |  |  |  |
| [Lightning Penetration](/wiki/Lightning_Penetration "Lightning Penetration") | *2* |  |  |  |
| [Cold Penetration](/wiki/Cold_Penetration "Cold Penetration") | *2* |  |  |  |
| [Fire Penetration I](/wiki/Fire_Penetration_I "Fire Penetration I") | *2* |  |  |  |
| [Reinforced Totems I](/wiki/Reinforced_Totems_I "Reinforced Totems I") | *3* |  |  |  |
| [Fire Penetration II](/wiki/Fire_Penetration_II "Fire Penetration II") | *5* |  |  |  |
| [Reinforced Totems II](/wiki/Reinforced_Totems_II "Reinforced Totems II") | *5* |  |  |  |

## Unique items

### Maximum resistance

The following unique items are associated with maximum resistances:

| Item | Stats |
| --- | --- |
| [Against the Darkness](/wiki/Against_the_Darkness "Against the Darkness") | | <2 random jewel modifiers> | | --- | | +(2-3)% to [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance")  ---  +(2-4)% to [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance")  ---  [Gain](/wiki/Gain "Gain") (2-4)% of Damage as Extra [Chaos](/wiki/Chaos "Chaos") Damage  ---  [Gain](/wiki/Gain "Gain") (2-4)% of Damage as Extra [Cold](/wiki/Cold "Cold") Damage  ---  [Gain](/wiki/Gain "Gain") (2-4)% of Damage as Extra [Fire](/wiki/Fire "Fire") Damage  ---  [Gain](/wiki/Gain "Gain") (2-4)% of Damage as Extra [Lightning](/wiki/Lightning "Lightning") Damage  ---  +(2-4)% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance")  ---  (4-6)% reduced [Freeze](/wiki/Freeze "Freeze") Duration on you  ---  (4-6)% reduced [Ignite](/wiki/Ignite "Ignite") Duration on you  ---  +8 to maximum Life  ---  +8 to maximum Mana  ---  +(2-4)% to [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance")  ---  +1% to [Maximum Chaos Resistance](/wiki/Maximum_Chaos_Resistance/edit?redlink=1 "Maximum Chaos Resistance (page does not exist)")  ---  +1% to [Maximum Cold Resistance](/wiki/Maximum_Cold_Resistance "Maximum Cold Resistance")  ---  +1% to [Maximum Fire Resistance](/wiki/Maximum_Fire_Resistance "Maximum Fire Resistance")  ---  +1% to [Maximum Lightning Resistance](/wiki/Maximum_Lightning_Resistance "Maximum Lightning Resistance")  ---  (2-3)% increased [Dexterity](/wiki/Dexterity "Dexterity")  ---  (2-3)% increased [Intelligence](/wiki/Intelligence "Intelligence")  ---  (2-3)% increased [Strength](/wiki/Strength "Strength")  ---  (4-6)% reduced [Shock](/wiki/Shock "Shock") duration on you  ---  +(8-12) to [Spirit](/wiki/Spirit "Spirit") | |
| [Heart of the Well](/wiki/Heart_of_the_Well "Heart of the Well") | <Custom Desecrated prefix> <Custom Desecrated prefix> <Custom Desecrated suffix> <Custom Desecrated suffix>   | <List of mods> | | --- | | (5-10)% chance to [Aggravate](/wiki/Aggravate "Aggravate") [Bleeding](/wiki/Bleeding "Bleeding") on targets you [Hit](/wiki/Hit "Hit") with [Attacks](/wiki/Attack "Attack")  ---  (5-8)% increased [Attack](/wiki/Attack "Attack") Speed while a [Rare or Unique](/wiki/Rarity "Rarity") Enemy is in your [Presence](/wiki/Presence "Presence")  ---  (40-60)% increased [Armour](/wiki/Armour "Armour") from Equipped Body Armour  ---  (30-50)% chance to [Pierce](/wiki/Pierce "Pierce") an Enemy  ---  (10-15)% chance when a [Charm](/wiki/Charm "Charm") is used to use another Charm without consuming Charges  ---  [Charms](/wiki/Charm "Charm") applied to you have (15-25)% increased Effect  ---  Recover (5-10)% of maximum Mana when a [Charm](/wiki/Charm "Charm") is used  ---  (15-25)% increased [Culling Strike](/wiki/Culling_Strike "Culling Strike") Threshold  ---  [Gain](/wiki/Gain "Gain") (9-15)% of Damage as Extra [Lightning](/wiki/Lightning "Lightning") Damage  ---  [Gain](/wiki/Gain "Gain") (7-13)% of Damage as Extra [Chaos](/wiki/Chaos "Chaos") Damage  ---  [Gain](/wiki/Gain "Gain") (9-15)% of Damage as Extra [Fire](/wiki/Fire "Fire") Damage  ---  [Gain](/wiki/Gain "Gain") (9-15)% of Damage as Extra [Cold](/wiki/Cold "Cold") Damage  ---  (15-25)% increased Damage while your [Companion](/wiki/Companion "Companion") is in your [Presence](/wiki/Presence "Presence")  ---  (15-25)% increased [Exposure](/wiki/Exposure "Exposure") Effect  ---  (40-60)% increased [Evasion](/wiki/Evasion "Evasion") Rating from Equipped Body Armour  ---  Regenerate (1-1.5)% of maximum Life per Second if you've used a Life [Flask](/wiki/Flask "Flask") in the past 10 seconds  ---  (10-18)% increased [Cooldown Recovery Rate](/wiki/Cooldown_Recovery_Rate "Cooldown Recovery Rate")  ---  (40-60)% increased [Ice Crystal](/wiki/Ice_Crystal "Ice Crystal") Life  ---  (4-8)% increased [Skill Speed](/wiki/Skill_Speed "Skill Speed")  ---  (15-25)% chance for [Lightning](/wiki/Lightning "Lightning") Damage with [Hits](/wiki/Hit "Hit") to be [Lucky](/wiki/Lucky "Lucky")  ---  (8-16)% increased Mana Cost [Efficiency](/wiki/Efficiency "Efficiency")  ---  (20-30)% increased Mana Regeneration Rate while moving  ---  +1% to all [Maximum Elemental Resistances](/wiki/Maximum_Resistance "Maximum Resistance")  ---  (40-60)% increased [Energy Shield](/wiki/Energy_Shield "Energy Shield") from Equipped Body Armour  ---  [Minions](/wiki/Minion "Minion") gain (10-15)% of their maximum Life as Extra maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield")  ---  [Minions](/wiki/Minion "Minion") Regenerate (1-3)% of maximum Life per second  ---  [Minions](/wiki/Minion "Minion") [Revive](/wiki/Reviving_Minions "Reviving Minions") (5-10)% faster  ---  (8-15)% of Leech is Instant  ---  (5-10)% of Physical Damage prevented [Recouped](/wiki/Recoup "Recoup") as Life  ---  (8-14)% increased speed of [Recoup](/wiki/Recoup "Recoup") Effects  ---  Recover (2-4)% of maximum Life on Killing a [Poisoned](/wiki/Poison "Poison") Enemy  ---  (10-15)% increased Skill Effect Duration  ---  +(2-4)% to Thorns [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance  ---  Gain [Physical](/wiki/Physical "Physical") [Thorns](/wiki/Thorns "Thorns") damage equal to (4-6)% of [Item Armour](/wiki/Defences "Defences") on [Equipped](/wiki/Equipped/edit?redlink=1 "Equipped (page does not exist)") Body Armour  ---  (6-12)% chance for [Trigger](/wiki/Trigger "Trigger") skills to refund half of [Energy](/wiki/Energy "Energy") Spent  ---  (4-8)% increased chance to inflict [Ailments](/wiki/Ailments "Ailments")  ---  Gain additional [Ailment Threshold](/wiki/Ailment_Threshold "Ailment Threshold") equal to (4-10)% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield")  ---  (5-10)% chance to inflict [Bleeding](/wiki/Bleeding "Bleeding") on [Hit](/wiki/Hit "Hit")  ---  (5-10)% chance to [Poison](/wiki/Poison "Poison") on [Hit](/wiki/Hit "Hit")  ---  (4-8)% increased [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance  ---  (6-12)% increased [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus")  ---  (2-3)% of Damage is taken from Mana before Life  ---  [Debuffs](/wiki/Debuff "Debuff") on you expire (4-8)% faster  ---  [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") deal damage (2-4)% faster  ---  (4-8)% increased [Flask](/wiki/Flask "Flask") Effect Duration  ---  Gain (1-2) [Rage](/wiki/Rage "Rage") when [Hit](/wiki/Hit "Hit") by an Enemy  ---  (2-3)% increased [Cooldown Recovery Rate](/wiki/Cooldown_Recovery_Rate "Cooldown Recovery Rate")  ---  (6-12)% increased [Elemental Ailment Threshold](/wiki/Ailment "Ailment")  ---  (2-3)% increased [Attack](/wiki/Attack "Attack") Speed  ---  (2-3)% increased Cast Speed  ---  (4-8)% increased [Flask](/wiki/Flask "Flask") Charges gained  ---  (5-10)% increased [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold")  ---  (2-3)% of Skill Mana Costs [Converted](/wiki/Stat_conversion "Stat conversion") to Life Costs  ---  (2-3)% of Damage taken [Recouped](/wiki/Recoup "Recoup") as Life  ---  (6-12)% increased Life Regeneration rate  ---  Recover (1-2)% of maximum Mana on Kill  ---  (4-8)% increased Mana Regeneration Rate  ---  +1% to [Maximum Cold Resistance](/wiki/Maximum_Cold_Resistance "Maximum Cold Resistance")  ---  +1% to [Maximum Fire Resistance](/wiki/Maximum_Fire_Resistance "Maximum Fire Resistance")  ---  Recover (1-2)% of maximum Life on Kill  ---  +1% to [Maximum Lightning Resistance](/wiki/Maximum_Lightning_Resistance "Maximum Lightning Resistance")  ---  [Minions](/wiki/Minion "Minion") have (2-3)% increased [Attack](/wiki/Attack "Attack") and Cast Speed  ---  [Minions](/wiki/Minion "Minion") have (6-12)% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance")  ---  [Minions](/wiki/Minion "Minion") have +(3-4)% to all Elemental [Resistances](/wiki/Resistances "Resistances")  ---  [Minions](/wiki/Minion "Minion") have (3-12)% additional [Physical](/wiki/Physical "Physical") Damage Reduction  ---  (1-2)% increased Movement Speed  ---  Gain 1 [Rage](/wiki/Rage "Rage") on [Melee](/wiki/Melee "Melee") [Hit](/wiki/Hit "Hit")  ---  (3-8)% increased Skill Effect Duration  ---  (10-5)% reduced [Slowing](/wiki/Slow "Slow") Potency of [Debuffs](/wiki/Debuff "Debuff") on You  ---  (4-8)% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for [Spells](/wiki/Spell "Spell")  ---  (6-12)% increased [Critical Spell Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus")  ---  (6-12)% increased [Stun](/wiki/Stun "Stun") Buildup  ---  Gain additional [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") equal to (4-10)% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") | |
| [Kaltenhalt](/wiki/Kaltenhalt "Kaltenhalt") | (80-120)% increased [Evasion](/wiki/Evasion "Evasion") Rating +5% to [Maximum Cold Resistance](/wiki/Maximum_Cold_Resistance "Maximum Cold Resistance") +(-40-40)% to [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance") Modifiers to [Stun](/wiki/Stun "Stun") Buildup apply to [Freeze](/wiki/Freeze "Freeze") Buildup instead for Parry 100% of Parry [Physical](/wiki/Physical "Physical") Damage Converted to [Cold](/wiki/Cold "Cold") Damage 25 to 35 [Cold](/wiki/Cold "Cold") [Thorns](/wiki/Thorns "Thorns") damage |
| [The Eternal Spark](/wiki/The_Eternal_Spark "The Eternal Spark") | (50-70)% increased [Energy Shield](/wiki/Energy_Shield "Energy Shield") +5% to [Maximum Lightning Resistance](/wiki/Maximum_Lightning_Resistance "Maximum Lightning Resistance") +(20-30)% to [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance") 40% increased Mana Regeneration Rate 40% increased Mana Regeneration Rate while stationary |
| [Rise of the Phoenix](/wiki/Rise_of_the_Phoenix "Rise of the Phoenix") | +5% to [Maximum Fire Resistance](/wiki/Maximum_Fire_Resistance "Maximum Fire Resistance") +(20-25)% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") +25% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") while on [Low Life](/wiki/Low_Life "Low Life") Regenerate 3% of maximum Life per second Regenerate 3% of maximum Life per second while on [Low Life](/wiki/Low_Life "Low Life") |
| [Sunsplinter](/wiki/Sunsplinter "Sunsplinter") | (100-300)% increased [Evasion](/wiki/Evasion "Evasion") Rating   | +(1–3) to Level of all Fire Skills +(1–3) to Level of all Cold Skills +(1–3) to Level of all Lightning Skills +(1-3)% to Maximum Fire Resistance +(1-3)% to Maximum Cold Resistance +(1-3)% to Maximum Lightning Resistance | | --- | | +1 to Level of all [Fire](/wiki/Fire "Fire") Skills +2 to Level of all [Cold](/wiki/Cold "Cold") Skills +3 to Level of all [Lightning](/wiki/Lightning "Lightning") Skills  ---  +1 to Level of all [Fire](/wiki/Fire "Fire") Skills +3 to Level of all [Cold](/wiki/Cold "Cold") Skills +2 to Level of all [Lightning](/wiki/Lightning "Lightning") Skills  ---  +2 to Level of all [Fire](/wiki/Fire "Fire") Skills +1 to Level of all [Cold](/wiki/Cold "Cold") Skills +3 to Level of all [Lightning](/wiki/Lightning "Lightning") Skills  ---  +2 to Level of all [Fire](/wiki/Fire "Fire") Skills +3 to Level of all [Cold](/wiki/Cold "Cold") Skills +1 to Level of all [Lightning](/wiki/Lightning "Lightning") Skills  ---  +3 to Level of all [Fire](/wiki/Fire "Fire") Skills +1 to Level of all [Cold](/wiki/Cold "Cold") Skills +2 to Level of all [Lightning](/wiki/Lightning "Lightning") Skills  ---  +3 to Level of all [Fire](/wiki/Fire "Fire") Skills +2 to Level of all [Cold](/wiki/Cold "Cold") Skills +1 to Level of all [Lightning](/wiki/Lightning "Lightning") Skills  ---  +1% to [Maximum Fire Resistance](/wiki/Maximum_Fire_Resistance "Maximum Fire Resistance") +2% to [Maximum Cold Resistance](/wiki/Maximum_Cold_Resistance "Maximum Cold Resistance") +3% to [Maximum Lightning Resistance](/wiki/Maximum_Lightning_Resistance "Maximum Lightning Resistance")  ---  +1% to [Maximum Fire Resistance](/wiki/Maximum_Fire_Resistance "Maximum Fire Resistance") +3% to [Maximum Cold Resistance](/wiki/Maximum_Cold_Resistance "Maximum Cold Resistance") +2% to [Maximum Lightning Resistance](/wiki/Maximum_Lightning_Resistance "Maximum Lightning Resistance")  ---  +2% to [Maximum Fire Resistance](/wiki/Maximum_Fire_Resistance "Maximum Fire Resistance") +1% to [Maximum Cold Resistance](/wiki/Maximum_Cold_Resistance "Maximum Cold Resistance") +3% to [Maximum Lightning Resistance](/wiki/Maximum_Lightning_Resistance "Maximum Lightning Resistance")  ---  +2% to [Maximum Fire Resistance](/wiki/Maximum_Fire_Resistance "Maximum Fire Resistance") +3% to [Maximum Cold Resistance](/wiki/Maximum_Cold_Resistance "Maximum Cold Resistance") +1% to [Maximum Lightning Resistance](/wiki/Maximum_Lightning_Resistance "Maximum Lightning Resistance")  ---  +3% to [Maximum Fire Resistance](/wiki/Maximum_Fire_Resistance "Maximum Fire Resistance") +1% to [Maximum Cold Resistance](/wiki/Maximum_Cold_Resistance "Maximum Cold Resistance") +2% to [Maximum Lightning Resistance](/wiki/Maximum_Lightning_Resistance "Maximum Lightning Resistance")  ---  +3% to [Maximum Fire Resistance](/wiki/Maximum_Fire_Resistance "Maximum Fire Resistance") +2% to [Maximum Cold Resistance](/wiki/Maximum_Cold_Resistance "Maximum Cold Resistance") +1% to [Maximum Lightning Resistance](/wiki/Maximum_Lightning_Resistance "Maximum Lightning Resistance") | |
| [The Brass Dome](/wiki/The_Brass_Dome "The Brass Dome") | (700-800)% increased [Armour](/wiki/Armour "Armour") -(5-1)% to all [Maximum Elemental Resistances](/wiki/Maximum_Resistance "Maximum Resistance") +(200-300) to [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") Take no Extra Damage from [Critical Hits](/wiki/Critical_Hit "Critical Hit") |

### Miscellaneous

| Item | Stats |
| --- | --- |
| [Carrion Call](/wiki/Carrion_Call "Carrion Call") | +(30-40) to maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") [Minions](/wiki/Minion "Minion") have (20-30)% increased maximum Life (20-30)% increased Mana Regeneration Rate [Minions](/wiki/Minion "Minion") deal (20-30)% increased Damage [Minions'](/wiki/Minion "Minion") [Resistances](/wiki/Resistances "Resistances") are equal to yours |
| [Veil of the Night](/wiki/Veil_of_the_Night "Veil of the Night") | 50% increased maximum Life +(10-20) to all [Attributes](/wiki/Attributes "Attributes") 40% reduced [Light Radius](/wiki/Light_Radius "Light Radius") You have no [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") |
| [Doryani's Prototype](/wiki/Doryani%27s_Prototype "Doryani's Prototype") | (50-100)% increased [Armour](/wiki/Armour "Armour") and [Evasion](/wiki/Evasion "Evasion") +(60-100) to maximum Life +100% of [Armour](/wiki/Armour "Armour") also applies to [Lightning Damage](/wiki/Lightning_Damage "Lightning Damage") Enemies in your [Presence](/wiki/Presence "Presence") have [Lightning Resistance](/wiki/Lightning_Damage "Lightning Damage") equal to yours [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance") does not affect [Lightning](/wiki/Lightning "Lightning") damage taken |
| [Sekhema's Resolve](/wiki/Sekhema%27s_Resolve_(Fire) "Sekhema's Resolve (Fire)") | (10-20)% increased [Rarity of Items](/wiki/Rarity "Rarity") found +(10-20) to all [Attributes](/wiki/Attributes "Attributes") [Fire](/wiki/Fire "Fire") Resistance is unaffected by Area Penalties You can only Socket Ruby Jewels in this item Has 1 Jewel Socket (Hidden) |
| [Sekhema's Resolve](/wiki/Sekhema%27s_Resolve_(Lightning) "Sekhema's Resolve (Lightning)") | (10-20)% increased [Rarity of Items](/wiki/Rarity "Rarity") found +(10-20) to all [Attributes](/wiki/Attributes "Attributes") [Lightning](/wiki/Lightning "Lightning") Resistance is unaffected by Area Penalties You can only Socket Emerald Jewels in this item Has 1 Jewel Socket (Hidden) |
| [Sekhema's Resolve](/wiki/Sekhema%27s_Resolve_(Cold) "Sekhema's Resolve (Cold)") | (10-20)% increased [Rarity of Items](/wiki/Rarity "Rarity") found +(10-20) to all [Attributes](/wiki/Attributes "Attributes") [Cold](/wiki/Cold "Cold") Resistance is unaffected by Area Penalties You can only Socket Sapphire Jewels in this item Has 1 Jewel Socket (Hidden) |
| [Glimpse of Chaos](/wiki/Glimpse_of_Chaos "Glimpse of Chaos") | Can be modified while Corrupted +(50-150) to maximum Life +(50-150) to maximum Mana +(-30-30)% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") +(-30-30)% to [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance") +(-30-30)% to [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance") [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance") is zero |
| [The Coming Calamity](/wiki/The_Coming_Calamity "The Coming Calamity") | +(60-80) to maximum Life+(30-40)% to all [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") [Herald](/wiki/Herald "Herald") Skills deal (50-100)% increased Damage Enemies in your [Presence](/wiki/Presence "Presence") have no [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") |
| [Sacred Flame](/wiki/Sacred_Flame "Sacred Flame") | [Gain](/wiki/Gain "Gain") (40-60)% of Damage as Extra [Fire](/wiki/Fire "Fire") Damage [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") [Gain](/wiki/Gain "Gain") (20-30)% of Damage as Extra Fire Damage [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") Regenerate (2-3)% of their Maximum Life per second Enemies in your [Presence](/wiki/Presence "Presence") Resist [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") based on their Lowest Resistance |

## Related passive skills

The following [passive skills](/wiki/Passive_skill "Passive skill") are related to resistances:

### Elemental resistances

| Name | Stats |
| --- | --- |
| [Shaman](/wiki/Shaman "Shaman") | +3% to all [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") [[1]](/wiki/Passive_Skill:Shaman1 "Passive Skill:Shaman1") |
| [All Natural](/wiki/All_Natural/edit?redlink=1 "All Natural (page does not exist)") | 30% increased [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") +5% to all [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") [[1]](/wiki/Passive_Skill:Elemental39 "Passive Skill:Elemental39") |
| [Elemental Force](/wiki/Elemental_Force/edit?redlink=1 "Elemental Force (page does not exist)") | 20% increased [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") +3% to all [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") [[1]](/wiki/Passive_Skill:Cold34 "Passive Skill:Cold34") |
| [Inspiring Leader](/wiki/Inspiring_Leader/edit?redlink=1 "Inspiring Leader (page does not exist)") | [Banners](/wiki/Banner "Banner") also grant +25% to all [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") to you and [Allies](/wiki/Allies "Allies") [[1]](/wiki/Passive_Skill:Banners10 "Passive Skill:Banners10") |
| [Invigorating Archon](/wiki/Invigorating_Archon/edit?redlink=1 "Invigorating Archon (page does not exist)") | [Archon](/wiki/Archon "Archon") Buffs also grant 10% increased Movement Speed [Archon](/wiki/Archon "Archon") Buffs also grant +20% to all [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") [[1]](/wiki/Passive_Skill:Archon11 "Passive Skill:Archon11") |
| [Unnatural Resilience](/wiki/Unnatural_Resilience/edit?redlink=1 "Unnatural Resilience (page does not exist)") | +3% to all [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") +2% to [Maximum Fire Resistance](/wiki/Maximum_Fire_Resistance "Maximum Fire Resistance") if you have at least 5 Red [Support Gems](/wiki/Support_Gem "Support Gem") Socketed [[1]](/wiki/Passive_Skill:Maximum~resistances20 "Passive Skill:Maximum~resistances20") |

### Fire resistance

| Name | Stats |
| --- | --- |
| [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") | +5% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") [[1]](/wiki/Passive_Skill:Maximum~resistances1 "Passive Skill:Maximum~resistances1") [[2]](/wiki/Passive_Skill:Shaman2 "Passive Skill:Shaman2") [[3]](/wiki/Passive_Skill:Shaman7 "Passive Skill:Shaman7") |
| [The Molten One's Gift](/wiki/The_Molten_One%27s_Gift/edit?redlink=1 "The Molten One's Gift (page does not exist)") | [Fully Broken Armour](/wiki/Fully_Broken_Armour "Fully Broken Armour") you inflict also increases [Fire](/wiki/Fire "Fire") Damage Taken from [Hits](/wiki/Hit "Hit") 15% increased effect of [Fully Broken Armour](/wiki/Fully_Broken_Armour "Fully Broken Armour") +10% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") [[1]](/wiki/Passive_Skill:Armour~break16~ "Passive Skill:Armour~break16~") |
| [Volcanic Skin](/wiki/Volcanic_Skin/edit?redlink=1 "Volcanic Skin (page does not exist)") | [Gain](/wiki/Gain "Gain") 8% of Damage as Extra [Fire](/wiki/Fire "Fire") Damage +20% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") [[1]](/wiki/Passive_Skill:Fire37 "Passive Skill:Fire37") |

### Cold resistance

| Name | Stats |
| --- | --- |
| [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance") | +5% to [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance") [[1]](/wiki/Passive_Skill:Maximum~resistances5 "Passive Skill:Maximum~resistances5") [[2]](/wiki/Passive_Skill:Shaman4 "Passive Skill:Shaman4") [[3]](/wiki/Passive_Skill:Shaman5 "Passive Skill:Shaman5") |
| [Mana Leech and Cold Resistance](/wiki/Mana_Leech_and_Cold_Resistance/edit?redlink=1 "Mana Leech and Cold Resistance (page does not exist)") | 10% increased amount of Mana [Leeched](/wiki/Leech "Leech") +5% to [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance") [[1]](/wiki/Passive_Skill:Mana~leech1 "Passive Skill:Mana~leech1") [[2]](/wiki/Passive_Skill:Mana~leech3 "Passive Skill:Mana~leech3") |
| [Embracing Frost](/wiki/Embracing_Frost/edit?redlink=1 "Embracing Frost (page does not exist)") | +1% to [Maximum Cold Resistance](/wiki/Maximum_Cold_Resistance "Maximum Cold Resistance") +10% to [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance") [[1]](/wiki/Passive_Skill:Freeze~and~chill~mitigation7 "Passive Skill:Freeze~and~chill~mitigation7") |
| [Unbothering Cold](/wiki/Unbothering_Cold/edit?redlink=1 "Unbothering Cold (page does not exist)") | +2% to [Maximum Cold Resistance](/wiki/Maximum_Cold_Resistance "Maximum Cold Resistance") if you have at least 5 Blue [Support Gems](/wiki/Support_Gem "Support Gem") Socketed +10% to [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance") [[1]](/wiki/Passive_Skill:Cold26 "Passive Skill:Cold26") |

### Lightning resistance

| Name | Stats |
| --- | --- |
| [Lightning Damage and Resistance](/wiki/Lightning_Damage_and_Resistance/edit?redlink=1 "Lightning Damage and Resistance (page does not exist)") | +3% to [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance") 5% increased [Lightning](/wiki/Lightning "Lightning") Damage [[1]](/wiki/Passive_Skill:Shock22~ "Passive Skill:Shock22~") [[2]](/wiki/Passive_Skill:Shock23 "Passive Skill:Shock23") |
| [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance") | +5% to [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance") [[1]](/wiki/Passive_Skill:Lightning58 "Passive Skill:Lightning58") [[2]](/wiki/Passive_Skill:Maximum~resistances9 "Passive Skill:Maximum~resistances9") [[3]](/wiki/Passive_Skill:Shaman3 "Passive Skill:Shaman3") [[4]](/wiki/Passive_Skill:Shaman6~~ "Passive Skill:Shaman6~~") |
| [Conductive Embrace](/wiki/Conductive_Embrace/edit?redlink=1 "Conductive Embrace (page does not exist)") | +10% to [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance") +2% to [Maximum Lightning Resistance](/wiki/Maximum_Lightning_Resistance "Maximum Lightning Resistance") if you have at least 5 Green [Support Gems](/wiki/Support_Gem "Support Gem") Socketed [[1]](/wiki/Passive_Skill:Shock36 "Passive Skill:Shock36") |

### Chaos resistance

| Name | Stats |
| --- | --- |
| [Chaos Damage and Resistance](/wiki/Chaos_Damage_and_Resistance/edit?redlink=1 "Chaos Damage and Resistance (page does not exist)") | 5% increased [Chaos](/wiki/Chaos "Chaos") Damage +3% to [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance") [[1]](/wiki/Passive_Skill:Monkchaos3 "Passive Skill:Monkchaos3") [[2]](/wiki/Passive_Skill:Monkchaos4 "Passive Skill:Monkchaos4") |
| [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance") | +5% to [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance") [[1]](/wiki/Passive_Skill:Monkchaos5 "Passive Skill:Monkchaos5") |
| [Distant Dreamer](/wiki/Distant_Dreamer/edit?redlink=1 "Distant Dreamer (page does not exist)") | +10% to [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance") [Gain](/wiki/Gain "Gain") 5% of Damage as Extra [Chaos](/wiki/Chaos "Chaos") Damage 50% reduced [effect](/wiki/Buff "Buff") of [Withered](/wiki/Withered "Withered") on you [[1]](/wiki/Passive_Skill:Monkchaos6 "Passive Skill:Monkchaos6") |
| [Spaghettification](/wiki/Spaghettification "Spaghettification") | +13 to all [Attributes](/wiki/Attributes "Attributes") 29% increased [Chaos](/wiki/Chaos "Chaos") Damage -7% to [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance") 23% reduced [Light Radius](/wiki/Light_Radius "Light Radius") 3% increased Movement Speed [[1]](/wiki/Passive_Skill:Chaos32 "Passive Skill:Chaos32") |
| [Spiral into Mania](/wiki/Spiral_into_Mania/edit?redlink=1 "Spiral into Mania (page does not exist)") | 10% increased Cast Speed +13% to [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance") [[1]](/wiki/Passive_Skill:Cast~speed34 "Passive Skill:Cast~speed34") |

### Maximum resistance

| Name | Stats |
| --- | --- |
| [Adaptive Skin](/wiki/Adaptive_Skin/edit?redlink=1 "Adaptive Skin (page does not exist)") | +1% to [Maximum Resistances](/wiki/Maximum_Resistance "Maximum Resistance") of each [Elemental](/wiki/Elemental "Elemental") Damage Type you have been [Hit](/wiki/Hit "Hit") with [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Shaman12 "Passive Skill:Shaman12") |
| [Blood of the Wolf](/wiki/Blood_of_the_Wolf/edit?redlink=1 "Blood of the Wolf (page does not exist)") | 15% increased Life Regeneration rate while [Shapeshifted](/wiki/Shapeshifting "Shapeshifting") 15% increased amount of Life [Leeched](/wiki/Leech "Leech") while [Shapeshifted](/wiki/Shapeshifting "Shapeshifting") +1% to [Maximum Cold Resistance](/wiki/Maximum_Cold_Resistance "Maximum Cold Resistance") while [Shapeshifted](/wiki/Shapeshifting "Shapeshifting") [[1]](/wiki/Passive_Skill:Wolf8 "Passive Skill:Wolf8") |
| [Conductive Embrace](/wiki/Conductive_Embrace/edit?redlink=1 "Conductive Embrace (page does not exist)") | +10% to [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance") +2% to [Maximum Lightning Resistance](/wiki/Maximum_Lightning_Resistance "Maximum Lightning Resistance") if you have at least 5 Green [Support Gems](/wiki/Support_Gem "Support Gem") Socketed [[1]](/wiki/Passive_Skill:Shock36 "Passive Skill:Shock36") |
| [Crystalline Resistance](/wiki/Crystalline_Resistance/edit?redlink=1 "Crystalline Resistance (page does not exist)") | +1% to all [Maximum Elemental Resistances](/wiki/Maximum_Resistance "Maximum Resistance") if you have at least 5 Red, Green and Blue [Support Gems](/wiki/Support_Gem "Support Gem") Socketed [[1]](/wiki/Passive_Skill:Attributes99 "Passive Skill:Attributes99") |
| [Electric Blood](/wiki/Electric_Blood/edit?redlink=1 "Electric Blood (page does not exist)") | 50% reduced [effect](/wiki/Buff "Buff") of [Shock](/wiki/Shock "Shock") on you +1% to [Maximum Lightning Resistance](/wiki/Maximum_Lightning_Resistance "Maximum Lightning Resistance") [[1]](/wiki/Passive_Skill:Lightning59 "Passive Skill:Lightning59") |
| [Embracing Frost](/wiki/Embracing_Frost/edit?redlink=1 "Embracing Frost (page does not exist)") | +1% to [Maximum Cold Resistance](/wiki/Maximum_Cold_Resistance "Maximum Cold Resistance") +10% to [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance") [[1]](/wiki/Passive_Skill:Freeze~and~chill~mitigation7 "Passive Skill:Freeze~and~chill~mitigation7") |
| [Hide of the Bear](/wiki/Hide_of_the_Bear/edit?redlink=1 "Hide of the Bear (page does not exist)") | 40% increased [Armour](/wiki/Armour "Armour") while [Shapeshifted](/wiki/Shapeshifting "Shapeshifting") 25% increased [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") while [Shapeshifted](/wiki/Shapeshifting "Shapeshifting") +1% to [Maximum Fire Resistance](/wiki/Maximum_Fire_Resistance "Maximum Fire Resistance") while [Shapeshifted](/wiki/Shapeshifting "Shapeshifting") [[1]](/wiki/Passive_Skill:Bear11 "Passive Skill:Bear11") |
| [Molten Carapace](/wiki/Molten_Carapace/edit?redlink=1 "Molten Carapace (page does not exist)") | +2% to [Maximum Fire Resistance](/wiki/Maximum_Fire_Resistance "Maximum Fire Resistance") while [Ignited](/wiki/Ignite "Ignite") 50% increased [Fire](/wiki/Fire "Fire") Damage while [Ignited](/wiki/Ignite "Ignite") 50% increased [Armour](/wiki/Armour "Armour") while [Ignited](/wiki/Ignite "Ignite") [[1]](/wiki/Passive_Skill:Ignite~mitigation4 "Passive Skill:Ignite~mitigation4") |
| [Scales of the Wyvern](/wiki/Scales_of_the_Wyvern/edit?redlink=1 "Scales of the Wyvern (page does not exist)") | 20% increased [Energy Shield Recharge Rate](/wiki/Energy_Shield_Recharge_Rate "Energy Shield Recharge Rate") while [Shapeshifted](/wiki/Shapeshifting "Shapeshifting") 20% [faster start of Energy Shield Recharge](/wiki/Energy_Shield "Energy Shield") while [Shapeshifted](/wiki/Shapeshifting "Shapeshifting") +1% to [Maximum Lightning Resistance](/wiki/Maximum_Lightning_Resistance "Maximum Lightning Resistance") while [Shapeshifted](/wiki/Shapeshifting "Shapeshifting") [[1]](/wiki/Passive_Skill:Wyvern4 "Passive Skill:Wyvern4") |
| [Unbothering Cold](/wiki/Unbothering_Cold/edit?redlink=1 "Unbothering Cold (page does not exist)") | +2% to [Maximum Cold Resistance](/wiki/Maximum_Cold_Resistance "Maximum Cold Resistance") if you have at least 5 Blue [Support Gems](/wiki/Support_Gem "Support Gem") Socketed +10% to [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance") [[1]](/wiki/Passive_Skill:Cold26 "Passive Skill:Cold26") |
| [Unnatural Resilience](/wiki/Unnatural_Resilience/edit?redlink=1 "Unnatural Resilience (page does not exist)") | +3% to all [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") +2% to [Maximum Fire Resistance](/wiki/Maximum_Fire_Resistance "Maximum Fire Resistance") if you have at least 5 Red [Support Gems](/wiki/Support_Gem "Support Gem") Socketed [[1]](/wiki/Passive_Skill:Maximum~resistances20 "Passive Skill:Maximum~resistances20") |

### Minion resistance

| Name | Stats |
| --- | --- |
| [Minion Cold Resistance](/wiki/Minion_Cold_Resistance/edit?redlink=1 "Minion Cold Resistance (page does not exist)") | [Minions](/wiki/Minion "Minion") have +20% to Cold Resistance [[1]](/wiki/Passive_Skill:Minion~defence26 "Passive Skill:Minion~defence26")  ---  [Minions](/wiki/Minion "Minion") have +20% to Cold Resistance [Minions](/wiki/Minion "Minion") have +3% to [Maximum Cold Resistances](/wiki/Maximum_Cold_Resistance "Maximum Cold Resistance") [[3]](/wiki/Passive_Skill:Minion~defence27 "Passive Skill:Minion~defence27") [[4]](/wiki/Passive_Skill:Minion~defence34 "Passive Skill:Minion~defence34") |
| [Minion Fire Resistance](/wiki/Minion_Fire_Resistance/edit?redlink=1 "Minion Fire Resistance (page does not exist)") | [Minions](/wiki/Minion "Minion") have +20% to Fire Resistance [Minions](/wiki/Minion "Minion") have +3% to [Maximum Fire Resistances](/wiki/Maximum_Fire_Resistance "Maximum Fire Resistance") [[1]](/wiki/Passive_Skill:Minion~defence14 "Passive Skill:Minion~defence14") [[2]](/wiki/Passive_Skill:Minion~defence41 "Passive Skill:Minion~defence41")  ---  [Minions](/wiki/Minion "Minion") have +20% to Fire Resistance [[2]](/wiki/Passive_Skill:Minion~defence38 "Passive Skill:Minion~defence38") |
| [Minion Life and Chaos Resistance](/wiki/Minion_Life_and_Chaos_Resistance/edit?redlink=1 "Minion Life and Chaos Resistance (page does not exist)") | [Minions](/wiki/Minion "Minion") have 8% increased maximum Life [Minions](/wiki/Minion "Minion") have +7% to [Chaos](/wiki/Chaos "Chaos") Resistance [[1]](/wiki/Passive_Skill:Minion~defence1 "Passive Skill:Minion~defence1") [[2]](/wiki/Passive_Skill:Minion~defence31 "Passive Skill:Minion~defence31") [[3]](/wiki/Passive_Skill:Minion~defence33 "Passive Skill:Minion~defence33") [[4]](/wiki/Passive_Skill:Minion~defence4 "Passive Skill:Minion~defence4") |
| [Minion Lightning Resistance](/wiki/Minion_Lightning_Resistance/edit?redlink=1 "Minion Lightning Resistance (page does not exist)") | [Minions](/wiki/Minion "Minion") have +20% to Lightning Resistance [Minions](/wiki/Minion "Minion") have +3% to [Maximum Lightning Resistances](/wiki/Maximum_Lightning_Resistance "Maximum Lightning Resistance") [[1]](/wiki/Passive_Skill:Minion~defence23 "Passive Skill:Minion~defence23") [[2]](/wiki/Passive_Skill:Minion~defence39 "Passive Skill:Minion~defence39")  ---  [Minions](/wiki/Minion "Minion") have +20% to Lightning Resistance [[2]](/wiki/Passive_Skill:Minion~defence37 "Passive Skill:Minion~defence37") |
| [Minion Resistances](/wiki/Minion_Resistances/edit?redlink=1 "Minion Resistances (page does not exist)") | [Minions](/wiki/Minion "Minion") have +8% to all Elemental [Resistances](/wiki/Resistances "Resistances") [[1]](/wiki/Passive_Skill:Minion~defence11~~ "Passive Skill:Minion~defence11~~") [[2]](/wiki/Passive_Skill:Minion~defence28 "Passive Skill:Minion~defence28") [[3]](/wiki/Passive_Skill:Minion~defence30 "Passive Skill:Minion~defence30") |
| [Crystalline Flesh](/wiki/Crystalline_Flesh/edit?redlink=1 "Crystalline Flesh (page does not exist)") | [Minions](/wiki/Minion "Minion") have +20% to all Elemental [Resistances](/wiki/Resistances "Resistances") [Minions](/wiki/Minion "Minion") have +5% to all [Maximum Elemental Resistances](/wiki/Maximum_Resistance "Maximum Resistance") [[1]](/wiki/Passive_Skill:Minion~defence21 "Passive Skill:Minion~defence21") |
| [Entropic Incarnation](/wiki/Entropic_Incarnation/edit?redlink=1 "Entropic Incarnation (page does not exist)") | [Minions](/wiki/Minion "Minion") gain 10% of [Physical](/wiki/Physical "Physical") Damage as [Chaos](/wiki/Chaos "Chaos") Damage [Minions](/wiki/Minion "Minion") have +13% to [Chaos](/wiki/Chaos "Chaos") Resistance [[1]](/wiki/Passive_Skill:Minion~reservation14 "Passive Skill:Minion~reservation14") |
| [Left Hand of Darkness](/wiki/Left_Hand_of_Darkness/edit?redlink=1 "Left Hand of Darkness (page does not exist)") | [Minions](/wiki/Minion "Minion") have 20% additional [Physical](/wiki/Physical "Physical") Damage Reduction [Minions](/wiki/Minion "Minion") have +23% to [Chaos](/wiki/Chaos "Chaos") Resistance [Attacks](/wiki/Attack "Attack") [Gain](/wiki/Gain "Gain") 5% of Damage as extra [Chaos](/wiki/Chaos "Chaos") Damage [[1]](/wiki/Passive_Skill:Minion~defence16 "Passive Skill:Minion~defence16") |
| [Living Death](/wiki/Living_Death/edit?redlink=1 "Living Death (page does not exist)") | [Minions](/wiki/Minion "Minion") have +22% to all Elemental [Resistances](/wiki/Resistances "Resistances") [Minions](/wiki/Minion "Minion") have +3% to all [Maximum Elemental Resistances](/wiki/Maximum_Resistance "Maximum Resistance") [[1]](/wiki/Passive_Skill:Minion~defence42 "Passive Skill:Minion~defence42") |
| [Silent Guardian](/wiki/Silent_Guardian/edit?redlink=1 "Silent Guardian (page does not exist)") | [Minions](/wiki/Minion "Minion") have +20% to all Elemental [Resistances](/wiki/Resistances "Resistances") 20% increased [Elemental Ailment Threshold](/wiki/Ailment "Ailment") [[1]](/wiki/Passive_Skill:Sentinels9 "Passive Skill:Sentinels9") |
| [Vile Mending](/wiki/Vile_Mending/edit?redlink=1 "Vile Mending (page does not exist)") | [Minions](/wiki/Minion "Minion") have 20% increased maximum Life [Minions](/wiki/Minion "Minion") Regenerate 3% of maximum Life per second [Minions](/wiki/Minion "Minion") have +13% to [Chaos](/wiki/Chaos "Chaos") Resistance [[1]](/wiki/Passive_Skill:Minion~defence35 "Passive Skill:Minion~defence35") |

### Companion resistance

| Name | Stats |
| --- | --- |
| [Ailment Threshold and Companion Resistance](/wiki/Ailment_Threshold_and_Companion_Resistance/edit?redlink=1 "Ailment Threshold and Companion Resistance (page does not exist)") | 8% increased [Elemental Ailment Threshold](/wiki/Ailment "Ailment") [Companions](/wiki/Companion "Companion") have +12% to all Elemental [Resistances](/wiki/Resistances "Resistances") [[1]](/wiki/Passive_Skill:Companions25 "Passive Skill:Companions25") [[2]](/wiki/Passive_Skill:Companions33 "Passive Skill:Companions33") [[3]](/wiki/Passive_Skill:Companions34 "Passive Skill:Companions34") |
| [Companion Resistance and Life](/wiki/Companion_Resistance_and_Life/edit?redlink=1 "Companion Resistance and Life (page does not exist)") | [Companions](/wiki/Companion "Companion") have +12% to all Elemental [Resistances](/wiki/Resistances "Resistances") [Companions](/wiki/Companion "Companion") have 12% increased maximum Life [[1]](/wiki/Passive_Skill:Companions38 "Passive Skill:Companions38") |
| [Unspoken Bond](/wiki/Unspoken_Bond/edit?redlink=1 "Unspoken Bond (page does not exist)") | [Companions](/wiki/Companion "Companion") have +30% to all Elemental [Resistances](/wiki/Resistances "Resistances") [Companions](/wiki/Companion "Companion") have +30% to [Chaos](/wiki/Chaos "Chaos") Resistance [[1]](/wiki/Passive_Skill:Companions6 "Passive Skill:Companions6") |

### Totem resistance

| Name | Stats |
| --- | --- |
| [Totem Elemental Resistance](/wiki/Totem_Elemental_Resistance/edit?redlink=1 "Totem Elemental Resistance (page does not exist)") | [Totems](/wiki/Totem "Totem") gain +12% to all Elemental [Resistances](/wiki/Resistances "Resistances") [[1]](/wiki/Passive_Skill:Totems47~ "Passive Skill:Totems47~") |
| [Hardened Wood](/wiki/Hardened_Wood/edit?redlink=1 "Hardened Wood (page does not exist)") | [Totems](/wiki/Totem "Totem") gain +20% to all Elemental [Resistances](/wiki/Resistances "Resistances") [Totems](/wiki/Totem "Totem") have 20% additional [Physical](/wiki/Physical "Physical") Damage Reduction [[1]](/wiki/Passive_Skill:Totems20 "Passive Skill:Totems20") |

### Miscellany

| Name | Stats |
| --- | --- |
| [Deep Freeze](/wiki/Deep_Freeze "Deep Freeze") | 20% increased [Freeze](/wiki/Freeze "Freeze") Buildup Enemies [Frozen](/wiki/Freeze "Freeze") by you have -8% to Cold Resistance [[1]](/wiki/Passive_Skill:Cold48 "Passive Skill:Cold48") |
| [Firestarter](/wiki/Firestarter/edit?redlink=1 "Firestarter (page does not exist)") | 80% increased [Flammability](/wiki/Flammability "Flammability") [Magnitude](/wiki/Magnitude "Magnitude") Enemies [Ignited](/wiki/Ignite "Ignite") by you have -5% to Fire Resistance [[1]](/wiki/Passive_Skill:Ignite10 "Passive Skill:Ignite10") |
| [Heavy Frost](/wiki/Heavy_Frost "Heavy Frost") | [Hits](/wiki/Hit "Hit") ignore non-negative [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") of [Frozen](/wiki/Frozen "Frozen") Enemies 20% increased [Freeze](/wiki/Freeze "Freeze") Buildup [[1]](/wiki/Passive_Skill:Cold33 "Passive Skill:Cold33") |
| [Void](/wiki/Void/edit?redlink=1 "Void (page does not exist)") | 29% increased [Chaos](/wiki/Chaos "Chaos") Damage Enemies you [Curse](/wiki/Curse "Curse") have -3% to Chaos Resistance [[1]](/wiki/Passive_Skill:Chaos36 "Passive Skill:Chaos36") |

### Paths Not Taken passive skills

The following passive skills are exclusive the [Oracle](/wiki/Oracle "Oracle") with [The Unseen Path](/wiki/The_Unseen_Path "The Unseen Path") allocated:

| Name | Stats |
| --- | --- |
| [Totem Cast and Attack Speed and Elemental Resistance](/wiki/Totem_Cast_and_Attack_Speed_and_Elemental_Resistance/edit?redlink=1 "Totem Cast and Attack Speed and Elemental Resistance (page does not exist)") | [Spells](/wiki/Spell "Spell") Cast by [Totems](/wiki/Totem "Totem") have 2% increased Cast Speed [Attacks](/wiki/Attack "Attack") used by Totems have 2% increased [Attack](/wiki/Attack "Attack") Speed [Totems](/wiki/Totem "Totem") gain +1% to all [Maximum Elemental Resistances](/wiki/Maximum_Resistance "Maximum Resistance") [[1]](/wiki/Passive_Skill:Oracle~totems9 "Passive Skill:Oracle~totems9") |
| [Totem Elemental Resistance](/wiki/Totem_Elemental_Resistance/edit?redlink=1 "Totem Elemental Resistance (page does not exist)") | [Totems](/wiki/Totem "Totem") gain +2% to all [Maximum Elemental Resistances](/wiki/Maximum_Resistance "Maximum Resistance") [[1]](/wiki/Passive_Skill:Oracle~totems3~ "Passive Skill:Oracle~totems3~") [[2]](/wiki/Passive_Skill:Oracle~totems4 "Passive Skill:Oracle~totems4") |
| [Dimensional Weakspot](/wiki/Dimensional_Weakspot "Dimensional Weakspot") | [Hits](/wiki/Hit "Hit") have 15% chance to treat Enemy Monster [Elemental](/wiki/Elemental "Elemental") Resistance values as inverted [[1]](/wiki/Passive_Skill:Oracle12 "Passive Skill:Oracle12") |
| [Forbidden Path](/wiki/Forbidden_Path "Forbidden Path") | [Minions](/wiki/Minion "Minion") [Gain](/wiki/Gain "Gain") 20% of Elemental Damage as Extra Chaos Damage -10% to all [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") [Minions](/wiki/Minion "Minion") [Recoup](/wiki/Recoup "Recoup") 30% of Damage taken as Life 5% reduced maximum Life [[1]](/wiki/Passive_Skill:Oracle~forbidden~path5 "Passive Skill:Oracle~forbidden~path5") |
| [Mighty Trunk](/wiki/Mighty_Trunk "Mighty Trunk") | 20% increased Area of Effect for Skills used by Totems [Totems](/wiki/Totem "Totem") gain +3% to all [Maximum Elemental Resistances](/wiki/Maximum_Resistance "Maximum Resistance") [[1]](/wiki/Passive_Skill:Oracle~totems8 "Passive Skill:Oracle~totems8") |

### Ascendancy passive skills

The following [Ascendancy passive skills](/wiki/Ascendancy_passive_skill "Ascendancy passive skill") are related to resistances:

| Ascendancy Class | Name | Stats |
| --- | --- | --- |
| [Acolyte of Chayula](/wiki/Acolyte_of_Chayula "Acolyte of Chayula") | [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance") | +7% to [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance") [[1]](/wiki/Passive_Skill:AscendancyMonk3Small4~ "Passive Skill:AscendancyMonk3Small4~") |
| [Acolyte of Chayula](/wiki/Acolyte_of_Chayula "Acolyte of Chayula") | [Chayula's Gift](/wiki/Chayula%27s_Gift "Chayula's Gift") | [Chaos](/wiki/Chaos "Chaos") Resistance is doubled +10% to [Maximum Chaos Resistance](/wiki/Maximum_Chaos_Resistance/edit?redlink=1 "Maximum Chaos Resistance (page does not exist)") [[1]](/wiki/Passive_Skill:AscendancyMonk3Notable4 "Passive Skill:AscendancyMonk3Notable4") |
| [Acolyte of Chayula](/wiki/Acolyte_of_Chayula "Acolyte of Chayula") | [Deepening Shadows](/wiki/Deepening_Shadows "Deepening Shadows") | 1% increased maximum Darkness per 1% [Chaos Resistance](/wiki/Chaos_Damage "Chaos Damage") [[1]](/wiki/Passive_Skill:AscendancyMonk3Notable9 "Passive Skill:AscendancyMonk3Notable9") |
| [Gemling Legionnaire](/wiki/Gemling_Legionnaire "Gemling Legionnaire") | [Thaumaturgical Infusion](/wiki/Thaumaturgical_Infusion "Thaumaturgical Infusion") | +1% to [Maximum Fire Resistance](/wiki/Maximum_Fire_Resistance "Maximum Fire Resistance") per 3 Red [Support Gems](/wiki/Support_Gem "Support Gem") Socketed +1% to [Maximum Lightning Resistance](/wiki/Maximum_Lightning_Resistance "Maximum Lightning Resistance") per 3 Green [Support Gems](/wiki/Support_Gem "Support Gem") Socketed +1% to [Maximum Cold Resistance](/wiki/Maximum_Cold_Resistance "Maximum Cold Resistance") per 3 Blue [Support Gems](/wiki/Support_Gem "Support Gem") Socketed [[1]](/wiki/Passive_Skill:AscendancyMercenary3Notable8 "Passive Skill:AscendancyMercenary3Notable8") |
| [Invoker](/wiki/Invoker "Invoker") | [Sunder my Enemies...](/wiki/Sunder_my_Enemies... "Sunder my Enemies...") | [Critical Hits](/wiki/Critical_Hit "Critical Hit") ignore non-negative Enemy Monster [Elemental Resistances](/wiki/Elemental_Resistance/edit?redlink=1 "Elemental Resistance (page does not exist)") [[1]](/wiki/Passive_Skill:AscendancyMonk2Notable6 "Passive Skill:AscendancyMonk2Notable6") |
| [Ritualist](/wiki/Ritualist "Ritualist") | [Reduced Resistances](/wiki/Reduced_Resistances/edit?redlink=1 "Reduced Resistances (page does not exist)") | -20% to all [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") [[1]](/wiki/Passive_Skill:AscendancyHuntress3Small1~3 "Passive Skill:AscendancyHuntress3Small1~3") |
| [Shaman](/wiki/Shaman "Shaman") | [Elemental Resistances](/wiki/Elemental_Resistances "Elemental Resistances") | +3% to all [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") [[1]](/wiki/Passive_Skill:AscendancyDruid2Small4~ "Passive Skill:AscendancyDruid2Small4~") [[2]](/wiki/Passive_Skill:AscendancyDruid2Small5 "Passive Skill:AscendancyDruid2Small5") |
| [Smith of Kitava](/wiki/Smith_of_Kitava "Smith of Kitava") | [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") | +8% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") [[1]](/wiki/Passive_Skill:AscendancyWarrior3Small4 "Passive Skill:AscendancyWarrior3Small4") [[2]](/wiki/Passive_Skill:AscendancyWarrior3Small5 "Passive Skill:AscendancyWarrior3Small5") |
| [Smith of Kitava](/wiki/Smith_of_Kitava "Smith of Kitava") | [Coal Stoker](/wiki/Coal_Stoker "Coal Stoker") | Modifiers to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") also grant Cold and Lightning Resistance at 50% of their value [[1]](/wiki/Passive_Skill:AscendancyWarrior3Notable4 "Passive Skill:AscendancyWarrior3Notable4") |
| [Smith of Kitava](/wiki/Smith_of_Kitava "Smith of Kitava") | [Forged in Flame](/wiki/Forged_in_Flame "Forged in Flame") | Modifiers to [Maximum Fire Resistance](/wiki/Maximum_Fire_Resistance "Maximum Fire Resistance") also grant [Maximum Cold and Lightning Resistance](/wiki/Maximum_Resistance "Maximum Resistance") [[1]](/wiki/Passive_Skill:AscendancyWarrior3Notable5 "Passive Skill:AscendancyWarrior3Notable5") |
| [Smith of Kitava](/wiki/Smith_of_Kitava "Smith of Kitava") | [Tantalum Alloy](/wiki/Tantalum_Alloy "Tantalum Alloy") | Body Armour grants +75% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") [[1]](/wiki/Passive_Skill:AscendancyWarrior3Notable6~1 "Passive Skill:AscendancyWarrior3Notable6~1") |

### Keystones

The following [Keystones](/wiki/Keystone "Keystone") are related to resistances:
No results found for the given query.
