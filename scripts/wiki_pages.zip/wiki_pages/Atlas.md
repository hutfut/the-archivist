# Atlas

The endgame map UI.

Endgame Map Legend

The **Atlas** is the primary endgame system of [Path of Exile 2](/wiki/Path_of_Exile_2 "Path of Exile 2"). The atlas is infinite and expands in all directions.

## Overview

At the center of the atlas stands the [The Ziggurat Refuge](/wiki/The_Ziggurat_Refuge "The Ziggurat Refuge"), an ancient [Vaal](/wiki/Vaal/edit?redlink=1 "Vaal (page does not exist)") research centre. The Ziggurat will serve as the exile's base of operations, from where they will open [portals](/wiki/Portal "Portal") to travel to nearby locations. One in four maps contain a [map boss](/wiki/Map_boss "Map boss"). The rewards of the atlas are augmented by the [atlas passive tree](/wiki/Atlas_passive_tree "Atlas passive tree"). Areas containing a given [map mechanic](/wiki/Map_mechanic "Map mechanic") will be signified by their respective icons appearing over them on the atlas screen.

[Waystones](/wiki/Waystone "Waystone") are required to empower the [Map Device](/wiki/Map_Device "Map Device") to make [portals](/wiki/Portal "Portal"). The tier of the waystone determines the [level](/wiki/Monster_level "Monster level") of [monster](/wiki/Monster "Monster") encountered. [Maps](/wiki/Map "Map") adjacent to previously completed maps or the Ziggurat will be avaliable to use waystones on, opening six portals to the location. All [rare](/wiki/Rare "Rare") and [unique](/wiki/Unique "Unique") enemies in the area need to be defeated to complete the map. If the player runs out of portals, or die, the map will be marked as failed. Any additional encounters on the map such as bosses and map mechanics are removed when you re-run the map.

The atlas is divided into [Biomes](/wiki/Biome "Biome"). Most map tilesets are restricted to certain biomes. Cities of various civilizations are scattered throughout the atlas; maps in those cities may drop items exclusive to those civilizations. Other structures, such as [The Reliquary Vault](/wiki/Reliquary_Vault "Reliquary Vault") and the [Realmgate](/wiki/Realmgate "Realmgate") may also be encountered. Some sections of the atlas are influenced by [Coalesced Corruption](/wiki/Coalesced_Corruption "Coalesced Corruption"), which adds +1 monster level to the affected maps, as well as potentially adding an additional modifier to the map.

Unique maps, like [Untainted Paradise](/wiki/Untainted_Paradise "Untainted Paradise") and [Moment of Zen](/wiki/Moment_of_Zen "Moment of Zen") may also be encountered. Various [hideouts](/wiki/Hideout "Hideout") can also appear as maps - completing these maps will unlock them as a layout for your personal hideout.

[Towers](/wiki/Tower "Tower") (also known as Precursor Towers) are scattered across the atlas. Completing a tower will reveal a radius of maps around it. [Precursor tablets](/wiki/Precursor_tablet "Precursor tablet") are items that can be placed within towers and consumed to add specific mechanics to maps in the tower's radius. Towers may be encountered with overlapping areas of effect, allowing players to stack the effects of multiple tablets onto a single map. Towers themselves may have beneficial and difficulty-increasing modifiers that apply to maps in their range.

The Atlas is a personal progression system and it is not shared with other players even when in a party.

Players can bookmark and add labels to up to 16 nodes on the Atlas for quick location.

## Map encounters

Main article: [Encounter](/wiki/Encounter "Encounter")

Maps can contain one or more **[encounters](/wiki/Encounters "Encounters")** (map mechanics) which add optional content that can increase the challenge and rewards of affected maps. Some of these mechanics are introduced in the campaign, such as [Ritual](/wiki/Ritual "Ritual"), while others first appear in maps. Some encounter types will appear naturally on maps, like [Map Bosses](/wiki/Map_Boss "Map Boss"), while others can be added to maps via [Precursor Tablets](/wiki/Precursor_Tablet "Precursor Tablet") and [Towers](/wiki/Tower "Tower") (mentioned above).

## Pinnacle encounters

Main article: [Pinnacle encounter](/wiki/Pinnacle_encounter "Pinnacle encounter")

* [The Realmgate](/wiki/The_Realmgate "The Realmgate") is a structure that can consume [map fragments](/wiki/Map_fragment "Map fragment") to open endgame encounters.
* [The Burning Monolith](/wiki/The_Burning_Monolith "The Burning Monolith") is a structure that contains the most difficult content of the atlas. Three keys are required to enter, and each key can be obtained from defeating each faction's two lieutenants and the faction leader at each of the three citadels ([Iron](/wiki/The_Iron_Citadel "The Iron Citadel"), [Copper](/wiki/The_Copper_Citadel "The Copper Citadel"), and [Stone](/wiki/The_Stone_Citadel "The Stone Citadel")).
  + Citadels locations can be identified by structures on the Atlas itself at the Citadel and nearby map nodes.
