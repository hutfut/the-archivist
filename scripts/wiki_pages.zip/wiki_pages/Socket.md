# Socket

**Socket** may refer to:

* [Gem socket](/wiki/Gem_socket "Gem socket"), found in the skills menu interface, and can be socketed with [skill gems](/wiki/Skill_gem "Skill gem") and [support gems](/wiki/Support_gem "Support gem")
* [Augment socket](/wiki/Augment_socket "Augment socket"), (or rune socket) found on [equipment](/wiki/Equipment "Equipment"), and can be socketed with [augments](/wiki/Augment "Augment") such as [runes](/wiki/Rune "Rune")
* [Jewel socket](/wiki/Jewel_socket "Jewel socket"), found on the [passive skill tree](/wiki/Passive_skill_tree "Passive skill tree"), and can be socketed with [jewels](/wiki/Jewel "Jewel")

This [disambiguation](https://en.wikipedia.org/wiki/Help:Disambiguation "wikipedia:Help:Disambiguation") page lists articles associated with the title **Socket**.
 If an [internal link](/wiki/Special:WhatLinksHere/Socket "Special:WhatLinksHere/Socket") led you here, you may wish to change the link to point directly to the intended article.
