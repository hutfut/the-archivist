# Druid

The Druid

Gender: M
[Strength](/wiki/Strength "Strength"): 11
[Dexterity](/wiki/Dexterity "Dexterity"): 7
[Intelligence](/wiki/Intelligence "Intelligence"): 11
[Weapon](/wiki/Weapon "Weapon"): [Primal Spells](/wiki/Gemcutting#Primal "Gemcutting")

* [Voltaic Staff](/wiki/Voltaic_Staff "Voltaic Staff")
* [Changeling Talisman](/wiki/Changeling_Talisman "Changeling Talisman")
* [Volcano](/wiki/Volcano "Volcano")

[Ascendancies](/wiki/Ascendancy_class "Ascendancy class"):

[Oracle](/wiki/Oracle "Oracle")
 [Shaman](/wiki/Shaman "Shaman")

The **Druid** is a [strength](/wiki/Strength "Strength")/[intelligence](/wiki/Intelligence "Intelligence")-oriented [class](/wiki/Character_class "Character class") that specializes in [shapeshifting](/wiki/Shapeshifting "Shapeshifting") and nature spells. He is of [Ezomyte](/wiki/Ezomyte/edit?redlink=1 "Ezomyte (page does not exist)") heritage, though he is an outcast and his lineage places more faith in the Draíocht than the First Ones.

The Druid obtains a [Voltaic Staff](/wiki/Voltaic_Staff "Voltaic Staff"), [Changeling Talisman](/wiki/Changeling_Talisman "Changeling Talisman") and [Volcano](/wiki/Volcano "Volcano") as his default starting weapon and skill in [The Riverbank](/wiki/The_Riverbank "The Riverbank").

## Ascendancy classes

Druids can specialize into one of these three [Ascendancy classes](/wiki/Ascendancy_classes "Ascendancy classes"):

* [Oracle](/wiki/Oracle "Oracle")
* [Shaman](/wiki/Shaman "Shaman")
* TBA
