# Ranger

The Ranger

Gender: F
[Strength](/wiki/Strength "Strength"): 7
[Dexterity](/wiki/Dexterity "Dexterity"): 15
[Intelligence](/wiki/Intelligence "Intelligence"): 7
[Weapon](/wiki/Weapon "Weapon"): [Bow](/wiki/Gemcutting#Bow "Gemcutting")

* [Crude Bow](/wiki/Crude_Bow "Crude Bow")
* [Broadhead Quiver](/wiki/Broadhead_Quiver "Broadhead Quiver")
* [Lightning Arrow](/wiki/Lightning_Arrow "Lightning Arrow")

[Ascendancies](/wiki/Ascendancy_class "Ascendancy class"):

[Deadeye](/wiki/Deadeye "Deadeye")
 [Pathfinder](/wiki/Pathfinder "Pathfinder")

> I've lived in this forest all my life, and if there's one thing I've learned, it's that a ranger must never miss.

The **Ranger** is a [dexterity](/wiki/Dexterity "Dexterity")-oriented [class](/wiki/Character_class "Character class") that specializes in agility and [bow](/wiki/Bow "Bow") skills. She is of [Ezomyte](/wiki/Ezomyte/edit?redlink=1 "Ezomyte (page does not exist)") heritage.

The Ranger obtains a [Crude Bow](/wiki/Crude_Bow "Crude Bow"), [Broadhead Quiver](/wiki/Broadhead_Quiver "Broadhead Quiver") and [Lightning Arrow](/wiki/Lightning_Arrow "Lightning Arrow") as her default starting weapon set and skill in [The Riverbank](/wiki/The_Riverbank "The Riverbank").

## Ascendancy classes

Rangers can specialize into one of these three [Ascendancy classes](/wiki/Ascendancy_classes "Ascendancy classes"):

* [Deadeye](/wiki/Deadeye "Deadeye")
* [Pathfinder](/wiki/Pathfinder "Pathfinder")
* TBA
