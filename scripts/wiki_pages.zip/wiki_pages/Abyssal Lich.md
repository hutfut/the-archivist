# Abyssal Lich

Abyssal Lich

[Witch](/wiki/Witch "Witch")

|  |  |
| --- | --- |
|  | **The Well of Souls is yours to command.** |

[File:Abyssal Lich official art.jpg](/index.php?title=Special:Upload&wpDestFile=Abyssal_Lich_official_art.jpg "File:Abyssal Lich official art.jpg")

Official artwork of the Abyssal Lich.

**Abyssal Lich** is an [alternate ascendancy class](/wiki/Alternate_ascendancy_class "Alternate ascendancy class") for the [Witch](/wiki/Witch "Witch").

## Unlocking

A character that has already ascended to be a [Lich](/wiki/Lich "Lich") can bring a [Kulemak's Invitation](/wiki/Kulemak%27s_Invitation "Kulemak's Invitation") to [the Well of Souls](/wiki/The_Well_of_Souls "The Well of Souls") and jump into the well. Doing so will take the player to [the Black Cathedral](/wiki/The_Black_Cathedral "The Black Cathedral"); after defeating [Vessel of Kulemak](/wiki/Vessel_of_Kulemak "Vessel of Kulemak"), the area will contains a urn with the displayed text "Embrace Abyssal Power?". Interacting with it allows the player to freely switch between the regular Lich ascendancy and the Abyssal Lich alternate ascendancy. The position of allocated ascendancy passives remain the same, though certain passives are changed.

Click to load content

## Overview

The Abyssal Lich is a [Lich](/wiki/Lich "Lich") that has absorbed the powers of the [Well of Souls](/wiki/Well_of_Souls "Well of Souls"), gaining the undying power of the [Abyssal](/wiki/Abyss "Abyss"), replacing some of its Ascendancy passives with alternates. [Necromantic Conduit](/wiki/Necromantic_Conduit "Necromantic Conduit") and [Blackened Heart](/wiki/Blackened_Heart "Blackened Heart") is replaced with [Umbral Well](/wiki/Umbral_Well "Umbral Well"), which replaces your Skeleton minions with different buffs, and [Unwilling Offering](/wiki/Unwilling_Offering "Unwilling Offering"), which allows you to use [Offering](/wiki/Offering "Offering") skills on enemies to [Cull](/wiki/Culling_Strike "Culling Strike") them and grant its effect to yourself instead of minions. [Price of Power](/wiki/Price_of_Power "Price of Power") is replaced with [Steward of Kulemak](/wiki/Steward_of_Kulemak "Steward of Kulemak"), which consumes [power charges](/wiki/Power_charge "Power charge") to summon an apparition that casts the same spell you used. [Rupture the Soul](/wiki/Rupture_the_Soul "Rupture the Soul") is replaced with [Rupture the Flesh](/wiki/Rupture_the_Flesh "Rupture the Flesh") which makes cursed enemies explode for physical damage instead of chaos.

## Passive skills

### Minor skills

This class has the following minor passive skills:

| Name | Stats |
| --- | --- |
| [Curse Area](/wiki/Curse_Area/edit?redlink=1 "Curse Area (page does not exist)") | 15% increased Area of Effect of [Curses](/wiki/Curse "Curse") [[1]](/wiki/Passive_Skill:AscendancyAltWitch3Small1 "Passive Skill:AscendancyAltWitch3Small1") [[2]](/wiki/Passive_Skill:AscendancyAltWitch3Small2 "Passive Skill:AscendancyAltWitch3Small2") |
| [Energy Shield](/wiki/Energy_Shield "Energy Shield") | 20% increased maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") [[1]](/wiki/Passive_Skill:AscendancyAltWitch3Small7~ "Passive Skill:AscendancyAltWitch3Small7~") [[2]](/wiki/Passive_Skill:AscendancyAltWitch3Small9 "Passive Skill:AscendancyAltWitch3Small9") |
| [Energy Shield if Consumed Power Charge](/wiki/Energy_Shield_if_Consumed_Power_Charge/edit?redlink=1 "Energy Shield if Consumed Power Charge (page does not exist)") | 30% increased maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") if you've consumed a [Power Charge](/wiki/Power_Charge "Power Charge") [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:AscendancyAltWitch3Small8 "Passive Skill:AscendancyAltWitch3Small8") |
| [Life](/wiki/Life_(passive_skill) "Life (passive skill)") | 3% increased maximum Life [[1]](/wiki/Passive_Skill:AscendancyAltWitch3Small5 "Passive Skill:AscendancyAltWitch3Small5") [[2]](/wiki/Passive_Skill:AscendancyAltWitch3Small6 "Passive Skill:AscendancyAltWitch3Small6") |
| [Minion Duration](/wiki/Minion_Duration/edit?redlink=1 "Minion Duration (page does not exist)") | 15% increased Minion Duration [[1]](/wiki/Passive_Skill:AscendancyAltWitch3Small3 "Passive Skill:AscendancyAltWitch3Small3") |
| [Minion Reservation Efficiency](/wiki/Minion_Reservation_Efficiency/edit?redlink=1 "Minion Reservation Efficiency (page does not exist)") | 6% increased [Reservation](/wiki/Reservation "Reservation") [Efficiency](/wiki/Efficiency "Efficiency") of [Minion](/wiki/Minion "Minion") Skills [[1]](/wiki/Passive_Skill:AscendancyAltWitch3Small4 "Passive Skill:AscendancyAltWitch3Small4") |

### Notable skills

This class has the following notable passive skills:

| Skill | Modifiers | Prerequisite | Preceding Passive |
| --- | --- | --- | --- |
| [Umbral Well](/wiki/Umbral_Well "Umbral Well") | Skeletal [Minions](/wiki/Minion "Minion") you would create instead grant you [Umbral Souls](/wiki/Umbral_Souls "Umbral Souls") for each [Minion](/wiki/Minion "Minion") you would have created | — | Minion Reservation Efficiency |
| [Unwilling Offering](/wiki/Unwilling_Offering "Unwilling Offering") | Your [Offerings](/wiki/Offering "Offering") can target Enemies in [Culling](/wiki/Cull "Cull") range Your [Offerings](/wiki/Offering "Offering") affect you instead of your [Minions](/wiki/Minion "Minion") [Offerings](/wiki/Offering "Offering") created by [Culling](/wiki/Cull "Cull") Enemies have 1% increased [Effect](/wiki/Buff "Buff") per [Power](/wiki/Power "Power") of [Culled](/wiki/Cull "Cull") Enemy | [Umbral Well](/wiki/Umbral_Well "Umbral Well") | Minion Duration |
| [Rupture the Flesh](/wiki/Rupture_the_Flesh "Rupture the Flesh") | [Cursed](/wiki/Curse "Curse") Enemies Killed by you, or by [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence"), have a 33% chance to Explode, dealing a quarter of their maximum Life as [Physical](/wiki/Physical "Physical") Damage | — | Curse Area |
| [Incessant Cacophony](/wiki/Incessant_Cacophony "Incessant Cacophony") | You can apply an additional [Curse](/wiki/Curse "Curse") [Curses](/wiki/Curse "Curse") you inflict have infinite Duration | [Rupture the Flesh](/wiki/Rupture_the_Flesh "Rupture the Flesh") | Curse Area |
| [Crystalline Phylactery](/wiki/Crystalline_Phylactery "Crystalline Phylactery") | 100% increased Effect of the Socketed [Jewel](/wiki/Jewel "Jewel") Can Socket a [non-Unique](/wiki/Rarity "Rarity") [Basic Jewel](/wiki/Basic_Jewel/edit?redlink=1 "Basic Jewel (page does not exist)") into the Phylactery 50% more Mana Cost of Skills if you have no [Energy Shield](/wiki/Energy_Shield "Energy Shield") | — | Energy Shield |
| [Eldritch Empowerment](/wiki/Eldritch_Empowerment "Eldritch Empowerment") | [Sacrifice](/wiki/Sacrifice_(keyword) "Sacrifice (keyword)") 5% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") when you Cast a [Spell](/wiki/Spell "Spell") [Spells](/wiki/Spell "Spell") for which this [Sacrifice](/wiki/Sacrifice_(keyword) "Sacrifice (keyword)") was fully made deal 30% more Damage [Sacrificing](/wiki/Sacrifice_(keyword) "Sacrifice (keyword)") [Energy Shield](/wiki/Energy_Shield "Energy Shield") does not interrupt [Recharge](/wiki/Energy_Shield "Energy Shield") | — | Energy Shield |
| [Steward of Kulemak](/wiki/Steward_of_Kulemak "Steward of Kulemak") | Grants Skill: [Abyssal Apparition](/wiki/Abyssal_Apparition "Abyssal Apparition") Damaging [Spells](/wiki/Spell "Spell") consume a [Power Charge](/wiki/Power_Charge "Power Charge") if able to trigger Abyssal Apparition | — | Energy Shield if Consumed Power Charge |
| [Soulless Form](/wiki/Soulless_Form "Soulless Form") | Regenerate Mana equal to 6% of maximum Life per second No inherent Mana Regeneration 10% of Damage taken bypasses [Energy Shield](/wiki/Energy_Shield "Energy Shield") | — | Life |
| [Eternal Life](/wiki/Eternal_Life "Eternal Life") | Your Life cannot change while you have [Energy Shield](/wiki/Energy_Shield "Energy Shield") | [Soulless Form](/wiki/Soulless_Form "Soulless Form") | Life |
