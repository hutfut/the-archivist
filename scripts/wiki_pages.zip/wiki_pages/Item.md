# Item

**Items** are ingame objects that can be picked up and placed into the character's [Inventory](/wiki/Inventory "Inventory"). Examples of items include [equipment](/wiki/Equipment "Equipment"), [currency](/wiki/Currency "Currency"), [flasks](/wiki/Flask "Flask"), [jewels](/wiki/Jewel "Jewel"), [skill gems](/wiki/Skill_gem "Skill gem"), [waystones](/wiki/Waystone "Waystone"), [relics](/wiki/Relic "Relic"), and [socketables](/wiki/Socketable "Socketable").

## Rarity

**Rarity** is a category descriptor of an item's structural state within the item-generation and crafting process. For non-unique items, rarity determines how many affixes an item may have and how those affixes are grouped and constrained. For both non-unique and unique items, rarity also determines which crafting actions can be applied to them, with the exception of items that are unmodifiable by design or [sanctified](/wiki/Sanctified "Sanctified").

For modifiable items, rarity works under the following rules:

| Rarity | Description | Identification | Disenchant Output |
| --- | --- | --- | --- |
| Normal | * Have no affixes (prefixes and/or suffixes). * Can be upgraded to magic, rare, or unique with basic currency, special currency, and/or crafting benches from league mechanics. | Drop identified naturally. | N/A |
| Magic | * Have 1-2 affixes (prefixes and/or suffixes) naturally. * Affixes can be increased/reduced above/below 1-2 affixes via basic currency, special currency, and/or crafting benches from league mechanics. Increasing the affixes above 2 will upgrade the item's rarity to rare while reducing the affixes below 1 will retain the item's magic rarity. * Items such as non-unique [relics](/wiki/Relic "Relic") and [flasks](/wiki/Flask "Flask") cannot be upgraded to rare as they are capped at 2 modifiers. | Drop unidentified naturally. Exceptions include items acquired while affected by certain unique effects, strongbox modifiers, expedition remnant modifiers, or corruption. | [Transmutation Shard](/wiki/Transmutation_Shard "Transmutation Shard") |
| Rare | * Have 3+ affixes (prefixes and/or suffixes) naturally. * Affixes can be increased/reduced above/below 3-6 affixes via basic currency, special currency, and/or crafting benches from league mechanics. Reducing the affixes below 3 will retain the item's rare rarity. * Can be [sanctified](/wiki/Sanctified "Sanctified") with an [Omen of Sanctification](/wiki/Omen_of_Sanctification "Omen of Sanctification") and a [Divine Orb](/wiki/Divine_Orb "Divine Orb"). | [Regal Shard](/wiki/Regal_Shard "Regal Shard") (2 if it has 6+ affixes) |
| Unique | * Usually inherit the implicit modifiers of their base item if one exists. * Can have 1+ unique affixes, including exclusive affixes that are not otherwise available in the modifier pool for that given item basetype. * Can have variable modifiers out of a set list that are generated when the item drops. * Cannot have modifiers added or removed via basic currency, with the exception of corrupted vaal uniques which can have some affixes replaced with a [Vaal Cultivation Orb](/wiki/Vaal_Cultivation_Orb "Vaal Cultivation Orb"). | [Chance Shard](/wiki/Chance_Shard "Chance Shard") |

## Quality

Main article: [Quality](/wiki/Quality "Quality")

**Quality** is a stat that either improves existing or adds new modifiers to an item. It can be applied to equipment (except [quivers](/wiki/Quivers "Quivers"), [jewels](/wiki/Jewels "Jewels"), and [belts](/wiki/Belts "Belts")) and [skill gems](/wiki/Skill_gem "Skill gem"). Most items which can have quality have a default maximum of 20% quality, and some item classes can achieve up to 23% quality through [corruption](/wiki/Corrupted "Corrupted"). [Breach Ring](/wiki/Breach_Ring "Breach Ring")s can have up to 40% quality. Effects which grant a global increase to gem quality apply independently of this maximum.

Normal and unique items (including boss drops) of at least item level 78 can rarely drop with quality over 20% (up to 30%), which will state "Exceptional" in front of the base type until it is upgrade/identified. This temporary affix is also shared with items that drop with an additional [item socket](/wiki/Item_socket "Item socket") over the default maximum.

Quality is a unique multiplier to the related stat that is applied after all other modifiers, including [corruption](/wiki/Corrupted "Corrupted")/sanctification magnitude modifiers, and rounding. Values are truncated after the quality multiplier is applied.

| Item type | Currency | Effect per % quality |
| --- | --- | --- |
| [Martial weapons](/wiki/Martial_weapon "Martial weapon") | [Blacksmith's Whetstone](/wiki/Blacksmith%27s_Whetstone "Blacksmith's Whetstone") | 1% more local Physical Damage |
| [Wands](/wiki/Wand "Wand"), [Sceptres](/wiki/Sceptre "Sceptre"), and [Staves](/wiki/Staff "Staff") | [Arcanist's Etcher](/wiki/Arcanist%27s_Etcher "Arcanist's Etcher") | +1% to inherent skill quality[[a]](#cite_note-Skill_quality-1) |
| [Armour (equipment)](/wiki/Armour_(equipment) "Armour (equipment)") | [Armourer's Scrap](/wiki/Armourer%27s_Scrap "Armourer's Scrap") | 1% more local [Defence](/wiki/Defence "Defence") |
| [Amulets](/wiki/Amulet "Amulet") and [Rings](/wiki/Ring "Ring") | [Catalyst](/wiki/Catalyst "Catalyst") | 1% increased modifier magnitude Modifier tag varies by catalyst |
| [Flasks](/wiki/Flask "Flask") | [Glassblower's Bauble](/wiki/Glassblower%27s_Bauble "Glassblower's Bauble") | 1% more local Life/Mana Recovery |
| [Charms](/wiki/Charm "Charm") | N/A (as dropped)\* | 1% increased local Duration |
| [Skill gems](/wiki/Skill_gem "Skill gem") | [Gemcutter's Prism](/wiki/Gemcutter%27s_Prism "Gemcutter's Prism") | Varies by skill, either adding a new skill modifier or enhancing an existing one |

\*: Charm quality cannot be manually increased, though they can drop with quality and can have their quality modified through [corruption](/wiki/Corrupted "Corrupted").

## Item level

Many types of item have an **item level**. For modifiable items, this determines which affixes and tiers can roll on them.

Items dropped from [chests](/wiki/Chest "Chest") and other non-monster sources will equal the [area level](/wiki/Area_level "Area level"). Items from [monsters](/wiki/Monsters "Monsters") will usually drop at a drop level equal to the monster level, which itself usually is equal to the area level. However, drop level can be increased in certain ways:

* Items dropped by rare monsters have +1 to item level
* Items dropped by unique monsters have +2 to item level
* Maps that are [Irradiated](/wiki/Irradiated "Irradiated") grant +1 monster level to all monsters in the area
* Maps with [Coalesced Corruption](/wiki/Coalesced_Corruption "Coalesced Corruption") or [cleansed maps](/wiki/Cleansed_maps "Cleansed maps") can have a modifier that grant +1 monster level to all monsters in the area

### Drop level

Most items have a [drop level](/wiki/Drop_level "Drop level"), which indicates the minimum area level or monster level required for an item to be eligible to drop. Stronger base types generally have a higher drop level. For [equipment](/wiki/Equipment "Equipment"), the drop level usually matches the base item's required level, though there are some exceptions.

## Corrupted

Main article: [Corrupted](/wiki/Corrupted "Corrupted")

**Corrupted** items cannot be altered further through regular [crafting](/wiki/Crafting "Crafting") methods. The process of making something corrupted is referred to as corruption, which cannot be reversed.

## Sanctified

Main article: [Sanctified](/wiki/Sanctified "Sanctified")

**Sanctified** items represent an item that has been modified with an [Omen of Sanctification](/wiki/Omen_of_Sanctification "Omen of Sanctification"). Sanctified items cannot be modified by most crafting methods. They can be considered a more deterministic alternate version of corruption.

## Mirrored

Main article: [Mirrored](/wiki/Mirrored "Mirrored")

**Mirrored** items represent copies of an original and cannot be modified by most crafting methods. Mirrored items can be created by using a [Mirror of Kalandra](/wiki/Mirror_of_Kalandra "Mirror of Kalandra") on a non-mirrored item.

## Desecrated

Main article: [Desecrated modifier](/wiki/Desecrated_modifier "Desecrated modifier")

**Desecrated** items are items that have either a revealed or unrevealed desecrated modifier. They are generally obtained from [Abyss](/wiki/Abyss "Abyss")-related mechanics or from crafting items using [preserved bone](/wiki/Preserved_bone "Preserved bone") currency. Unrevealed desecrated items can be revealed at [the Well of Souls](/wiki/The_Well_of_Souls "The Well of Souls").

## Quest

**Quest** items are green-labeled objects that are obtained as part of a campaign or endgame questline and are designed either to be turned in to an NPC or consumed for a permanent reward. They do not follow the rarity system and are excluded from standard item-generation and crafting rules.

## Notes

1. [↑](#cite_ref-Skill_quality_1-0) As of [version 0.2.0](/wiki/Version_0.2.0 "Version 0.2.0"), inherent skills found on [wands](/wiki/Wand "Wand"), [sceptres](/wiki/Sceptre "Sceptre"), and [staves](/wiki/Staves "Staves") now gain an equivalent amount of quality as the weapon itself. This is correctly reflected in the Skills Panel, but is currently not reflected in the gem's hover tooltip.[Likely due to a [bug](https://www.pathofexile.com/forum/view-forum/2214)] Global quality effects apply to Wand/Sceptres/Staves and are reflected in both gem's hover tooltip as well as Skills Panel.
