# Holten

This article describes new Path of Exile 2 content released in [version 0.3.0](/wiki/Version_0.3.0 "Version 0.3.0"). Information may be missing or incorrect.

Please [expand this article](https://www.poe2wiki.net/wiki/Holten/edit) so that it provides complete and accurate information.

✍️This article is a [stub](/wiki/Category:Stubs "Category:Stubs"). Please help [improve the article](https://www.poe2wiki.net/wiki/Holten/edit) by expanding it.

Holten

area

|  |  |
| --- | --- |
| Id | [P1\_4](/wiki/Area:P1~4 "Area:P1~4") |
| Act | 6 |
| Area level | 55 |
| Bosses |  |
| Tags | EzomyteStrongbox, ezomyte\_shrine |
| Connections | [The Blackwood](/wiki/The_Blackwood "The Blackwood") [Wolvenhold](/wiki/Wolvenhold "Wolvenhold") [Holten Estate](/wiki/Holten_Estate "Holten Estate") |

*The fallen Thane and Lady of Holten serve a dark master.*

[File:Holten area screenshot.jpg](/index.php?title=Special:Upload&wpDestFile=Holten_area_screenshot.jpg "File:Holten area screenshot.jpg")

**Holten** is an area in [Interlude 1](/wiki/Interlude_1 "Interlude 1").

This area has a [waypoint](/wiki/Waypoint "Waypoint") and is connected to [The Blackwood](/wiki/The_Blackwood "The Blackwood"), [Wolvenhold](/wiki/Wolvenhold "Wolvenhold") and [Holten Estate](/wiki/Holten_Estate "Holten Estate").

## Area

TBD

### Points of interest

* [Boss Arena] **TBD**: A church is the arena of the [Sigbert of the Sullied Oath](/wiki/Sigbert_of_the_Sullied_Oath "Sigbert of the Sullied Oath") and [Godwin of the Shattered Creed](/wiki/Godwin_of_the_Shattered_Creed "Godwin of the Shattered Creed").
* [Notable Landmark] **The Ferryman**: [Soul of the Ferryman](/wiki/Soul_of_the_Ferryman "Soul of the Ferryman") sells various Greater [Runes](/wiki/Rune "Rune").

### Readables

* [Red Thane's Decree](/wiki/Red_Thane%27s_Decree/edit?redlink=1 "Red Thane's Decree (page does not exist)")
* [Psalm of Blood](/wiki/Psalm_of_Blood/edit?redlink=1 "Psalm of Blood (page does not exist)"): reading it spawns [Sigbert of the Sullied Oath](/wiki/Sigbert_of_the_Sullied_Oath "Sigbert of the Sullied Oath") and [Godwin of the Shattered Creed](/wiki/Godwin_of_the_Shattered_Creed "Godwin of the Shattered Creed")

## Monsters

* **[Sigbert of the Sullied Oath](/wiki/Sigbert_of_the_Sullied_Oath "Sigbert of the Sullied Oath")**
* **[Godwin of the Shattered Creed](/wiki/Godwin_of_the_Shattered_Creed "Godwin of the Shattered Creed")**
* TBD

## Item drops

The following [drop-restricted items](/wiki/Drop-restricted_item "Drop-restricted item") can drop in this area.

:   *No items include this area in their drop restrictions.*
