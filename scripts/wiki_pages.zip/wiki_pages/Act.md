# Act

**Acts** divide Path of Exile 2's storyline (or **Campaign**) into sections. Each act has its own [quests](/wiki/Quest "Quest"), [town](/wiki/Town "Town"), [NPCs](/wiki/NPC "NPC"), and an [act boss](/wiki/Act_boss "Act boss") at the end. Each following act applies a permanent -10% to elemental resistances, accumulating to -60% in the epilogue.

## Current acts

*See [Wraeclast](/wiki/Wraeclast "Wraeclast") for more information*

* [Act 1](/wiki/Act_1 "Act 1") - Ogham
* [Act 2](/wiki/Act_2 "Act 2") - Vastiri
* [Act 3](/wiki/Act_3 "Act 3") - Aggorat
* [Act 4](/wiki/Act_4 "Act 4") - Ngamakanui
* [Act 5](/wiki/Act_5 "Act 5") *(TBA)*
* [Act 6](/wiki/Act_6 "Act 6") *(TBA)*
* [Epilogue](/wiki/Epilogue "Epilogue")

### Interludes

Main article: [Interlude](/wiki/Interlude "Interlude")

Interlude is a temporary act put in place to fill in the gap between Act 4 and endgame during [Early Access](/wiki/Early_Access "Early Access"). It will be removed with the release of the full campaign.

* [Interlude 1](/wiki/Interlude_1 "Interlude 1") - The Curse of Holten
* [Interlude 2](/wiki/Interlude_2 "Interlude 2") - The Stolen Barya
* [Interlude 3](/wiki/Interlude_3 "Interlude 3") - Doryani's Contingency
