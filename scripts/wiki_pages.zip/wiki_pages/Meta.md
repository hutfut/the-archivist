# Meta

Meta Gems

Tooltip

Meta Gems are Skill Gems that can use, [Trigger](/wiki/Trigger "Trigger"), or otherwise apply the effects of other Skill Gems. Skill Gems and [Support Gems](/wiki/Support_Gem "Support Gem") can be socketed into them interchangeably, though most Meta Gems require at least one Skill Gem to be socketed to function.

**Meta** [skills](/wiki/Skill "Skill") are those that allow you to socket other active [skills](/wiki/Skills "Skills") as [support gems](/wiki/Support_gem "Support gem"). Meta gems are often used to [trigger](/wiki/Trigger "Trigger") active skills or change its functionality (for example, summoning a [totem](/wiki/Totem "Totem") that attacks with a socketed skill).

## Mechanics

[Support gems](/wiki/Support_gem "Support gem") socketed in a meta gem will support the meta gem and any other compatible socketed skill gems.

### Energy

Main article: [Energy](/wiki/Energy "Energy")

Most trigger meta gems generate and use [Energy](/wiki/Energy "Energy"), a counter that balances the frequency of triggering the skill based on its [use time](/wiki/Skill_speed "Skill speed"). The rate that Energy is obtained may be influenced by enemy [Power](/wiki/Power "Power"), a stat dependent on the enemy's [rarity](/wiki/Rarity "Rarity").

## Skills

The following skills have the Meta [gem tag](/wiki/Gem_tag "Gem tag"):

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Spellslinger](/wiki/Spellslinger "Spellslinger") | *0* |  |  |  |
| [Called Shots](/wiki/Called_Shots "Called Shots") | *0* |  |  |  |
| [Cast on Block](/wiki/Cast_on_Block "Cast on Block") | *0* |  |  |  |
| [Cast on Charm Use](/wiki/Cast_on_Charm_Use "Cast on Charm Use") | *0* |  |  |  |
| [Fire Spell on Hit](/wiki/Fire_Spell_on_Hit "Fire Spell on Hit") | *0* |  |  |  |
| [Mirage Deadeye](/wiki/Mirage_Deadeye "Mirage Deadeye") | *0* |  |  |  |
| [Thundergod's Wrath](/wiki/Thundergod%27s_Wrath "Thundergod's Wrath") | *0* |  |  |  |
| [Pounce](/wiki/Pounce "Pounce") | *3* |  |  |  |
| [Ferocious Roar](/wiki/Ferocious_Roar "Ferocious Roar") | *7* |  |  |  |
| [Spell Totem](/wiki/Spell_Totem "Spell Totem") | *7* |  |  |  |
| [Mirage Archer](/wiki/Mirage_Archer "Mirage Archer") | *8* |  |  |  |
| [Blasphemy](/wiki/Blasphemy "Blasphemy") | *8* |  |  |  |
| [Cast on Minion Death](/wiki/Cast_on_Minion_Death "Cast on Minion Death") | *8* |  |  |  |
| [Barrier Invocation](/wiki/Barrier_Invocation "Barrier Invocation") | *8* |  |  |  |
| [Elemental Invocation](/wiki/Elemental_Invocation "Elemental Invocation") | *8* |  |  |  |
| [Hand of Chayula](/wiki/Hand_of_Chayula "Hand of Chayula") | *9* |  |  |  |
| [Mortar Cannon](/wiki/Mortar_Cannon "Mortar Cannon") | *11* |  |  |  |
| [Ancestral Warrior Totem](/wiki/Ancestral_Warrior_Totem "Ancestral Warrior Totem") | *13* |  |  |  |
| [Cast on Critical](/wiki/Cast_on_Critical "Cast on Critical") | *14* |  |  |  |
| [Cast on Elemental Ailment](/wiki/Cast_on_Elemental_Ailment "Cast on Elemental Ailment") | *14* |  |  |  |
| [Cast on Dodge](/wiki/Cast_on_Dodge "Cast on Dodge") | *14* |  |  |  |
| [Feral Invocation](/wiki/Feral_Invocation "Feral Invocation") | *14* |  |  |  |
| [Reaper's Invocation](/wiki/Reaper%27s_Invocation "Reaper's Invocation") | *14* |  |  |  |
