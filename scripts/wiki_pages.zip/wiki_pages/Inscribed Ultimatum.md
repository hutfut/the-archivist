# Inscribed Ultimatum

Inscribed UltimatumArea Level: #
Number of Trials: #Mortals spend their lives wondering which
fate shall be theirs. Chaos takes amusement
in knowing the answer: all of them.Take this item to The Temple of Chaos to participate in a Trial of Chaos.

*Acquisition*
Drop level: *39**Metadata*
Item class: *Inscribed Ultimatum*
Metadata ID: *Metadata/Items/UltimatumKey*

**Inscribed Ultimatum** are items that can be used to access a [Trial of Chaos](/wiki/Trial_of_Chaos "Trial of Chaos"). Higher levels of Inscribed Ultimatum increase the number of trial rooms up to a maximum of 10.

## Mechanics

Inscribed Ultimatums can range from Area Level 39 to 80. The number of Trials corresponds to the Area Level:

* Area Level 39-59: 4 Trials
* Area Level 60-74: 7 Trials
* Area Level 75-80: 10 Trials

Additionally, Area Level 75-80 Inscribed Ultimatums will also display either Deadly, Victorious, or Cowardly beneath the number of Trials, indicating the final boss of the Trial of Chaos and their corresponding [Fate](/wiki/Fate "Fate") [key](/wiki/Key "Key") ([Deadly Fate](/wiki/Deadly_Fate "Deadly Fate") ([Bahlak, the Sky Seer](/wiki/Bahlak,_the_Sky_Seer "Bahlak, the Sky Seer")), [Victorious Fate](/wiki/Victorious_Fate "Victorious Fate") ([Chetza, the Feathered Plague](/wiki/Chetza,_the_Feathered_Plague "Chetza, the Feathered Plague")), or [Cowardly Fate](/wiki/Cowardly_Fate "Cowardly Fate") ([Uxmal, the Beastlord](/wiki/Uxmal,_the_Beastlord "Uxmal, the Beastlord"))).

Inscribed Ultimatums are typically only normal rarity and cannot be crafted. However, it is possible to drop [corrupted](/wiki/Corrupted "Corrupted") magic Inscribed Ultimatums from [the Trialmaster](/wiki/The_Trialmaster "The Trialmaster") that can have 2 affixes. The prefix provides a reward modifier, such as sacrificing [currency](/wiki/Currency "Currency") to recieve double on trial completion, while the suffix can roll dangerous area modifiers.

## Item acquisition

Inscribed Ultimatum can drop anywhere.
