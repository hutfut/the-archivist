# Receiving damage

**This article needs to be updated**.

**Reason:** This page was adapted from the sister page on poewiki. Mechanics may need to be re-tested to confirm the proper order of operations.

Please [update this article](https://www.poe2wiki.net/wiki/Receiving_damage/edit) to reflect newly available information. Relevant discussion may be found on [the talk page](/wiki/Talk:Receiving_damage "Talk:Receiving damage").

Receiving [damage](/wiki/Damage "Damage") involves several steps to determine whether the damage [hits](/wiki/Hit "Hit"), how much damage is dealt by the attacker, how much of that damage is prevented by the defender's mitigation, and what resources (e.g. [life](/wiki/Life "Life"), [energy shield](/wiki/Energy_shield "Energy shield")) are ultimately lost as a result.

## Order of operations

The list below displays the order of operations when an attacker attempts to damage a defender:

1. **Avoiding the hit:**
   * Manually avoiding hits via [movement](/wiki/Movement "Movement")
   * Damage avoidance frames from [dodge roll](/wiki/Dodge_roll "Dodge roll")
   * [Avoidance](/wiki/Avoidance/edit?redlink=1 "Avoidance (page does not exist)") of [projectiles](/wiki/Projectiles "Projectiles")
   * [Evasion](/wiki/Evasion "Evasion") against (vs [accuracy](/wiki/Accuracy "Accuracy") of) [attacks](/wiki/Attack "Attack") or [monster](/wiki/Monster "Monster") [skills](/wiki/Skill "Skill")

   These are the only defensive mechanics that prevent a hit from occurring, including preventing all on-hit effects. Other forms of mitigation cannot prevent a hit, even if they reduce damage taken to 0.
2. **Before being Hit:**
   Effects such as [Defiance of Destiny](/wiki/Defiance_of_Destiny "Defiance of Destiny")'s Gain #% of Missing Life before being Hit by an Enemy occur immediately after the defender fails to prevent the hit. (Regular when-hit or on-hit effects do not apply until after all other steps on this page.)
3. **Calculating unmitigated damage:**
   1. **Flat damage**
   * **Base damage** is typically the damage as found on [martial weapons](/wiki/Martial_weapon "Martial weapon") for [attacks](/wiki/Attack "Attack") or the [skill](/wiki/Skill "Skill") gem for [spells](/wiki/Spell "Spell"). [Unarmed](/wiki/Unarmed "Unarmed") attacks and [minions](/wiki/Minion "Minion") also have independent base damage.
   * **Added damage** (or **flat damage**) is damage added to a skill through conditional stats, [support gems](/wiki/Support_gem "Support gem"), [equipment](/wiki/Equipment "Equipment") (e.g. [rings](/wiki/Ring "Ring")), or certain skill mechanics such as [Flame Wall](/wiki/Flame_Wall "Flame Wall") with projectiles. Added damage is added to base damage before other modifiers.2. **Damage conversion**
   * Regular [conversion](/wiki/Conversion "Conversion") modifiers change a percentage of one [damage type](/wiki/Damage_type "Damage type")'s base+flat damage into another, for example #% of Physical Damage Converted to Fire Damage.
   * [Gain conversion](/wiki/Gain_conversion "Gain conversion") modifiers add a percentage of one damage type's base+flat damage as another damage type, for example Gain #% of Damage as Cold Damage.
   * All sources of conversion apply simultaneously, as a two-step process:
     + **Step 1**: Skill-based conversion occurs first. This includes conversion inherent to [skills](/wiki/Skill "Skill"), whether from [skill gems](/wiki/Skill_gem "Skill gem"), or skills granted by items or ([Ascendancy](/wiki/Ascendancy_class "Ascendancy class")) passive skills. This does not include global conversion effects (e.g. [Archmage](/wiki/Archmage "Archmage"), [Infernal Cry](/wiki/Infernal_Cry "Infernal Cry")) or conditional modifiers (e.g. [Detonating Arrow](/wiki/Detonating_Arrow "Detonating Arrow"), [Rapid Shot](/wiki/Rapid_Shot "Rapid Shot")).
     + **Step 2**: The resulting damage is then affected by conversion from global or conditional conversion, or conversion from [items](/wiki/Item "Item"), [buffs](/wiki/Buff "Buff"), [support gems](/wiki/Support_gem "Support gem"), or [passive skills](/wiki/Passive_skill "Passive skill").
       - Step 1 and Step 2 conversions are *not* additive. Regular conversion exceeding 100% of any original damage type is scaled down to 100%. [Damage types](/wiki/Damage_type "Damage type") cannot be converted to the same damage type3. **Damage multipliers**
   * All increased and reduced [modifiers](/wiki/Modifier "Modifier") stack additively, then applied as a single multiplier. This also includes conditional stats.
   * All more and less [modifiers](/wiki/Modifier "Modifier") apply independently, multiplicative against each other, unless the multiplier is from the same source (e.g. 10% more Damage per Stage would deal 50% more damage at 5 stages).Damage multipliers may be applied to enemies through effects like [Sap](/wiki/Sap/edit?redlink=1 "Sap (page does not exist)").

   :   * Modifiers to minimum or maximum damage range (e.g. [Heft](/wiki/Heft "Heft"), [Ryslatha's Coil](/wiki/Ryslatha%27s_Coil "Ryslatha's Coil"), [Wild Storm](/wiki/Wild_Storm "Wild Storm")) apply after conversion.

   4. **Critical hits**
   If a hit succeeds in landing a [critical hit](/wiki/Critical_hit "Critical hit"), the damage is multiplied by its critical damage bonus. By default, this is +100% (200%) of base damage, and can be modified further. The extra damage from critical damage bonus can be reduced by Take #% reduced Extra Damage from Critical Hits or Take no Extra Damage from Critical Hits (e.g. [The Brass Dome](/wiki/The_Brass_Dome "The Brass Dome")). For example, Take 60% reduced Extra Damage from Critical Hits will cause a critical hit from a monster with +200% critical damage bonus.
   If a hit that would deal a [critical hit](/wiki/Critical_hit "Critical hit") can be [evaded](/wiki/Evaded "Evaded"), the evasion check applies again at this step. If the evasion check succeeds, the critical hit is downgraded to a non-critical hit. This does not affect evasion's entropy value.5. **Rolling for damage:**
      After the previous multipliers are applied to the hit's minimum and maximum damage range, it now randomly chooses a number within this range. If the attacker's damage is [lucky](/wiki/Luck "Luck"), or damage against the defender is *unlucky*, damage rolls twice and ignores the lower value. Similarly, if the attacker's damage is *unlucky*, damage rolls twice and ignores the higher value. This does not affect rolls for other mechanics (e.g. crit, ailments, block, suppression).
   6. **Doubling/tripling damage:**
      Modifiers that [double or triple damage](/wiki/Double_damage/edit?redlink=1 "Double damage (page does not exist)") apply after other offensive damage modifiers.
4. **Cannot take damage:**
   Damage is removed by modifiers that make the defender unable to take damage, such as Cannot take Reflected Physical/Elemental Damage or [Proximal Tangibility](/wiki/Proximal_Tangibility "Proximal Tangibility"). This step is not considered 'preventing' damage (e.g. for [Wandering Reliquary](/wiki/Wandering_Reliquary "Wandering Reliquary")). It should not be confused with damage [immunity](/wiki/Immunity/edit?redlink=1 "Immunity (page does not exist)"), which applies later.
5. **Damage taken as/damage shift:**
   Incoming damage can be [taken as](/wiki/Damage_taken_as "Damage taken as") (or **shifted** to) another [damage type](/wiki/Damage_type "Damage type"). It is usually done by utilizing an item which offers the #% of X Damage taken as Y [modifier](/wiki/Modifier "Modifier") (e.g. [Cloak of Flame](/wiki/Cloak_of_Flame "Cloak of Flame")).
   This is **not** [conversion](/wiki/Conversion "Conversion"), though it is mechanically similar. Damage types can only be shifted once and all damage shift effects apply simultaneously. Additionally, damage shift is not proportional when exceeding 100% of a base damage type; for example, if a player has 120% physical to fire damage shift, they will take more base fire damage than they would have originally taken as physical. [[1]](#cite_note-1)
   Similar to conversion with damage modifiers, shifted damage is only affected by mitigation for its final damage type. For example, if physical damage is taken as fire, the shifted fire damage will not be affected by [physical damage reduction](/wiki/Physical_damage_reduction/edit?redlink=1 "Physical damage reduction (page does not exist)").
6. **Damage mitigation:**
   1. Cannot take X damage applies again here, preventing damage that wasn't already removed before the *damage taken as* step. This step does count as preventing damage.
   2. [Immunities](/wiki/Immunity/edit?redlink=1 "Immunity (page does not exist)") prevent 100% of damage, such as [Chaos Inoculation](/wiki/Chaos_Inoculation "Chaos Inoculation") preventing chaos damage.
   3. [Damage avoidance](/wiki/Avoidance/edit?redlink=1 "Avoidance (page does not exist)") offers a chance to prevent damage entirely, for example with [Elusive](/wiki/Elusive/edit?redlink=1 "Elusive (page does not exist)").
   4. [Damage reduction](/wiki/Damage_reduction "Damage reduction"), not to be confused with reduced damage taken,[[2]](#cite_note-2) mitigates damage types it exists for. By default, 'damage reduction' is only gained from [armour](/wiki/Armour "Armour") and #% additional Physical Damage Reduction against [physical](/wiki/Physical "Physical") damage, but certain modifiers or stats can allow damage reduction to apply to other damage types (e.g. [Blackbraid](/wiki/Blackbraid "Blackbraid") or [Doryani's Prototype](/wiki/Doryani%27s_Prototype "Doryani's Prototype")), or allow different stats to contribute to damage reduction (e.g. [Invoker](/wiki/Invoker "Invoker")'s [...and Protect me from Harm](/wiki/...and_Protect_me_from_Harm "...and Protect me from Harm")). Damage reduction occurs before resistances, unlike in POE1.[[3]](#cite_note-3)[[4]](#cite_note-4) and is calculated independently per damage type.[[5]](#cite_note-5)
   5. [Resistance](/wiki/Resistance "Resistance") mitigates [elemental](/wiki/Elemental "Elemental") and [chaos](/wiki/Chaos "Chaos") damage. Effects such as [exposure](/wiki/Exposure "Exposure") or area penalties apply here. The attacker's [penetration](/wiki/Penetration "Penetration") applies afterward to the final resistance value, though it cannot penetrate below 0% resistance. If the resistance is at 0% or negative, penetration has no effect.
7. **Modifying damage taken:**
   After damage mitigation has calculated base [damage taken](/wiki/Damage_taken "Damage taken"), modifiers to damage taken are applied.[[6]](#cite_note-6) Flat modifiers are applied first, then the sum of all increases/reductions, and lastly all more or less multipliers independently:

   | Order | [Modifier](/wiki/Modifier "Modifier") | Examples |
   | --- | --- | --- |
   | 1 | ±# X Damage taken from Y | [Ashrend](/wiki/Ashrend "Ashrend")   [Astramentis](/wiki/Astramentis "Astramentis") |
   | 2 | #% increased/reduced X Damage taken | [Shock](/wiki/Shock "Shock")   [Withered](/wiki/Withered "Withered")   [Intimidate](/wiki/Intimidate "Intimidate") |
   | 3 | #% more/less X Damage taken | [Toughness](/wiki/Toughness "Toughness")   [The Dancing Mirage](/wiki/The_Dancing_Mirage "The Dancing Mirage")   [Wind Ward](/wiki/Wind_Ward "Wind Ward") |
8. **Stun and ailment thresholds:**

   [Stun](/wiki/Stun "Stun") and elemental [ailment](/wiki/Ailment "Ailment") chance/buildup is rolled based on damage at this point.
9. **Blocking the damage:**

   [Block](/wiki/Block "Block") rolls to prevent all damage from a hit, or a percentage of damage with modifiers like [Glancing Blows](/wiki/Glancing_Blows "Glancing Blows"). Block also prevents most of the attacker's on-hit effects, including [triggers](/wiki/Trigger "Trigger"). X when you Block effects occur in this step, before damage taken (if any). Block does not prevent [stun](/wiki/Stun "Stun") or [freeze](/wiki/Freeze "Freeze").
10. **Final damage taken:**

    Effects that count the amount of damage taken by the player use the damage value at this point. The difference between this damage and the damage at the start of the 'damage mitigation' step is considered *prevented* damage for effects like [Wandering Reliquary](/wiki/Wandering_Reliquary "Wandering Reliquary"). It does not include damage mitigation from block.
11. **Applying damage and losing resources:**
    Damage (or a portion thereof) is taken from resources in the following order. Any remaining damage will be taken from the next resource. Some effects allow damage to bypass a resource, in which case the bypassing damage will apply directly to the next resource instead.

    **From other entities or effects:**
    1. Effects that cause damage to take resources from other entities "before you", e.g. [Loyal Hellhound](/wiki/Loyal_Hellhound "Loyal Hellhound"). Each effect is multiplicative, not additive.
    2. Buffs that intercept damage to consume the buff "before your Life, (Mana) or Energy Shield", such as [Aegises](/wiki/Aegis/edit?redlink=1 "Aegis (page does not exist)"), [Obsessive Rituals](/wiki/Obsessive_Rituals "Obsessive Rituals"), or [Jade Heritage](/wiki/Jade_Heritage "Jade Heritage").**From the defender's resources:**
    1. Damage is taken from [energy shield](/wiki/Energy_shield "Energy shield") before [life](/wiki/Life "Life"), unless damage can bypass energy shield.
       * [Chaos Damage](/wiki/Chaos_Damage "Chaos Damage") inherently removes twice as much energy shield as the damage value. This does not affect the actual damage dealt.
       * [Bleeding](/wiki/Bleeding "Bleeding") and [Poison](/wiki/Poison "Poison") deal damage over time bypassing energy shield.
       * Energy shield recharge is interrupted when energy shield or the resource it is protecting is lost due to damage, unless recharge explicitly cannot be interrupted (e.g. [Energy Barrier](/wiki/Energy_Barrier "Energy Barrier")).
       * If [Eternal Youth](/wiki/Eternal_Youth "Eternal Youth") is allocated, only directly losing life due to damage will interrupt life recharge. Life loss over time (e.g. from [Grasping Wounds](/wiki/Grasping_Wounds "Grasping Wounds")) does not interrupt life recharge. Spending or sacrificing life does not interrupt recharge.
    2. #% of the remaining damage is removed from mana, if granted by an effect such as [Mind over Matter](/wiki/Mind_over_Matter "Mind over Matter").
    3. Life loss can be prevented by various effects. Effects that grant #% of life loss prevented are multiplicative rather than additive. Life loss cannot be further mitigated.
       1. #% of life loss from damage is prevented through [Grasping Wounds](/wiki/Grasping_Wounds "Grasping Wounds") and an equal amount of life loss is applied over time over 4 seconds.
       2. The remaining damage is removed from Life. Life does not protect any other resource. If all Life is removed, you die.
       3. Death from hits can be prevented (e.g. [The Barrow Dweller](/wiki/The_Barrow_Dweller "The Barrow Dweller")). This will leave the player at 1 life instead if the effect occurs. Death from damage over time, life loss over time, or instant death effects (e.g. [Drowning](/wiki/Drowning "Drowning")) cannot be prevented.

## Damage over time

[Damage over time](/wiki/Damage_over_time "Damage over time") generally follows the same principles; however, damage over time does not [hit](/wiki/Hit "Hit"), bypassing many hit-based defensive mechanics such as evasion, [armour](/wiki/Armour "Armour"), [block](/wiki/Block "Block"), etc. Damage over time occurs at the start of each server frame, before potential hit damage, though after over-time [recovery](/wiki/Recovery "Recovery").

While damaging [ailments](/wiki/Ailments "Ailments") are applied by hits, their damage is calculated as a percentage of the hit's damage before mitigations. This percentage is modified by ailment magnitude; no other damage multipliers will apply to prevent "double-dipping". Mitigation applies to damage over time after this independently of hit damage. This prevents debuffs like [ignite](/wiki/Ignite "Ignite") from scaling twice with stats like #% increased Fire damage, but also prevents it from being mitigated twice by Fire Resistance.
