# Act 2

Example overworld map of Act 2

Example underground map of Act 2

> The trail of Corruption leads east, so east we shall go. It seems fate conspires to return me to the Plains of Vastiri...
>
> The Hooded One

**Act Two** is [Path of Exile 2](/wiki/Path_of_Exile_2 "Path of Exile 2")'s second storyline [act](/wiki/Act "Act"), taking place in the deserts and ruins of the [Vastiri Plains](/wiki/Vastiri_Plains/edit?redlink=1 "Vastiri Plains (page does not exist)"). In this act, the exile assists a [Maraketh](/wiki/Maraketh "Maraketh") caravan in tracking down their enemies, the [Faridun](/wiki/Faridun "Faridun"), who have gained possession of a [Seed of Corruption](/wiki/Seed_of_Corruption/edit?redlink=1 "Seed of Corruption (page does not exist)"). The exile must retrace the steps of the legendary [Orbala](/wiki/Orbala/edit?redlink=1 "Orbala (page does not exist)") to combat the foul magic the Faridun use to hinder their path with unnatural sandstorms.

After confronting Jamanra at the Halani Gates, the progression in this act is split into three different routes which can be completed in any order. All three routes must be completed to progress forward. These routes permanently increase in area level when the unique bosses at the end of the other two routes are defeated.

## Quests

* [Earning Passage](/wiki/Earning_Passage "Earning Passage")
* [The Trail of Corruption](/wiki/The_Trail_of_Corruption_(Act_2) "The Trail of Corruption (Act 2)")
* [The Well of Souls](/wiki/The_Well_of_Souls_(quest) "The Well of Souls (quest)") (optional)
* [A Theft of Ivory](/wiki/A_Theft_of_Ivory "A Theft of Ivory")
* [The City of Seven Waters](/wiki/The_City_of_Seven_Waters "The City of Seven Waters")
* [A Crown of Stone](/wiki/A_Crown_of_Stone "A Crown of Stone")
* [Ancient Vows](/wiki/Ancient_Vows "Ancient Vows") (optional)
* [Ascent to Power](/wiki/Ascent_to_Power "Ascent to Power") (optional)
* [Tradition's Toll](/wiki/Tradition%27s_Toll "Tradition's Toll") (optional)

## Progression

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  |  |  | ↓ |
|  |  |  |  | [Vastiri Outskirts](/wiki/Vastiri_Outskirts "Vastiri Outskirts")   16  Boss: [Rathbreaker](/wiki/Rathbreaker "Rathbreaker") |  |  |
|  |  |  |  | ↕ |
| [Mawdun Mine](/wiki/Mawdun_Mine "Mawdun Mine")   18  Boss: [Rudja, the Dread Engineer](/wiki/Rudja,_the_Dread_Engineer "Rudja, the Dread Engineer") | ↔ | [Mawdun Quarry](/wiki/Mawdun_Quarry "Mawdun Quarry")   17 | ↔ | [The Ardura Caravan](/wiki/The_Ardura_Caravan "The Ardura Caravan") | | | ↔ | [Trial of the Sekhemas](/wiki/Trial_of_the_Sekhemas "Trial of the Sekhemas") |
|  |
| [The Halani Gates](/wiki/The_Halani_Gates "The Halani Gates")   20  Boss: [Jamanra, the Risen King](/wiki/Jamanra,_the_Risen_King "Jamanra, the Risen King") | ↔ | [Traitor's Passage](/wiki/Traitor%27s_Passage "Traitor's Passage")   19  Boss: [Balbala, the Traitor](/wiki/Balbala,_the_Traitor "Balbala, the Traitor") | ↔ | ↔ | [The Dreadnought](/wiki/The_Dreadnought "The Dreadnought")   31 | ↔ | [Dreadnought Vanguard](/wiki/Dreadnought_Vanguard "Dreadnought Vanguard")   32  Boss: [Jamanra, the Abomination](/wiki/Jamanra,_the_Abomination "Jamanra, the Abomination") |
|  |  |  | ⤢ | ↕ |  | ↕ | ⤡ |
| [Lightless Passage](/wiki/Lightless_Passage "Lightless Passage")   22 | ↔ | [Mastodon Badlands](/wiki/Mastodon_Badlands "Mastodon Badlands")   21-26 |  | [Valley of the Titans](/wiki/Valley_of_the_Titans "Valley of the Titans")   21-26 |  | [Keth](/wiki/Keth "Keth")   21-25  Boss: [Kabala, Constrictor Queen](/wiki/Kabala,_Constrictor_Queen "Kabala, Constrictor Queen") |  | [Deshar](/wiki/Deshar "Deshar")   28 |
| ↕ |  | ↕ |  | ↕ |  | ↕ |  | ↕ |
| [The Well of Souls](/wiki/The_Well_of_Souls "The Well of Souls")   22 |  | [The Bone Pits](/wiki/The_Bone_Pits "The Bone Pits")   22-27  Boss: [Iktab, the Deathlord](/wiki/Iktab,_the_Deathlord "Iktab, the Deathlord") and [Ekbab, Ancient Steed](/wiki/Ekbab,_Ancient_Steed "Ekbab, Ancient Steed") |  | [The Titan Grotto](/wiki/The_Titan_Grotto "The Titan Grotto")    22-27  Boss: [Zalmarath, the Colossus](/wiki/Zalmarath,_the_Colossus "Zalmarath, the Colossus") |  | [The Lost City](/wiki/The_Lost_City "The Lost City")  22-26 |  | [Path of Mourning](/wiki/Path_of_Mourning "Path of Mourning")   29 |
| ↓ |  |  |  |  |  | ↕ |  | ↕ |
| [The Black Cathedral](/wiki/The_Black_Cathedral "The Black Cathedral")   80 |  |  |  |  |  | [Buried Shrines](/wiki/Buried_Shrines "Buried Shrines")  23-27  Boss: [Azarian, the Forsaken Son](/wiki/Azarian,_the_Forsaken_Son "Azarian, the Forsaken Son") |  | [The Spires of Deshar](/wiki/The_Spires_of_Deshar "The Spires of Deshar")   30  Boss: [Tor Gul, the Defiler](/wiki/Tor_Gul,_the_Defiler "Tor Gul, the Defiler") |
