# Shadow

This article is about unreleased content and is not yet available in the game.

The Shadow

Gender: M
[Strength](/wiki/Strength "Strength"): 7
[Dexterity](/wiki/Dexterity "Dexterity"): 11
[Intelligence](/wiki/Intelligence "Intelligence"): 11

The **Shadow** is a [dexterity](/wiki/Dexterity "Dexterity")/[intelligence](/wiki/Intelligence "Intelligence")-oriented [class](/wiki/Character_class "Character class") that specializes in ? skills. On the official PoE2 website, The Shadow is called The Assassin in tooltips.

The Shadow obtains a **Module Error: No results found for item using search term "item\_name = "** and **Module Error: No results found for item using search term "item\_name = "** as his default starting weapon and skill in [The Riverbank](/wiki/The_Riverbank "The Riverbank").

## Ascendancy classes

Shadows can specialize into one of these three [Ascendancy classes](/wiki/Ascendancy_classes "Ascendancy classes"):

* TBA
* TBA
* TBA
