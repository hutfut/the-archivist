# Life

Life

Tooltip

Lost when you take damage of any Type.

If your Life falls to 0, you die.

**Life** (also named Health or Hit Points) is the main health source of a [character](/wiki/Character "Character") or [monster](/wiki/Monster "Monster") and it decreases when receiving damage; when it reaches 0% the entity [dies](/wiki/Die "Die").
For characters it means that it must be resurrected in [town](/wiki/Town "Town") or [checkpoint](/wiki/Checkpoint "Checkpoint"), for monsters it means complete death and it can be only revived by other monsters, or by players as a [minion](/wiki/Minion "Minion").
Players can [recover](/wiki/Recover "Recover") life by using [life flask](/wiki/Life_flask "Life flask"), gaining [life regeneration](/wiki/Life_regeneration "Life regeneration") from passive skills and equipment, or [leeching](/wiki/Leeching "Leeching") life from enemies. Life is also fully restored upon entering a [town](/wiki/Town "Town") or [hideout](/wiki/Hideout "Hideout").

## Mechanics

### Base stats

Life starts at 28 for level 1 characters, before factoring additional life from levels or [Strength](/wiki/Strength "Strength").

Characters gain +12 maximum Life per Player Level, +2 maximum Life per [Strength](/wiki/Strength "Strength").

### Low life

Players or Monsters are considered to be on **low life** if they are at 35% of maximum life or lower.

### Full life

The player is considered to be on **full life** if they are at 100% of maximum life or higher through [overflow](/wiki/Overflow "Overflow"), unless life is being [reserved](/wiki/Reserved "Reserved"). Life [recovery](/wiki/Recovery "Recovery") effects are typically removed when the player reaches or is at full life.

### Life recharge

Life Recharge

Tooltip

Lost Life will start Recharging at a rate of 12.5% per second after a base delay of 4 seconds. Further loss of Life resets this delay, interrupting Recharge.
Modifiers to Energy Shield [Recharge Rate](/wiki/Energy_Shield "Energy Shield") or to [how fast it starts](/wiki/Energy_Shield "Energy Shield") will also apply to Life Recharge.

[Eternal Youth](/wiki/Eternal_Youth "Eternal Youth") and [Tetzlapokal's Desire](/wiki/Tetzlapokal%27s_Desire "Tetzlapokal's Desire") allows life to recharge after not taking damage to life for a period of time, much in the same way [energy shield](/wiki/Energy_shield "Energy shield") recharge works. Life recharges at a rate of 12.5% of Life per second with a delay of 4 seconds. Modifiers to energy shield recharge rate and delay will also affect life recharge.

## Related unique items

### Unique items related to low life

| Item | Base item | Item class |  | Stats |
| --- | --- | --- | --- | --- |
| [Redbeak](/wiki/Redbeak "Redbeak") | [Shortsword](/wiki/Shortsword "Shortsword") | *[One Hand Sword](/wiki/One_Hand_Sword "One Hand Sword")* | 1 | Adds (4-6) to (7-10) [Physical](/wiki/Physical "Physical") Damage 10% increased [Attack](/wiki/Attack "Attack") Speed Gain 3 Life per Enemy Killed 100% increased [Attack](/wiki/Attack "Attack") Damage while on [Low Life](/wiki/Low_Life "Low Life") |
| [The Barrow Dweller](/wiki/The_Barrow_Dweller "The Barrow Dweller") | [Rogue Armour](/wiki/Rogue_Armour "Rogue Armour") | *[Body Armour](/wiki/Body_Armour "Body Armour")* | 11 | (60-100)% increased [Armour](/wiki/Armour "Armour") and [Evasion](/wiki/Evasion "Evasion") -(20-10)% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") +50% to [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance") Damage of Enemies Hitting you is Unlucky while you are on [Low Life](/wiki/Low_Life "Low Life") 50% chance to Avoid Death from [Hits](/wiki/Hit "Hit") |
| [Birthright Buckle](/wiki/Birthright_Buckle "Birthright Buckle") | [Wide Belt](/wiki/Wide_Belt "Wide Belt") | *[Belt](/wiki/Belt "Belt")* | 14 | Has (1-3) [Charm](/wiki/Charm "Charm") Slots (20-30)% increased [Flask](/wiki/Flask "Flask") Charges gained+(100-150) to [Armour](/wiki/Armour "Armour") (15-10)% reduced [Flask](/wiki/Flask "Flask") Charges used (20-30)% increased [Flask](/wiki/Flask "Flask") Charges gained Life [Flasks](/wiki/Flask "Flask") used while on [Low Life](/wiki/Low_Life "Low Life") apply Recovery Instantly Mana [Flasks](/wiki/Flask "Flask") used while on [Low Mana](/wiki/Low_Mana "Low Mana") apply Recovery Instantly |
| [Serpent's Lesson](/wiki/Serpent%27s_Lesson "Serpent's Lesson") | [Tonal Focus](/wiki/Tonal_Focus "Tonal Focus") | *[Focus](/wiki/Focus "Focus")* | 22 | +(60-100) to maximum Life +(60-100) to maximum Mana You count as on [Low Life](/wiki/Low_Life "Low Life") while at 35% of maximum Mana or below You count as on [Low Mana](/wiki/Low_Mana "Low Mana") while at 35% of maximum Life or below |
| [Wondertrap](/wiki/Wondertrap "Wondertrap") | [Silk Slippers](/wiki/Silk_Slippers "Silk Slippers") | *[Boots](/wiki/Boots "Boots")* | 27 | (10-20)% increased Movement Speed +(30-50) to maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") +(10-20) to [Strength](/wiki/Strength "Strength") +(10-20) to [Dexterity](/wiki/Dexterity "Dexterity") +(10-20) to [Intelligence](/wiki/Intelligence "Intelligence") 50% increased [Rarity](/wiki/Rarity "Rarity") of Items found when on [Low Life](/wiki/Low_Life "Low Life") |
| [Rise of the Phoenix](/wiki/Rise_of_the_Phoenix "Rise of the Phoenix") | [Omen Crest Shield](/wiki/Omen_Crest_Shield "Omen Crest Shield") | *[Shield](/wiki/Shield "Shield")* | 36 | +5% to [Maximum Fire Resistance](/wiki/Maximum_Fire_Resistance "Maximum Fire Resistance") +(20-25)% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") +25% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") while on [Low Life](/wiki/Low_Life "Low Life") Regenerate 3% of maximum Life per second Regenerate 3% of maximum Life per second while on [Low Life](/wiki/Low_Life "Low Life") |
| [Coward's Legacy](/wiki/Coward%27s_Legacy "Coward's Legacy") | [Mail Belt](/wiki/Mail_Belt "Mail Belt") | *[Belt](/wiki/Belt "Belt")* | 40 | Has (1-3) [Charm](/wiki/Charm "Charm") Slots (15-10)% reduced [Flask](/wiki/Flask "Flask") Charges used-(20-10) to [Strength](/wiki/Strength "Strength") +(20-30) to [Dexterity](/wiki/Dexterity "Dexterity") (30-40)% increased Life and Mana Recovery from [Flasks](/wiki/Flask "Flask") You are considered on [Low Life](/wiki/Low_Life "Low Life") while at 75% of maximum Life or below instead |
| [Starkonja's Head](/wiki/Starkonja%27s_Head "Starkonja's Head") | [Leatherbound Hood](/wiki/Leatherbound_Hood "Leatherbound Hood") | *[Helmet](/wiki/Helmet "Helmet")* | 50 | (100-200)% increased [Evasion](/wiki/Evasion "Evasion") Rating (15-25)% increased [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance +(30-40) to [Dexterity](/wiki/Dexterity "Dexterity") 150% increased Global [Evasion](/wiki/Evasion "Evasion") Rating when on [Low Life](/wiki/Low_Life "Low Life") 15% of Damage from [Hits](/wiki/Hit "Hit") is taken from your Damageable [Companion](/wiki/Companion "Companion")'s Life before you |
| [The Unborn Lich](/wiki/The_Unborn_Lich "The Unborn Lich") | [Ravenous Staff](/wiki/Ravenous_Staff "Ravenous Staff") | *[Staff](/wiki/Staff "Staff")* | 78 | (60-80)% increased [Desecrated Modifier](/wiki/Desecrated_modifier "Desecrated modifier") magnitudes <Custom Desecrated prefix> <Lich's Desecrated prefix> <Lich's Desecrated suffix> <Lich's Desecrated prefix or suffix>   | <List of mods> | | --- | | (86-99)% increased [Fire](/wiki/Fire "Fire") Damage (14-23)% increased [Ignite](/wiki/Ignite "Ignite") [Magnitude](/wiki/Magnitude "Magnitude")  ---  (25-40)% chance to build an additional [Combo](/wiki/Combo "Combo") on [Hit](/wiki/Hit "Hit")  ---  (86-99)% increased [Cold](/wiki/Cold "Cold") Damage (14-23)% increased [Freeze](/wiki/Freeze "Freeze") Buildup  ---  Recover (4-6)% of Maximum Mana when you expend at least 10 [Combo](/wiki/Combo "Combo")  ---  (86-99)% increased [Lightning](/wiki/Lightning "Lightning") Damage (14-23)% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Shock](/wiki/Shock "Shock") you inflict  ---  Recover (6-12)% of Maximum Life when you expend at least 10 [Combo](/wiki/Combo "Combo")  ---  +(35-50) to [Spirit](/wiki/Spirit "Spirit")  ---  (148-178)% increased [Spell](/wiki/Spell "Spell") Damage with [Spells](/wiki/Spell "Spell") that cost Life  ---  (25-35)% increased [Archon](/wiki/Archon "Archon") Buff duration  ---  +(12-16)% to [Block](/wiki/Block "Block") chance  ---  (25-35)% of [Spell](/wiki/Spell "Spell") Mana Cost [Converted](/wiki/Stat_conversion "Stat conversion") to Life Cost  ---  +(1-2) to maximum number of [Elemental Infusions](/wiki/Elemental_Infusion "Elemental Infusion")  ---  (4-5)% increased [Spell](/wiki/Spell "Spell") Damage per 100 maximum Mana  ---  [Archon](/wiki/Archon "Archon") recovery period expires (25-35)% faster  ---  (26-36)% increased Cast Speed while on Full Mana  ---  (40-64)% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") you inflict  ---  (4-5)% increased [Spell](/wiki/Spell "Spell") Damage per 100 Maximum Life  ---  (30-40)% increased Cast Speed when on [Low Life](/wiki/Low_Life "Low Life")  ---  (25-35)% chance for [Spell](/wiki/Spell "Spell") Skills to fire 2 additional [Projectiles](/wiki/Projectile "Projectile")  ---  (100-160)% increased [Chaos](/wiki/Chaos "Chaos") Damage Enemies you kill have a (5-10)% chance to explode, dealing a quarter of their maximum Life as [Chaos](/wiki/Chaos "Chaos") damage  ---  (100-160)% increased [Chaos](/wiki/Chaos "Chaos") Damage Enemies you [Curse](/wiki/Curse "Curse") have -(8-5)% to Chaos [Resistance](/wiki/Resistance "Resistance")  ---  (100-160)% increased [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") (10-20)% increased Duration of Elemental [Ailments](/wiki/Ailments "Ailments") on Enemies  ---  (100-160)% increased [Spell](/wiki/Spell "Spell") [Physical](/wiki/Physical "Physical") Damage (20-30)% chance to inflict [Bleeding](/wiki/Bleeding "Bleeding") on [Hit](/wiki/Hit "Hit")  ---  +(40-60) to [Spirit](/wiki/Spirit "Spirit") (6-10)% increased [Spirit](/wiki/Spirit "Spirit") [Reservation](/wiki/Reservation "Reservation") [Efficiency](/wiki/Efficiency "Efficiency") of Skills  ---  You have [Unholy Might](/wiki/Unholy_Might "Unholy Might") (28-56)% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Unholy Might](/wiki/Unholy_Might "Unholy Might") buffs you grant | |

### Unique items related to full life

| Item | Base item | Item class |  | Stats |
| --- | --- | --- | --- | --- |
| [Winter's Bite](/wiki/Winter%27s_Bite "Winter's Bite") | [Glass Shank](/wiki/Glass_Shank "Glass Shank") | *[Dagger](/wiki/Dagger "Dagger")* | 1 | No [Physical](/wiki/Physical "Physical") Damage Adds (8-10) to (15-18) [Cold](/wiki/Cold "Cold") Damage [Freezes](/wiki/Freeze "Freeze") Enemies that are on Full Life |
| [Foxshade](/wiki/Foxshade "Foxshade") | [Quilted Vest](/wiki/Quilted_Vest "Quilted Vest") | *[Body Armour](/wiki/Body_Armour "Body Armour")* | 4 | +(50-70) to [Evasion](/wiki/Evasion "Evasion") Rating +(20-30) to [Dexterity](/wiki/Dexterity "Dexterity") 10% increased Movement Speed when on Full Life 100% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") when on Full Life |
| [The Black Doubt](/wiki/The_Black_Doubt "The Black Doubt") | [Hexer's Robe](/wiki/Hexer%27s_Robe "Hexer's Robe") | *[Body Armour](/wiki/Body_Armour "Body Armour")* | 11 | (60-100)% increased [Energy Shield](/wiki/Energy_Shield "Energy Shield") +(10-30) to [Intelligence](/wiki/Intelligence "Intelligence") +(10-20)% to [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance") Damage over Time bypasses your [Energy Shield](/wiki/Energy_Shield "Energy Shield") While not on Full Life, [Sacrifice](/wiki/Sacrifice "Sacrifice") 10% of maximum Mana per Second to Recover that much Life |
| [Marohi Erqi](/wiki/Marohi_Erqi "Marohi Erqi") | [Totemic Greatclub](/wiki/Totemic_Greatclub "Totemic Greatclub") | *[Two Hand Mace](/wiki/Two_Hand_Mace "Two Hand Mace")* | 60 | [Warcries](/wiki/Warcry "Warcry") Empower an additional attack+150 [Strength](/wiki/Strength "Strength") Requirement (600-700)% increased [Physical](/wiki/Physical "Physical") Damage -(300-200) to [Accuracy](/wiki/Accuracy "Accuracy") Rating 35% reduced [Attack](/wiki/Attack "Attack") Speed Causes (40-60)% increased [Stun](/wiki/Stun "Stun") Buildup [Heavy Stuns](/wiki/Heavy_Stun "Heavy Stun") Enemies that are on Full Life |
