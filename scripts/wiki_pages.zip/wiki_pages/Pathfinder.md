# Pathfinder

Pathfinder

[Ranger](/wiki/Ranger "Ranger")

|  |  |
| --- | --- |
|  | **There are venoms and virtues aplenty in the wilds, if you know where to look.** |

Official artwork of the Pathfinder.

**Pathfinder** is an [Ascendancy class](/wiki/Ascendancy_class "Ascendancy class") for the [Ranger](/wiki/Ranger "Ranger").

## Overview

The Pathfinder is a survival specialist with a focus in [flasks](/wiki/Flask "Flask"), mobility, and flexibility with the [passive skill tree](/wiki/Passive_skill_tree "Passive skill tree"). [Enduring Elixirs](/wiki/Enduring_Elixirs "Enduring Elixirs") allows her life flasks to continue recovering her life even after recovering to full, and she can learn one of five Concoction skills to turn her mana flask into a source of damage. [Relentless Pursuit](/wiki/Relentless_Pursuit "Relentless Pursuit") and [Running Assault](/wiki/Running_Assault "Running Assault") keeps her mobile by mitigating effects that can reduce her movement speed or stop her entirely. The Pathfinder can gain a second starting point on the [passive skill tree](/wiki/Passive_skill_tree "Passive skill tree") with [Path Seeker](/wiki/Path_Seeker "Path Seeker") and gain additional choices of stat bonuses on the travel nodes from [Traveller's Wisdom](/wiki/Traveller%27s_Wisdom "Traveller's Wisdom"). Other passives include [Overwhelming Toxicity](/wiki/Overwhelming_Toxicity "Overwhelming Toxicity") to double the number of [poison](/wiki/Poison "Poison") stacks, and [Sustainable Practices](/wiki/Sustainable_Practices "Sustainable Practices") to gain elemental damage reduction from [evasion](/wiki/Evasion "Evasion").

## Passive skills

### Minor skills

This class has the following minor passive skills:

| Name | Stats |
| --- | --- |
| [Evasion](/wiki/Evasion_(passive_skill) "Evasion (passive skill)") | 20% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") [[1]](/wiki/Passive_Skill:AscendancyRanger3Small5 "Passive Skill:AscendancyRanger3Small5") |
| [Life Flask Charges](/wiki/Life_Flask_Charges/edit?redlink=1 "Life Flask Charges (page does not exist)") | 20% increased Life [Flask](/wiki/Flask "Flask") Charges gained [[1]](/wiki/Passive_Skill:AscendancyRanger3Small6 "Passive Skill:AscendancyRanger3Small6") |
| [Mana Flask Charges](/wiki/Mana_Flask_Charges/edit?redlink=1 "Mana Flask Charges (page does not exist)") | 20% increased Mana [Flask](/wiki/Flask "Flask") Charges gained [[1]](/wiki/Passive_Skill:AscendancyRanger3Small7 "Passive Skill:AscendancyRanger3Small7") |
| [Passive Points](/wiki/Passive_Points/edit?redlink=1 "Passive Points (page does not exist)") | Grants 1 Passive Skill Point [[1]](/wiki/Passive_Skill:AscendancyRanger3Small8 "Passive Skill:AscendancyRanger3Small8") [[2]](/wiki/Passive_Skill:AscendancyRanger3Small9 "Passive Skill:AscendancyRanger3Small9") |
| [Poison Effect](/wiki/Poison_Effect/edit?redlink=1 "Poison Effect (page does not exist)") | 12% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Poison](/wiki/Poison "Poison") you inflict [[1]](/wiki/Passive_Skill:AscendancyRanger3Small1 "Passive Skill:AscendancyRanger3Small1") [[2]](/wiki/Passive_Skill:AscendancyRanger3Small2 "Passive Skill:AscendancyRanger3Small2") |
| [Skill Speed](/wiki/Skill_Speed "Skill Speed") | 4% increased [Skill Speed](/wiki/Skill_Speed "Skill Speed") [[1]](/wiki/Passive_Skill:AscendancyRanger3Small3 "Passive Skill:AscendancyRanger3Small3") [[2]](/wiki/Passive_Skill:AscendancyRanger3Small4 "Passive Skill:AscendancyRanger3Small4") |

### Notable skills

This class has the following notable passive skills:

| Skill | | Modifiers | Prerequisite | Preceding Passive |
| --- | --- | --- | --- | --- |
| [Enduring Elixirs](/wiki/Enduring_Elixirs "Enduring Elixirs") | | Life [Flask](/wiki/Flask "Flask") Effects are not removed when [Unreserved](/wiki/Reservation "Reservation") Life is Filled Life [Flask](/wiki/Flask "Flask") Effects do not Queue | — | [Life Flask Charges](/wiki/Life_Flask_Charges_(ascendancy_passive_skill) "Life Flask Charges (ascendancy passive skill)") |
| [Sustainable Practices](/wiki/Sustainable_Practices "Sustainable Practices") | | 50% of [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") also grants [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") reduction |  | [Evasion](/wiki/Evasion_(ascendancy_passive_skill) "Evasion (ascendancy passive skill)") |
| [Path Seeker](/wiki/Path_Seeker "Path Seeker") | [Path of the Sorceress](/wiki/Path_of_the_Sorceress "Path of the Sorceress") | Grants 4 Passive Skill Points Can Allocate Passives from the Sorceress's starting point | — | [Passive Points](/wiki/Passive_Points_(ascendancy_passive_skill) "Passive Points (ascendancy passive skill)") |
| [Path of the Warrior](/wiki/Path_of_the_Warrior "Path of the Warrior") | Grants 4 Passive Skill Points Can Allocate Passives from the Warrior's starting point |
| [Traveller's Wisdom](/wiki/Traveller%27s_Wisdom "Traveller's Wisdom") | | Attribute Passive Skills can instead grant 5% increased Damage Attribute Passive Skills can instead grant 5% increased [Defences](/wiki/Defences "Defences") Attribute Passive Skills can instead grant 5% increased Cost [Efficiency](/wiki/Efficiency "Efficiency") | [Path Seeker](/wiki/Path_Seeker "Path Seeker") | [Passive Points](/wiki/Passive_Points_(ascendancy_passive_skill) "Passive Points (ascendancy passive skill)") |
| [Brew Concoction](/wiki/Brew_Concoction "Brew Concoction") | [Explosive Concoction](/wiki/Explosive_Concoction_(passive) "Explosive Concoction (passive)") | Grants Skill: [Explosive Concoction](/wiki/Explosive_Concoction "Explosive Concoction") | — | [Mana Flask Charges](/wiki/Mana_Flask_Charges_(ascendancy_passive_skill) "Mana Flask Charges (ascendancy passive skill)") |
| [Shattering Concoction](/wiki/Shattering_Concoction_(passive) "Shattering Concoction (passive)") | Grants Skill: [Shattering Concoction](/wiki/Shattering_Concoction "Shattering Concoction") |
| [Fulminating Concoction](/wiki/Fulminating_Concoction_(passive) "Fulminating Concoction (passive)") | Grants Skill: [Fulminating Concoction](/wiki/Fulminating_Concoction "Fulminating Concoction") |
| [Acidic Concoction](/wiki/Acidic_Concoction_(passive) "Acidic Concoction (passive)") | Grants Skill: [Acidic Concoction](/wiki/Acidic_Concoction "Acidic Concoction") |
| [Bleeding Concoction](/wiki/Bleeding_Concoction_(passive) "Bleeding Concoction (passive)") | Grants Skill: [Bleeding Concoction](/wiki/Bleeding_Concoction "Bleeding Concoction") |
| [Overwhelming Toxicity](/wiki/Overwhelming_Toxicity "Overwhelming Toxicity") | | Double the number of your [Poisons](/wiki/Poison "Poison") that targets can be affected by at the same time 35% less [Poison](/wiki/Poison "Poison") Duration | — | [Poison Effect](/wiki/Poison_Effect_(ascendancy_passive_skill) "Poison Effect (ascendancy passive skill)") |
| [Relentless Pursuit](/wiki/Relentless_Pursuit "Relentless Pursuit") | | Your speed is unaffected by [Slows](/wiki/Slow "Slow") | — | [Skill Speed](/wiki/Skill_Speed_(ascendancy_passive_skill) "Skill Speed (ascendancy passive skill)") |
| [Running Assault](/wiki/Running_Assault "Running Assault") | | 50% less Movement Speed Penalty from using Skills while moving Cannot be [Heavy Stunned](/wiki/Heavy_Stun "Heavy Stun") while Sprinting | [Relentless Pursuit](/wiki/Relentless_Pursuit "Relentless Pursuit") | [Skill Speed](/wiki/Skill_Speed_(ascendancy_passive_skill) "Skill Speed (ascendancy passive skill)") |
