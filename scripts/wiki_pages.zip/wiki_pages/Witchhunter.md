# Witchhunter

Witchhunter

[Mercenary](/wiki/Mercenary "Mercenary")

|  |  |
| --- | --- |
|  | **There's something very wrong with this world... and you're going to fix it.** |

Official artwork of the Witchhunter.

**Witchhunter** is an [Ascendancy class](/wiki/Ascendancy_class "Ascendancy class") for the [Mercenary](/wiki/Mercenary "Mercenary").

## Overview

The Witchhunter has access to passives that grant general offensive bonuses, as well as specialized bonuses towards certain types of enemies. The Witchhunter is a potent boss killer, with access to [Culling Strike](/wiki/Culling_Strike "Culling Strike") and [Decimating Strike](/wiki/Decimating_Strike "Decimating Strike") to remove a chunk of their life, and the ability to reduce the enemy's [Concentration](/wiki/Concentration "Concentration") and make them more vulnerable to damage and use their special abilities less frequently as you continue to hurt them. [Sorcery Ward](/wiki/Sorcery_Ward "Sorcery Ward") gives him an elemental barrier in exchange for armour and evasion, [Zealous Inquisition](/wiki/Zealous_Inquisition "Zealous Inquisition") adds pack-clearing power with infrequent but powerful on-kill explosions, and [Weapon Master](/wiki/Weapon_Master "Weapon Master") allows for more variety between weapon set passive trees.

## Passive skills

### Minor skills

This class has the following minor passive skills:

| Name | Stats |
| --- | --- |
| [Area of Effect](/wiki/Area_of_Effect "Area of Effect") | 8% increased Area of Effect [[1]](/wiki/Passive_Skill:AscendancyMercenary2Small7 "Passive Skill:AscendancyMercenary2Small7") |
| [Armour and Evasion](/wiki/Armour_and_Evasion/edit?redlink=1 "Armour and Evasion (page does not exist)") | 15% increased [Armour](/wiki/Armour "Armour") and [Evasion](/wiki/Evasion "Evasion") Rating [[1]](/wiki/Passive_Skill:AscendancyMercenary2Small5 "Passive Skill:AscendancyMercenary2Small5") [[2]](/wiki/Passive_Skill:AscendancyMercenary2Small6 "Passive Skill:AscendancyMercenary2Small6") |
| [Cooldown Recovery Rate](/wiki/Cooldown_Recovery_Rate "Cooldown Recovery Rate") | 6% increased [Cooldown Recovery Rate](/wiki/Cooldown_Recovery_Rate "Cooldown Recovery Rate") [[1]](/wiki/Passive_Skill:AscendancyMercenary2Small3 "Passive Skill:AscendancyMercenary2Small3") [[2]](/wiki/Passive_Skill:AscendancyMercenary2Small4 "Passive Skill:AscendancyMercenary2Small4") [[3]](/wiki/Passive_Skill:AscendancyMercenary2Small8~ "Passive Skill:AscendancyMercenary2Small8~") |
| [Damage vs Low Life Enemies](/wiki/Damage_vs_Low_Life_Enemies "Damage vs Low Life Enemies") | 35% increased Damage with [Hits](/wiki/Hit "Hit") against Enemies that are on [Low Life](/wiki/Low_Life "Low Life") [[1]](/wiki/Passive_Skill:AscendancyMercenary2Small1 "Passive Skill:AscendancyMercenary2Small1") [[2]](/wiki/Passive_Skill:AscendancyMercenary2Small2 "Passive Skill:AscendancyMercenary2Small2") |

### Notable skills

This class has the following notable passive skills:

| Skill | Modifiers | Prerequisite | Preceding Passive |
| --- | --- | --- | --- |
| [Weapon Master](/wiki/Weapon_Master "Weapon Master") | 100 Passive Skill Points become [Weapon Set Skill Points](/wiki/Weapon_Set_Passive_Skill_Points "Weapon Set Passive Skill Points") | — | [Cooldown Recovery Rate](/wiki/Cooldown_Recovery_Rate_(ascendancy_passive_skill) "Cooldown Recovery Rate (ascendancy passive skill)") |
| [Pitiless Killer](/wiki/Pitiless_Killer "Pitiless Killer") | [Culling Strike](/wiki/Culling_Strike "Culling Strike") | — | [Damage vs Low Life Enemies](/wiki/Damage_vs_Low_Life_Enemies "Damage vs Low Life Enemies") |
| [Judge, Jury, and Executioner](/wiki/Judge,_Jury,_and_Executioner "Judge, Jury, and Executioner") | [Decimating Strike](/wiki/Decimating_Strike "Decimating Strike") | [Pitiless Killer](/wiki/Pitiless_Killer "Pitiless Killer") | [Damage vs Low Life Enemies](/wiki/Damage_vs_Low_Life_Enemies "Damage vs Low Life Enemies") |
| [Witchbane](/wiki/Witchbane "Witchbane") | Break enemy [Concentration](/wiki/Concentration "Concentration") on [Hit](/wiki/Hit "Hit") equal to 100% of Damage Dealt Enemies have Maximum [Concentration](/wiki/Concentration "Concentration") equal to 30% of their Maximum Life Enemies regain 10% of [Concentration](/wiki/Concentration "Concentration") every second if they haven't lost [Concentration](/wiki/Concentration "Concentration") in the past 5 seconds | — | [Cooldown Recovery Rate](/wiki/Cooldown_Recovery_Rate_(ascendancy_passive_skill) "Cooldown Recovery Rate (ascendancy passive skill)") |
| [No Mercy](/wiki/No_Mercy "No Mercy") | Deal up to 40% more Damage to Enemies based on their missing [Concentration](/wiki/Concentration "Concentration") | [Witchbane](/wiki/Witchbane "Witchbane") | [Cooldown Recovery Rate](/wiki/Cooldown_Recovery_Rate_(ascendancy_passive_skill) "Cooldown Recovery Rate (ascendancy passive skill)") |
| [Obsessive Rituals](/wiki/Obsessive_Rituals "Obsessive Rituals") | Grants Skill: [Sorcery Ward](/wiki/Sorcery_Ward "Sorcery Ward") 35% less [Armour](/wiki/Armour "Armour") and [Evasion](/wiki/Evasion "Evasion") Rating | — | [Armour and Evasion](/wiki/Armour_and_Evasion_(ascendancy_passive_skill) "Armour and Evasion (ascendancy passive skill)") |
| [Ceremonial Ablution](/wiki/Ceremonial_Ablution "Ceremonial Ablution") | Sorcery Ward's Barrier can also take [Physical](/wiki/Physical "Physical") and [Chaos](/wiki/Chaos "Chaos") Damage from [Hits](/wiki/Hit "Hit") | [Obsessive Rituals](/wiki/Obsessive_Rituals "Obsessive Rituals") | [Armour and Evasion](/wiki/Armour_and_Evasion_(ascendancy_passive_skill) "Armour and Evasion (ascendancy passive skill)") |
| [Zealous Inquisition](/wiki/Zealous_Inquisition "Zealous Inquisition") | 10% chance for Enemies you Kill to Explode, dealing 100% of their maximum Life as [Physical](/wiki/Physical "Physical") Damage Chance is doubled against Undead and Demons | — | [Area of Effect](/wiki/Area_of_Effect_(ascendancy_passive_skill) "Area of Effect (ascendancy passive skill)") |
