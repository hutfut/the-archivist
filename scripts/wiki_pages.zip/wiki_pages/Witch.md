# Witch

The Witch

Gender: F
[Strength](/wiki/Strength "Strength"): 7
[Dexterity](/wiki/Dexterity "Dexterity"): 7
[Intelligence](/wiki/Intelligence "Intelligence"): 15
[Weapon](/wiki/Weapon "Weapon"): [Occult Spells](/wiki/Gemcutting#Occult "Gemcutting")

* [Withered Wand](/wiki/Withered_Wand "Withered Wand")
* [Rattling Sceptre](/wiki/Rattling_Sceptre "Rattling Sceptre")
* [Unearth](/wiki/Unearth "Unearth")

[Ascendancies](/wiki/Ascendancy_class "Ascendancy class"):

[Infernalist](/wiki/Infernalist "Infernalist")
 [Blood Mage](/wiki/Blood_Mage "Blood Mage")
 [Lich](/wiki/Lich "Lich")
 [Abyssal Lich](/wiki/Abyssal_Lich "Abyssal Lich")

> I do not fear death. I am its master. Darkness and the dead are my weapons of war. My enemies will rot from the inside out, as my army of corpses tear them screaming limb from limb.

The **Witch** is an [intelligence](/wiki/Intelligence "Intelligence")-oriented [class](/wiki/Character_class "Character class") that specializes in [minion](/wiki/Minion "Minion") and occult spells. Her exact heritage is unknown, though she was born to a swamp coven, likely the Black Fen.

The Witch obtains a [Withered Wand](/wiki/Withered_Wand "Withered Wand"), [Rattling Sceptre](/wiki/Rattling_Sceptre "Rattling Sceptre") and [Unearth](/wiki/Unearth "Unearth") as her default starting weapon set and skill in [The Riverbank](/wiki/The_Riverbank "The Riverbank").

## Ascendancy classes

Witches can specialize into one of these three [Ascendancy classes](/wiki/Ascendancy_classes "Ascendancy classes"):

* [Infernalist](/wiki/Infernalist "Infernalist")
* [Blood Mage](/wiki/Blood_Mage "Blood Mage")
* [Lich](/wiki/Lich "Lich")

Witches also have access to these alternate Ascendancy classes:

* [Abyssal Lich](/wiki/Abyssal_Lich "Abyssal Lich")
