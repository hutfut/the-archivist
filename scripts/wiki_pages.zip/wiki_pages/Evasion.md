# Evasion

Evasion

Tooltip

Evasion Rating grants a chance to Evade enemy [Hits](/wiki/Hit "Hit"), preventing them from [Hitting](/wiki/Hit "Hit") you at all. Exact chance to Evade also depends on the attacker's [Accuracy](/wiki/Accuracy "Accuracy").

**Evasion** is one of the three core [defences](/wiki/Defence "Defence") that can be found on [equipment](/wiki/Equipment "Equipment"). It is associated with [dexterity](/wiki/Dexterity "Dexterity") and provides an entropy-based system of damage avoidance against most types of [hits](/wiki/Hits "Hits"). Evasion chance is based on your Evasion Rating versus the enemy's [Accuracy](/wiki/Accuracy "Accuracy") Rating.

## Mechanics

Evading an attack prevents all [damage](/wiki/Damage "Damage") from the attack and other hit-related effects. For projectiles, evasion prevents collision. Chance to evade/chance to hit is determined by a function of the defender's evasion rating against the attacker's [accuracy](/wiki/Accuracy "Accuracy") rating. Chance to hit cannot go below 5%; likewise, chance to evade cannot exceed 95%.

The formula to calculate evasion chance is as follows:

Uncapped Chance to Hit
=

Attacker's Accuracy
∗
1.25
∗
100

(

Attacker's Accuracy
+

Defender's Evasion \* 0.3
)
\color [rgb]{0.6392156862745098,0.5529411764705883,0.42745098039215684}{\text{Uncapped Chance to Hit}}={{\text{Attacker's Accuracy}}\*1.25\*100 \over ({\text{Attacker's Accuracy}}+{\text{Defender's Evasion \* 0.3}})}
[[1]](#cite_note-1)

Additionally, if the evasion check fails, leading to a hit, and that hit would deal a [critical hit](/wiki/Critical_hit "Critical hit"), the chance to evade is tested again independently. If this check is passed, the critical hit is downgraded to a non-critical hit.[[2]](#cite_note-2)

### Distance

Player attacks have an accuracy penalty that drops off with [distance](/wiki/Distance "Distance") from the attacker between 2 metres (no penalty) and 9 metres (90% less accuracy rating); this primarily affects projectile skills.

Enemies do not have an accuracy penalty, but can be given one with [Tactician](/wiki/Tactician "Tactician")'s [Stay Light, Use Cover](/wiki/Stay_Light,_Use_Cover "Stay Light, Use Cover") or [Vigilant View](/wiki/Vigilant_View "Vigilant View").

### Entropy

Evasion is not a random system. Instead, it uses a deterministic "entropy" system that ensures a hit will occur after a certain number of evades:

1. If it is the first time an entity is attacked, or if the time since the last attempted hit exceeds 100 server ticks (3.33 seconds), randomize the entropy value from 0-99.
2. Calculate the attacker's chance to hit against the defender's chance to evade, and add this integer to the entropy value.
3. If the resulting entropy value is lower than 100, the hit counts as **evade**. When the value reaches 100 or greater, the check counts as a **hit**, and subtract 100 from the entropy value.

The secondary critical hit downgrade test does not affect the entropy value.

> **Example:**
> A player is fighting three monsters, one (*A*) with a 70% chance to hit and two (*B*, *C*) with a 45% chance to hit.
>
> * *A* attacks. The player's entropy value is a random number between 0-99, in this case **37**.
> * *A'*s attack adds 70 to the counter, raising it to **107**. This counts as a hit. 100 is then subtracted from entropy, leaving a value of **7**.
> * *B* attacks, adding 45 to entropy. Entropy value is now **52**
> * *C* attacks, adding 45 to entropy. Entropy value is now **97**
> * *A* attacks, adding 70 to entropy. Entropy value is now **167**. This hits, 100 is subtracted from entropy, and the value becomes **67**. It happens to be a critical hit, which means it has a 70% chance to do bonus damage, but this roll is independent and doesn't affect entropy.
> * The player runs away for more than 3.33 seconds (100 ticks), so a new entropy value will be rolled on the next attack.

As a result, if a player has a 1 in N chance to be hit, then the player will be hit exactly once for every N consecutive attacks. This eliminates all possibilities of lucky and/or unlucky streaks. It is still based on chance because of the entropy's value randomization in the first step. Note that if multiple mobs are attacking one character, all of the mobs' attacks share the same entropy value. The chance to evade shown in the character stats window is based on the average accuracy of a monster at the player's level.

### Other mechanics

When defending against monster hits, there is no distinction between attacks and [spells](/wiki/Spell "Spell") and will apply to any attack from enemies except boss attacks with a red flash.

When attacking monsters, their evasion provides avoidance against all attack hits, interacting with accuracy/chance to hit. Monsters cannot evade spell hits.

### Bypassing evasion

* Effects that state Can't be Evaded or Always Hit (e.g. [Killing Palm](/wiki/Killing_Palm "Killing Palm")) will raise the chance to hit to 100%, ignoring all accuracy and evasion stats of the attacker and defender respectively.
* Cannot Evade (e.g. [Bramblejack](/wiki/Bramblejack "Bramblejack")) does the same, in reverse; all skills against the subject will hit regardless of accuracy.
* [Pinned](/wiki/Pinned "Pinned") targets cannot evade attacks.
* The Parried [debuff](/wiki/Debuff "Debuff") applied by [Parry](/wiki/Parry "Parry") negates evasion.

## Related mechanics

### Blind

[Blind](/wiki/Blind "Blind") is a [debuff](/wiki/Debuff "Debuff") that reduces the target's Evasion and [Accuracy](/wiki/Accuracy "Accuracy") by 20% and lowers their vision radius to minimum.

### Maim

[Maim](/wiki/Maim "Maim") is a [debuff](/wiki/Debuff "Debuff") that reduces the target's [movement speed](/wiki/Movement_speed "Movement speed") by 30% and Evasion Rating by 15%.

## Related skills

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Parry](/wiki/Parry "Parry") | *0* |  |  |  |
| [Raise Shield](/wiki/Raise_Shield "Raise Shield") | *0* |  |  |  |
| [Killing Palm](/wiki/Killing_Palm "Killing Palm") | *1* |  |  |  |
| [Staggering Palm](/wiki/Staggering_Palm "Staggering Palm") | *3* |  |  |  |
| [Hand of Chayula](/wiki/Hand_of_Chayula "Hand of Chayula") | *9* |  |  |  |
| [Shattering Palm](/wiki/Shattering_Palm "Shattering Palm") | *11* |  |  |  |
| [Spear of Solaris](/wiki/Spear_of_Solaris "Spear of Solaris") | *13* |  |  |  |
| [Hammer of the Gods](/wiki/Hammer_of_the_Gods "Hammer of the Gods") | *13* |  |  |  |

### Persistent skills

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Sorcery Ward](/wiki/Sorcery_Ward "Sorcery Ward") | *0* |  |  |  |
| [Wind Dancer](/wiki/Wind_Dancer "Wind Dancer") | *4* |  |  |  |
| [Ghost Dance](/wiki/Ghost_Dance "Ghost Dance") | *4* |  |  |  |
| [Defiance Banner](/wiki/Defiance_Banner "Defiance Banner") | *8* |  |  |  |

## Support gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Window of Opportunity II](/wiki/Window_of_Opportunity_II "Window of Opportunity II") | *5* |  |  |  |

## Related unique items

| Item | Base item | Item class |  | Stats |
| --- | --- | --- | --- | --- |
| [Bramblejack](/wiki/Bramblejack "Bramblejack") | [Rusted Cuirass](/wiki/Rusted_Cuirass "Rusted Cuirass") | *[Body Armour](/wiki/Body_Armour "Body Armour")* | 1 | +(60-100) to maximum Life +(60-100) to [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") Cannot Evade Enemy [Attacks](/wiki/Attack "Attack") 250% of [Melee](/wiki/Melee "Melee") Physical Damage taken reflected to Attacker Regenerate 5% of maximum Life per second while [Surrounded](/wiki/Surrounded "Surrounded") |
| [Vigilant View](/wiki/Vigilant_View "Vigilant View") | [Emerald Ring](/wiki/Emerald_Ring "Emerald Ring") | *[Ring](/wiki/Ring "Ring")* | 26 | +(120-160) to [Accuracy](/wiki/Accuracy "Accuracy") Rating+(100-150) to [Accuracy](/wiki/Accuracy "Accuracy") Rating +(100-150) to Evasion Rating (10-20)% increased [Rarity of Items](/wiki/Rarity "Rarity") found +(20-30) to [Dexterity](/wiki/Dexterity "Dexterity") Enemies have an [Accuracy](/wiki/Accuracy "Accuracy") Penalty against you based on Distance Maximum Chance to Evade is 50% |

## Related passive skills

The following [passive skills](/wiki/Passive_skill "Passive skill") are related to evasion:

### Base evasion rating

| Name | Stats |
| --- | --- |
| [Armour and Evasion](/wiki/Armour_and_Evasion/edit?redlink=1 "Armour and Evasion (page does not exist)") | +10 to [Armour](/wiki/Armour "Armour") +8 to Evasion Rating [[1]](/wiki/Passive_Skill:Armour~and~evasion1 "Passive Skill:Armour~and~evasion1") [[2]](/wiki/Passive_Skill:Armour~and~evasion2 "Passive Skill:Armour~and~evasion2") |
| [Evasion](/wiki/Evasion_(passive_skill) "Evasion (passive skill)") | +16 to Evasion Rating [[1]](/wiki/Passive_Skill:Evasion11 "Passive Skill:Evasion11") [[2]](/wiki/Passive_Skill:Evasion12 "Passive Skill:Evasion12") |
| [Evasion and Energy Shield](/wiki/Evasion_and_Energy_Shield/edit?redlink=1 "Evasion and Energy Shield (page does not exist)") | +8 to Evasion Rating +5 to maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") [[1]](/wiki/Passive_Skill:Evasion~and~energy~shield1 "Passive Skill:Evasion~and~energy~shield1") [[2]](/wiki/Passive_Skill:Evasion~and~energy~shield3 "Passive Skill:Evasion~and~energy~shield3")  ---  +30 to Evasion Rating +15 to maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") [[2]](/wiki/Passive_Skill:Evasion~and~energy~shield7 "Passive Skill:Evasion~and~energy~shield7") |

### Increased evasion

| Name | Stats |
| --- | --- |
| [Armour and Evasion](/wiki/Armour_and_Evasion/edit?redlink=1 "Armour and Evasion (page does not exist)") | 12% increased [Armour](/wiki/Armour "Armour") and Evasion Rating [[1]](/wiki/Passive_Skill:Armour~and~evasion10 "Passive Skill:Armour~and~evasion10") [[2]](/wiki/Passive_Skill:Armour~and~evasion16 "Passive Skill:Armour~and~evasion16") [[3]](/wiki/Passive_Skill:Armour~and~evasion17 "Passive Skill:Armour~and~evasion17") [[4]](/wiki/Passive_Skill:Armour~and~evasion18 "Passive Skill:Armour~and~evasion18") [[5]](/wiki/Passive_Skill:Armour~and~evasion19 "Passive Skill:Armour~and~evasion19") [[6]](/wiki/Passive_Skill:Armour~and~evasion20~ "Passive Skill:Armour~and~evasion20~") [[7]](/wiki/Passive_Skill:Armour~and~evasion21 "Passive Skill:Armour~and~evasion21") [[8]](/wiki/Passive_Skill:Armour~and~evasion22 "Passive Skill:Armour~and~evasion22") [[9]](/wiki/Passive_Skill:Armour~and~evasion23 "Passive Skill:Armour~and~evasion23") [[10]](/wiki/Passive_Skill:Armour~and~evasion24 "Passive Skill:Armour~and~evasion24") [[11]](/wiki/Passive_Skill:Armour~and~evasion25 "Passive Skill:Armour~and~evasion25") [[12]](/wiki/Passive_Skill:Armour~and~evasion26 "Passive Skill:Armour~and~evasion26") [[13]](/wiki/Passive_Skill:Armour~and~evasion27 "Passive Skill:Armour~and~evasion27") [[14]](/wiki/Passive_Skill:Armour~and~evasion3 "Passive Skill:Armour~and~evasion3") [[15]](/wiki/Passive_Skill:Armour~and~evasion4 "Passive Skill:Armour~and~evasion4") [[16]](/wiki/Passive_Skill:Armour~and~evasion5 "Passive Skill:Armour~and~evasion5") [[17]](/wiki/Passive_Skill:Armour~and~evasion6 "Passive Skill:Armour~and~evasion6") [[18]](/wiki/Passive_Skill:Armour~and~evasion7 "Passive Skill:Armour~and~evasion7") [[19]](/wiki/Passive_Skill:Armour~and~evasion8 "Passive Skill:Armour~and~evasion8") [[20]](/wiki/Passive_Skill:Armour~and~evasion9 "Passive Skill:Armour~and~evasion9") |
| [Armour and Evasion while Surrounded](/wiki/Armour_and_Evasion_while_Surrounded/edit?redlink=1 "Armour and Evasion while Surrounded (page does not exist)") | 20% increased [Armour](/wiki/Armour "Armour") while [Surrounded](/wiki/Surrounded "Surrounded") 20% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") while [Surrounded](/wiki/Surrounded "Surrounded") [[1]](/wiki/Passive_Skill:Being~surrounded17~ "Passive Skill:Being~surrounded17~") [[2]](/wiki/Passive_Skill:Being~surrounded18 "Passive Skill:Being~surrounded18") [[3]](/wiki/Passive_Skill:Being~surrounded19 "Passive Skill:Being~surrounded19") |
| [Deflection and Evasion](/wiki/Deflection_and_Evasion/edit?redlink=1 "Deflection and Evasion (page does not exist)") | Gain [Deflection Rating](/wiki/Deflect "Deflect") equal to 3% of [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") 8% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") [[1]](/wiki/Passive_Skill:Deflect38 "Passive Skill:Deflect38") [[2]](/wiki/Passive_Skill:Deflect39 "Passive Skill:Deflect39")  ---  8% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") Gain [Deflection Rating](/wiki/Deflect "Deflect") equal to 3% of [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") [[3]](/wiki/Passive_Skill:Evasion22 "Passive Skill:Evasion22") [[4]](/wiki/Passive_Skill:Evasion27 "Passive Skill:Evasion27") |
| [Evasion](/wiki/Evasion_(passive_skill) "Evasion (passive skill)") | 15% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") [[1]](/wiki/Passive_Skill:Azmerianimals38 "Passive Skill:Azmerianimals38") [[2]](/wiki/Passive_Skill:Azmerianimals39 "Passive Skill:Azmerianimals39") [[3]](/wiki/Passive_Skill:Azmerianimals8 "Passive Skill:Azmerianimals8") [[4]](/wiki/Passive_Skill:Azmerianimals9 "Passive Skill:Azmerianimals9") [[5]](/wiki/Passive_Skill:Deflect33 "Passive Skill:Deflect33") [[6]](/wiki/Passive_Skill:Deflect63 "Passive Skill:Deflect63") [[7]](/wiki/Passive_Skill:Evasion1 "Passive Skill:Evasion1") [[8]](/wiki/Passive_Skill:Evasion10 "Passive Skill:Evasion10") [[9]](/wiki/Passive_Skill:Evasion13 "Passive Skill:Evasion13") [[10]](/wiki/Passive_Skill:Evasion14 "Passive Skill:Evasion14") [[11]](/wiki/Passive_Skill:Evasion15 "Passive Skill:Evasion15") [[12]](/wiki/Passive_Skill:Evasion16 "Passive Skill:Evasion16") [[13]](/wiki/Passive_Skill:Evasion17~ "Passive Skill:Evasion17~") [[14]](/wiki/Passive_Skill:Evasion18 "Passive Skill:Evasion18") [[15]](/wiki/Passive_Skill:Evasion2 "Passive Skill:Evasion2") [[16]](/wiki/Passive_Skill:Evasion21 "Passive Skill:Evasion21") [[17]](/wiki/Passive_Skill:Evasion24~ "Passive Skill:Evasion24~") [[18]](/wiki/Passive_Skill:Evasion25 "Passive Skill:Evasion25") [[19]](/wiki/Passive_Skill:Evasion26 "Passive Skill:Evasion26") [[20]](/wiki/Passive_Skill:Evasion28 "Passive Skill:Evasion28") [[21]](/wiki/Passive_Skill:Evasion3 "Passive Skill:Evasion3") [[22]](/wiki/Passive_Skill:Evasion36 "Passive Skill:Evasion36") [[23]](/wiki/Passive_Skill:Evasion8 "Passive Skill:Evasion8") |
| [Evasion and Energy Shield](/wiki/Evasion_and_Energy_Shield/edit?redlink=1 "Evasion and Energy Shield (page does not exist)") | 12% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") 12% increased maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") [[1]](/wiki/Passive_Skill:Evasion~and~energy~shield10 "Passive Skill:Evasion~and~energy~shield10") [[2]](/wiki/Passive_Skill:Evasion~and~energy~shield16 "Passive Skill:Evasion~and~energy~shield16") [[3]](/wiki/Passive_Skill:Evasion~and~energy~shield17 "Passive Skill:Evasion~and~energy~shield17") [[4]](/wiki/Passive_Skill:Evasion~and~energy~shield18 "Passive Skill:Evasion~and~energy~shield18") [[5]](/wiki/Passive_Skill:Evasion~and~energy~shield19 "Passive Skill:Evasion~and~energy~shield19") [[6]](/wiki/Passive_Skill:Evasion~and~energy~shield2 "Passive Skill:Evasion~and~energy~shield2") [[7]](/wiki/Passive_Skill:Evasion~and~energy~shield20 "Passive Skill:Evasion~and~energy~shield20") [[8]](/wiki/Passive_Skill:Evasion~and~energy~shield22 "Passive Skill:Evasion~and~energy~shield22") [[9]](/wiki/Passive_Skill:Evasion~and~energy~shield23 "Passive Skill:Evasion~and~energy~shield23") [[10]](/wiki/Passive_Skill:Evasion~and~energy~shield24 "Passive Skill:Evasion~and~energy~shield24") [[11]](/wiki/Passive_Skill:Evasion~and~energy~shield26 "Passive Skill:Evasion~and~energy~shield26") [[12]](/wiki/Passive_Skill:Evasion~and~energy~shield27 "Passive Skill:Evasion~and~energy~shield27") [[13]](/wiki/Passive_Skill:Evasion~and~energy~shield4 "Passive Skill:Evasion~and~energy~shield4") [[14]](/wiki/Passive_Skill:Evasion~and~energy~shield5 "Passive Skill:Evasion~and~energy~shield5") [[15]](/wiki/Passive_Skill:Evasion~and~energy~shield8 "Passive Skill:Evasion~and~energy~shield8") [[16]](/wiki/Passive_Skill:Evasion~and~energy~shield9~ "Passive Skill:Evasion~and~energy~shield9~") |
| [Evasion and Energy Shield Recharge](/wiki/Evasion_and_Energy_Shield_Recharge/edit?redlink=1 "Evasion and Energy Shield Recharge (page does not exist)") | 10% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") 10% increased [Energy Shield Recharge Rate](/wiki/Energy_Shield_Recharge_Rate "Energy Shield Recharge Rate") [[1]](/wiki/Passive_Skill:Evasion~and~energy~shield21~ "Passive Skill:Evasion~and~energy~shield21~") [[2]](/wiki/Passive_Skill:Evasion~and~energy~shield6~ "Passive Skill:Evasion~and~energy~shield6~") |
| [Evasion and Movement Speed](/wiki/Evasion_and_Movement_Speed/edit?redlink=1 "Evasion and Movement Speed (page does not exist)") | 8% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") 1% increased Movement Speed [[1]](/wiki/Passive_Skill:Azmerianimals7 "Passive Skill:Azmerianimals7") |
| [Evasion and Movement Speed while Sprinting](/wiki/Evasion_and_Movement_Speed_while_Sprinting/edit?redlink=1 "Evasion and Movement Speed while Sprinting (page does not exist)") | 15% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") while Sprinting 2% increased Movement Speed while Sprinting [[1]](/wiki/Passive_Skill:Sprint7 "Passive Skill:Sprint7") |
| [Evasion and Reduced Movement Penalty](/wiki/Evasion_and_Reduced_Movement_Penalty/edit?redlink=1 "Evasion and Reduced Movement Penalty (page does not exist)") | 10% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") 2% reduced Movement Speed Penalty from using Skills while moving [[1]](/wiki/Passive_Skill:Evasion23~ "Passive Skill:Evasion23~") [[2]](/wiki/Passive_Skill:Evasion4 "Passive Skill:Evasion4") [[3]](/wiki/Passive_Skill:Evasion9 "Passive Skill:Evasion9") |
| [Evasion during Parry](/wiki/Evasion_during_Parry/edit?redlink=1 "Evasion during Parry (page does not exist)") | 25% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") while [Parrying](/wiki/Parry "Parry") [[1]](/wiki/Passive_Skill:Buckler20 "Passive Skill:Buckler20") |
| [Evasion if Consumed Frenzy Charge](/wiki/Evasion_if_Consumed_Frenzy_Charge/edit?redlink=1 "Evasion if Consumed Frenzy Charge (page does not exist)") | 20% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") if you've consumed a [Frenzy Charge](/wiki/Frenzy_Charge "Frenzy Charge") [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Frenzy~charges1 "Passive Skill:Frenzy~charges1") [[2]](/wiki/Passive_Skill:Frenzy~charges2 "Passive Skill:Frenzy~charges2") [[3]](/wiki/Passive_Skill:Frenzy~charges3 "Passive Skill:Frenzy~charges3") |
| [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") | 15% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") [[1]](/wiki/Passive_Skill:Azmerianimals51 "Passive Skill:Azmerianimals51") [[2]](/wiki/Passive_Skill:Deflect50~ "Passive Skill:Deflect50~") [[3]](/wiki/Passive_Skill:Stun~threshold18 "Passive Skill:Stun~threshold18") |
| [Evasion Rating on Hit Recently](/wiki/Evasion_Rating_on_Hit_Recently/edit?redlink=1 "Evasion Rating on Hit Recently (page does not exist)") | 20% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") if you have Hit an Enemy [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Attack~speed59 "Passive Skill:Attack~speed59") |
| [Evasion while Sprinting](/wiki/Evasion_while_Sprinting/edit?redlink=1 "Evasion while Sprinting (page does not exist)") | 25% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") while Sprinting [[1]](/wiki/Passive_Skill:Sprint5 "Passive Skill:Sprint5") [[2]](/wiki/Passive_Skill:Sprint6 "Passive Skill:Sprint6") |
| [Evasion while Surrounded](/wiki/Evasion_while_Surrounded/edit?redlink=1 "Evasion while Surrounded (page does not exist)") | 30% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") while [Surrounded](/wiki/Surrounded "Surrounded") [[1]](/wiki/Passive_Skill:Being~surrounded4 "Passive Skill:Being~surrounded4") [[2]](/wiki/Passive_Skill:Being~surrounded5 "Passive Skill:Being~surrounded5") |
| [Life Leech. Armour and Evasion while Leeching](/wiki/Life_Leech._Armour_and_Evasion_while_Leeching/edit?redlink=1 "Life Leech. Armour and Evasion while Leeching (page does not exist)") | 8% increased [Armour](/wiki/Armour "Armour") and Evasion Rating while Leeching 8% increased amount of Life [Leeched](/wiki/Leech "Leech") [[1]](/wiki/Passive_Skill:Life~leech1 "Passive Skill:Life~leech1") [[2]](/wiki/Passive_Skill:Life~leech2 "Passive Skill:Life~leech2") |
| [Minion Physical Damage Reduction](/wiki/Minion_Physical_Damage_Reduction/edit?redlink=1 "Minion Physical Damage Reduction (page does not exist)") | [Minions](/wiki/Minion "Minion") have 12% additional [Physical](/wiki/Physical "Physical") Damage Reduction [Minions](/wiki/Minion "Minion") have 25% increased Evasion Rating [[1]](/wiki/Passive_Skill:Minion~defence40~ "Passive Skill:Minion~defence40~") |
| [Stun Threshold and Evasion Rating](/wiki/Stun_Threshold_and_Evasion_Rating/edit?redlink=1 "Stun Threshold and Evasion Rating (page does not exist)") | 12% increased [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") if you haven't been [Stunned](/wiki/Stun "Stun") [Recently](/wiki/Recently "Recently") 8% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") [[1]](/wiki/Passive_Skill:Stun~threshold29 "Passive Skill:Stun~threshold29") |
| [Afterimage](/wiki/Afterimage/edit?redlink=1 "Afterimage (page does not exist)") | 60% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") if you have Hit an Enemy [Recently](/wiki/Recently "Recently") 5% reduced Movement Speed Penalty from using Skills while moving [[1]](/wiki/Passive_Skill:Evasion35 "Passive Skill:Evasion35") |
| [Agile Sprinter](/wiki/Agile_Sprinter/edit?redlink=1 "Agile Sprinter (page does not exist)") | 100% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") while Sprinting [[1]](/wiki/Passive_Skill:Sprint10 "Passive Skill:Sprint10") |
| [Agile Succession](/wiki/Agile_Succession/edit?redlink=1 "Agile Succession (page does not exist)") | 6% increased [Attack](/wiki/Attack "Attack") Speed 30% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") if you have Hit an Enemy [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Attack~speed60~ "Passive Skill:Attack~speed60~") |
| [Backup Plan](/wiki/Backup_Plan/edit?redlink=1 "Backup Plan (page does not exist)") | 50% increased [Armour](/wiki/Armour "Armour") if you haven't been [Hit](/wiki/Hit "Hit") [Recently](/wiki/Recently "Recently") 50% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") if you have been [Hit](/wiki/Hit "Hit") [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Armour~and~evasion13 "Passive Skill:Armour~and~evasion13") |
| [Battle-hardened](/wiki/Battle-hardened/edit?redlink=1 "Battle-hardened (page does not exist)") | 20% increased [Armour](/wiki/Armour "Armour") and Evasion Rating Hits against you have 20% reduced [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus") +5 to [Strength](/wiki/Strength "Strength") and [Dexterity](/wiki/Dexterity "Dexterity") [[1]](/wiki/Passive_Skill:Duelist~mercenary~notable1 "Passive Skill:Duelist~mercenary~notable1") |
| [Beastial Skin](/wiki/Beastial_Skin/edit?redlink=1 "Beastial Skin (page does not exist)") | 100% increased Evasion Rating from Equipped Body Armour [[1]](/wiki/Passive_Skill:Evasion33 "Passive Skill:Evasion33") |
| [Blur](/wiki/Blur/edit?redlink=1 "Blur (page does not exist)") | 20% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") 4% increased Movement Speed +10 to [Dexterity](/wiki/Dexterity "Dexterity") [[1]](/wiki/Passive_Skill:Ranger~huntress~notable1 "Passive Skill:Ranger~huntress~notable1") |
| [Careful Consideration](/wiki/Careful_Consideration/edit?redlink=1 "Careful Consideration (page does not exist)") | 30% reduced [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") if you have been [Hit](/wiki/Hit "Hit") [Recently](/wiki/Recently "Recently") 100% increased Evasion Rating if you haven't been [Hit](/wiki/Hit "Hit") [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Evasion7~ "Passive Skill:Evasion7~") |
| [Catlike Agility](/wiki/Catlike_Agility "Catlike Agility") | 25% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") 40% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") if you've Dodge Rolled [Recently](/wiki/Recently "Recently") 3% reduced Movement Speed Penalty from using Skills while moving [[1]](/wiki/Passive_Skill:Evasion39 "Passive Skill:Evasion39") |
| [Chakra of Breathing](/wiki/Chakra_of_Breathing/edit?redlink=1 "Chakra of Breathing (page does not exist)") | 1% increased [Energy Shield Recharge Rate](/wiki/Energy_Shield_Recharge_Rate "Energy Shield Recharge Rate") per 4 [Dexterity](/wiki/Dexterity "Dexterity") 20% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") while you have [Energy Shield](/wiki/Energy_Shield "Energy Shield") [[1]](/wiki/Passive_Skill:Unarmed12 "Passive Skill:Unarmed12") |
| [Dead can Dance](/wiki/Dead_can_Dance/edit?redlink=1 "Dead can Dance (page does not exist)") | [Minions](/wiki/Minion "Minion") have 25% increased Evasion Rating [Minions](/wiki/Minion "Minion") have 25% increased maximum Life [[1]](/wiki/Passive_Skill:Minion~offence16 "Passive Skill:Minion~offence16") |
| [Defiance](/wiki/Defiance/edit?redlink=1 "Defiance (page does not exist)") | 120% increased [Armour](/wiki/Armour "Armour") and Evasion Rating when on [Low Life](/wiki/Low_Life "Low Life") [[1]](/wiki/Passive_Skill:Armour~and~evasion12 "Passive Skill:Armour~and~evasion12") |
| [Enduring Deflection](/wiki/Enduring_Deflection/edit?redlink=1 "Enduring Deflection (page does not exist)") | Prevent +3% of Damage from [Deflected](/wiki/Deflect "Deflect") [Hits](/wiki/Hit "Hit") 20% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") [[1]](/wiki/Passive_Skill:Deflect41 "Passive Skill:Deflect41") |
| [Enhanced Reflexes](/wiki/Enhanced_Reflexes/edit?redlink=1 "Enhanced Reflexes (page does not exist)") | 20% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") 8% increased [Dexterity](/wiki/Dexterity "Dexterity") Gain [Deflection Rating](/wiki/Deflect "Deflect") equal to 5% of [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") [[1]](/wiki/Passive_Skill:Evasion32 "Passive Skill:Evasion32") |
| [Escape Strategy](/wiki/Escape_Strategy/edit?redlink=1 "Escape Strategy (page does not exist)") | 100% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") if you have been [Hit](/wiki/Hit "Hit") [Recently](/wiki/Recently "Recently") 30% reduced Evasion Rating if you haven't been [Hit](/wiki/Hit "Hit") [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Evasion6 "Passive Skill:Evasion6") |
| [Escape Velocity](/wiki/Escape_Velocity/edit?redlink=1 "Escape Velocity (page does not exist)") | 30% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") 3% increased Movement Speed [[1]](/wiki/Passive_Skill:Evasion31 "Passive Skill:Evasion31") |
| [Feel no Pain](/wiki/Feel_no_Pain/edit?redlink=1 "Feel no Pain (page does not exist)") | 20% increased [Armour](/wiki/Armour "Armour") and Evasion Rating 20% increased [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") [[1]](/wiki/Passive_Skill:Armour~and~evasion28 "Passive Skill:Armour~and~evasion28") |
| [Fortified Location](/wiki/Fortified_Location/edit?redlink=1 "Fortified Location (page does not exist)") | 10% increased [Armour](/wiki/Armour "Armour") and Evasion Rating per Summoned [Totem](/wiki/Totem "Totem") in your [Presence](/wiki/Presence "Presence") 10% increased [Attack](/wiki/Attack "Attack") Damage per Summoned [Totem](/wiki/Totem "Totem") in your [Presence](/wiki/Presence "Presence") [[1]](/wiki/Passive_Skill:Ballista17 "Passive Skill:Ballista17") |
| [Fortifying Blood](/wiki/Fortifying_Blood/edit?redlink=1 "Fortifying Blood (page does not exist)") | 40% increased [Armour](/wiki/Armour "Armour") and Evasion Rating while Leeching 20% increased amount of Life [Leeched](/wiki/Leech "Leech") [[1]](/wiki/Passive_Skill:Life~leech13 "Passive Skill:Life~leech13") |
| [Freedom of Movement](/wiki/Freedom_of_Movement "Freedom of Movement") | 20% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") 5% reduced Movement Speed Penalty from using Skills while moving 10% reduced [Slowing](/wiki/Slow "Slow") Potency of [Debuffs](/wiki/Debuff "Debuff") on You [[1]](/wiki/Passive_Skill:Evasion30 "Passive Skill:Evasion30") |
| [High Alert](/wiki/High_Alert/edit?redlink=1 "High Alert (page does not exist)") | 50% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") when on Full Life 25% increased [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") while on Full Life [[1]](/wiki/Passive_Skill:Evasion5 "Passive Skill:Evasion5") |
| [Immaterial](/wiki/Immaterial/edit?redlink=1 "Immaterial (page does not exist)") | 30% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") while you have [Energy Shield](/wiki/Energy_Shield "Energy Shield") 50% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") if [Energy Shield Recharge](/wiki/Energy_Shield_Recharge "Energy Shield Recharge") has started in the past 2 seconds [[1]](/wiki/Passive_Skill:Evasion~and~energy~shield14 "Passive Skill:Evasion~and~energy~shield14") |
| [Inner Faith](/wiki/Inner_Faith/edit?redlink=1 "Inner Faith (page does not exist)") | 20% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") 20% increased maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") 25% reduced [effect](/wiki/Buff "Buff") of [Curses](/wiki/Curse "Curse") on you [[1]](/wiki/Passive_Skill:Evasion~and~energy~shield12~ "Passive Skill:Evasion~and~energy~shield12~") |
| [Mindful Awareness](/wiki/Mindful_Awareness/edit?redlink=1 "Mindful Awareness (page does not exist)") | 24% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") 24% increased maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") [[1]](/wiki/Passive_Skill:Evasion~and~energy~shield35~ "Passive Skill:Evasion~and~energy~shield35~") |
| [Savagery](/wiki/Savagery/edit?redlink=1 "Savagery (page does not exist)") | 50% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") if you've consumed a [Frenzy Charge](/wiki/Frenzy_Charge "Frenzy Charge") [Recently](/wiki/Recently "Recently") +1 to Maximum [Frenzy Charges](/wiki/Frenzy_Charge "Frenzy Charge") [[1]](/wiki/Passive_Skill:Frenzy~charges8 "Passive Skill:Frenzy~charges8") |
| [Shadow Dancing](/wiki/Shadow_Dancing/edit?redlink=1 "Shadow Dancing (page does not exist)") | 60% [faster start of Energy Shield Recharge](/wiki/Energy_Shield "Energy Shield") if you've been [Stunned](/wiki/Stun "Stun") [Recently](/wiki/Recently "Recently") 30% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") if you have been [Hit](/wiki/Hit "Hit") [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Evasion~and~energy~shield13 "Passive Skill:Evasion~and~energy~shield13") |
| [Spell Haste](/wiki/Spell_Haste/edit?redlink=1 "Spell Haste (page does not exist)") | 8% increased Cast Speed 15% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") [[1]](/wiki/Passive_Skill:Cast~speed35 "Passive Skill:Cast~speed35") |
| [The Wild Cat](/wiki/The_Wild_Cat/edit?redlink=1 "The Wild Cat (page does not exist)") | Gain [Deflection Rating](/wiki/Deflect "Deflect") equal to 10% of [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") 40% increased Evasion Rating while moving +10 to [Dexterity](/wiki/Dexterity "Dexterity") [[1]](/wiki/Passive_Skill:Azmerianimals42 "Passive Skill:Azmerianimals42") |
| [The Winter Owl](/wiki/The_Winter_Owl/edit?redlink=1 "The Winter Owl (page does not exist)") | Gain Accuracy Rating equal to your [Intelligence](/wiki/Intelligence "Intelligence") 3% increased Evasion Rating per 10 [Intelligence](/wiki/Intelligence "Intelligence") +10 to [Intelligence](/wiki/Intelligence "Intelligence") [[1]](/wiki/Passive_Skill:Azmerianimals54 "Passive Skill:Azmerianimals54") |

### Gain Deflection rating

| Name | Stats |
| --- | --- |
| [Deflection](/wiki/Deflection "Deflection") | Gain [Deflection Rating](/wiki/Deflect "Deflect") equal to 6% of [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") [[1]](/wiki/Passive_Skill:Azmerianimals40 "Passive Skill:Azmerianimals40") [[2]](/wiki/Passive_Skill:Azmerianimals41 "Passive Skill:Azmerianimals41") [[3]](/wiki/Passive_Skill:Deflect23 "Passive Skill:Deflect23") [[4]](/wiki/Passive_Skill:Deflect24 "Passive Skill:Deflect24") [[5]](/wiki/Passive_Skill:Deflect25 "Passive Skill:Deflect25") [[6]](/wiki/Passive_Skill:Deflect26 "Passive Skill:Deflect26") [[7]](/wiki/Passive_Skill:Deflect27 "Passive Skill:Deflect27") [[8]](/wiki/Passive_Skill:Deflect28 "Passive Skill:Deflect28") [[9]](/wiki/Passive_Skill:Deflect30 "Passive Skill:Deflect30") [[10]](/wiki/Passive_Skill:Deflect31 "Passive Skill:Deflect31") [[11]](/wiki/Passive_Skill:Deflect32 "Passive Skill:Deflect32") [[12]](/wiki/Passive_Skill:Deflect36 "Passive Skill:Deflect36") [[13]](/wiki/Passive_Skill:Deflect37 "Passive Skill:Deflect37") [[14]](/wiki/Passive_Skill:Deflect43 "Passive Skill:Deflect43") [[15]](/wiki/Passive_Skill:Deflect44 "Passive Skill:Deflect44") [[16]](/wiki/Passive_Skill:Deflect45 "Passive Skill:Deflect45") [[17]](/wiki/Passive_Skill:Deflect49 "Passive Skill:Deflect49") [[18]](/wiki/Passive_Skill:Deflect51 "Passive Skill:Deflect51") [[19]](/wiki/Passive_Skill:Deflect52~ "Passive Skill:Deflect52~") [[20]](/wiki/Passive_Skill:Deflect54 "Passive Skill:Deflect54") [[21]](/wiki/Passive_Skill:Deflect55 "Passive Skill:Deflect55") [[22]](/wiki/Passive_Skill:Deflect56 "Passive Skill:Deflect56") [[23]](/wiki/Passive_Skill:Deflect57~ "Passive Skill:Deflect57~") [[24]](/wiki/Passive_Skill:Deflect60 "Passive Skill:Deflect60") [[25]](/wiki/Passive_Skill:Deflect65 "Passive Skill:Deflect65") |
| [Deflection and Evasion](/wiki/Deflection_and_Evasion/edit?redlink=1 "Deflection and Evasion (page does not exist)") | Gain [Deflection Rating](/wiki/Deflect "Deflect") equal to 3% of [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") 8% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") [[1]](/wiki/Passive_Skill:Deflect38 "Passive Skill:Deflect38") [[2]](/wiki/Passive_Skill:Deflect39 "Passive Skill:Deflect39")  ---  8% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") Gain [Deflection Rating](/wiki/Deflect "Deflect") equal to 3% of [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") [[3]](/wiki/Passive_Skill:Evasion22 "Passive Skill:Evasion22") [[4]](/wiki/Passive_Skill:Evasion27 "Passive Skill:Evasion27") |
| [Enhanced Reflexes](/wiki/Enhanced_Reflexes/edit?redlink=1 "Enhanced Reflexes (page does not exist)") | 20% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") 8% increased [Dexterity](/wiki/Dexterity "Dexterity") Gain [Deflection Rating](/wiki/Deflect "Deflect") equal to 5% of [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") [[1]](/wiki/Passive_Skill:Evasion32 "Passive Skill:Evasion32") |
| [The Wild Cat](/wiki/The_Wild_Cat/edit?redlink=1 "The Wild Cat (page does not exist)") | Gain [Deflection Rating](/wiki/Deflect "Deflect") equal to 10% of [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") 40% increased Evasion Rating while moving +10 to [Dexterity](/wiki/Dexterity "Dexterity") [[1]](/wiki/Passive_Skill:Azmerianimals42 "Passive Skill:Azmerianimals42") |

### Miscellany

| Name | Stats |
| --- | --- |
| [Easy Target](/wiki/Easy_Target "Easy Target") | Your [Hits](/wiki/Hit "Hit") cannot be Evaded by [Heavy Stunned](/wiki/Heavy_Stun "Heavy Stun") Enemies [[1]](/wiki/Passive_Skill:Stun21 "Passive Skill:Stun21") |
| [General's Bindings](/wiki/General%27s_Bindings "General's Bindings") | [Gain](/wiki/Gain "Gain") 8% of Evasion Rating as extra [Armour](/wiki/Armour "Armour") [[1]](/wiki/Passive_Skill:Armour37 "Passive Skill:Armour37") |
| [Insulated Treads](/wiki/Insulated_Treads/edit?redlink=1 "Insulated Treads (page does not exist)") | Gain [Ailment Threshold](/wiki/Ailment_Threshold "Ailment Threshold") equal to the lowest of Evasion and [Armour](/wiki/Armour "Armour") on your Boots [[1]](/wiki/Passive_Skill:Armour~and~evasion14~~ "Passive Skill:Armour~and~evasion14~~") |
| [Leather Bound Gauntlets](/wiki/Leather_Bound_Gauntlets/edit?redlink=1 "Leather Bound Gauntlets (page does not exist)") | +1 to Evasion Rating per 1 [Item Armour](/wiki/Defences "Defences") on Equipped Gloves [[1]](/wiki/Passive_Skill:Evasion38~ "Passive Skill:Evasion38~") |
| [Shredding Contraptions](/wiki/Shredding_Contraptions/edit?redlink=1 "Shredding Contraptions (page does not exist)") | Enemies affected by your [Hazards](/wiki/Hazard "Hazard") [Recently](/wiki/Recently "Recently") have 25% reduced [Armour](/wiki/Armour "Armour") Enemies affected by your [Hazards](/wiki/Hazard "Hazard") [Recently](/wiki/Recently "Recently") have 25% reduced [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") [[1]](/wiki/Passive_Skill:Hazards2 "Passive Skill:Hazards2") |
| [Sitting Duck](/wiki/Sitting_Duck/edit?redlink=1 "Sitting Duck (page does not exist)") | Your Hits cannot be Evaded by [Pinned](/wiki/Pinned "Pinned") Enemies 35% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") against [Immobilised](/wiki/Immobilised "Immobilised") enemies [[1]](/wiki/Passive_Skill:Pin9 "Passive Skill:Pin9") |
| [Spectral Ward](/wiki/Spectral_Ward/edit?redlink=1 "Spectral Ward (page does not exist)") | +1 to Maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") per 12 [Item Evasion Rating](/wiki/Defences "Defences") on Equipped Body Armour [[1]](/wiki/Passive_Skill:Evasion~and~energy~shield11 "Passive Skill:Evasion~and~energy~shield11") |
| [Strong Chin](/wiki/Strong_Chin/edit?redlink=1 "Strong Chin (page does not exist)") | Gain [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") equal to the lowest of Evasion and [Armour](/wiki/Armour "Armour") on your Helmet [[1]](/wiki/Passive_Skill:Armour~and~evasion11 "Passive Skill:Armour~and~evasion11") |
| [Subterfuge Mask](/wiki/Subterfuge_Mask/edit?redlink=1 "Subterfuge Mask (page does not exist)") | +2 to Evasion Rating per 1 [Item Energy Shield](/wiki/Defences "Defences") on Equipped Helmet [[1]](/wiki/Passive_Skill:Evasion~and~energy~shield25 "Passive Skill:Evasion~and~energy~shield25") |
| [Tolerant Equipment](/wiki/Tolerant_Equipment/edit?redlink=1 "Tolerant Equipment (page does not exist)") | Immune to [Bleeding](/wiki/Bleeding "Bleeding") if Equipped Helmet has higher [Armour](/wiki/Armour "Armour") than Evasion Rating Immune to [Poison](/wiki/Poison "Poison") if Equipped Helmet has higher Evasion Rating than [Armour](/wiki/Armour "Armour") [[1]](/wiki/Passive_Skill:Armour~and~evasion40 "Passive Skill:Armour~and~evasion40") |

### Ascendancy passive skills

The following [Ascendancy passive skills](/wiki/Ascendancy_passive_skill "Ascendancy passive skill") are related to evasion:

| Ascendancy Class | Name | Stats |
| --- | --- | --- |
| [Amazon](/wiki/Amazon "Amazon") | [Evasion](/wiki/Evasion_(passive_skill) "Evasion (passive skill)") | 20% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") [[1]](/wiki/Passive_Skill:AscendancyHuntress1Small8 "Passive Skill:AscendancyHuntress1Small8") [[2]](/wiki/Passive_Skill:AscendancyMonk2Small2 "Passive Skill:AscendancyMonk2Small2") [[3]](/wiki/Passive_Skill:AscendancyRanger3Small5 "Passive Skill:AscendancyRanger3Small5") |
| [Amazon](/wiki/Amazon "Amazon") | [Stalking Panther](/wiki/Stalking_Panther "Stalking Panther") | Evasion Rating from Equipped Helmet, Gloves and Boots is doubled Evasion Rating from Equipped Body Armour is halved [[1]](/wiki/Passive_Skill:AscendancyHuntress1Notable8 "Passive Skill:AscendancyHuntress1Notable8") |
| [Invoker](/wiki/Invoker "Invoker") | [Evasion and Energy Shield](/wiki/Evasion_and_Energy_Shield/edit?redlink=1 "Evasion and Energy Shield (page does not exist)") | 15% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") 15% increased maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") [[1]](/wiki/Passive_Skill:AscendancyMonk2Small1 "Passive Skill:AscendancyMonk2Small1") |
| [Invoker](/wiki/Invoker "Invoker") | [...and Protect me from Harm](/wiki/...and_Protect_me_from_Harm "...and Protect me from Harm") | 35% less [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") Physical Damage Reduction from [Armour](/wiki/Armour "Armour") is based on your combined [Armour](/wiki/Armour "Armour") and Evasion Rating [[1]](/wiki/Passive_Skill:AscendancyMonk2Notable2~ "Passive Skill:AscendancyMonk2Notable2~") |
| [Invoker](/wiki/Invoker "Invoker") | [Lead me through Grace...](/wiki/Lead_me_through_Grace... "Lead me through Grace...") | Cannot gain [Spirit](/wiki/Spirit "Spirit") from Equipment +1 to [Spirit](/wiki/Spirit "Spirit") for every 20 [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") on Equipped Body Armour +1 to [Spirit](/wiki/Spirit "Spirit") for every 8 [Item Energy Shield](/wiki/Defences "Defences") on Equipped Body Armour [[1]](/wiki/Passive_Skill:AscendancyMonk2Notable1~ "Passive Skill:AscendancyMonk2Notable1~") |
| [Pathfinder](/wiki/Pathfinder "Pathfinder") | [Sustainable Practices](/wiki/Sustainable_Practices "Sustainable Practices") | 50% of [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") also grants [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") reduction [[1]](/wiki/Passive_Skill:AscendancyRanger3Notable5 "Passive Skill:AscendancyRanger3Notable5") |
| [Tactician](/wiki/Tactician "Tactician") | [Armour and Evasion](/wiki/Armour_and_Evasion/edit?redlink=1 "Armour and Evasion (page does not exist)") | 15% increased [Armour](/wiki/Armour "Armour") and Evasion Rating [[1]](/wiki/Passive_Skill:AscendancyMercenary1Small6 "Passive Skill:AscendancyMercenary1Small6") [[2]](/wiki/Passive_Skill:AscendancyMercenary1Small7~ "Passive Skill:AscendancyMercenary1Small7~") [[3]](/wiki/Passive_Skill:AscendancyMercenary2Small5 "Passive Skill:AscendancyMercenary2Small5") [[4]](/wiki/Passive_Skill:AscendancyMercenary2Small6 "Passive Skill:AscendancyMercenary2Small6") |
| [Tactician](/wiki/Tactician "Tactician") | [Polish That Gear](/wiki/Polish_That_Gear "Polish That Gear") | Gain [Deflection Rating](/wiki/Deflect "Deflect") equal to 20% of [Armour](/wiki/Armour "Armour") [Gain](/wiki/Gain "Gain") 100% of [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") as extra [Ailment Threshold](/wiki/Ailment_Threshold "Ailment Threshold") [[1]](/wiki/Passive_Skill:AscendancyMercenary1Notable6 "Passive Skill:AscendancyMercenary1Notable6") |
| [Tactician](/wiki/Tactician "Tactician") | [Stay Light, Use Cover](/wiki/Stay_Light,_Use_Cover "Stay Light, Use Cover") | Defend with 200% of [Armour](/wiki/Armour "Armour") Enemies have an [Accuracy](/wiki/Accuracy "Accuracy") Penalty against you based on Distance Maximum Chance to Evade is 50% Maximum [Physical Damage](/wiki/Physical_Damage "Physical Damage") Reduction is 50% [[1]](/wiki/Passive_Skill:AscendancyMercenary1Notable7 "Passive Skill:AscendancyMercenary1Notable7") |
| [Witchhunter](/wiki/Witchhunter "Witchhunter") | [Obsessive Rituals](/wiki/Obsessive_Rituals "Obsessive Rituals") | Grants Skill: [Sorcery Ward](/wiki/Sorcery_Ward "Sorcery Ward") 35% less [Armour](/wiki/Armour "Armour") and Evasion Rating [[1]](/wiki/Passive_Skill:AscendancyMercenary2Notable5 "Passive Skill:AscendancyMercenary2Notable5") |

### Keystones

The following [Keystones](/wiki/Keystone "Keystone") are related to evasion:

| Name | Stats |
| --- | --- |
| [Glancing Blows](/wiki/Glancing_Blows "Glancing Blows") | Chance to Evade is [Unlucky](/wiki/Unlucky "Unlucky") Chance to [Deflect](/wiki/Deflect "Deflect") is [Lucky](/wiki/Lucky "Lucky") [[1]](/wiki/Passive_Skill:Passive~keystone~glancing~blows~ "Passive Skill:Passive~keystone~glancing~blows~") |
| [Hollow Palm Technique](/wiki/Hollow_Palm_Technique "Hollow Palm Technique") | Can [Attack](/wiki/Attack "Attack") as though using a [Quarterstaff](/wiki/Quarterstaff "Quarterstaff") while both of your hand slots are empty Unarmed [Attacks](/wiki/Attack "Attack") that would use your [Quarterstaff](/wiki/Quarterstaff "Quarterstaff")'s damage gain: • [Physical](/wiki/Physical "Physical") damage based on their Skill Level • 1% more [Attack](/wiki/Attack "Attack") Speed per 75 [Item Evasion Rating](/wiki/Defences "Defences") on [Equipped Armour Items](/wiki/Armour_(equipment) "Armour (equipment)") • +0.1% to [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") per 10 [Item Energy Shield](/wiki/Defences "Defences") on [Equipped Armour Items](/wiki/Armour_(equipment) "Armour (equipment)") [[1]](/wiki/Passive_Skill:Passive~keystone~hollow~palm~technique "Passive Skill:Passive~keystone~hollow~palm~technique") |
| [Iron Reflexes](/wiki/Iron_Reflexes "Iron Reflexes") | [Converts](/wiki/Stat_conversion "Stat conversion") all [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") to [Armour](/wiki/Armour "Armour") [[1]](/wiki/Passive_Skill:Passive~keystone~iron~reflexes~ "Passive Skill:Passive~keystone~iron~reflexes~") |
| [Knightly Tenets](/wiki/Knightly_Tenets "Knightly Tenets") | Gain no inherent bonus from [Intelligence](/wiki/Intelligence "Intelligence") 1% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") per 2 Intelligence [[1]](/wiki/Passive_Skill:Kalguur~keystone~3 "Passive Skill:Kalguur~keystone~3") |
