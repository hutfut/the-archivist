# Maraketh

✍️This article is a [stub](/wiki/Category:Stubs "Category:Stubs"). Please help [improve the article](https://www.poe2wiki.net/wiki/Maraketh/edit) by expanding it.

The **Maraketh** are a legendary and enigmatic people, living in the unforgiving desert region of [Wraeclast](/wiki/Wraeclast "Wraeclast"). They are skilled warriors with a strong connection to their gods and the desert. Their culture, while focused on survival and combat, also has a deep spiritual side, and their ancient ruins and temples hold many secrets of the past.
