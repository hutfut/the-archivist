# Trinket

**Trinkets** are a category of items that provide recovery or temporary buffs by consuming charges.

* [Flasks](/wiki/Flask "Flask")
  + [Life flasks](/wiki/Life_flask "Life flask")
  + [Mana flasks](/wiki/Mana_flask "Mana flask")
* [Charms](/wiki/Charm "Charm")
