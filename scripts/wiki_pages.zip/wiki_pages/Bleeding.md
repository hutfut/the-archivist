# Bleeding

Bleeding

Tooltip

Bleeding is an [Ailment](/wiki/Ailment "Ailment") that deals [Physical](/wiki/Physical "Physical") damage over time, and lasts 5 seconds by default. Damage from Bleeding bypasses [Energy Shield](/wiki/Energy_Shield "Energy Shield")

Bleeding deals an extra 100% damage while the target is moving, or if the Bleeding is [Aggravated](/wiki/Aggravated_Bleeding "Aggravated Bleeding").

[Physical](/wiki/Physical "Physical") damage from [Hits](/wiki/Hit "Hit") [Contributes](/wiki/Damage_Contributing_to_Ailments "Damage Contributing to Ailments") to Bleeding [Magnitude](/wiki/Magnitude "Magnitude").

Damage does not [Contribute](/wiki/Damage_Contributing_to_Ailments "Damage Contributing to Ailments") to Bleeding chance, so it cannot be inflicted without an explicit source of Bleeding chance.

The base [Magnitude](/wiki/Magnitude "Magnitude") of Bleeding is [Physical](/wiki/Physical "Physical") damage per second equal to 15% of the [Pre-mitigation](/wiki/Pre-mitigation_Damage "Pre-mitigation Damage") [Physical](/wiki/Physical "Physical") damage of the [Hit](/wiki/Hit "Hit") that inflicted it. This magnitude is not further affected by any modifiers to the damage you deal.

Modifiers and [Debuffs](/wiki/Debuff "Debuff") that affect the enemy's ability to mitigate damage (such as [Shock](/wiki/Shock "Shock")) can affect the damage the enemy takes from Bleeding, but any such modifiers that specifically apply to [Hit](/wiki/Hit "Hit") damage (such as [Armour Break](/wiki/Armour_Break "Armour Break")) do not affect Bleeding damage.

**Bleeding** or **bleed** is a damaging [ailment](/wiki/Ailment "Ailment") that deals [physical](/wiki/Physical "Physical") [damage over time](/wiki/Damage_over_time "Damage over time").

## Mechanics

Bleeding deals 75% of a [hit](/wiki/Hit "Hit")'s physical damage dealt (before mitigation and [damage taken](/wiki/Damage_taken "Damage taken") modifiers) as physical damage over time over 5 seconds. Bleeding deals an extra 100% damage while the target is moving, or if the bleeding is Aggravated. This percentage is affected multiplicatively by ailment magnitude. Ailment damage cannot be scaled directly; however, it can be indirectly scaled by modifying the hit damage.

Bleeding does not stack; each instance of bleeding has an independent duration and only the highest damage instance of bleeding will deal damage.

Bleeding chance depends on an explicit chance to inflict Bleeding.

The damage over time from bleeding bypasses [energy shield](/wiki/Energy_shield "Energy shield") and damages life directly. It also cannot be redirected to another resource, such as to Mana with [Mind Over Matter](/wiki/Mind_Over_Matter "Mind Over Matter").

Note that bleeding can be applied by any skill that can hit, not exclusively [attacks](/wiki/Attack "Attack").

### Aggravate

Aggravated Bleeding

Tooltip

Bleeding that has been Aggravated always treats the target as moving, which causes it to deal 100% extra damage.

Once a Bleeding [Debuff](/wiki/Debuff "Debuff") has been Aggravated, it will remain Aggravated until its duration expires.

Each Bleeding [Debuff](/wiki/Debuff "Debuff") can be Aggravated, or not, independently — one Bleeding [Debuff](/wiki/Debuff "Debuff") being Aggravated does not mean other Bleeding [Debuffs](/wiki/Debuff "Debuff") on the target are also Aggravated, and Aggravating some or all of them will have no effect on new Bleeding [Debuffs](/wiki/Debuff "Debuff") applied afterwards. However, effects which Aggravate Bleeding on a target do so to all Bleeding [Debuffs](/wiki/Debuff "Debuff") currently on that target unless otherwise specified.

**Aggravate** is a mechanic primarily related to bleeding. When a bleeding debuff is aggravated, it causes that bleeding debuff to permanently deal extra base damage over time, equivalent to if the target was moving. This multiplier does not stack even if the target is actually moving.

Each instance of aggravated bleeding is independent from all other instances of bleeding. A bleeding debuff that is aggravated will remain aggravated until its duration expires.

### Blood Loss

Main article: [Blood Loss](/wiki/Blood_Loss "Blood Loss")

**Blood Loss** refers to the total amount of damage a target has taken from [physical](/wiki/Physical_damage "Physical damage") [damage over time](/wiki/Damage_over_time "Damage over time"), which includes Bleeding. Blood Loss amount is shown as a darker red bar on the target's life bar and is used for certain skills.

## Related mechanics

### Incision

Main article: [Incision](/wiki/Incision "Incision")

[Incision](/wiki/Incision "Incision") is a stacking [debuff](/wiki/Debuff "Debuff") that applies +10% chance to apply Bleeding per stack. When a target becomes inflicted with Bleeding, all stacks of Incision are removed from them.

## Related skills

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Bone Blast](/wiki/Bone_Blast "Bone Blast") | *0* |  |  |  |
| [Bleeding Concoction](/wiki/Bleeding_Concoction "Bleeding Concoction") | *0* |  |  |  |
| [Rake](/wiki/Rake "Rake") | *3* |  |  |  |
| [Rapid Assault](/wiki/Rapid_Assault "Rapid Assault") | *5* |  |  |  |
| [Blood Hunt](/wiki/Blood_Hunt "Blood Hunt") | *7* |  |  |  |

### Persistent skills

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Herald of Blood](/wiki/Herald_of_Blood "Herald of Blood") | *4* |  |  |  |

## Related support gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Bleed I](/wiki/Bleed_I "Bleed I") | *1* |  |  |  |
| [Admixture](/wiki/Admixture "Admixture") | *2* |  |  |  |
| [Concoct I](/wiki/Concoct_I "Concoct I") | *2* |  |  |  |
| [Bleed II](/wiki/Bleed_II "Bleed II") | *3* |  |  |  |
| [Deep Cuts I](/wiki/Deep_Cuts_I "Deep Cuts I") | *3* |  |  |  |
| [Haemocrystals](/wiki/Haemocrystals "Haemocrystals") | *3* |  |  |  |
| [Rip](/wiki/Rip "Rip") | *3* |  |  |  |
| [Rupture](/wiki/Rupture "Rupture") | *3* |  |  |  |
| [Tear](/wiki/Tear "Tear") | *3* |  |  |  |
| [Concoct II](/wiki/Concoct_II "Concoct II") | *4* |  |  |  |
| [Incision](/wiki/Incision_(support_gem) "Incision (support gem)") | *4* |  |  |  |
| [Poison III](/wiki/Poison_III "Poison III") | *5* |  |  |  |
| [Bleed III](/wiki/Bleed_III "Bleed III") | *5* |  |  |  |
| [Bleed IV](/wiki/Bleed_IV "Bleed IV") | *5* |  |  |  |
| [Deep Cuts II](/wiki/Deep_Cuts_II "Deep Cuts II") | *5* |  |  |  |

## Related unique items

| Item | Base item | Item class |  | Stats |
| --- | --- | --- | --- | --- |
| [Apron of Emiran](/wiki/Apron_of_Emiran "Apron of Emiran") | [Hermit Garb](/wiki/Hermit_Garb "Hermit Garb") | *[Body Armour](/wiki/Body_Armour "Body Armour")* | 1 | (30-50)% increased [Evasion](/wiki/Evasion "Evasion") and [Energy Shield](/wiki/Energy_Shield "Energy Shield") +(10-20) to [Dexterity](/wiki/Dexterity "Dexterity") (60-40)% reduced Duration of Bleeding on You Bleeding you inflict is [Aggravated](/wiki/Aggravated_Bleeding "Aggravated Bleeding") |
| [Coat of Red](/wiki/Coat_of_Red "Coat of Red") | [Chain Mail](/wiki/Chain_Mail "Chain Mail") | *[Body Armour](/wiki/Body_Armour "Body Armour")* | 1 | (80-100)% increased [Armour](/wiki/Armour "Armour") and [Evasion](/wiki/Evasion "Evasion") +(80-100) to maximum Life +(75-150) to [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") 25% chance to be inflicted with Bleeding when Hit |
| [Heart of the Well](/wiki/Heart_of_the_Well "Heart of the Well") | [Diamond](/wiki/Diamond "Diamond") | *[Jewel](/wiki/Jewel "Jewel")* | 1 | <Custom Desecrated prefix> <Custom Desecrated prefix> <Custom Desecrated suffix> <Custom Desecrated suffix>   | <List of mods> | | --- | | (5-10)% chance to [Aggravate](/wiki/Aggravate "Aggravate") Bleeding on targets you [Hit](/wiki/Hit "Hit") with [Attacks](/wiki/Attack "Attack")  ---  (5-8)% increased [Attack](/wiki/Attack "Attack") Speed while a [Rare or Unique](/wiki/Rarity "Rarity") Enemy is in your [Presence](/wiki/Presence "Presence")  ---  (40-60)% increased [Armour](/wiki/Armour "Armour") from Equipped Body Armour  ---  (30-50)% chance to [Pierce](/wiki/Pierce "Pierce") an Enemy  ---  (10-15)% chance when a [Charm](/wiki/Charm "Charm") is used to use another Charm without consuming Charges  ---  [Charms](/wiki/Charm "Charm") applied to you have (15-25)% increased Effect  ---  Recover (5-10)% of maximum Mana when a [Charm](/wiki/Charm "Charm") is used  ---  (15-25)% increased [Culling Strike](/wiki/Culling_Strike "Culling Strike") Threshold  ---  [Gain](/wiki/Gain "Gain") (9-15)% of Damage as Extra [Lightning](/wiki/Lightning "Lightning") Damage  ---  [Gain](/wiki/Gain "Gain") (7-13)% of Damage as Extra [Chaos](/wiki/Chaos "Chaos") Damage  ---  [Gain](/wiki/Gain "Gain") (9-15)% of Damage as Extra [Fire](/wiki/Fire "Fire") Damage  ---  [Gain](/wiki/Gain "Gain") (9-15)% of Damage as Extra [Cold](/wiki/Cold "Cold") Damage  ---  (15-25)% increased Damage while your [Companion](/wiki/Companion "Companion") is in your [Presence](/wiki/Presence "Presence")  ---  (15-25)% increased [Exposure](/wiki/Exposure "Exposure") Effect  ---  (40-60)% increased [Evasion](/wiki/Evasion "Evasion") Rating from Equipped Body Armour  ---  Regenerate (1-1.5)% of maximum Life per Second if you've used a Life [Flask](/wiki/Flask "Flask") in the past 10 seconds  ---  (10-18)% increased [Cooldown Recovery Rate](/wiki/Cooldown_Recovery_Rate "Cooldown Recovery Rate")  ---  (40-60)% increased [Ice Crystal](/wiki/Ice_Crystal "Ice Crystal") Life  ---  (4-8)% increased [Skill Speed](/wiki/Skill_Speed "Skill Speed")  ---  (15-25)% chance for [Lightning](/wiki/Lightning "Lightning") Damage with [Hits](/wiki/Hit "Hit") to be [Lucky](/wiki/Lucky "Lucky")  ---  (8-16)% increased Mana Cost [Efficiency](/wiki/Efficiency "Efficiency")  ---  (20-30)% increased Mana Regeneration Rate while moving  ---  +1% to all [Maximum Elemental Resistances](/wiki/Maximum_Resistance "Maximum Resistance")  ---  (40-60)% increased [Energy Shield](/wiki/Energy_Shield "Energy Shield") from Equipped Body Armour  ---  [Minions](/wiki/Minion "Minion") gain (10-15)% of their maximum Life as Extra maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield")  ---  [Minions](/wiki/Minion "Minion") Regenerate (1-3)% of maximum Life per second  ---  [Minions](/wiki/Minion "Minion") [Revive](/wiki/Reviving_Minions "Reviving Minions") (5-10)% faster  ---  (8-15)% of Leech is Instant  ---  (5-10)% of Physical Damage prevented [Recouped](/wiki/Recoup "Recoup") as Life  ---  (8-14)% increased speed of [Recoup](/wiki/Recoup "Recoup") Effects  ---  Recover (2-4)% of maximum Life on Killing a [Poisoned](/wiki/Poison "Poison") Enemy  ---  (10-15)% increased Skill Effect Duration  ---  +(2-4)% to Thorns [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance  ---  Gain [Physical](/wiki/Physical "Physical") [Thorns](/wiki/Thorns "Thorns") damage equal to (4-6)% of [Item Armour](/wiki/Defences "Defences") on [Equipped](/wiki/Equipped/edit?redlink=1 "Equipped (page does not exist)") Body Armour  ---  (6-12)% chance for [Trigger](/wiki/Trigger "Trigger") skills to refund half of [Energy](/wiki/Energy "Energy") Spent  ---  (4-8)% increased chance to inflict [Ailments](/wiki/Ailments "Ailments")  ---  Gain additional [Ailment Threshold](/wiki/Ailment_Threshold "Ailment Threshold") equal to (4-10)% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield")  ---  (5-10)% chance to inflict Bleeding on [Hit](/wiki/Hit "Hit")  ---  (5-10)% chance to [Poison](/wiki/Poison "Poison") on [Hit](/wiki/Hit "Hit")  ---  (4-8)% increased [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance  ---  (6-12)% increased [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus")  ---  (2-3)% of Damage is taken from Mana before Life  ---  [Debuffs](/wiki/Debuff "Debuff") on you expire (4-8)% faster  ---  [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") deal damage (2-4)% faster  ---  (4-8)% increased [Flask](/wiki/Flask "Flask") Effect Duration  ---  Gain (1-2) [Rage](/wiki/Rage "Rage") when [Hit](/wiki/Hit "Hit") by an Enemy  ---  (2-3)% increased [Cooldown Recovery Rate](/wiki/Cooldown_Recovery_Rate "Cooldown Recovery Rate")  ---  (6-12)% increased [Elemental Ailment Threshold](/wiki/Ailment "Ailment")  ---  (2-3)% increased [Attack](/wiki/Attack "Attack") Speed  ---  (2-3)% increased Cast Speed  ---  (4-8)% increased [Flask](/wiki/Flask "Flask") Charges gained  ---  (5-10)% increased [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold")  ---  (2-3)% of Skill Mana Costs [Converted](/wiki/Stat_conversion "Stat conversion") to Life Costs  ---  (2-3)% of Damage taken [Recouped](/wiki/Recoup "Recoup") as Life  ---  (6-12)% increased Life Regeneration rate  ---  Recover (1-2)% of maximum Mana on Kill  ---  (4-8)% increased Mana Regeneration Rate  ---  +1% to [Maximum Cold Resistance](/wiki/Maximum_Cold_Resistance "Maximum Cold Resistance")  ---  +1% to [Maximum Fire Resistance](/wiki/Maximum_Fire_Resistance "Maximum Fire Resistance")  ---  Recover (1-2)% of maximum Life on Kill  ---  +1% to [Maximum Lightning Resistance](/wiki/Maximum_Lightning_Resistance "Maximum Lightning Resistance")  ---  [Minions](/wiki/Minion "Minion") have (2-3)% increased [Attack](/wiki/Attack "Attack") and Cast Speed  ---  [Minions](/wiki/Minion "Minion") have (6-12)% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance")  ---  [Minions](/wiki/Minion "Minion") have +(3-4)% to all Elemental [Resistances](/wiki/Resistances "Resistances")  ---  [Minions](/wiki/Minion "Minion") have (3-12)% additional [Physical](/wiki/Physical "Physical") Damage Reduction  ---  (1-2)% increased Movement Speed  ---  Gain 1 [Rage](/wiki/Rage "Rage") on [Melee](/wiki/Melee "Melee") [Hit](/wiki/Hit "Hit")  ---  (3-8)% increased Skill Effect Duration  ---  (10-5)% reduced [Slowing](/wiki/Slow "Slow") Potency of [Debuffs](/wiki/Debuff "Debuff") on You  ---  (4-8)% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for [Spells](/wiki/Spell "Spell")  ---  (6-12)% increased [Critical Spell Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus")  ---  (6-12)% increased [Stun](/wiki/Stun "Stun") Buildup  ---  Gain additional [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") equal to (4-10)% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") | |
| [The Blood Thorn](/wiki/The_Blood_Thorn "The Blood Thorn") | [Wrapped Quarterstaff](/wiki/Wrapped_Quarterstaff "Wrapped Quarterstaff") | *[Quarterstaff](/wiki/Quarterstaff "Quarterstaff")* | 1 | Adds (8-12) to (16-18) [Physical](/wiki/Physical "Physical") Damage +(10-15) to [Strength](/wiki/Strength "Strength") Causes Bleeding on [Hit](/wiki/Hit "Hit") (4-5) to (8-10) [Physical](/wiki/Physical "Physical") [Thorns](/wiki/Thorns "Thorns") damage |
| [Sanguine Diviner](/wiki/Sanguine_Diviner "Sanguine Diviner") | [Bone Wand](/wiki/Bone_Wand "Bone Wand") | *[Wand](/wiki/Wand "Wand")* | 2 | (80-100)% increased [Spell](/wiki/Spell "Spell") Damage Gain (10-15) Life per enemy killed 25% chance to inflict Bleeding on [Hit](/wiki/Hit "Hit") 25% of [Spell](/wiki/Spell "Spell") Mana Cost [Converted](/wiki/Stat_conversion "Stat conversion") to Life Cost |
| [Blistering Bond](/wiki/Blistering_Bond "Blistering Bond") | [Ruby Ring](/wiki/Ruby_Ring "Ruby Ring") | *[Ring](/wiki/Ring "Ring")* | 8 | +(20-30)% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance")+(40-60) to maximum Life +(20-30)% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") -(15-10)% to [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance") You take [Fire](/wiki/Fire "Fire") Damage instead of [Physical](/wiki/Physical "Physical") Damage from Bleeding |
| [Edyrn's Tusks](/wiki/Edyrn%27s_Tusks "Edyrn's Tusks") | [Iron Cuirass](/wiki/Iron_Cuirass "Iron Cuirass") | *[Body Armour](/wiki/Body_Armour "Body Armour")* | 11 | (120-160)% increased [Armour](/wiki/Armour "Armour") 50% chance to inflict Bleeding on [Hit](/wiki/Hit "Hit") 50% reduced [Slowing](/wiki/Slow "Slow") Potency of [Debuffs](/wiki/Debuff "Debuff") on You (15-20) to (25-30) [Physical](/wiki/Physical "Physical") [Thorns](/wiki/Thorns "Thorns") damage |
| [The Road Warrior](/wiki/The_Road_Warrior "The Road Warrior") | [Raider Plate](/wiki/Raider_Plate "Raider Plate") | *[Body Armour](/wiki/Body_Armour "Body Armour")* | 16 | +(10-15) to all [Attributes](/wiki/Attributes "Attributes") +(15-30)% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") +(15-30)% to [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance") (10-15) Life Regeneration per second Moving while Bleeding doesn't cause you to take extra damage |
| [Sanguis Heroum](/wiki/Sanguis_Heroum "Sanguis Heroum") | [Staunching Charm](/wiki/Staunching_Charm "Staunching Charm") | *[Charm](/wiki/Charm "Charm")* | 18 | Used when you start BleedingCreates [Consecrated Ground](/wiki/Consecrated_Ground "Consecrated Ground") on use Gains (0.15-0.20) Charges per Second |
| [The Empty Roar](/wiki/The_Empty_Roar "The Empty Roar") | [Cultist Greathammer](/wiki/Cultist_Greathammer "Cultist Greathammer") | *[Two Hand Mace](/wiki/Two_Hand_Mace "Two Hand Mace")* | 22 | Strikes deal Splash damage to targets within 1.8 metresAdds (25-35) to (40-50) [Physical](/wiki/Physical "Physical") Damage [Leeches](/wiki/Leech "Leech") 10% of [Physical](/wiki/Physical "Physical") Damage as Life (10-20)% chance to cause Bleeding on [Hit](/wiki/Hit "Hit") All Attacks count as [Empowered Attacks](/wiki/Empowered_skill "Empowered skill") Cannot use [Warcries](/wiki/Warcries "Warcries") |
| [The Smiling Knight](/wiki/The_Smiling_Knight "The Smiling Knight") | [Cowled Helm](/wiki/Cowled_Helm "Cowled Helm") | *[Helmet](/wiki/Helmet "Helmet")* | 26 | (150-200)% increased [Armour](/wiki/Armour "Armour") and [Evasion](/wiki/Evasion "Evasion") +(50-100) to [Accuracy](/wiki/Accuracy "Accuracy") Rating (15-25)% increased [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance [Aggravate](/wiki/Aggravate "Aggravate") Bleeding on targets you [Critically Hit](/wiki/Critically_Hit "Critically Hit") with [Attacks](/wiki/Attack "Attack") |
| [Saitha's Spear](/wiki/Saitha%27s_Spear "Saitha's Spear") | [Barbed Spear](/wiki/Barbed_Spear "Barbed Spear") | *[Spear](/wiki/Spear "Spear")* | 33 | Bleeding you inflict deals Damage (10-20)% fasterAdds (14-26) to (27-32) [Physical](/wiki/Physical "Physical") Damage Adds (33-41) to (47-53) [Fire](/wiki/Fire "Fire") Damage (15-25)% chance to cause Bleeding on [Hit](/wiki/Hit "Hit") [Aggravating any Bleeding](/wiki/Aggravating_any_Bleeding/edit?redlink=1 "Aggravating any Bleeding (page does not exist)") with this Weapon also [Aggravates all Ignites](/wiki/Aggravated_Ignite/edit?redlink=1 "Aggravated Ignite (page does not exist)") on the target (25-40)% chance to [Aggravate](/wiki/Aggravate "Aggravate") Bleeding on [Hit](/wiki/Hit "Hit") |
| [Venopuncture](/wiki/Venopuncture "Venopuncture") | [Iron Ring](/wiki/Iron_Ring "Iron Ring") | *[Ring](/wiki/Ring "Ring")* | 36 | Adds 1 to 4 [Physical](/wiki/Physical "Physical") Damage to [Attacks](/wiki/Attack "Attack")Adds (5-7) to (9-13) [Physical](/wiki/Physical "Physical") Damage to [Attacks](/wiki/Attack "Attack") +(20-30) to [Strength](/wiki/Strength "Strength") [All Damage](/wiki/Damage_type "Damage type") taken from [Hits](/wiki/Hit "Hit") while Bleeding [Contributes](/wiki/Contributes "Contributes") to [Magnitude](/wiki/Magnitude "Magnitude") of [Chill](/wiki/Chill "Chill") on you [All Damage](/wiki/Damage_type "Damage type") from [Hits](/wiki/Hit "Hit") against Bleeding targets [Contributes](/wiki/Contributes "Contributes") to [Chill](/wiki/Chill "Chill") [Magnitude](/wiki/Magnitude "Magnitude") (10-20)% chance to inflict Bleeding on [Hit](/wiki/Hit "Hit") (15-25)% increased [Magnitude](/wiki/Magnitude "Magnitude") of Bleeding you inflict |
| [The Mutable Star](/wiki/The_Mutable_Star "The Mutable Star") | [Cleric Vestments](/wiki/Cleric_Vestments "Cleric Vestments") | *[Body Armour](/wiki/Body_Armour "Body Armour")* | 45 | (100-150)% increased [Armour](/wiki/Armour "Armour") and [Energy Shield](/wiki/Energy_Shield "Energy Shield") (50-100)% increased [Energy Shield Recharge Rate](/wiki/Energy_Shield_Recharge_Rate "Energy Shield Recharge Rate") (25-35) Life Regeneration per second (50-30)% reduced Duration of Bleeding on You (30-50)% reduced [Ignite](/wiki/Ignite "Ignite") Duration on you Defend against [Hits](/wiki/Hit "Hit") as though you had 1% more [Armour](/wiki/Armour "Armour") per 1% current [Energy Shield](/wiki/Energy_Shield "Energy Shield") |
| [Beetlebite](/wiki/Beetlebite "Beetlebite") | [Velour Shoes](/wiki/Velour_Shoes "Velour Shoes") | *[Boots](/wiki/Boots "Boots")* | 52 | (20-30)% increased Movement Speed (60-120)% increased [Evasion](/wiki/Evasion "Evasion") and [Energy Shield](/wiki/Energy_Shield "Energy Shield") [Aggravate](/wiki/Aggravate "Aggravate") Bleeding on Enemies when they Enter your [Presence](/wiki/Presence "Presence") 100% increased [Thorns](/wiki/Thorns "Thorns") damage |
| [Couture of Crimson](/wiki/Couture_of_Crimson "Couture of Crimson") | [Gilded Vestments](/wiki/Gilded_Vestments "Gilded Vestments") | *[Body Armour](/wiki/Body_Armour "Body Armour")* | 52 | (50-100)% increased [Armour](/wiki/Armour "Armour") and [Energy Shield](/wiki/Energy_Shield "Energy Shield") (10-15)% increased maximum Life (60-40)% reduced Duration of Bleeding on You [Life Leech](/wiki/Life_Leech "Life Leech") can [Overflow](/wiki/Overflow "Overflow") Maximum Life |
| [Yriel's Fostering](/wiki/Yriel%27s_Fostering "Yriel's Fostering") | [Strider Vest](/wiki/Strider_Vest "Strider Vest") | *[Body Armour](/wiki/Body_Armour "Body Armour")* | 52 | (100-150)% increased [Evasion](/wiki/Evasion "Evasion") Rating +(80-120) to maximum Life +(10-30) to [Spirit](/wiki/Spirit "Spirit") (60-40)% reduced Duration of Bleeding on You (60-40)% reduced [Poison](/wiki/Poison "Poison") Duration on you You can have two [Companions](/wiki/Companion "Companion") of different types |
| [The Unborn Lich](/wiki/The_Unborn_Lich "The Unborn Lich") | [Ravenous Staff](/wiki/Ravenous_Staff "Ravenous Staff") | *[Staff](/wiki/Staff "Staff")* | 78 | (60-80)% increased [Desecrated Modifier](/wiki/Desecrated_modifier "Desecrated modifier") magnitudes <Custom Desecrated prefix> <Lich's Desecrated prefix> <Lich's Desecrated suffix> <Lich's Desecrated prefix or suffix>   | <List of mods> | | --- | | (86-99)% increased [Fire](/wiki/Fire "Fire") Damage (14-23)% increased [Ignite](/wiki/Ignite "Ignite") [Magnitude](/wiki/Magnitude "Magnitude")  ---  (25-40)% chance to build an additional [Combo](/wiki/Combo "Combo") on [Hit](/wiki/Hit "Hit")  ---  (86-99)% increased [Cold](/wiki/Cold "Cold") Damage (14-23)% increased [Freeze](/wiki/Freeze "Freeze") Buildup  ---  Recover (4-6)% of Maximum Mana when you expend at least 10 [Combo](/wiki/Combo "Combo")  ---  (86-99)% increased [Lightning](/wiki/Lightning "Lightning") Damage (14-23)% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Shock](/wiki/Shock "Shock") you inflict  ---  Recover (6-12)% of Maximum Life when you expend at least 10 [Combo](/wiki/Combo "Combo")  ---  +(35-50) to [Spirit](/wiki/Spirit "Spirit")  ---  (148-178)% increased [Spell](/wiki/Spell "Spell") Damage with [Spells](/wiki/Spell "Spell") that cost Life  ---  (25-35)% increased [Archon](/wiki/Archon "Archon") Buff duration  ---  +(12-16)% to [Block](/wiki/Block "Block") chance  ---  (25-35)% of [Spell](/wiki/Spell "Spell") Mana Cost [Converted](/wiki/Stat_conversion "Stat conversion") to Life Cost  ---  +(1-2) to maximum number of [Elemental Infusions](/wiki/Elemental_Infusion "Elemental Infusion")  ---  (4-5)% increased [Spell](/wiki/Spell "Spell") Damage per 100 maximum Mana  ---  [Archon](/wiki/Archon "Archon") recovery period expires (25-35)% faster  ---  (26-36)% increased Cast Speed while on Full Mana  ---  (40-64)% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") you inflict  ---  (4-5)% increased [Spell](/wiki/Spell "Spell") Damage per 100 Maximum Life  ---  (30-40)% increased Cast Speed when on [Low Life](/wiki/Low_Life "Low Life")  ---  (25-35)% chance for [Spell](/wiki/Spell "Spell") Skills to fire 2 additional [Projectiles](/wiki/Projectile "Projectile")  ---  (100-160)% increased [Chaos](/wiki/Chaos "Chaos") Damage Enemies you kill have a (5-10)% chance to explode, dealing a quarter of their maximum Life as [Chaos](/wiki/Chaos "Chaos") damage  ---  (100-160)% increased [Chaos](/wiki/Chaos "Chaos") Damage Enemies you [Curse](/wiki/Curse "Curse") have -(8-5)% to Chaos [Resistance](/wiki/Resistance "Resistance")  ---  (100-160)% increased [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") (10-20)% increased Duration of Elemental [Ailments](/wiki/Ailments "Ailments") on Enemies  ---  (100-160)% increased [Spell](/wiki/Spell "Spell") [Physical](/wiki/Physical "Physical") Damage (20-30)% chance to inflict Bleeding on [Hit](/wiki/Hit "Hit")  ---  +(40-60) to [Spirit](/wiki/Spirit "Spirit") (6-10)% increased [Spirit](/wiki/Spirit "Spirit") [Reservation](/wiki/Reservation "Reservation") [Efficiency](/wiki/Efficiency "Efficiency") of Skills  ---  You have [Unholy Might](/wiki/Unholy_Might "Unholy Might") (28-56)% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Unholy Might](/wiki/Unholy_Might "Unholy Might") buffs you grant | |

## Related passive skills

The following [passive skills](/wiki/Passive_skill "Passive skill") are related to bleeding:

### Chance to inflict bleeding

| Name | Stats |
| --- | --- |
| [Bleed Chance](/wiki/Bleed_Chance/edit?redlink=1 "Bleed Chance (page does not exist)") | 5% chance to inflict Bleeding on [Hit](/wiki/Hit "Hit") [[1]](/wiki/Passive_Skill:Jagged~ground1 "Passive Skill:Jagged~ground1") [[2]](/wiki/Passive_Skill:Jagged~ground2 "Passive Skill:Jagged~ground2") [[3]](/wiki/Passive_Skill:Physical16 "Passive Skill:Physical16") [[4]](/wiki/Passive_Skill:Physical19 "Passive Skill:Physical19") [[5]](/wiki/Passive_Skill:Physical~witch5~ "Passive Skill:Physical~witch5~") [[6]](/wiki/Passive_Skill:Physical~witch6 "Passive Skill:Physical~witch6") [[7]](/wiki/Passive_Skill:Physical~witch9 "Passive Skill:Physical~witch9") |
| [Bleeding Chance](/wiki/Bleeding_Chance/edit?redlink=1 "Bleeding Chance (page does not exist)") | 5% chance to inflict Bleeding on [Hit](/wiki/Hit "Hit") [[1]](/wiki/Passive_Skill:Bleed10 "Passive Skill:Bleed10") [[2]](/wiki/Passive_Skill:Bleed15 "Passive Skill:Bleed15") [[3]](/wiki/Passive_Skill:Bleed21~ "Passive Skill:Bleed21~") [[4]](/wiki/Passive_Skill:Bleed23 "Passive Skill:Bleed23") [[5]](/wiki/Passive_Skill:Bleed26 "Passive Skill:Bleed26") [[6]](/wiki/Passive_Skill:Bleed27 "Passive Skill:Bleed27") [[7]](/wiki/Passive_Skill:Bleed4 "Passive Skill:Bleed4") |
| [Bleeding Chance on Critical](/wiki/Bleeding_Chance_on_Critical/edit?redlink=1 "Bleeding Chance on Critical (page does not exist)") | 10% chance to inflict Bleeding on [Critical Hit](/wiki/Critical_Hit "Critical Hit") with [Attacks](/wiki/Attack "Attack") [[1]](/wiki/Passive_Skill:Bleed8~ "Passive Skill:Bleed8~") [[2]](/wiki/Passive_Skill:Bleed9 "Passive Skill:Bleed9") |
| [Empowered Attack Damage and Bleeding Chance](/wiki/Empowered_Attack_Damage_and_Bleeding_Chance/edit?redlink=1 "Empowered Attack Damage and Bleeding Chance (page does not exist)") | [Empowered Attacks](/wiki/Empowered_skill "Empowered skill") deal 10% increased Damage 5% chance to inflict Bleeding on [Hit](/wiki/Hit "Hit") [[1]](/wiki/Passive_Skill:Warcries4 "Passive Skill:Warcries4") [[2]](/wiki/Passive_Skill:Warcries2 "Passive Skill:Warcries2") |
| [Bloodletting](/wiki/Bloodletting/edit?redlink=1 "Bloodletting (page does not exist)") | 10% chance to inflict Bleeding on [Hit](/wiki/Hit "Hit") 15% increased [Magnitude](/wiki/Magnitude "Magnitude") of Bleeding you inflict [[1]](/wiki/Passive_Skill:Bleed6 "Passive Skill:Bleed6") |

### Bleeding magnitude

| Name | Stats |
| --- | --- |
| [Bleed Damage](/wiki/Bleed_Damage/edit?redlink=1 "Bleed Damage (page does not exist)") | 10% increased [Magnitude](/wiki/Magnitude "Magnitude") of Bleeding you inflict [[1]](/wiki/Passive_Skill:Jagged~ground6 "Passive Skill:Jagged~ground6") |
| [Bleeding Damage](/wiki/Bleeding_Damage/edit?redlink=1 "Bleeding Damage (page does not exist)") | 10% increased [Magnitude](/wiki/Magnitude "Magnitude") of Bleeding you inflict [[1]](/wiki/Passive_Skill:Bleed14 "Passive Skill:Bleed14") [[2]](/wiki/Passive_Skill:Bleed17 "Passive Skill:Bleed17") [[3]](/wiki/Passive_Skill:Bleed19~ "Passive Skill:Bleed19~") [[4]](/wiki/Passive_Skill:Bleed22~ "Passive Skill:Bleed22~") [[5]](/wiki/Passive_Skill:Bleed24 "Passive Skill:Bleed24") [[6]](/wiki/Passive_Skill:Bleed25 "Passive Skill:Bleed25")  ---  15% increased [Magnitude](/wiki/Magnitude "Magnitude") of Bleeding you inflict against Enemies affected by [Incision](/wiki/Incision "Incision") [[5]](/wiki/Passive_Skill:Bleed37 "Passive Skill:Bleed37") [[6]](/wiki/Passive_Skill:Bleed38 "Passive Skill:Bleed38") [[7]](/wiki/Passive_Skill:Bleed44 "Passive Skill:Bleed44") [[8]](/wiki/Passive_Skill:Bleed45 "Passive Skill:Bleed45") |
| [Critical Bleeding Effect](/wiki/Critical_Bleeding_Effect/edit?redlink=1 "Critical Bleeding Effect (page does not exist)") | 15% increased [Magnitude](/wiki/Magnitude "Magnitude") of Bleeding you inflict with [Critical Hits](/wiki/Critical_Hit "Critical Hit") [[1]](/wiki/Passive_Skill:Bleed2 "Passive Skill:Bleed2") [[2]](/wiki/Passive_Skill:Bleed3 "Passive Skill:Bleed3") [[3]](/wiki/Passive_Skill:Bleed7 "Passive Skill:Bleed7") |
| [Blood Tearing](/wiki/Blood_Tearing/edit?redlink=1 "Blood Tearing (page does not exist)") | 25% increased [Physical](/wiki/Physical "Physical") Damage 15% increased [Magnitude](/wiki/Magnitude "Magnitude") of Bleeding you inflict [[1]](/wiki/Passive_Skill:Physical35 "Passive Skill:Physical35") |
| [Bloodletting](/wiki/Bloodletting/edit?redlink=1 "Bloodletting (page does not exist)") | 10% chance to inflict Bleeding on [Hit](/wiki/Hit "Hit") 15% increased [Magnitude](/wiki/Magnitude "Magnitude") of Bleeding you inflict [[1]](/wiki/Passive_Skill:Bleed6 "Passive Skill:Bleed6") |
| [Rupturing Pins](/wiki/Rupturing_Pins/edit?redlink=1 "Rupturing Pins (page does not exist)") | 40% increased [Magnitude](/wiki/Magnitude "Magnitude") of Bleeding you inflict against [Pinned](/wiki/Pinned "Pinned") Enemies [[1]](/wiki/Passive_Skill:Physical~witch10 "Passive Skill:Physical~witch10") |

### Bleeding duration

| Name | Stats |
| --- | --- |
| [Bleeding Duration](/wiki/Bleeding_Duration/edit?redlink=1 "Bleeding Duration (page does not exist)") | 10% increased Bleeding Duration [[1]](/wiki/Passive_Skill:Bleed1 "Passive Skill:Bleed1") [[2]](/wiki/Passive_Skill:Bleed28 "Passive Skill:Bleed28") |

### Aggravate bleeding

| Name | Stats |
| --- | --- |
| [Aggravation](/wiki/Aggravation/edit?redlink=1 "Aggravation (page does not exist)") | 10% chance to [Aggravate](/wiki/Aggravate "Aggravate") Bleeding on targets you [Hit](/wiki/Hit "Hit") with [Attacks](/wiki/Attack "Attack") [[1]](/wiki/Passive_Skill:Bleed13 "Passive Skill:Bleed13") |
| [Deep Wounds](/wiki/Deep_Wounds/edit?redlink=1 "Deep Wounds (page does not exist)") | [Attack](/wiki/Attack "Attack") [Hits](/wiki/Hit "Hit") [Aggravate](/wiki/Aggravate "Aggravate") any Bleeding on targets which is older than 4 seconds [[1]](/wiki/Passive_Skill:Bleed5 "Passive Skill:Bleed5") |
| [Internal Bleeding](/wiki/Internal_Bleeding/edit?redlink=1 "Internal Bleeding (page does not exist)") | [Empowered Attacks](/wiki/Empowered_skill "Empowered skill") deal 30% increased Damage 20% chance to [Aggravate](/wiki/Aggravate "Aggravate") Bleeding on targets you [Hit](/wiki/Hit "Hit") with [Empowered](/wiki/Empowered "Empowered") [Attacks](/wiki/Attack "Attack") [[1]](/wiki/Passive_Skill:Warcries14~ "Passive Skill:Warcries14~") |
| [Perfectly Placed Knife](/wiki/Perfectly_Placed_Knife/edit?redlink=1 "Perfectly Placed Knife (page does not exist)") | 25% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") against Bleeding Enemies 20% chance to [Aggravate](/wiki/Aggravate "Aggravate") Bleeding on targets you [Critically Hit](/wiki/Critically_Hit "Critically Hit") with [Attacks](/wiki/Attack "Attack") [[1]](/wiki/Passive_Skill:Bleed12 "Passive Skill:Bleed12") |
| [Perforation](/wiki/Perforation/edit?redlink=1 "Perforation (page does not exist)") | 20% chance for Bleeding to be [Aggravated](/wiki/Aggravated_Bleeding "Aggravated Bleeding") when Inflicted against Enemies on [Jagged Ground](/wiki/Jagged_Ground "Jagged Ground") 40% increased [Jagged Ground](/wiki/Jagged_Ground "Jagged Ground") Duration [[1]](/wiki/Passive_Skill:Jagged~ground25 "Passive Skill:Jagged~ground25") |
| [Rusted Pins](/wiki/Rusted_Pins/edit?redlink=1 "Rusted Pins (page does not exist)") | Bleeding you inflict on [Pinned](/wiki/Pinned "Pinned") Enemies is [Aggravated](/wiki/Aggravated_Bleeding "Aggravated Bleeding") 30% increased [Pin](/wiki/Pinned "Pinned") Buildup [[1]](/wiki/Passive_Skill:Bleed32 "Passive Skill:Bleed32") |

### Miscellany

| Name | Stats |
| --- | --- |
| [Attack Damage vs Bleeding Enemies](/wiki/Attack_Damage_vs_Bleeding_Enemies/edit?redlink=1 "Attack Damage vs Bleeding Enemies (page does not exist)") | 16% increased [Attack](/wiki/Attack "Attack") Damage against Bleeding Enemies [[1]](/wiki/Passive_Skill:Bleed11~~ "Passive Skill:Bleed11~~") [[2]](/wiki/Passive_Skill:Bleed16 "Passive Skill:Bleed16") |
| [Bleeding Out](/wiki/Bleeding_Out/edit?redlink=1 "Bleeding Out (page does not exist)") | +250 to Accuracy against Bleeding Enemies Bleeding you inflict deals Damage 10% faster [[1]](/wiki/Passive_Skill:Bleed18 "Passive Skill:Bleed18") |
| [Haemorrhaging Cuts](/wiki/Haemorrhaging_Cuts/edit?redlink=1 "Haemorrhaging Cuts (page does not exist)") | Enemies you inflict Bleeding on cannot Regenerate Life [[1]](/wiki/Passive_Skill:Physical~witch8 "Passive Skill:Physical~witch8") |
| [Perfectly Placed Knife](/wiki/Perfectly_Placed_Knife/edit?redlink=1 "Perfectly Placed Knife (page does not exist)") | 25% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") against Bleeding Enemies 20% chance to [Aggravate](/wiki/Aggravate "Aggravate") Bleeding on targets you [Critically Hit](/wiki/Critically_Hit "Critically Hit") with [Attacks](/wiki/Attack "Attack") [[1]](/wiki/Passive_Skill:Bleed12 "Passive Skill:Bleed12") |
| [Staggering Wounds](/wiki/Staggering_Wounds/edit?redlink=1 "Staggering Wounds (page does not exist)") | 50% chance to [Knock Back](/wiki/Knock_Back "Knock Back") Bleeding Enemies with [Hits](/wiki/Hit "Hit") [[1]](/wiki/Passive_Skill:Bleed34 "Passive Skill:Bleed34") |
| [Staunch Deflection](/wiki/Staunch_Deflection/edit?redlink=1 "Staunch Deflection (page does not exist)") | [Deflected](/wiki/Deflect "Deflect") [Hits](/wiki/Hit "Hit") cannot inflict Bleeding on you [Deflected](/wiki/Deflect "Deflect") [Hits](/wiki/Hit "Hit") cannot inflict [Maim](/wiki/Maim "Maim") on you [[1]](/wiki/Passive_Skill:Deflect53 "Passive Skill:Deflect53") |
| [Tolerant Equipment](/wiki/Tolerant_Equipment/edit?redlink=1 "Tolerant Equipment (page does not exist)") | Immune to Bleeding if Equipped Helmet has higher [Armour](/wiki/Armour "Armour") than [Evasion](/wiki/Evasion "Evasion") Rating Immune to [Poison](/wiki/Poison "Poison") if Equipped Helmet has higher [Evasion](/wiki/Evasion "Evasion") Rating than [Armour](/wiki/Armour "Armour") [[1]](/wiki/Passive_Skill:Armour~and~evasion40 "Passive Skill:Armour~and~evasion40") |

### Paths Not Taken passive skills

The following passive skills are exclusive the [Oracle](/wiki/Oracle "Oracle") with [The Unseen Path](/wiki/The_Unseen_Path "The Unseen Path") allocated:

| Name | Stats |
| --- | --- |
| [Bleed Duration](/wiki/Bleed_Duration/edit?redlink=1 "Bleed Duration (page does not exist)") | 10% increased Bleeding Duration 20% chance for [Attack](/wiki/Attack "Attack") [Hits](/wiki/Hit "Hit") to apply [Incision](/wiki/Incision "Incision") [[1]](/wiki/Passive_Skill:Oracle~bleed1 "Passive Skill:Oracle~bleed1") [[2]](/wiki/Passive_Skill:Oracle~bleed2 "Passive Skill:Oracle~bleed2") |
| [Scent of Blood](/wiki/Scent_of_Blood "Scent of Blood") | 20% increased Bleeding Duration 40% chance for [Attack](/wiki/Attack "Attack") [Hits](/wiki/Hit "Hit") to apply [Incision](/wiki/Incision "Incision") 3% increased Movement Speed [[1]](/wiki/Passive_Skill:Oracle~bleed3 "Passive Skill:Oracle~bleed3") |

### Ascendancy passive skills

The following [Ascendancy passive skills](/wiki/Ascendancy_passive_skill "Ascendancy passive skill") are related to bleeding:

| Ascendancy Class | Name | Stats |
| --- | --- | --- |
| [Blood Mage](/wiki/Blood_Mage "Blood Mage") | [Bleed on Critical Chance](/wiki/Bleed_on_Critical_Chance/edit?redlink=1 "Bleed on Critical Chance (page does not exist)") | 15% chance to inflict Bleeding on [Critical Hit](/wiki/Critical_Hit "Critical Hit") [[1]](/wiki/Passive_Skill:AscendancyWitch2Small4~ "Passive Skill:AscendancyWitch2Small4~") |
| [Blood Mage](/wiki/Blood_Mage "Blood Mage") | [Blood Barbs](/wiki/Blood_Barbs "Blood Barbs") | Bleeding you inflict on [Cursed](/wiki/Curse "Curse") targets is [Aggravated](/wiki/Aggravated_Bleeding "Aggravated Bleeding") [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") also [Contributes](/wiki/Contributes "Contributes") to Bleeding [Magnitude](/wiki/Magnitude "Magnitude") [[1]](/wiki/Passive_Skill:AscendancyWitch2Notable4 "Passive Skill:AscendancyWitch2Notable4") |

### Keystones

The following [keystones](/wiki/Keystone "Keystone") are related to bleeding:

| Name | Stats |
| --- | --- |
| [Chaos Inoculation](/wiki/Chaos_Inoculation "Chaos Inoculation") | Maximum Life is 1 Immune to [Chaos](/wiki/Chaos "Chaos") Damage and Bleeding [[1]](/wiki/Passive_Skill:Passive~keystone~chaos~inoculation "Passive Skill:Passive~keystone~chaos~inoculation") |
| [Crimson Assault](/wiki/Crimson_Assault "Crimson Assault") | Bleeding you inflict is [Aggravated](/wiki/Aggravated_Bleeding "Aggravated Bleeding") Base Bleeding Duration is 1 second 50% more [Magnitude](/wiki/Magnitude "Magnitude") of Bleeding you inflict [[1]](/wiki/Passive_Skill:Passive~keystone~crimson~dance~ "Passive Skill:Passive~keystone~crimson~dance~") |
