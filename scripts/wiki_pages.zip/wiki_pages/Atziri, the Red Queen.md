# Atziri, the Red Queen

|  |  |
| --- | --- |
| Atziri, the Red Queen | |
| Atziri, the Red Queen | |
| Location(s) | [Atziri's Temple](/wiki/Atziri%27s_Temple "Atziri's Temple") |
| Damage | Fire, Lightning, Physical |
| Resistance(s) | 30% 30% 30% |

Atziri prior to communing with [the Beast](/wiki/The_Beast "The Beast").

Atziri, the Fell Serpent

**Atziri, the Red Queen** is the [pinnacle boss](/wiki/Pinnacle_boss "Pinnacle boss") of the [Fate of the Vaal](/wiki/Fate_of_the_Vaal "Fate of the Vaal") [league mechanic](/wiki/Encounter "Encounter"). She is found in [Atziri's Temple](/wiki/Atziri%27s_Temple "Atziri's Temple"). She has a second form called **Atziri, the Fell Serpent**.

## Access

In order to fight Atziri, the player must first complete a series of tasks in the Temple of Atziri:

* Place rooms to access the Architect's Chamber
* Defeat [Xipocado, Royal Architect](/wiki/Xipocado,_Royal_Architect "Xipocado, Royal Architect")
* Use Xipocado's Console to place a Royal Access Chamber
* Place rooms to access Royal Access Chamber and unlock Atziri's Chambers
* Place rooms to access Atziri's Chamber

Though Atziri's Chamber can be pathed to directly, the door that leads to her arena will not unlock until the character interacts with the Royal Access Chamber.

## Abilities

### Atziri, the Red Queen

* Melee Attacks: Can randomly convert 40% of Physical Damage to Fire or Lightning.
* Blood Spear: Throws a spear in the air which falls and explodes into a tightly packed nova of 50 projectiles that inflict a stack of [Corrupted Blood](/wiki/Corrupted_Blood "Corrupted Blood") and [Maim](/wiki/Maim "Maim").
* Spinning Flame Wall: Swings her spear in a circle dealing attack damage, creating a ring of fire on the ground that inflicts [Ignite](/wiki/Ignite "Ignite").
* Flameblast: Channels for a duration before exploding a large marked area, dealing fire damage.
* Empowered Flameblast: Creates two overlapping large red runes that explode after a delay, dealing heavy fire damage.
* Lightning Bolt: Infuses herself with lightning before firing a bolt of energy, exploding in an area on impact with the ground.
* Lightning Spear: Throws a ring of lightning-infused spears, which create runes that explode dealing lightning damage.
* Storm Call: Lightning randomly strikes in a large area for a duration.

After reaching 10% life, she will escape through the mirror portal at the back of the arena to "The Cradle", entering phase 2 and transforming into **Atziri, the Fell Serpent** at full life.

### Atziri, the Fell Serpent

* Spinning Flame Wall 2: Swings her spear in a circle dealing attack damage, creating a ring of fire on the ground. The arena outside of the ring is covered in [Ignited Ground](/wiki/Ignited_Ground "Ignited Ground") for a long duration.
* Blood Spear Barrage: Throws four spears which fall consecutively in random locations, exploding into a tightly packed nova of 50 projectiles that inflict a stack of [Corrupted Blood](/wiki/Corrupted_Blood "Corrupted Blood") and [Maim](/wiki/Maim "Maim").
* Empowered Flameblast: Creates two overlapping large red runes that explode after a delay, dealing heavy fire damage.
* Vaal Storm Call: Creates several rows of runes covering the arena except for a small line down the center that explode dealing heavy lightning damage.
* Teleport Slam: Leaps into the air out of sight before slamming down in an area.
* Flesh Bubble: After reaching 20% life, creates an expanding large red area that eventually covers almost the entire arena except the far corners of the arena closest to the Beast, before exploding dealing lethal physical spell damage that cannot be avoided. Can be damaged during animation.

At 5% life, she will become invulnerable, and a cutscene will play resulting in her being swallowed by the Beast and starting the Cataclysm, ending the encounter.

## Drops

After defeating Atziri, she will drop [Atziri's Medallion](/wiki/Atziri%27s_Medallion "Atziri's Medallion"). This item must be taken to entrance of Atziri's Chamber at the [checkpoint](/wiki/Checkpoint "Checkpoint"). The Medallion will be consumed to unlock Atziri's Vault (containing her drops) as well as six Royal Trove chests (containing currency). The opening of the chests is delayed to an animation.

### Atziri's Vault

Estimated drop rates from [version 0.4.0](/wiki/Version_0.4.0 "Version 0.4.0"). n=100[[1]](#cite_note-1) Actual drop rates may vary.

Atziri's Vault always contains one of the following unique items:

* [Atziri's Step](/wiki/Atziri%27s_Step "Atziri's Step") (35%)
* [Drillneck](/wiki/Drillneck "Drillneck") (32%)
* [Atziri's Splendour](/wiki/Atziri%27s_Splendour "Atziri's Splendour") (12%, 7 random variants)
* [Atziri's Rule](/wiki/Atziri%27s_Rule "Atziri's Rule") (12%)
* [Atziri's Contempt](/wiki/Atziri%27s_Contempt "Atziri's Contempt") (8%)
* [Flesh Crucible](/wiki/Flesh_Crucible "Flesh Crucible") (1%)

Atziri's Vault can also contain the following items:

* [Sacrificial Regalia](/wiki/Sacrificial_Regalia "Sacrificial Regalia") (100%, magic or rare rarity)
* Several rare items with high unidentified tier
* [Atziri's Impatience](/wiki/Atziri%27s_Impatience "Atziri's Impatience") (8%)
* [Zerphi's Infamy](/wiki/Zerphi%27s_Infamy "Zerphi's Infamy") (11%)

### Royal Trove

The six Royal Troves can contain several of the following items:

* Rare tier or higher regular currency
* Greater or Perfect currency
* [Atziri's Temple](/wiki/Atziri%27s_Temple "Atziri's Temple") exclusive currency
  + [Ancient Infuser](/wiki/Ancient_Infuser "Ancient Infuser")
  + [Architect's Orb](/wiki/Architect%27s_Orb "Architect's Orb")
  + [Core Destabiliser](/wiki/Core_Destabiliser "Core Destabiliser")
  + [Crystallised Corruption](/wiki/Crystallised_Corruption "Crystallised Corruption")
  + [Orb of Extraction](/wiki/Orb_of_Extraction "Orb of Extraction")
  + [Vaal Cultivation Orb](/wiki/Vaal_Cultivation_Orb "Vaal Cultivation Orb")
  + [Vaal Infuser](/wiki/Vaal_Infuser "Vaal Infuser")
* [Vaal Siphoner](/wiki/Vaal_Siphoner "Vaal Siphoner")

## Lore

The fight with Atziri takes place right as Atziri communes with the Beast and takes on her new corrupted form, which would eventually be further twisted into the demonic form that can be encountered in [Path of Exile](/wiki/Path_of_Exile "Path of Exile")'s [Apex of Sacrifice](https://www.poewiki.net/wiki/Apex_of_Sacrifice "poewiki:Apex of Sacrifice").
