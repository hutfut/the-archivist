# Gold

GoldStack Size: *10000*Can be spent at Vendors.Account-bound

*Acquisition*
Drop level: *1**Metadata*
Item class: *Currency Item*
Metadata ID: *Metadata/Items/Currency/GoldCoin*

**Gold** is a collectible item that drops from monsters and [chests](/wiki/Chest "Chest"). Gold can be used to purchase [items](/wiki/Item "Item") from [vendors](/wiki/Vendor "Vendor"), [respec](/wiki/Respec "Respec") [passive skills](/wiki/Passive_skill "Passive skill"), and exchange items on the [currency exchange](/wiki/Currency_exchange "Currency exchange"). Gold is account-bound and is shared between all characters within the same [league](/wiki/League "League"). It cannot be traded or transferred to other players in any way.

## Mechanics

* Any Gold within pickup range will be added to your inventory automatically upon moving or teleporting using a skill.
* Gold does not take up any inventory space. The amount of Gold currently held can be seen on your Inventory screen.
* Gold cannot be traded with other players or itemized.
* Gold can be used to respec passive skills.
* Gold can be used to change the chosen attribute of [attribute](/wiki/Attribute "Attribute") travel nodes, at half the price of respeccing.
* Gold is required as a cost for buying and selling items on the [Currency Exchange](/wiki/Currency_Exchange "Currency Exchange").
* Gold is required to purchase items via [asynchronous trading](/wiki/Asynchronous_trading "Asynchronous trading").

## Uses

Each [town](/wiki/Town "Town") contains a [vendor](/wiki/Vendor "Vendor") and [gambler](/wiki/Gambler "Gambler") that can trade the player items for gold.

## Item acquisition

Gold can drop anywhere.

Dropped items have a chance to be converted to gold. This is inversely correlated with the item's [rarity](/wiki/Rarity "Rarity"); normal items are significantly more likely to drop as gold than higher rarity items.[[1]](#cite_note-1) Only up to 50% of a Unique monster's drops can be gold.[[2]](#cite_note-2)
