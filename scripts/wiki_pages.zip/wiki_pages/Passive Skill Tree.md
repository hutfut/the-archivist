# Passive Skill Tree

The **Passive Skill Tree** is a vast, interconnected web of [passive](/wiki/Passive "Passive") skill in [Path of Exile 2](/wiki/Path_of_Exile_2 "Path of Exile 2") that allows players to customize their character's [attributes](/wiki/Attributes "Attributes") and powers. It serves as the primary progression system for character development, providing access to numerous bonuses, such as increased [damage](/wiki/Damage "Damage"), [survivability](/wiki/Survivability "Survivability"), or [utility](/wiki/Utility "Utility"). Players allocate **Passive Skill Points** on the Passive Tree by leveling up or completing certain [quests](/wiki/Quest "Quest"), enabling deep build customization and unique playstyles.

## Passive tree nodes

Passive Tree Nodes are individual points on the Tree that grant specific bonuses when allocated. Nodes come in various types:

* **Attribute Nodes (Travel Nodes):** Adds +5 to any [attribute](/wiki/Attribute "Attribute") selected. This node can be changed to a different [attribute](/wiki/Attribute "Attribute") for half the [gold](/wiki/Gold "Gold") cost as refunding one passive.
  + The [Traveller's Wisdom](/wiki/Traveller%27s_Wisdom "Traveller's Wisdom") passive from [Pathfinder](/wiki/Pathfinder "Pathfinder") grants additional options for stat bonuses that can be selected on the attribute nodes.
* **Small Passives:** Provide minor bonuses to a variety of stats, such as increased damage or defenses.
* **Notable Passives:** Passives which provide a significant boost to power or unique mechanics, generally requiring allocating the small passives preceding them to unlock.
* **Jewel Sockets:** Special nodes that allow players to socket [jewels](/wiki/Jewel "Jewel") into them, which grant highly modular bonuses. Jewels can be removed and swapped out at any time.
* **Keystones:** Passives which dramatically alter gameplay mechanics, often providing powerful benefits alongside drawbacks.

Nodes are interconnected, and players must allocate points in a path to reach desired nodes.

## Layout

The Passive Skill Tree consists of a large circle in the center as the starting area, several passives cluster spread across the entire tree, and attribute nodes that connect everything together. Each cluster contains multiple small passives that lead to a notable passive, some of which having different pathways leading into the notable. The type of bonuses from each cluster tend to be more generalized near the center and more powerful or specialized the further they are. Each class starts from one of the sections from the large circle in the center of the tree, depending on their primary attributes.

The Passive Skill Tree is divided into distinct sections, each indirectly associated with one of the game's three primary [attributes](/wiki/Attributes "Attributes"): [Strength](/wiki/Strength "Strength"), [Dexterity](/wiki/Dexterity "Dexterity"), and [Intelligence](/wiki/Intelligence "Intelligence"). These sections influence the types of bonuses and playstyles available in each area and dictate the starting points for characters based on their class:

* The southwest section of the passive tree is focused on **Strength**; it proves bonuses to mechanics such as [fire damage](/wiki/Fire_damage "Fire damage"), [armour](/wiki/Armour "Armour"), [melee](/wiki/Melee "Melee") combat, [endurance charges](/wiki/Endurance_charge "Endurance charge"), [block](/wiki/Block "Block"), [warcries](/wiki/Warcry "Warcry"), and life [leech](/wiki/Leech "Leech").
* The southeast section of the passive tree is focused on **Dexterity**; it proves bonuses to mechanics such as [lightning damage](/wiki/Lightning_damage "Lightning damage"), [evasion](/wiki/Evasion "Evasion"), [ranged](/wiki/Ranged "Ranged") attacks, [Frenzy charges](/wiki/Frenzy_charge "Frenzy charge"), [deflection](/wiki/Deflection "Deflection"), [accuracy](/wiki/Accuracy "Accuracy"), and [flask](/wiki/Flask "Flask") recovery.
* The north section of the passive tree is focused on **Intelligence**; it proves bonuses to mechanics such as [cold damage](/wiki/Cold_damage "Cold damage"), [chaos damage](/wiki/Chaos_damage "Chaos damage"), [energy shield](/wiki/Energy_shield "Energy shield"), [spells](/wiki/Spell "Spell"), [minions](/wiki/Minion "Minion"), [power charges](/wiki/Power_charge "Power charge"), [mana](/wiki/Mana "Mana"), and [curses](/wiki/Curse "Curse").
* The passive skills available between these sections are hybridized between the two.

This structure ensures that starting positions reflect each class's core identity, while the flexibility of the Passive Skill Tree allows for highly customized builds that can explore other sections as desired.

The [Druid](/wiki/Druid "Druid") [Ascendancy class](/wiki/Ascendancy_class "Ascendancy class") [Oracle](/wiki/Oracle "Oracle") can view exclusive passive nodes no other classes have access to. They can be allocated after taking [The Unseen Path](/wiki/The_Unseen_Path "The Unseen Path") passive.

### Ascendancy skill tree

Each class gains access to an [Ascendancy class](/wiki/Ascendancy_class "Ascendancy class") skill tree after completing their first [Ascension Trial](/wiki/Ascension_Trial "Ascension Trial"), which can be found within the center circle. The Ascendancy skill tree is a small sub-tree that contains highly specialized and build-defining passive skills. They require Ascendancy passive skill points to allocate, and each difficulty of an Ascension Trial grants two Ascendancy passive points, up to 8 per character.

The Ascendancy passive tree is separate from the regular skill tree and generally do not interact with each other.

## Passive skill points

Characters gain one Passive Skill Point each time they gain a [level](/wiki/Level "Level"). They can also gain additional skill points by completing certain [quests](/wiki/Quest "Quest") or using [quest rewards](/wiki/Quest_reward "Quest reward") dropped by certain [bosses](/wiki/Boss "Boss"). Each character can gain up to 99 passive points from levels and 24 from quests, for a total of 123 skill points. However, players should have a build that can function with 10-20 points less than this, due to the time it takes to reach maximum level.

Certain [Ascendancy classes](/wiki/Ascendancy_class "Ascendancy class") can gain additional passive skill points:

* [Pathfinders](/wiki/Pathfinder "Pathfinder") can gain up to 6 passive skill points from [Path Seeker](/wiki/Path_Seeker "Path Seeker") and the minor nodes surrounding it.
* [Oracles](/wiki/Oracle "Oracle") can gain up to 2 passive skill points from the minor nodes preceding [The Unseen Path](/wiki/The_Unseen_Path "The Unseen Path") and [Entwined Realities](/wiki/Entwined_Realities "Entwined Realities").

## Weapon specialisation

Certain quest items like the [Book of Specialisation](/wiki/Book_of_Specialisation "Book of Specialisation") or quest rewards grant two Weapon Set Passive Skill Points, which can be allocated separately to each weapon set, with the exception of [keystone](/wiki/Keystone "Keystone") passives and [jewel](/wiki/Jewel "Jewel") sockets. This system provides flexibility for builds that utilize multiple weapon setups or prefer to invest in general passives. You can also allocate these passive points as regular passives instead.

Each character can gain up to 24 Weapon Set Passive Skill Points throughout the course of the campaign. The [Witchhunter](/wiki/Witchhunter "Witchhunter") passive [Weapon Master](/wiki/Weapon_Master "Weapon Master") converts up to 100 regular passive points into weapon set passive points.

If you allocate points to both [weapon sets](/wiki/Weapon_set "Weapon set"), refunding these points requires removing one from each weapon set to reclaim a single normal Passive Skill Point.

## Respecialisation

**Respecialisation**, also known as "refunding" or "respeccing", is the process of reallocating passive skill points. Players can remove previously allocated nodes on the tree by spending [Gold](/wiki/Gold "Gold"), with the cost increasing as the character's level rises. This system allows for build adjustments, experimentation, and correcting mistakes in skill allocation while balancing accessibility with resource management.

Refund cost per level

| Level | [Gold](/wiki/Gold "Gold") Cost |
| --- | --- |
| 1 | 15 |
| 2 | 19 |
| 3 | 25 |
| 4 | 31 |
| 5 | 39 |
| 6 | 46 |
| 7 | 60 |
| 8 | 73 |
| 9 | 85 |
| 10 | 98 |
| 11 | 113 |
| 12 | 128 |
| 13 | 145 |
| 14 | 163 |
| 15 | 182 |
| 16 | 211 |
| 17 | 225 |
| 18 | 241 |
| 19 | 257 |
| 20 | 273 |
| 21 | 290 |
| 22 | 308 |
| 23 | 326 |
| 24 | 344 |
| 25 | 364 |
| 26 | 384 |
| 27 | 404 |
| 28 | 425 |
| 29 | 447 |
| 30 | 470 |
| 31 | 493 |
| 32 | 517 |
| 33 | 542 |
| 34 | 567 |
| 35 | 593 |
| 36 | 620 |
| 37 | 648 |
| 38 | 676 |
| 39 | 706 |
| 40 | 736 |
| 41 | 767 |
| 42 | 799 |
| 43 | 832 |
| 44 | 866 |
| 45 | 900 |
| 46 | 936 |
| 47 | 973 |
| 48 | 1010 |
| 49 | 1049 |
| 50 | 1089 |
| 51 | 1130 |
| 52 | 1172 |
| 53 | 1215 |
| 54 | 1259 |
| 55 | 1304 |
| 56 | 1351 |
| 57 | 1399 |
| 58 | 1448 |
| 59 | 1498 |
| 60 | 1550 |
| 61 | 1603 |
| 62 | 1657 |
| 63 | 1713 |
| 64 | 1770 |
| 65 | 1829 |
| 66 | 1889 |
| 67 | 1950 |
| 68 | 2014 |
| 69 | 2078 |
| 70 | 2145 |
| 71 | 2213 |
| 72 | 2282 |
| 73 | 2354 |
| 74 | 2427 |
| 75 | 2502 |
| 76 | 2578 |
| 77 | 2657 |
| 78 | 2737 |
| 79 | 2820 |
| 80 | 2904 |
| 81 | 3089 |
| 82 | 3281 |
| 83 | 3480 |
| 84 | 3686 |
| 85 | 3899 |
| 86 | 4120 |
| 87 | 4349 |
| 88 | 4585 |
| 89 | 4829 |
| 90 | 5081 |
| 91 | 5509 |
| 92 | 5952 |
| 93 | 6412 |
| 94 | 6889 |
| 95 | 7383 |
| 96 | 7895 |
| 97 | 8425 |
| 98 | 8974 |
| 99 | 9542 |
| 100 | 10129 |

## Ways to interact with the skill tree

Certain effects allow you to modify the bonuses granted by passive skills on the skill tree or even allocate passives that you haven't directly pathed into.

[Liquid emotions](/wiki/Liquid_emotion "Liquid emotion") from [Delirium](/wiki/Delirium "Delirium") encounters can be used to Instil an amulet to give it an [enchantment](/wiki/Enchantment "Enchantment") modifier that allocates a notable passive skill anywhere on the tree and without using a skill point. Note that effects which allocate passives do not stack if you have already directly allocated the passive skill yourself.

Unique jewels such as [Controlled Metamorphosis](/wiki/Controlled_Metamorphosis "Controlled Metamorphosis") and [From Nothing](/wiki/From_Nothing "From Nothing") and certain Ascendancy passives allow you to allocate points into passives within its radius without having them be directly connected to your skill tree.

Certain effects like the [Titan](/wiki/Titan "Titan") passive skill [Hulking Form](/wiki/Hulking_Form "Hulking Form"), [Time-lost jewel](/wiki/Time-lost_jewel "Time-lost jewel") modifiers, and certain unique jewels can increase the effect of small passives, modifying the amount of stats they give, or add additional stats to passives.

Unique [Timeless Jewels](/wiki/Timeless_Jewel "Timeless Jewel") transform passive skills within their radius, adding new modifiers or replacing them with new ones, including keystone passives, which is determined by the seed listed on its modifier.
