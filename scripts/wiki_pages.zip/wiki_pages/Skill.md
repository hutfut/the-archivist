# Skill

**Skills** are abilities used by [players](/wiki/Player/edit?redlink=1 "Player (page does not exist)"), [allies](/wiki/Allies "Allies"), and [monsters](/wiki/Monster "Monster") that are not inherent effects. For players, most skills are obtained by placing a [skill gem](/wiki/Skill_gem "Skill gem") in the skills menu, which grants the ability to bind that skill to a keybind. Certain [items](/wiki/Item "Item") and [Ascendancy class](/wiki/Ascendancy_class "Ascendancy class") passives can also grant skills, which are automatically added to the skills menu. For non-player allies and monsters, skills simply describe all of their used abilities.

## Using skills

Skills are used when the corresponding keybind on their skill bar is pressed, as long as the character can pay the skill's cost and meets any specific conditions or requirements to use it. The most common varieties of skills usually involve [attacking](/wiki/Attack "Attack") with a [martial weapon](/wiki/Martial_weapon "Martial weapon"), [shield](/wiki/Shield "Shield"), or [unarmed](/wiki/Unarmed "Unarmed") hand, casting a [spell](/wiki/Spell "Spell"), summoning a [minion](/wiki/Minion "Minion") or [totem](/wiki/Totem "Totem"), using a [warcry](/wiki/Warcry "Warcry"), or throwing a [trap](/wiki/Trap "Trap") or [grenade](/wiki/Attachment "Attachment"). Most of the skills require an initial animation to be played, which scales with player's stats such as [attack speed](/wiki/Attack_speed "Attack speed"), [cast speed](/wiki/Cast_speed "Cast speed"), throw time, etc. It is possible to animation cancel most skills by using a [dodge roll](/wiki/Dodge_roll "Dodge roll") or certain other skills, and skills with longer animations usually have some form of maneuverability to adjust aim.

Some skills are considered instant skills and have no animation time. These can be used without interrupting other actions. Additionally, other skills may not require active use, and instead [reserve](/wiki/Reserve "Reserve") a resource called [spirit](/wiki/Spirit "Spirit") to provide permanent [buffs](/wiki/Buff "Buff"), maintain automatically reviving permanent minions, or [trigger](/wiki/Trigger "Trigger") other skills automatically when a condition is met. Notably, triggered skills do not count as a "skill use", and will accordingly not benefit stats that care if you've attacked or cast a skill.

The number of permanent minions of each type can be customized in the skills menu for a fixed reservation for each minion.

All players have a default of 9 skill slots in their skills menu in which skill gems can be placed. Inserting a skill gem unlocks several linked [gem sockets](/wiki/Gem_socket "Gem socket"), which can be socketed with [support gems](/wiki/Support_gem "Support gem") to modify the skill's effects. Certain types of skill gems called [meta gems](/wiki/Meta_gem "Meta gem") also can be supported by skill gems, often to trigger them automatically. Each skill gem has a listed minimum [level](/wiki/Level "Level") requirement and [attribute](/wiki/Attribute "Attribute") requirement to equip and use it. Support gems do not have a set level or attribute requirement, but are limited in how many can be socketed overall of each colour based on the player's total [attributes](/wiki/Attribute "Attribute"); for example, a player with high [dexterity](/wiki/Dexterity "Dexterity") will have a higher limit of green support gems than red or blue.

In addition to these skill slots, all players have a default skill based on their currently equipped weapon which can also be supported by support gems. For [martial weapons](/wiki/Martial_weapon "Martial weapon"), these are a thematically appropriate [default attack](/wiki/Default_attack "Default attack"). For [wands](/wiki/Wand "Wand"), [staves](/wiki/Staff "Staff"), and [sceptres](/wiki/Sceptre "Sceptre"), these are unique [spells](/wiki/Spell "Spell"), [minion](/wiki/Minion "Minion") skills, or [auras](/wiki/Aura "Aura") that cannot be found as skill gems. These default skills have no cost or reservation, allowing them to be used relatively freely regardless of the player's [mana](/wiki/Mana "Mana") or spirit.

Other skills granted from [items](/wiki/Item "Item") and [passive skills](/wiki/Passive_skill_tree "Passive skill tree") such as from [ascendancy classes](/wiki/Ascendancy_class "Ascendancy class") also do not use skill slots and are automatically added to the skills menu. Likewise, they are supportable by support gems. These skills' level and number of sockets scales with character level. Item skill sockets can be directly modified using a [Jeweller's Orb](/wiki/Jeweller%27s_Orb "Jeweller's Orb"), while skills from passives will gain sockets with character level, up to level 90 for a 6-link gem.

You cannot socket more than one copy of the same skill gem, but it is still possible to acquire multiple versions of the same the same skill if it comes from an item or passive. Skill gems which store a captured monster (e.g. [Bind Spectre](/wiki/Bind_Spectre "Bind Spectre"), [Tame Beast](/wiki/Tame_Beast "Tame Beast")) count as different skills if a different monster is bound to them.

## Obtaining skills

### Skill gems

All [skill gems](/wiki/Skill_gem "Skill gem") grant skills.

### Hybrid gems

Main article: [List of hybrid gems](/wiki/List_of_hybrid_gems/edit?redlink=1 "List of hybrid gems (page does not exist)")

[Support gems](/wiki/Support_gem "Support gem") may sometimes have a skill component, usually as a trigger; these are sometimes called "hybrid gems".

### Items granting inherent skills

Main article: [List of items granting inherent weapon skills](/wiki/List_of_items_granting_inherent_weapon_skills "List of items granting inherent weapon skills")

All [wands](/wiki/Wand "Wand"), [staves](/wiki/Staff "Staff"), and [sceptres](/wiki/Sceptre "Sceptre") grant inherent skills as an implicit modifier. All [shields](/wiki/Shield "Shield") grant the [Raise Shield](/wiki/Raise_Shield "Raise Shield") skill, all [bucklers](/wiki/Buckler "Buckler") grant the [Parry](/wiki/Parry "Parry") skill, and all [spears](/wiki/Spear "Spear") grant the [Spear Throw](/wiki/Spear_Throw "Spear Throw") skill. All [martial weapons](/wiki/Martial_weapons "Martial weapons") grant a "default attack" skill, but this skill is not listed in its mods. Some [unique items](/wiki/Unique_item "Unique item") may also grant a skill, either directly or through a [trigger](/wiki/Trigger "Trigger").

### Items granting existing skills

Main article: [List of items granting existing skills](/wiki/List_of_items_granting_existing_skills "List of items granting existing skills")

Certain items may grant skills that exist as skill gems as an explicit modifier. These are functionally identical to their gem counterparts, but cannot be [corrupted](/wiki/Corrupted "Corrupted") or have their skill level or [gem socket](/wiki/Gem_socket "Gem socket") increased using [uncut gems](/wiki/Uncut_gem "Uncut gem") or [Jeweller's Orbs](/wiki/Jeweller%27s_Orb "Jeweller's Orb").

### Passives granting skills

Main article: [List of passive skills granting skills](/wiki/List_of_passive_skills_granting_skills "List of passive skills granting skills")

Certain passive skills, typically [ascendancy](/wiki/Ascendancy "Ascendancy") passive skills, can grant exclusive unique skills.
