# Miscellaneous map item

A **miscellaneous map item**, or **misc map item**, is an item that can be used similar to a [waystone](/wiki/Waystone "Waystone") to generate an [area](/wiki/Area "Area"). Many of these items are used to encounter [endgame](/wiki/Endgame "Endgame") bosses and encounters. The specific properties of these items can vary.

## Mechanics

Most misc map items can be used by placing them into [the Realmgate](/wiki/The_Realmgate "The Realmgate").

[Expedition Logbooks](/wiki/Expedition_Logbook "Expedition Logbook") are an exception and must be opened through [Dannig](/wiki/Dannig "Dannig")'s interface to select a specific logbook area to enter.

Like [waystones](/wiki/Waystone "Waystone"), these items create six [portals](/wiki/Portal "Portal") to the area, but players cannot enter the area again if they [die](/wiki/Death "Death").

## List of misc map items

| Item |
| --- |
| [Expedition Logbook](/wiki/Expedition_Logbook "Expedition Logbook") |
| [Breach Splinter](/wiki/Breach_Splinter "Breach Splinter") |
| [Petition Splinter](/wiki/Petition_Splinter "Petition Splinter") |
| [Runic Splinter](/wiki/Runic_Splinter "Runic Splinter") |
| [Simulacrum Splinter](/wiki/Simulacrum_Splinter "Simulacrum Splinter") |
