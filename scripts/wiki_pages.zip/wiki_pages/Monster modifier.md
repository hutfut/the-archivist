# Monster modifier

✍️This article is a [stub](/wiki/Category:Stubs "Category:Stubs"). Please help [improve the article](https://www.poe2wiki.net/wiki/Monster_modifier/edit) by expanding it.

[Monsters](/wiki/Monsters "Monsters") can have [modifiers](/wiki/Modifier "Modifier") which increase their danger and rewards.

## Explicit modifiers

Magic monsters and monster minions can have up to one affix; rare monsters have 2-4 affixes. It is possible to increase the number of affixes further or apply them to unique monsters through certain [Atlas passive skills](/wiki/Atlas_passive_skill "Atlas passive skill") or modifiers. Each additional modifier grants the monster increased item [rarity](/wiki/Rarity "Rarity") and [quantity](/wiki/Quantity/edit?redlink=1 "Quantity (page does not exist)").

When monster modifiers are stolen by players (e.g. through [Behead](/wiki/Behead "Behead"), [Headhunter](/wiki/Headhunter "Headhunter"), [Ritual Sacrifice](/wiki/Ritual_Sacrifice "Ritual Sacrifice"), etc.) the stats the modifiers grant to players may be different than the stats they grant to monsters.

| Modifier | Modifier description |
| --- | --- |
| Increased Stun Threshold | Cannot be [Stunned](/wiki/Stun "Stun") |
| Fire Resistant | +10% to Maximum Fire Resistance +50% to Fire Resistance |
| Cold Resistant | +10% to Maximum Cold Resistance +50% to Cold Resistance |
| Lightning Resistant | +10% to Maximum Lightning Resistance +50% to Lightning Resistance |
| Chaos Resistant | +50% to Chaos Resistance |
| Extra Fire Damage | Gain 40% of Damage as Extra Fire Damage |
| Extra Cold Damage | Gain 40% of Damage as Extra Cold Damage |
| Extra Lightning Damage | Gain 40% of Damage as Extra Lightning Damage |
| Extra Chaos Damage | Gain 40% of Damage as Extra Chaos Damage |
| Always Bleeds | Inflict [Bleeding](/wiki/Bleeding "Bleeding") on Hit |
| All Damage Ignites | Hits always Ignite All Damage from Hits Contributes to Ignite Chance and Magnitude |
| All Damage Chills | All Damage from Hits Contributes to Chill Magnitude Chills from your Hits always reduce Action Speed by at least 10% |
| All Damage Shocks | Hits always Shock All Damage from Hits Contributes to Shock Chance |
| Always Poisons | [Poison](/wiki/Poison "Poison") on Hit |
| Breaks Armour | Break [Armour](/wiki/Armour "Armour") equal to 1000% of Physical Damage dealt |
| Stuns | 100% increased Stun Buildup |
| Extra Crits | 300% increased Critical Hit Chance |
| Accurate | 200% increased Accuracy Rating |
| Hasted | 30% increased Movement Speed 30% increased Attack and Cast Speed |
| Increased Area of Effect | 100% more Area of Effect |
| Additional Projectiles | Skills fire 4 additional Projectiles |
| Armoured | 100% increased Armour |
| Evasive | 100% increased Evasion Rating |
| Extra Energy Shield | Gain 25% of Maximum Life as Extra Maximum Energy Shield |
| Increased Life | 50% increased maximum Life |
| Regenerates Life | Regenerate 2% of Life per second |
| Crit Resistant | Hits against you have 80% reduced Critical Damage Bonus |
| Stun Resistant | 250% increased Stun Threshold |
| Slow Resistant | 50% less Slowing Potency of Debuffs on you |
| Damage Taken From Minions First | 50% of Damage is taken from your Minions before your Life or Energy Shield |
| Trail of Fire | Creates [Ignited Ground](/wiki/Ignited_Ground "Ignited Ground") that lasts for 3 seconds |
| Trail of Ice | Creates [Chilled Ground](/wiki/Chilled_Ground "Chilled Ground") that lasts for 4 seconds |
| Trail of Lightning | Creates [Shocked Ground](/wiki/Shocked_Ground "Shocked Ground") that lasts for 4 seconds |
| Periodically unleashes Fire |  |
| Periodically unleashes Ice | Periodically unleashes an Ice Nova |
| Periodically unleashes Lightning |  |
| Periodic Fire Explosions | Creates circular areas on the ground that explode dealing Fire Damage |
| Periodic Cold Explosions | Creates circular areas on the ground that explode dealing Cold Damage |
| Periodic Lightning Explosions | Creates circular areas on the ground that explode dealing Lightning Damage |
| Conjures Flamewalls | Periodically creates [Flame Walls](/wiki/Flame_Wall "Flame Wall") |
| Conjures Ice Prisons | Periodically creates walls of ice |
| Conjures Lightning Storms | Periodically creates several markers on the ground, creating lightning bolts from the sky at their locations |
| Magma Barrier | Surrounded by a Magma Barrier that takes #% of Damage from Hits up to a fixed amount When the Magma Barrier is depleted it explodes for massive Fire Damage Barrier returns # seconds after exploding |
| Lightning Mirages When Hit | Trigger Lightning Mirage when Hit with a global cooldown |
| Siphons Mana and Deals Lightning Damage | Surrounded by a Mana [Siphoning Ring](/wiki/Siphoning_Ring/edit?redlink=1 "Siphoning Ring (page does not exist)") Aura (disables Mana recovery) Enemies in the Aura take Lightning Damage Over Time and lose Mana every second Enemies standing inside the Ring are not affected by the Aura |
| Siphons Mana and Deals Lightning Damage (Empowered) | Surrounded by a Mana [Siphoning Ring](/wiki/Siphoning_Ring/edit?redlink=1 "Siphoning Ring (page does not exist)") Aura (disables Mana recovery) Enemies in the Aura take Lightning Damage Over Time and lose Mana every second Enemies standing inside the Ring are not affected by the Aura Periodically creates areas of damaging [Shocked Ground](/wiki/Shocked_Ground "Shocked Ground") |
| Bombardier | Periodically fires mortar projectiles |
| Explodes Nearby Corpses | [Explodes](/wiki/Explode/edit?redlink=1 "Explode (page does not exist)") nearby corpses, dealing Physical Damage equal to #% of the corpse's Maximum Life |
| Heals Allies and Suppresses Foe Recovery | Periodically casts a Healing Nova that causes nearby allies to regenerate 10% of life over 2 seconds Healing Nova applies a Verdant Spores debuff causing 60% reduced Recovery Rate of Life and Energy Shield for a duration  Healing Nova does not affect itself (or player minions) Healing Nova cannot be used if the Monster with this modifier is on full life |
| Shroud Walker | Teleports to distant Enemies creating a Smoke Cloud |
| Soul Eater | [Soul Eater](/wiki/Soul_Eater "Soul Eater") (Gains 1% increased skill speed and 1% additional [damage reduction](/wiki/Damage_reduction "Damage reduction") per consumed Soul, max 50 Souls) |
| Siphons Flask Charges | Flasks gain -0.05 charges per Second |
| Prevents Recovery Above 50% | Nearby Enemies Cannot Recover Life or Energy Shield to above 35% |
| Hinder Aura | Nearby Enemies are Hindered with 30% reduced Movement Speed |
| Temporal Bubble | Enemies within the Temporal Bubble have 10/25% reduced Action Speed, 20/60% reduced Cooldown Recovery Rate and Debuffs on them expire 40% slower |
| Elemental Resistance Aura | You and nearby Allies gain +20/35% to all Elemental Resistances |
| Energy Shield Aura | You and nearby Allies gain 12/30% of Maximum Life as Extra Maximum Energy Shield |
| Haste Aura | You and nearby Allies gain 25% increased Attack and Cast Speed and 25% increased Movement Speed |
| Extra Physical Damage Aura | You and nearby Allies gain 20/40% increased Global Physical Damage |
| [Proximal Tangibility](/wiki/Proximal_Tangibility "Proximal Tangibility") | Can only be damaged by enemies in Close Range (2m?) |
| Powerful Minions | Minions have 25% increased Damage Minions have 50% increased maximum Life |
| Reviving Minions | Revives nearby Minion corpses |
| Empowering Reviving Minions | Revives nearby Minion corpses |
| Periodic Invulnerability Aura | Applies an Immunity buff to nearby allies for a short duration Immunity buff is removed on death Allies with Immunity cannot gain Immunity |
| Empowered Periodic Invulnerability Aura | Applies an Immunity buff to nearby allies for a short duration Immunity buff is removed on death Allies with Immunity cannot gain Immunity |
| Periodically Enrages | Every 9 seconds become Frenzied for 5 seconds 40% increased Damage while Frenzied 25% increased Action Speed while Frenzied 50% reduced Damage Taken while Frenzied |
| Enraged | 40% increased Damage 25% increased Action Speed 50% reduced Damage Taken |
| Volatile Plants | Creates Purple Explosive Plants that deal Damage |
| Empowering Volatile Plants | Creates Purple Explosive Plants that deal Damage Plant explosions also grant allies ~10% of Physical Damage as Extra Chaos Damage for a duration |
| Volatile Crag | Creates Volatile Orbs that follow the player and explode, dealing Damage |
| Empowering Volatile Crag | Creates Volatile Orbs that follow the player and explode, dealing Damage |

### Reward modifiers

Main article: [List of monster reward mods](/wiki/List_of_monster_reward_mods/edit?redlink=1 "List of monster reward mods (page does not exist)")

[List of monster reward mods](/wiki/List_of_monster_reward_mods/edit?redlink=1 "List of monster reward mods (page does not exist)")
