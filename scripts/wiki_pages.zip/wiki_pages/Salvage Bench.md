# Salvage Bench

A **Salvage Bench** is a crafting bench that allows you to destroy [equipment](/wiki/Equipment "Equipment") [items](/wiki/Item "Item") for [quality](/wiki/Quality "Quality") [currency](/wiki/Currency "Currency") ([Armourer's Scrap](/wiki/Armourer%27s_Scrap "Armourer's Scrap")s, [Blacksmith's Whetstone](/wiki/Blacksmith%27s_Whetstone "Blacksmith's Whetstone")s, [Arcanist's Etcher](/wiki/Arcanist%27s_Etcher "Arcanist's Etcher")) and [Artificer's Shard](/wiki/Artificer%27s_Shard "Artificer's Shard")s.

## Acquisition

The Salvage Bench is unlocked after completing the [quest](/wiki/Quest "Quest") [Finding the Forge](/wiki/Finding_the_Forge "Finding the Forge") by handing in [Smithing Tools](/wiki/Smithing_Tools "Smithing Tools") to [Renly](/wiki/Renly "Renly") in [Act 1](/wiki/Act_1 "Act 1"). Doing so will unlock the bench in [towns](/wiki/Town "Town") and [hideouts](/wiki/Hideout "Hideout").

## Mechanics

Most equipment that can have quality and/or rune sockets can be salvaged for currency. [Gems](/wiki/Gem "Gem") and [jewellery](/wiki/Jewellery "Jewellery") cannot be salvaged, even if they have quality.

* [Martial weapons](/wiki/Martial_weapon "Martial weapon") give [Blacksmith's Whetstones](/wiki/Blacksmith%27s_Whetstone "Blacksmith's Whetstone")
* [wands](/wiki/Wand "Wand"), [staves](/wiki/Staff "Staff"), and [sceptres](/wiki/Sceptre "Sceptre") give [Arcanist's Etchers](/wiki/Arcanist%27s_Etcher "Arcanist's Etcher")
* [armour](/wiki/Armour_(equipment) "Armour (equipment)") and [off-hand](/wiki/Off-hand "Off-hand") items give [Armourer's Scraps](/wiki/Armourer%27s_Scrap "Armourer's Scrap")
* [Flasks](/wiki/Flask "Flask") and [charms](/wiki/Charm "Charm") give [Glassblower's Baubles](/wiki/Glassblower%27s_Bauble "Glassblower's Bauble")

When salvaging an item, you receive the following:

* 1x quality currency for every 5% quality, with a chance for an additional 1x quality currency for additional quality between each 5% breakpoint.
* 1x [Artificer's Shard](/wiki/Artificer%27s_Shard "Artificer's Shard") per socket

Any items socketed into a [rune socket](/wiki/Rune_socket "Rune socket") will be destroyed when salvaging.
