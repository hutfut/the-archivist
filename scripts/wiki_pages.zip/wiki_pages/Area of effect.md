# Area of effect

Area of Effect Skills

Tooltip

This Skill has an effect that applies to every target in its area, rather than picking specific targets.

Areas of Effect that originate from a target hit by a Skill will add that target's size to their radius.

**Area of Effect**, (AoE for short), refers to [skills](/wiki/Skill "Skill") that strike an area rather than a specific target. This [area](/wiki/Area "Area") could range form a line to a cone to circle.

## Mechanics

This skill has an effect that applies to every target in its area, rather than picking specific targets. Areas of Effect that originate from a target hit by a Skill will add that target's size to their radius.

[Dodge roll](/wiki/Dodge_roll "Dodge roll") does not grant avoidance towards AoE attacks.

## Related skills

The following [skills](/wiki/Skill "Skill") have the AoE [gem tag](/wiki/Gem_tag "Gem tag"):

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Phantasmal Arrow](/wiki/Phantasmal_Arrow "Phantasmal Arrow") | *0* |  |  |  |
| [Shattering Spite](/wiki/Shattering_Spite "Shattering Spite") | *0* |  |  |  |
| [Bone Blast](/wiki/Bone_Blast "Bone Blast") | *0* |  |  |  |
| [Decompose](/wiki/Decompose "Decompose") | *0* |  |  |  |
| [Enervating Nova](/wiki/Enervating_Nova "Enervating Nova") | *0* |  |  |  |
| [Feast of Flesh](/wiki/Feast_of_Flesh "Feast of Flesh") | *0* |  |  |  |
| [Firebolt](/wiki/Firebolt "Firebolt") | *0* |  |  |  |
| [Galvanic Field](/wiki/Galvanic_Field "Galvanic Field") | *0* |  |  |  |
| [His Foul Emergence](/wiki/His_Foul_Emergence "His Foul Emergence") | *0* |  |  |  |
| [His Scattering Calamity](/wiki/His_Scattering_Calamity "His Scattering Calamity") | *0* |  |  |  |
| [His Vile Intrusion](/wiki/His_Vile_Intrusion "His Vile Intrusion") | *0* |  |  |  |
| [His Winnowing Flame](/wiki/His_Winnowing_Flame "His Winnowing Flame") | *0* |  |  |  |
| [Icestorm](/wiki/Icestorm "Icestorm") | *0* |  |  |  |
| [Lightning Bolt](/wiki/Lightning_Bolt "Lightning Bolt") | *0* |  |  |  |
| [Lightning Bolt](/wiki/Lightning_Bolt_(Choir_of_the_Storm) "Lightning Bolt (Choir of the Storm)") | *0* |  |  |  |
| [Reap](/wiki/Reap "Reap") | *0* |  |  |  |
| [Sigil of Power](/wiki/Sigil_of_Power "Sigil of Power") | *0* |  |  |  |
| [Solar Orb](/wiki/Solar_Orb "Solar Orb") | *0* |  |  |  |
| [Volatile Dead](/wiki/Volatile_Dead "Volatile Dead") | *0* |  |  |  |
| [Acidic Concoction](/wiki/Acidic_Concoction "Acidic Concoction") | *0* |  |  |  |
| [Apocalypse](/wiki/Apocalypse "Apocalypse") | *0* |  |  |  |
| [Bleeding Concoction](/wiki/Bleeding_Concoction "Bleeding Concoction") | *0* |  |  |  |
| [Bursting Fen Toad](/wiki/Bursting_Fen_Toad "Bursting Fen Toad") | *0* |  |  |  |
| [Chaotic Surge](/wiki/Chaotic_Surge "Chaotic Surge") | *0* |  |  |  |
| [Consecrate](/wiki/Consecrate "Consecrate") | *0* |  |  |  |
| [Crossbow Shot](/wiki/Crossbow_Shot "Crossbow Shot") | *0* |  |  |  |
| [Elemental Expression](/wiki/Elemental_Expression "Elemental Expression") | *0* |  |  |  |
| [Elemental Storm](/wiki/Elemental_Storm "Elemental Storm") | *0* |  |  |  |
| [Elemental Surge](/wiki/Elemental_Surge "Elemental Surge") | *0* |  |  |  |
| [Explosive Concoction](/wiki/Explosive_Concoction "Explosive Concoction") | *0* |  |  |  |
| [Fulminating Concoction](/wiki/Fulminating_Concoction "Fulminating Concoction") | *0* |  |  |  |
| [Gemini Surge](/wiki/Gemini_Surge "Gemini Surge") | *0* |  |  |  |
| [Inevitable Agony](/wiki/Inevitable_Agony "Inevitable Agony") | *0* |  |  |  |
| [Kelari's Deception](/wiki/Kelari%27s_Deception "Kelari's Deception") | *0* |  |  |  |
| [Kelari's Judgment](/wiki/Kelari%27s_Judgment "Kelari's Judgment") | *0* |  |  |  |
| [Mace Strike](/wiki/Mace_Strike_(two_hand) "Mace Strike (two hand)") | *0* |  |  |  |
| [Mace Strike](/wiki/Mace_Strike_(one_hand) "Mace Strike (one hand)") | *0* |  |  |  |
| [Mace Strike](/wiki/Mace_Strike_(dual_wield) "Mace Strike (dual wield)") | *0* |  |  |  |
| [Maul](/wiki/Maul "Maul") | *0* |  |  |  |
| [Molten Crash](/wiki/Molten_Crash "Molten Crash") | *0* |  |  |  |
| [Moment of Vulnerability](/wiki/Moment_of_Vulnerability "Moment of Vulnerability") | *0* |  |  |  |
| [Navira's Fracturing](/wiki/Navira%27s_Fracturing "Navira's Fracturing") | *0* |  |  |  |
| [Navira's Oasis](/wiki/Navira%27s_Oasis "Navira's Oasis") | *0* |  |  |  |
| [Punch](/wiki/Punch "Punch") | *0* |  |  |  |
| [Quarterstaff Strike](/wiki/Quarterstaff_Strike "Quarterstaff Strike") | *0* |  |  |  |
| [Raise Shield](/wiki/Raise_Shield "Raise Shield") | *0* |  |  |  |
| [Rend](/wiki/Rend "Rend") | *0* |  |  |  |
| [Requiem](/wiki/Requiem "Requiem") | *0* |  |  |  |
| [Ruzhan's Fury](/wiki/Ruzhan%27s_Fury "Ruzhan's Fury") | *0* |  |  |  |
| [Ruzhan's Reckoning](/wiki/Ruzhan%27s_Reckoning "Ruzhan's Reckoning") | *0* |  |  |  |
| [Ruzhan's Trap](/wiki/Ruzhan%27s_Trap "Ruzhan's Trap") | *0* |  |  |  |
| [Shattering Concoction](/wiki/Shattering_Concoction "Shattering Concoction") | *0* |  |  |  |
| [Shred](/wiki/Shred "Shred") | *0* |  |  |  |
| [Spear Stab](/wiki/Spear_Stab "Spear Stab") | *0* |  |  |  |
| [Spear Throw](/wiki/Spear_Throw "Spear Throw") | *0* |  |  |  |
| [Temper Weapon](/wiki/Temper_Weapon "Temper Weapon") | *0* |  |  |  |
| [Time Freeze](/wiki/Time_Freeze "Time Freeze") | *0* |  |  |  |
| [Valako's Charge](/wiki/Valako%27s_Charge "Valako's Charge") | *0* |  |  |  |
| [Disengage](/wiki/Disengage "Disengage") | *1* |  |  |  |
| [Escape Shot](/wiki/Escape_Shot "Escape Shot") | *1* |  |  |  |
| [Explosive Spear](/wiki/Explosive_Spear "Explosive Spear") | *1* |  |  |  |
| [Lightning Arrow](/wiki/Lightning_Arrow "Lightning Arrow") | *1* |  |  |  |
| [Lightning Rod](/wiki/Lightning_Rod "Lightning Rod") | *1* |  |  |  |
| [Poisonburst Arrow](/wiki/Poisonburst_Arrow "Poisonburst Arrow") | *1* |  |  |  |
| [Twister](/wiki/Twister "Twister") | *1* |  |  |  |
| [Whirling Slash](/wiki/Whirling_Slash "Whirling Slash") | *1* |  |  |  |
| [Contagion](/wiki/Contagion "Contagion") | *1* |  |  |  |
| [Flame Wall](/wiki/Flame_Wall "Flame Wall") | *1* |  |  |  |
| [Frost Bomb](/wiki/Frost_Bomb "Frost Bomb") | *1* |  |  |  |
| [Ice Nova](/wiki/Ice_Nova "Ice Nova") | *1* |  |  |  |
| [Unearth](/wiki/Unearth "Unearth") | *1* |  |  |  |
| [Entangle](/wiki/Entangle "Entangle") | *1* |  |  |  |
| [Explosive Grenade](/wiki/Explosive_Grenade "Explosive Grenade") | *1* |  |  |  |
| [Falling Thunder](/wiki/Falling_Thunder "Falling Thunder") | *1* |  |  |  |
| [Fragmentation Rounds](/wiki/Fragmentation_Rounds "Fragmentation Rounds") | *1* |  |  |  |
| [Frozen Locus](/wiki/Frozen_Locus "Frozen Locus") | *1* |  |  |  |
| [Furious Slam](/wiki/Furious_Slam "Furious Slam") | *1* |  |  |  |
| [Glacial Cascade](/wiki/Glacial_Cascade "Glacial Cascade") | *1* |  |  |  |
| [Killing Palm](/wiki/Killing_Palm "Killing Palm") | *1* |  |  |  |
| [Lunar Assault](/wiki/Lunar_Assault "Lunar Assault") | *1* |  |  |  |
| [Permafrost Bolts](/wiki/Permafrost_Bolts "Permafrost Bolts") | *1* |  |  |  |
| [Volcano](/wiki/Volcano "Volcano") | *1* |  |  |  |
| [Boneshatter](/wiki/Boneshatter "Boneshatter") | *1* |  |  |  |
| [Earthquake](/wiki/Earthquake "Earthquake") | *1* |  |  |  |
| [Rolling Slam](/wiki/Rolling_Slam "Rolling Slam") | *1* |  |  |  |
| [Cull The Weak](/wiki/Cull_The_Weak "Cull The Weak") | *3* |  |  |  |
| [Fangs of Frost](/wiki/Fangs_of_Frost "Fangs of Frost") | *3* |  |  |  |
| [Freezing Salvo](/wiki/Freezing_Salvo "Freezing Salvo") | *3* |  |  |  |
| [Lightning Spear](/wiki/Lightning_Spear "Lightning Spear") | *3* |  |  |  |
| [Rake](/wiki/Rake "Rake") | *3* |  |  |  |
| [Snipe](/wiki/Snipe "Snipe") | *3* |  |  |  |
| [Stormcaller Arrow](/wiki/Stormcaller_Arrow "Stormcaller Arrow") | *3* |  |  |  |
| [Vine Arrow](/wiki/Vine_Arrow "Vine Arrow") | *3* |  |  |  |
| [Bone Cage](/wiki/Bone_Cage "Bone Cage") | *3* |  |  |  |
| [Enfeeble](/wiki/Enfeeble "Enfeeble") | *3* |  |  |  |
| [Fireball](/wiki/Fireball "Fireball") | *3* |  |  |  |
| [Frost Darts](/wiki/Frost_Darts "Frost Darts") | *3* |  |  |  |
| [Living Bomb](/wiki/Living_Bomb "Living Bomb") | *3* |  |  |  |
| [Orb of Storms](/wiki/Orb_of_Storms "Orb of Storms") | *3* |  |  |  |
| [Flash Grenade](/wiki/Flash_Grenade "Flash Grenade") | *3* |  |  |  |
| [Incendiary Shot](/wiki/Incendiary_Shot "Incendiary Shot") | *3* |  |  |  |
| [Pounce](/wiki/Pounce "Pounce") | *3* |  |  |  |
| [Rolling Magma](/wiki/Rolling_Magma "Rolling Magma") | *3* |  |  |  |
| [Staggering Palm](/wiki/Staggering_Palm "Staggering Palm") | *3* |  |  |  |
| [Tempest Bell](/wiki/Tempest_Bell "Tempest Bell") | *3* |  |  |  |
| [Wind Blast](/wiki/Wind_Blast "Wind Blast") | *3* |  |  |  |
| [Wing Blast](/wiki/Wing_Blast "Wing Blast") | *3* |  |  |  |
| [Armour Breaker](/wiki/Armour_Breaker "Armour Breaker") | *3* |  |  |  |
| [Infernal Cry](/wiki/Infernal_Cry "Infernal Cry") | *3* |  |  |  |
| [Shield Charge](/wiki/Shield_Charge "Shield Charge") | *3* |  |  |  |
| [Shockwave Totem](/wiki/Shockwave_Totem "Shockwave Totem") | *3* |  |  |  |
| [Electrocuting Arrow](/wiki/Electrocuting_Arrow "Electrocuting Arrow") | *5* |  |  |  |
| [Ice-Tipped Arrows](/wiki/Ice-Tipped_Arrows "Ice-Tipped Arrows") | *5* |  |  |  |
| [Rapid Assault](/wiki/Rapid_Assault "Rapid Assault") | *5* |  |  |  |
| [Spearfield](/wiki/Spearfield "Spearfield") | *5* |  |  |  |
| [Storm Lance](/wiki/Storm_Lance "Storm Lance") | *5* |  |  |  |
| [Toxic Growth](/wiki/Toxic_Growth "Toxic Growth") | *5* |  |  |  |
| [Bonestorm](/wiki/Bonestorm "Bonestorm") | *5* |  |  |  |
| [Ember Fusillade](/wiki/Ember_Fusillade "Ember Fusillade") | *5* |  |  |  |
| [Frostbolt](/wiki/Frostbolt "Frostbolt") | *5* |  |  |  |
| [Pain Offering](/wiki/Pain_Offering "Pain Offering") | *5* |  |  |  |
| [Snap](/wiki/Snap "Snap") | *5* |  |  |  |
| [Arctic Howl](/wiki/Arctic_Howl "Arctic Howl") | *5* |  |  |  |
| [Devour](/wiki/Devour "Devour") | *5* |  |  |  |
| [Fury of the Mountain](/wiki/Fury_of_the_Mountain "Fury of the Mountain") | *5* |  |  |  |
| [Gas Grenade](/wiki/Gas_Grenade "Gas Grenade") | *5* |  |  |  |
| [Ice Shards](/wiki/Ice_Shards "Ice Shards") | *5* |  |  |  |
| [Ice Strike](/wiki/Ice_Strike "Ice Strike") | *5* |  |  |  |
| [Tempest Flurry](/wiki/Tempest_Flurry "Tempest Flurry") | *5* |  |  |  |
| [Thunderstorm](/wiki/Thunderstorm "Thunderstorm") | *5* |  |  |  |
| [Vaulting Impact](/wiki/Vaulting_Impact "Vaulting Impact") | *5* |  |  |  |
| [Molten Blast](/wiki/Molten_Blast "Molten Blast") | *5* |  |  |  |
| [Perfect Strike](/wiki/Perfect_Strike "Perfect Strike") | *5* |  |  |  |
| [Resonating Shield](/wiki/Resonating_Shield "Resonating Shield") | *5* |  |  |  |
| [Blood Hunt](/wiki/Blood_Hunt "Blood Hunt") | *7* |  |  |  |
| [Gas Arrow](/wiki/Gas_Arrow "Gas Arrow") | *7* |  |  |  |
| [Glacial Lance](/wiki/Glacial_Lance "Glacial Lance") | *7* |  |  |  |
| [Primal Strikes](/wiki/Primal_Strikes "Primal Strikes") | *7* |  |  |  |
| [Detonate Dead](/wiki/Detonate_Dead "Detonate Dead") | *7* |  |  |  |
| [Elemental Weakness](/wiki/Elemental_Weakness "Elemental Weakness") | *7* |  |  |  |
| [Profane Ritual](/wiki/Profane_Ritual "Profane Ritual") | *7* |  |  |  |
| [Temporal Chains](/wiki/Temporal_Chains "Temporal Chains") | *7* |  |  |  |
| [Vulnerability](/wiki/Vulnerability "Vulnerability") | *7* |  |  |  |
| [Artillery Ballista](/wiki/Artillery_Ballista "Artillery Ballista") | *7* |  |  |  |
| [Cross Slash](/wiki/Cross_Slash "Cross Slash") | *7* |  |  |  |
| [Explosive Shot](/wiki/Explosive_Shot "Explosive Shot") | *7* |  |  |  |
| [Ferocious Roar](/wiki/Ferocious_Roar "Ferocious Roar") | *7* |  |  |  |
| [Glacial Bolt](/wiki/Glacial_Bolt "Glacial Bolt") | *7* |  |  |  |
| [Siphoning Strike](/wiki/Siphoning_Strike "Siphoning Strike") | *7* |  |  |  |
| [Storm Wave](/wiki/Storm_Wave "Storm Wave") | *7* |  |  |  |
| [Voltaic Grenade](/wiki/Voltaic_Grenade "Voltaic Grenade") | *7* |  |  |  |
| [Wave of Frost](/wiki/Wave_of_Frost "Wave of Frost") | *7* |  |  |  |
| [Earthshatter](/wiki/Earthshatter "Earthshatter") | *7* |  |  |  |
| [Leap Slam](/wiki/Leap_Slam "Leap Slam") | *7* |  |  |  |
| [Shield Wall](/wiki/Shield_Wall "Shield Wall") | *7* |  |  |  |
| [Volcanic Fissure](/wiki/Volcanic_Fissure "Volcanic Fissure") | *7* |  |  |  |
| [Bloodhound's Mark](/wiki/Bloodhound%27s_Mark "Bloodhound's Mark") | *9* |  |  |  |
| [Detonating Arrow](/wiki/Detonating_Arrow "Detonating Arrow") | *9* |  |  |  |
| [Rain of Arrows](/wiki/Rain_of_Arrows "Rain of Arrows") | *9* |  |  |  |
| [Thunderous Leap](/wiki/Thunderous_Leap "Thunderous Leap") | *9* |  |  |  |
| [Dark Effigy](/wiki/Dark_Effigy "Dark Effigy") | *9* |  |  |  |
| [Despair](/wiki/Despair "Despair") | *9* |  |  |  |
| [Frost Wall](/wiki/Frost_Wall "Frost Wall") | *9* |  |  |  |
| [Incinerate](/wiki/Incinerate "Incinerate") | *9* |  |  |  |
| [Lightning Warp](/wiki/Lightning_Warp "Lightning Warp") | *9* |  |  |  |
| [Charged Staff](/wiki/Charged_Staff "Charged Staff") | *9* |  |  |  |
| [Hand of Chayula](/wiki/Hand_of_Chayula "Hand of Chayula") | *9* |  |  |  |
| [Oil Barrage](/wiki/Oil_Barrage "Oil Barrage") | *9* |  |  |  |
| [Oil Grenade](/wiki/Oil_Grenade "Oil Grenade") | *9* |  |  |  |
| [Siege Ballista](/wiki/Siege_Ballista "Siege Ballista") | *9* |  |  |  |
| [Stormblast Bolts](/wiki/Stormblast_Bolts "Stormblast Bolts") | *9* |  |  |  |
| [Thrashing Vines](/wiki/Thrashing_Vines "Thrashing Vines") | *9* |  |  |  |
| [Forge Hammer](/wiki/Forge_Hammer "Forge Hammer") | *9* |  |  |  |
| [Fortifying Cry](/wiki/Fortifying_Cry "Fortifying Cry") | *9* |  |  |  |
| [Sunder](/wiki/Sunder "Sunder") | *9* |  |  |  |
| [Elemental Sundering](/wiki/Elemental_Sundering "Elemental Sundering") | *11* |  |  |  |
| [Shockchain Arrow](/wiki/Shockchain_Arrow "Shockchain Arrow") | *11* |  |  |  |
| [Tornado Shot](/wiki/Tornado_Shot "Tornado Shot") | *11* |  |  |  |
| [Whirlwind Lance](/wiki/Whirlwind_Lance "Whirlwind Lance") | *11* |  |  |  |
| [Ball Lightning](/wiki/Ball_Lightning "Ball Lightning") | *11* |  |  |  |
| [Bone Offering](/wiki/Bone_Offering "Bone Offering") | *11* |  |  |  |
| [Comet](/wiki/Comet "Comet") | *11* |  |  |  |
| [Firestorm](/wiki/Firestorm "Firestorm") | *11* |  |  |  |
| [Hexblast](/wiki/Hexblast "Hexblast") | *11* |  |  |  |
| [Hailstorm Rounds](/wiki/Hailstorm_Rounds "Hailstorm Rounds") | *11* |  |  |  |
| [Rampage](/wiki/Rampage "Rampage") | *11* |  |  |  |
| [Shattering Palm](/wiki/Shattering_Palm "Shattering Palm") | *11* |  |  |  |
| [Shockburst Rounds](/wiki/Shockburst_Rounds "Shockburst Rounds") | *11* |  |  |  |
| [Tornado](/wiki/Tornado "Tornado") | *11* |  |  |  |
| [Whirling Assault](/wiki/Whirling_Assault "Whirling Assault") | *11* |  |  |  |
| [Seismic Cry](/wiki/Seismic_Cry "Seismic Cry") | *11* |  |  |  |
| [Stampede](/wiki/Stampede "Stampede") | *11* |  |  |  |
| [Supercharged Slam](/wiki/Supercharged_Slam "Supercharged Slam") | *11* |  |  |  |
| [Magnetic Salvo](/wiki/Magnetic_Salvo "Magnetic Salvo") | *13* |  |  |  |
| [Spear of Solaris](/wiki/Spear_of_Solaris "Spear of Solaris") | *13* |  |  |  |
| [Toxic Domain](/wiki/Toxic_Domain "Toxic Domain") | *13* |  |  |  |
| [Wind Serpent's Fury](/wiki/Wind_Serpent%27s_Fury "Wind Serpent's Fury") | *13* |  |  |  |
| [Flameblast](/wiki/Flameblast "Flameblast") | *13* |  |  |  |
| [Lightning Conduit](/wiki/Lightning_Conduit "Lightning Conduit") | *13* |  |  |  |
| [Cluster Grenade](/wiki/Cluster_Grenade "Cluster Grenade") | *13* |  |  |  |
| [Flame Breath](/wiki/Flame_Breath "Flame Breath") | *13* |  |  |  |
| [Flicker Strike](/wiki/Flicker_Strike "Flicker Strike") | *13* |  |  |  |
| [Gathering Storm](/wiki/Gathering_Storm "Gathering Storm") | *13* |  |  |  |
| [Lunar Blessing](/wiki/Lunar_Blessing "Lunar Blessing") | *13* |  |  |  |
| [Plasma Blast](/wiki/Plasma_Blast "Plasma Blast") | *13* |  |  |  |
| [Siege Cascade](/wiki/Siege_Cascade "Siege Cascade") | *13* |  |  |  |
| [Walking Calamity](/wiki/Walking_Calamity "Walking Calamity") | *13* |  |  |  |
| [Ancestral Cry](/wiki/Ancestral_Cry "Ancestral Cry") | *13* |  |  |  |
| [Ancestral Warrior Totem](/wiki/Ancestral_Warrior_Totem "Ancestral Warrior Totem") | *13* |  |  |  |
| [Hammer of the Gods](/wiki/Hammer_of_the_Gods "Hammer of the Gods") | *13* |  |  |  |

### Persistent skills

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Black Powder Blitz](/wiki/Black_Powder_Blitz "Black Powder Blitz") | *0* |  |  |  |
| [Blood Boil](/wiki/Blood_Boil "Blood Boil") | *0* |  |  |  |
| [Called Shots](/wiki/Called_Shots "Called Shots") | *0* |  |  |  |
| [Crackling Palm](/wiki/Crackling_Palm "Crackling Palm") | *0* |  |  |  |
| [Void Illusion](/wiki/Void_Illusion "Void Illusion") | *0* |  |  |  |
| [Herald of Thunder](/wiki/Herald_of_Thunder "Herald of Thunder") | *4* |  |  |  |
| [Plague Bearer](/wiki/Plague_Bearer "Plague Bearer") | *4* |  |  |  |
| [Wind Dancer](/wiki/Wind_Dancer "Wind Dancer") | *4* |  |  |  |
| [Briarpatch](/wiki/Briarpatch_(skill_gem) "Briarpatch (skill gem)") | *4* |  |  |  |
| [Herald of Blood](/wiki/Herald_of_Blood "Herald of Blood") | *4* |  |  |  |
| [Herald of Ice](/wiki/Herald_of_Ice "Herald of Ice") | *4* |  |  |  |
| [War Banner](/wiki/War_Banner "War Banner") | *4* |  |  |  |
| [Herald of Ash](/wiki/Herald_of_Ash "Herald of Ash") | *4* |  |  |  |
| [Iron Ward](/wiki/Iron_Ward "Iron Ward") | *4* |  |  |  |
| [Magma Barrier](/wiki/Magma_Barrier "Magma Barrier") | *4* |  |  |  |
| [Trail of Caltrops](/wiki/Trail_of_Caltrops "Trail of Caltrops") | *8* |  |  |  |
| [Blasphemy](/wiki/Blasphemy "Blasphemy") | *8* |  |  |  |
| [Defiance Banner](/wiki/Defiance_Banner "Defiance Banner") | *8* |  |  |  |
| [Dread Banner](/wiki/Dread_Banner "Dread Banner") | *14* |  |  |  |

## Support gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Doedre's Undoing](/wiki/Doedre%27s_Undoing "Doedre's Undoing") | *0* |  |  |  |
| [Hayoxi's Fulmination](/wiki/Hayoxi%27s_Fulmination "Hayoxi's Fulmination") | *0* |  |  |  |
| [Xibaqua's Rending](/wiki/Xibaqua%27s_Rending "Xibaqua's Rending") | *0* |  |  |  |
| [Zarokh's Refrain](/wiki/Zarokh%27s_Refrain "Zarokh's Refrain") | *0* |  |  |  |
| [Tawhoa's Tending](/wiki/Tawhoa%27s_Tending "Tawhoa's Tending") | *0* |  |  |  |
| [Zerphi's Infamy](/wiki/Zerphi%27s_Infamy "Zerphi's Infamy") | *0* |  |  |  |
| [Concentrated Area](/wiki/Concentrated_Area "Concentrated Area") | *1* |  |  |  |
| [Creeping Chill](/wiki/Creeping_Chill "Creeping Chill") | *1* |  |  |  |
| [Expanse](/wiki/Expanse "Expanse") | *1* |  |  |  |
| [Impending Doom](/wiki/Impending_Doom "Impending Doom") | *1* |  |  |  |
| [Magnified Area I](/wiki/Magnified_Area_I "Magnified Area I") | *1* |  |  |  |
| [Spell Cascade](/wiki/Spell_Cascade "Spell Cascade") | *1* |  |  |  |
| [Armour Explosion](/wiki/Armour_Explosion "Armour Explosion") | *1* |  |  |  |
| [Battershout](/wiki/Battershout "Battershout") | *1* |  |  |  |
| [Impact Shockwave](/wiki/Impact_Shockwave "Impact Shockwave") | *1* |  |  |  |
| [Stomping Ground](/wiki/Stomping_Ground "Stomping Ground") | *1* |  |  |  |
| [Bursting Plague](/wiki/Bursting_Plague "Bursting Plague") | *2* |  |  |  |
| [Frozen Spite](/wiki/Frozen_Spite "Frozen Spite") | *2* |  |  |  |
| [Overreach](/wiki/Overreach "Overreach") | *2* |  |  |  |
| [Shocking Leap](/wiki/Shocking_Leap "Shocking Leap") | *2* |  |  |  |
| [Accelerated Growth I](/wiki/Accelerated_Growth_I "Accelerated Growth I") | *2* |  |  |  |
| [Bone Shrapnel](/wiki/Bone_Shrapnel "Bone Shrapnel") | *2* |  |  |  |
| [Encroaching Ground](/wiki/Encroaching_Ground "Encroaching Ground") | *2* |  |  |  |
| [Fiery Death](/wiki/Fiery_Death "Fiery Death") | *2* |  |  |  |
| [Frost Nexus](/wiki/Frost_Nexus "Frost Nexus") | *2* |  |  |  |
| [Mana Flare](/wiki/Mana_Flare "Mana Flare") | *2* |  |  |  |
| [Shock Conduction I](/wiki/Shock_Conduction_I "Shock Conduction I") | *2* |  |  |  |
| [Spell Echo](/wiki/Spell_Echo "Spell Echo") | *2* |  |  |  |
| [Wildfire](/wiki/Wildfire "Wildfire") | *2* |  |  |  |
| [Crater](/wiki/Crater "Crater") | *2* |  |  |  |
| [Fan The Flames I](/wiki/Fan_The_Flames_I "Fan The Flames I") | *2* |  |  |  |
| [Infernal Legion I](/wiki/Infernal_Legion_I "Infernal Legion I") | *2* |  |  |  |
| [Jagged Ground I](/wiki/Jagged_Ground_I "Jagged Ground I") | *2* |  |  |  |
| [Volcanic Eruption](/wiki/Volcanic_Eruption "Volcanic Eruption") | *2* |  |  |  |
| [Caltrops](/wiki/Caltrops "Caltrops") | *3* |  |  |  |
| [Poison Spores](/wiki/Poison_Spores "Poison Spores") | *3* |  |  |  |
| [Electromagnetism](/wiki/Electromagnetism "Electromagnetism") | *3* |  |  |  |
| [Elemental Discharge](/wiki/Elemental_Discharge "Elemental Discharge") | *3* |  |  |  |
| [Hex Bloom](/wiki/Hex_Bloom "Hex Bloom") | *3* |  |  |  |
| [Magnified Area II](/wiki/Magnified_Area_II "Magnified Area II") | *3* |  |  |  |
| [Ritualistic Curse](/wiki/Ritualistic_Curse "Ritualistic Curse") | *3* |  |  |  |
| [Static Shocks](/wiki/Static_Shocks "Static Shocks") | *3* |  |  |  |
| [Deadly Resolve](/wiki/Deadly_Resolve "Deadly Resolve") | *3* |  |  |  |
| [Haemocrystals](/wiki/Haemocrystals "Haemocrystals") | *3* |  |  |  |
| [Quill Burst](/wiki/Quill_Burst "Quill Burst") | *3* |  |  |  |
| [Burning Inscription](/wiki/Burning_Inscription "Burning Inscription") | *4* |  |  |  |
| [Echoing Cry](/wiki/Echoing_Cry "Echoing Cry") | *4* |  |  |  |
| [Fan The Flames II](/wiki/Fan_The_Flames_II "Fan The Flames II") | *4* |  |  |  |
| [Infernal Legion II](/wiki/Infernal_Legion_II "Infernal Legion II") | *4* |  |  |  |
| [Charged Mark](/wiki/Charged_Mark "Charged Mark") | *5* |  |  |  |
| [Accelerated Growth II](/wiki/Accelerated_Growth_II "Accelerated Growth II") | *5* |  |  |  |
| [Catalysing Elements](/wiki/Catalysing_Elements "Catalysing Elements") | *5* |  |  |  |
| [Expand](/wiki/Expand "Expand") | *5* |  |  |  |
| [Shock Conduction II](/wiki/Shock_Conduction_II "Shock Conduction II") | *5* |  |  |  |
| [Brambleslam](/wiki/Brambleslam "Brambleslam") | *5* |  |  |  |
| [Holy Descent](/wiki/Holy_Descent "Holy Descent") | *5* |  |  |  |
| [Infernal Legion III](/wiki/Infernal_Legion_III "Infernal Legion III") | *5* |  |  |  |
| [Jagged Ground II](/wiki/Jagged_Ground_II "Jagged Ground II") | *5* |  |  |  |

## Related unique items

| Item | Base item | Item class |  | Stats |
| --- | --- | --- | --- | --- |
| [Grip of Kulemak](/wiki/Grip_of_Kulemak "Grip of Kulemak") | [Abyssal Signet](/wiki/Abyssal_Signet "Abyssal Signet") | *[Ring](/wiki/Ring "Ring")* | 1 | Inflict [Abyssal Wasting](/wiki/Abyssal_Wasting/edit?redlink=1 "Abyssal Wasting (page does not exist)") on [Hit](/wiki/Hit "Hit")(30-20)% reduced [Presence](/wiki/Presence "Presence") Area of Effect (30-20)% reduced [Light Radius](/wiki/Light_Radius "Light Radius")   | <Can gain 0-4 custom [Desecrated Modifiers](/wiki/Desecrated_Modifier "Desecrated Modifier")> (Hidden) | | --- | | (60-100)% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Abyssal Wasting](/wiki/Abyssal_Wasting/edit?redlink=1 "Abyssal Wasting (page does not exist)") you inflict  ---  [Abyssal Wasting](/wiki/Abyssal_Wasting/edit?redlink=1 "Abyssal Wasting (page does not exist)") you inflict has Infinite Duration  ---  [Abyssal Wasting](/wiki/Abyssal_Wasting/edit?redlink=1 "Abyssal Wasting (page does not exist)") also applies -(8-6)% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance")  ---  +(20-30)% of [Armour](/wiki/Armour "Armour") also applies to [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage")  ---  [Gain](/wiki/Gain "Gain") (8-12)% of Damage as Extra [Fire](/wiki/Fire "Fire") Damage  ---  (20-10)% faster [Curse](/wiki/Curse "Curse") Activation  ---  +(20-25) to [Spirit](/wiki/Spirit "Spirit") while you have at least 200 [Strength](/wiki/Strength "Strength")  ---  (20-30)% increased [Ignite](/wiki/Ignite "Ignite") [Magnitude](/wiki/Magnitude "Magnitude")  ---  (30-40)% increased [Armour](/wiki/Armour "Armour")  ---  (15-25)% increased Area of Effect of [Curses](/wiki/Curse "Curse")  ---  [Debuffs](/wiki/Debuff "Debuff") you inflict have (12-20)% increased [Slow Magnitude](/wiki/Slow_Magnitude_Modifier/edit?redlink=1 "Slow Magnitude Modifier (page does not exist)")  ---  (6-10)% increased [Spirit](/wiki/Spirit "Spirit")  ---  (4-6)% increased [Strength](/wiki/Strength "Strength")  ---  +1 to Maximum [Endurance Charges](/wiki/Endurance_Charge "Endurance Charge")  ---  Hits against you have (20-30)% reduced [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus")  ---  (20-10)% reduced [Slowing](/wiki/Slow "Slow") Potency of [Debuffs](/wiki/Debuff "Debuff") on You  ---  (10-16)% increased Skill Effect Duration  ---  (6-10)% increased [Spirit](/wiki/Spirit "Spirit") [Reservation](/wiki/Reservation "Reservation") [Efficiency](/wiki/Efficiency "Efficiency") of Skills  ---  (30-50)% increased [Thorns](/wiki/Thorns "Thorns") damage if you've consumed an [Endurance Charge](/wiki/Endurance_Charge "Endurance Charge") [Recently](/wiki/Recently "Recently")  ---  You and [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") have +(17-23)% to [Chaos](/wiki/Chaos "Chaos") Resistance  ---  You and [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") have (10-14)% increased [Cooldown Recovery Rate](/wiki/Cooldown_Recovery_Rate "Cooldown Recovery Rate")  ---  (30-40)% increased [Accuracy](/wiki/Accuracy "Accuracy") Rating against Enemies affected by [Abyssal Wasting](/wiki/Abyssal_Wasting/edit?redlink=1 "Abyssal Wasting (page does not exist)")  ---  (20-30)% of Mana [Leeched](/wiki/Leech "Leech") from targets affected by [Abyssal Wasting](/wiki/Abyssal_Wasting/edit?redlink=1 "Abyssal Wasting (page does not exist)") is Instant  ---  [Abyssal Wasting](/wiki/Abyssal_Wasting/edit?redlink=1 "Abyssal Wasting (page does not exist)") also applies -(8-6)% to [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance")  ---  (20-30)% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Chill](/wiki/Chill "Chill") you inflict  ---  (25-40)% increased [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance  ---  [Gain](/wiki/Gain "Gain") (8-12)% of Damage as Extra [Cold](/wiki/Cold "Cold") Damage  ---  (10-14)% of Damage is taken from Mana before Life  ---  Recover (3-5)% of your maximum Mana when an Enemy dies in your [Presence](/wiki/Presence "Presence")  ---  (15-25)% [faster start of Energy Shield Recharge](/wiki/Energy_Shield "Energy Shield")  ---  +(20-25) to [Spirit](/wiki/Spirit "Spirit") while you have at least 200 [Intelligence](/wiki/Intelligence "Intelligence")  ---  Gain [Arcane Surge](/wiki/Arcane_Surge "Arcane Surge") when a [Minion](/wiki/Minion "Minion") Dies  ---  (30-40)% increased maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield")  ---  (4-6)% increased [Intelligence](/wiki/Intelligence "Intelligence")  ---  [Spell](/wiki/Spell "Spell") Skills have (9-18)% increased Area of Effect  ---  (40-60)% increased Mana Regeneration Rate while [Surrounded](/wiki/Surrounded "Surrounded")  ---  (5-10)% increased maximum Mana  ---  +1 to Maximum [Power Charges](/wiki/Power_Charge "Power Charge")  ---  [Meta](/wiki/Meta "Meta") Skills gain (10-16)% increased [Energy](/wiki/Energy "Energy")  ---  2% increased Cast Speed per 20 [Spirit](/wiki/Spirit "Spirit")  ---  (10-20)% increased Cost [Efficiency](/wiki/Efficiency "Efficiency") of Skills if you've consumed a [Power Charge](/wiki/Power_Charge "Power Charge") [Recently](/wiki/Recently "Recently")  ---  [Triggered](/wiki/Trigger "Trigger") [Spells](/wiki/Spell "Spell") deal (25-40)% increased [Spell](/wiki/Spell "Spell") Damage  ---  You and [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") have (11-16)% increased Cast Speed  ---  (30-40)% increased chance to inflict [Ailments](/wiki/Ailments "Ailments") against Enemies affected by [Abyssal Wasting](/wiki/Abyssal_Wasting/edit?redlink=1 "Abyssal Wasting (page does not exist)")  ---  (20-30)% of Life [Leeched](/wiki/Leech "Leech") from targets affected by [Abyssal Wasting](/wiki/Abyssal_Wasting/edit?redlink=1 "Abyssal Wasting (page does not exist)") is Instant  ---  [Abyssal Wasting](/wiki/Abyssal_Wasting/edit?redlink=1 "Abyssal Wasting (page does not exist)") also applies -(8-6)% to [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance")  ---  Projectiles have (40-50)% chance for an additional Projectile when [Forking](/wiki/Fork "Fork")  ---  (15-25)% increased [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus")  ---  [Gain](/wiki/Gain "Gain") (8-12)% of Damage as Extra [Lightning](/wiki/Lightning "Lightning") Damage  ---  Recover (2-3)% of your maximum Life when an Enemy dies in your [Presence](/wiki/Presence "Presence")  ---  Gain [Deflection Rating](/wiki/Deflect "Deflect") equal to (10-20)% of [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating")  ---  +(20-25) to [Spirit](/wiki/Spirit "Spirit") while you have at least 200 [Dexterity](/wiki/Dexterity "Dexterity")  ---  Gain [Onslaught](/wiki/Onslaught "Onslaught") for 4 seconds when a [Minion](/wiki/Minion "Minion") Dies  ---  (9-18)% increased Area of Effect for [Attacks](/wiki/Attack "Attack")  ---  (4-6)% increased [Dexterity](/wiki/Dexterity "Dexterity")  ---  (30-40)% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating")  ---  (20-30)% increased amount of Life [Leeched](/wiki/Leech "Leech") if you've consumed a [Frenzy Charge](/wiki/Frenzy_Charge "Frenzy Charge") [Recently](/wiki/Recently "Recently")  ---  (30-40)% increased Life Regeneration rate while [Surrounded](/wiki/Surrounded "Surrounded")  ---  +1 to Maximum [Frenzy Charges](/wiki/Frenzy_Charge "Frenzy Charge")  ---  (5-10)% increased maximum Life  ---  1% increased [Attack](/wiki/Attack "Attack") Speed per 20 [Spirit](/wiki/Spirit "Spirit")  ---  [Projectiles](/wiki/Projectile "Projectile") have (10-16)% chance to [Chain](/wiki/Chain "Chain") an additional time from terrain  ---  (15-25)% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Shock](/wiki/Shock "Shock") you inflict  ---  You and [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") have (20-28)% increased [Accuracy](/wiki/Accuracy "Accuracy") Rating  ---  You and [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") have (7-12)% increased [Attack](/wiki/Attack "Attack") Speed | |
| [Pillar of the Caged God](/wiki/Pillar_of_the_Caged_God "Pillar of the Caged God") | [Long Quarterstaff](/wiki/Long_Quarterstaff "Long Quarterstaff") | *[Quarterstaff](/wiki/Quarterstaff "Quarterstaff")* | 4 | 16% increased [Melee](/wiki/Melee "Melee") [Strike](/wiki/Strike "Strike") Range with this weapon1% increased Area of Effect for [Attacks](/wiki/Attack "Attack") per 10 [Intelligence](/wiki/Intelligence "Intelligence") 1% increased [Attack](/wiki/Attack "Attack") Speed per 10 [Dexterity](/wiki/Dexterity "Dexterity") 10% increased Weapon Damage per 10 [Strength](/wiki/Strength "Strength") |
| [Ezomyte Peak](/wiki/Ezomyte_Peak "Ezomyte Peak") | [Soldier Greathelm](/wiki/Soldier_Greathelm "Soldier Greathelm") | *[Helmet](/wiki/Helmet "Helmet")* | 12 | (50-100)% increased [Armour](/wiki/Armour "Armour") +(50-80) to maximum Life (3-6) Life Regeneration per second (10-20)% increased Area of Effect [Unwavering Stance](/wiki/Unwavering_Stance "Unwavering Stance") |
| [Fixation of Yix](/wiki/Fixation_of_Yix "Fixation of Yix") | [Stellar Amulet](/wiki/Stellar_Amulet "Stellar Amulet") | *[Amulet](/wiki/Amulet "Amulet")* | 24 | +(5-7) to all [Attributes](/wiki/Attributes "Attributes")+100 to maximum Life [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") have (30-50)% increased [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") have (30-50)% increased [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus") [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") have (10-20)% increased [Attack](/wiki/Attack "Attack") Speed [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") have (10-20)% increased Cast Speed 50% reduced [Presence](/wiki/Presence "Presence") Area of Effect |
| [Deidbell](/wiki/Deidbell "Deidbell") | [Elite Greathelm](/wiki/Elite_Greathelm "Elite Greathelm") | *[Helmet](/wiki/Helmet "Helmet")* | 33 | (60-100)% increased [Armour](/wiki/Armour "Armour") +(10-20) to [Strength](/wiki/Strength "Strength") (20-30)% increased [Warcry](/wiki/Warcry "Warcry") Speed [Warcries](/wiki/Warcries "Warcries") Explode [Corpses](/wiki/Corpse "Corpse") dealing 10% of their Life as [Physical](/wiki/Physical "Physical") Damage [Warcry](/wiki/Warcry "Warcry") Skills have (20-30)% increased Area of Effect |
| [The Flesh Poppet](/wiki/The_Flesh_Poppet "The Flesh Poppet") | [Vicious Talisman](/wiki/Vicious_Talisman "Vicious Talisman") | *[Talisman](/wiki/Talisman "Talisman")* | 40 | (90-120)% increased [Physical](/wiki/Physical "Physical") Damage (7-13)% increased [Attack](/wiki/Attack "Attack") Speed +(7-13) to all [Attributes](/wiki/Attributes "Attributes") (40-30)% reduced [Presence](/wiki/Presence "Presence") Area of Effect Copy a random [Modifier](/wiki/Monster_modifier "Monster modifier") from each enemy in your [Presence](/wiki/Presence "Presence") when you [Shapeshift](/wiki/Shapeshift "Shapeshift") to an Animal form Modifiers gained this way are lost after 30 seconds or when you next [Shapeshift](/wiki/Shapeshift "Shapeshift") |
| [Blood Price](/wiki/Blood_Price "Blood Price") | [Fierce Greathelm](/wiki/Fierce_Greathelm "Fierce Greathelm") | *[Helmet](/wiki/Helmet "Helmet")* | 51 | (80-120)% increased [Armour](/wiki/Armour "Armour") (10-15) Life Regeneration per second +(100-150) to [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") (30-60)% increased [Presence](/wiki/Presence "Presence") Area of Effect Enemies in your [Presence](/wiki/Presence "Presence") have at least 10% of Life [Reserved](/wiki/Reservation "Reservation") |
| [Atziri's Contempt](/wiki/Atziri%27s_Contempt "Atziri's Contempt") | [Pronged Spear](/wiki/Pronged_Spear "Pronged Spear") | *[Spear](/wiki/Spear "Spear")* | 72 | (100-120)% increased [Physical](/wiki/Physical "Physical") Damage Adds (83-97) to (123-153) [Fire](/wiki/Fire "Fire") Damage Adds 1 to (193-207) [Lightning](/wiki/Lightning "Lightning") Damage (10-16)% increased [Attack](/wiki/Attack "Attack") Speed (60-80)% increased [Presence](/wiki/Presence "Presence") Area of Effect Spear Skills inflict a Bloodstone Lance on [Hit](/wiki/Hit "Hit"), up to a maximum of 30 on each target |
