# Block

Block

Tooltip

Blocking completely prevents the damage of an incoming [Hit](/wiki/Hit "Hit").

You will still take any [Stun](/wiki/Stun "Stun") from the Blocked hit. You can't Block while [Stunned](/wiki/Stun "Stun") or [Frozen](/wiki/Freeze "Freeze").

Some skills used by Bosses cannot be blocked. These are indicated by a red glow and audio cue during the windup of the skill.

Chance to Block

Tooltip

Chance to Block only includes modifiers that are explicitly chance-based. Guaranteed Block (such as raising your [Shield](/wiki/Shield "Shield")) does not affect your Chance to Block.

**Block** is a type of damage mitigation that typically negates all hit damage. Block is primarily obtained from [shields](/wiki/Shield "Shield"). Shields skills can also provide a guaranteed directional block, though its consecutive usage is limited by the player's stagger.

## Mechanics

The character still receives [Debuffs](/wiki/Debuff "Debuff") such as [Stun](/wiki/Stun "Stun") and [Freeze](/wiki/Freeze "Freeze") associated with the blocked hit despite the damage being negated.

### Unblockable skills

Certain [monsters](/wiki/Monster "Monster") (usually bosses) can use attacks which cannot be blocked, which will be indicated by the enemy flashing red when used. [Damage over time](/wiki/Damage_over_time "Damage over time") and other damage that does not come from a [hit](/wiki/Hit "Hit") cannot be blocked.

Damage mitigated by block is not considered "prevented damage" for stats such as those found on [Wandering Reliquary](/wiki/Wandering_Reliquary "Wandering Reliquary").[Likely due to a [bug](https://www.pathofexile.com/forum/view-forum/2214)][[1]](#cite_note-1)

### Passive block

Chance to block is applied to blockable incoming hits, such as [projectiles](/wiki/Projectile "Projectile") or [strikes](/wiki/Strike "Strike") from enemies.

When the roll for block chance succeeds, the damage will be negated. The attack can be coming from any direction, unlike active block.

Base passive block is primarily obtained from [shields](/wiki/Shield "Shield"), though they can rarely be found on other items such as [Barrier Quarterstaff](/wiki/Barrier_Quarterstaff "Barrier Quarterstaff"). Increases to block chance modify this value. Block rounds towards the nearest integer, instead of rounding down. By default, maximum block chance is capped at 50%.

Blocking a hit with passive block doesn't build up your [Heavy Stun](/wiki/Heavy_Stun "Heavy Stun") meter.

### Active block

When using certain shield/buckler skills such as [Raise Shield](/wiki/Raise_Shield "Raise Shield") and [Parry](/wiki/Parry "Parry") the player will gain a directional guaranteed block. This will cause all non-unblockable hits to be blocked if the shield is facing the direction of the attacker. Passive block will still function against attacks coming from other directions.

Blocking hits through Active Block will build up your Player [Heavy Stun](/wiki/Heavy_Stun "Heavy Stun") meter. When the stun meter is full, the active block skill will be cancelled and the player will become Heavy Stunned for 3 seconds.

All other effects related to block still apply. The You take #% of damage from Blocked Hits modifier will also apply to Active Block.

## Related skills

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Cast on Block](/wiki/Cast_on_Block "Cast on Block") | *0* |  |  |  |
| [Parry](/wiki/Parry "Parry") | *0* |  |  |  |
| [Raise Shield](/wiki/Raise_Shield "Raise Shield") | *0* |  |  |  |
| [Shield Charge](/wiki/Shield_Charge "Shield Charge") | *3* |  |  |  |
| [Magma Barrier](/wiki/Magma_Barrier "Magma Barrier") | *4* |  |  |  |
| [Resonating Shield](/wiki/Resonating_Shield "Resonating Shield") | *5* |  |  |  |

## Related unique items

| Item | Base item | Item class |  | Stats |
| --- | --- | --- | --- | --- |
| [Alkem Eira](/wiki/Alkem_Eira "Alkem Eira") | [Blazon Crest Shield](/wiki/Blazon_Crest_Shield "Blazon Crest Shield") | *[Shield](/wiki/Shield "Shield")* | 1 | (15-20)% increased Block chance (30-50)% increased [Armour](/wiki/Armour "Armour") and [Energy Shield](/wiki/Energy_Shield "Energy Shield") +(50-70) to maximum Mana Damage Blocked is [Recouped](/wiki/Recoup "Recoup") as Mana |
| [Dunkelhalt](/wiki/Dunkelhalt "Dunkelhalt") | [Leather Buckler](/wiki/Leather_Buckler "Leather Buckler") | *[Buckler](/wiki/Buckler "Buckler")* | 1 | (20-30)% increased Block chance +(20-30) to [Evasion](/wiki/Evasion "Evasion") Rating You take 50% of damage from Blocked [Hits](/wiki/Hit "Hit") 50% increased [Parried Debuff](/wiki/Parried_Debuff "Parried Debuff") [Magnitude](/wiki/Magnitude "Magnitude") |
| [Legionstride](/wiki/Legionstride "Legionstride") | [Rough Greaves](/wiki/Rough_Greaves "Rough Greaves") | *[Boots](/wiki/Boots "Boots")* | 1 | +(50-70) to [Armour](/wiki/Armour "Armour") +(50-70) to [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") -10 [Physical](/wiki/Physical "Physical") damage taken from [Projectile](/wiki/Projectile "Projectile") [Attacks](/wiki/Attack "Attack") +10% to Block chance |
| [Wulfsbane](/wiki/Wulfsbane "Wulfsbane") | [Painted Tower Shield](/wiki/Painted_Tower_Shield "Painted Tower Shield") | *[Shield](/wiki/Shield "Shield")* | 6 | +(40-60) to maximum Life +(10-15) to [Strength](/wiki/Strength "Strength") +(60-80) to [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") [Intimidate](/wiki/Intimidate "Intimidate") Enemies on Block for 8 seconds |
| [Oaksworn](/wiki/Oaksworn "Oaksworn") | [Sigil Crest Shield](/wiki/Sigil_Crest_Shield "Sigil Crest Shield") | *[Shield](/wiki/Shield "Shield")* | 7 | (20-30)% increased Block chance (80-120)% increased [Armour](/wiki/Armour "Armour") and [Energy Shield](/wiki/Energy_Shield "Energy Shield") 50% increased Life Regeneration rate +(17-23)% to [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance") |
| [Stone of Lazhwar](/wiki/Stone_of_Lazhwar "Stone of Lazhwar") | [Lapis Amulet](/wiki/Lapis_Amulet "Lapis Amulet") | *[Amulet](/wiki/Amulet "Amulet")* | 8 | +(10-15) to [Intelligence](/wiki/Intelligence "Intelligence")+(50-100) to maximum Mana (15-25)% increased Cast Speed +(15-25)% to Block Chance while holding a [Focus](/wiki/Focus "Focus") |
| [Rondel de Ezo](/wiki/Rondel_de_Ezo "Rondel de Ezo") | [Plated Buckler](/wiki/Plated_Buckler "Plated Buckler") | *[Buckler](/wiki/Buckler "Buckler")* | 11 | (50-150)% increased [Evasion](/wiki/Evasion "Evasion") Rating +(10-20) to [Dexterity](/wiki/Dexterity "Dexterity") 5 Life Regeneration per second 100% increased Block chance against [Projectiles](/wiki/Projectile "Projectile") [Curse](/wiki/Curse "Curse") Enemies with [Enfeeble](/wiki/Enfeeble "Enfeeble") on Block |
| [Doomgate](/wiki/Doomgate "Doomgate") | [Braced Tower Shield](/wiki/Braced_Tower_Shield "Braced Tower Shield") | *[Shield](/wiki/Shield "Shield")* | 12 | (80-100)% increased Block chance (100-150)% increased [Armour](/wiki/Armour "Armour") +(13-17)% to [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance") You take (25-40)% of damage from Blocked [Hits](/wiki/Hit "Hit") Enemies are [Culled](/wiki/Cull "Cull") on Block |
| [Bloodbarrier](/wiki/Bloodbarrier "Bloodbarrier") | [Iron Buckler](/wiki/Iron_Buckler "Iron Buckler") | *[Buckler](/wiki/Buckler "Buckler")* | 16 | (10-15)% increased Block chance +(13-17)% to [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance") (5-10) Life Regeneration per second Inflict [Corrupted Blood](/wiki/Corrupted_Blood "Corrupted Blood") for 5 seconds on Block, dealing 50% of your maximum Life as [Physical](/wiki/Physical "Physical") damage per second |
| [Saffell's Frame](/wiki/Saffell%27s_Frame "Saffell's Frame") | [Emblem Crest Shield](/wiki/Emblem_Crest_Shield "Emblem Crest Shield") | *[Shield](/wiki/Shield "Shield")* | 16 | +(15-25)% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") +(15-25)% to [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance") +(15-25)% to [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance") Cannot Block Modifiers to Maximum Block Chance instead apply to [Maximum Resistances](/wiki/Maximum_Resistance "Maximum Resistance") |
| [The Anvil](/wiki/The_Anvil "The Anvil") | [Bloodstone Amulet](/wiki/Bloodstone_Amulet "Bloodstone Amulet") | *[Amulet](/wiki/Amulet "Amulet")* | 18 | +(30-40) to maximum Life10% reduced Movement Speed 10% reduced [Skill Speed](/wiki/Skill_Speed "Skill Speed") (25-50)% increased [Armour](/wiki/Armour "Armour") 25% increased Block chance +(5-10)% to maximum Block chance |
| [Lycosidae](/wiki/Lycosidae "Lycosidae") | [Rampart Tower Shield](/wiki/Rampart_Tower_Shield "Rampart Tower Shield") | *[Shield](/wiki/Shield "Shield")* | 28 | (10-15)% increased Block chance (60-100)% increased [Armour](/wiki/Armour "Armour") [Accuracy](/wiki/Accuracy "Accuracy") Rating is Doubled Blocking Damage [Poisons](/wiki/Poison "Poison") the Enemy as though dealing 200 Base [Chaos](/wiki/Chaos "Chaos") Damage |
| [Rearguard](/wiki/Rearguard "Rearguard") | [Blunt Quiver](/wiki/Blunt_Quiver "Blunt Quiver") | *[Quiver](/wiki/Quiver "Quiver")* | 33 | (25-40)% increased [Stun](/wiki/Stun "Stun") BuildupAdds (7-11) to (14-20) [Physical](/wiki/Physical "Physical") Damage to [Attacks](/wiki/Attack "Attack") +(150-200) to [Armour](/wiki/Armour "Armour") (20-30)% increased [Projectile](/wiki/Projectile "Projectile") Speed +(15-25)% to Block chance |
| [Redblade Banner](/wiki/Redblade_Banner "Redblade Banner") | [Heraldric Tower Shield](/wiki/Heraldric_Tower_Shield "Heraldric Tower Shield") | *[Shield](/wiki/Shield "Shield")* | 33 | (10-15)% increased Block chance (60-100)% increased [Armour](/wiki/Armour "Armour") +(20-30) to [Strength](/wiki/Strength "Strength") +(100-150) to [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") Enemies in your [Presence](/wiki/Presence "Presence") count as having double [Power](/wiki/Power "Power") |
| [Svalinn](/wiki/Svalinn "Svalinn") | [Crucible Tower Shield](/wiki/Crucible_Tower_Shield "Crucible Tower Shield") | *[Shield](/wiki/Shield "Shield")* | 60 | (200-300)% increased [Armour](/wiki/Armour "Armour") Chance to Block [Damage](/wiki/Hit "Hit") is [Lucky](/wiki/Lucky "Lucky") You take (0-20)% of damage from Blocked [Hits](/wiki/Hit "Hit") |
| [Chernobog's Pillar](/wiki/Chernobog%27s_Pillar "Chernobog's Pillar") | [Blacksteel Tower Shield](/wiki/Blacksteel_Tower_Shield "Blacksteel Tower Shield") | *[Shield](/wiki/Shield "Shield")* | 65 | (100-150)% increased [Armour](/wiki/Armour "Armour") +(30-40)% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") +(23-29)% to [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance") +(150-200) to [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") [Gain](/wiki/Gain "Gain") 1% of damage as [Fire](/wiki/Fire "Fire") damage per 1% [Chance to Block](/wiki/Chance_to_Block/edit?redlink=1 "Chance to Block (page does not exist)") |
| [The Surrender](/wiki/The_Surrender "The Surrender") | [Vaal Tower Shield](/wiki/Vaal_Tower_Shield "Vaal Tower Shield") | *[Shield](/wiki/Shield "Shield")* | 75 | (40-60)% increased Block chance (150-200)% increased [Armour](/wiki/Armour "Armour") +(150-200) to [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") Recover 4% of maximum Life when you Block |
| [The Unborn Lich](/wiki/The_Unborn_Lich "The Unborn Lich") | [Ravenous Staff](/wiki/Ravenous_Staff "Ravenous Staff") | *[Staff](/wiki/Staff "Staff")* | 78 | (60-80)% increased [Desecrated Modifier](/wiki/Desecrated_modifier "Desecrated modifier") magnitudes <Custom Desecrated prefix> <Lich's Desecrated prefix> <Lich's Desecrated suffix> <Lich's Desecrated prefix or suffix>   | <List of mods> | | --- | | (86-99)% increased [Fire](/wiki/Fire "Fire") Damage (14-23)% increased [Ignite](/wiki/Ignite "Ignite") [Magnitude](/wiki/Magnitude "Magnitude")  ---  (25-40)% chance to build an additional [Combo](/wiki/Combo "Combo") on [Hit](/wiki/Hit "Hit")  ---  (86-99)% increased [Cold](/wiki/Cold "Cold") Damage (14-23)% increased [Freeze](/wiki/Freeze "Freeze") Buildup  ---  Recover (4-6)% of Maximum Mana when you expend at least 10 [Combo](/wiki/Combo "Combo")  ---  (86-99)% increased [Lightning](/wiki/Lightning "Lightning") Damage (14-23)% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Shock](/wiki/Shock "Shock") you inflict  ---  Recover (6-12)% of Maximum Life when you expend at least 10 [Combo](/wiki/Combo "Combo")  ---  +(35-50) to [Spirit](/wiki/Spirit "Spirit")  ---  (148-178)% increased [Spell](/wiki/Spell "Spell") Damage with [Spells](/wiki/Spell "Spell") that cost Life  ---  (25-35)% increased [Archon](/wiki/Archon "Archon") Buff duration  ---  +(12-16)% to Block chance  ---  (25-35)% of [Spell](/wiki/Spell "Spell") Mana Cost [Converted](/wiki/Stat_conversion "Stat conversion") to Life Cost  ---  +(1-2) to maximum number of [Elemental Infusions](/wiki/Elemental_Infusion "Elemental Infusion")  ---  (4-5)% increased [Spell](/wiki/Spell "Spell") Damage per 100 maximum Mana  ---  [Archon](/wiki/Archon "Archon") recovery period expires (25-35)% faster  ---  (26-36)% increased Cast Speed while on Full Mana  ---  (40-64)% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") you inflict  ---  (4-5)% increased [Spell](/wiki/Spell "Spell") Damage per 100 Maximum Life  ---  (30-40)% increased Cast Speed when on [Low Life](/wiki/Low_Life "Low Life")  ---  (25-35)% chance for [Spell](/wiki/Spell "Spell") Skills to fire 2 additional [Projectiles](/wiki/Projectile "Projectile")  ---  (100-160)% increased [Chaos](/wiki/Chaos "Chaos") Damage Enemies you kill have a (5-10)% chance to explode, dealing a quarter of their maximum Life as [Chaos](/wiki/Chaos "Chaos") damage  ---  (100-160)% increased [Chaos](/wiki/Chaos "Chaos") Damage Enemies you [Curse](/wiki/Curse "Curse") have -(8-5)% to Chaos [Resistance](/wiki/Resistance "Resistance")  ---  (100-160)% increased [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") (10-20)% increased Duration of Elemental [Ailments](/wiki/Ailments "Ailments") on Enemies  ---  (100-160)% increased [Spell](/wiki/Spell "Spell") [Physical](/wiki/Physical "Physical") Damage (20-30)% chance to inflict [Bleeding](/wiki/Bleeding "Bleeding") on [Hit](/wiki/Hit "Hit")  ---  +(40-60) to [Spirit](/wiki/Spirit "Spirit") (6-10)% increased [Spirit](/wiki/Spirit "Spirit") [Reservation](/wiki/Reservation "Reservation") [Efficiency](/wiki/Efficiency "Efficiency") of Skills  ---  You have [Unholy Might](/wiki/Unholy_Might "Unholy Might") (28-56)% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Unholy Might](/wiki/Unholy_Might "Unholy Might") buffs you grant | |

## Related passive skills

The following [passive skills](/wiki/Passive_skill "Passive skill") are related to block:

### Block chance

| Name | Stats |
| --- | --- |
| Block | 5% increased Block chance [[1]](/wiki/Passive_Skill:Block1 "Passive Skill:Block1") [[2]](/wiki/Passive_Skill:Block11 "Passive Skill:Block11") [[3]](/wiki/Passive_Skill:Block2 "Passive Skill:Block2") [[4]](/wiki/Passive_Skill:Block21 "Passive Skill:Block21") [[5]](/wiki/Passive_Skill:Block22 "Passive Skill:Block22") [[6]](/wiki/Passive_Skill:Block23 "Passive Skill:Block23") [[7]](/wiki/Passive_Skill:Block25~ "Passive Skill:Block25~") [[8]](/wiki/Passive_Skill:Block5 "Passive Skill:Block5") [[9]](/wiki/Passive_Skill:Block6 "Passive Skill:Block6") [[10]](/wiki/Passive_Skill:Block7~ "Passive Skill:Block7~") [[11]](/wiki/Passive_Skill:Block8 "Passive Skill:Block8") [[12]](/wiki/Passive_Skill:Block9 "Passive Skill:Block9") [[13]](/wiki/Passive_Skill:Deflect6 "Passive Skill:Deflect6") [[14]](/wiki/Passive_Skill:Deflect7 "Passive Skill:Deflect7") |
| [Block and Movement Penalty with Raised Shield](/wiki/Block_and_Movement_Penalty_with_Raised_Shield/edit?redlink=1 "Block and Movement Penalty with Raised Shield (page does not exist)") | 4% increased Block chance 5% reduced Movement Speed Penalty while Actively Blocking [[1]](/wiki/Passive_Skill:Shield29 "Passive Skill:Shield29") |
| [Block and Shield Defences](/wiki/Block_and_Shield_Defences/edit?redlink=1 "Block and Shield Defences (page does not exist)") | 4% increased Block chance 15% increased [Defences](/wiki/Defences "Defences") from Equipped [Shield](/wiki/Shield "Shield") [[1]](/wiki/Passive_Skill:Block3 "Passive Skill:Block3") [[2]](/wiki/Passive_Skill:Block4 "Passive Skill:Block4") |
| [Block and Stun Threshold](/wiki/Block_and_Stun_Threshold/edit?redlink=1 "Block and Stun Threshold (page does not exist)") | 4% increased Block chance 5% increased [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") [[1]](/wiki/Passive_Skill:Shield31 "Passive Skill:Shield31") [[2]](/wiki/Passive_Skill:Shield33 "Passive Skill:Shield33") |
| [Shield Block](/wiki/Shield_Block/edit?redlink=1 "Shield Block (page does not exist)") | 5% increased Block chance [[1]](/wiki/Passive_Skill:Shield15 "Passive Skill:Shield15") [[2]](/wiki/Passive_Skill:Shield16 "Passive Skill:Shield16") [[3]](/wiki/Passive_Skill:Shield17 "Passive Skill:Shield17") [[4]](/wiki/Passive_Skill:Shield19 "Passive Skill:Shield19") [[5]](/wiki/Passive_Skill:Shield20 "Passive Skill:Shield20") [[6]](/wiki/Passive_Skill:Shield21 "Passive Skill:Shield21") [[7]](/wiki/Passive_Skill:Shield22 "Passive Skill:Shield22") [[8]](/wiki/Passive_Skill:Shield6 "Passive Skill:Shield6") [[9]](/wiki/Passive_Skill:Shield7 "Passive Skill:Shield7") [[10]](/wiki/Passive_Skill:Shield8 "Passive Skill:Shield8") |
| [Thorns and Block](/wiki/Thorns_and_Block/edit?redlink=1 "Thorns and Block (page does not exist)") | 10% increased [Thorns](/wiki/Thorns "Thorns") damage 4% increased Block chance [[1]](/wiki/Passive_Skill:Getting~hit4~ "Passive Skill:Getting~hit4~") [[2]](/wiki/Passive_Skill:Getting~hit5 "Passive Skill:Getting~hit5") |
| [Defender's Resolve](/wiki/Defender%27s_Resolve/edit?redlink=1 "Defender's Resolve (page does not exist)") | 12% increased Block chance Your [Heavy Stun](/wiki/Heavy_Stun "Heavy Stun") buildup empties 50% faster [[1]](/wiki/Passive_Skill:Block15 "Passive Skill:Block15") |
| [Defensive Reflexes](/wiki/Defensive_Reflexes/edit?redlink=1 "Defensive Reflexes (page does not exist)") | 12% increased Block chance 5 Mana gained when you Block [[1]](/wiki/Passive_Skill:Shield28~ "Passive Skill:Shield28~") |
| [Flashy Parrying](/wiki/Flashy_Parrying/edit?redlink=1 "Flashy Parrying (page does not exist)") | 12% increased Block chance 20% increased [Parried Debuff](/wiki/Parried_Debuff "Parried Debuff") Duration [[1]](/wiki/Passive_Skill:Deflect10 "Passive Skill:Deflect10") |
| [Holy Protector](/wiki/Holy_Protector/edit?redlink=1 "Holy Protector (page does not exist)") | [Minions](/wiki/Minion "Minion") have 25% increased maximum Life 10% increased Block chance [[1]](/wiki/Passive_Skill:Sentinels11 "Passive Skill:Sentinels11") |
| [Shield Expertise](/wiki/Shield_Expertise/edit?redlink=1 "Shield Expertise (page does not exist)") | 12% increased Block chance 40% increased Block Recovery [[1]](/wiki/Passive_Skill:Block18 "Passive Skill:Block18") |
| [Swift Blocking](/wiki/Swift_Blocking/edit?redlink=1 "Swift Blocking (page does not exist)") | 12% increased Block chance 1% increased Movement Speed for each time you've Blocked in the past 10 seconds [[1]](/wiki/Passive_Skill:Block16 "Passive Skill:Block16") |
| [Unstoppable Barrier](/wiki/Unstoppable_Barrier/edit?redlink=1 "Unstoppable Barrier (page does not exist)") | 10% increased Block chance 15% reduced [Slowing](/wiki/Slow "Slow") Potency of [Debuffs](/wiki/Debuff "Debuff") on You [[1]](/wiki/Passive_Skill:Block12 "Passive Skill:Block12") |
| [Vigilance](/wiki/Vigilance/edit?redlink=1 "Vigilance (page does not exist)") | 12% increased Block chance 10 Life gained when you Block +2% to maximum Block chance [[1]](/wiki/Passive_Skill:Shield25 "Passive Skill:Shield25") |
| [Wide Barrier](/wiki/Wide_Barrier/edit?redlink=1 "Wide Barrier (page does not exist)") | 30% increased Block chance 25% reduced [Defences](/wiki/Defences "Defences") [[1]](/wiki/Passive_Skill:Shield10 "Passive Skill:Shield10") |

### Maximum block chance

| Name | Stats |
| --- | --- |
| [Maximum Block](/wiki/Maximum_Block/edit?redlink=1 "Maximum Block (page does not exist)") | +1% to maximum Block chance [[1]](/wiki/Passive_Skill:Shield36 "Passive Skill:Shield36") |
| [Defensive Stance](/wiki/Defensive_Stance/edit?redlink=1 "Defensive Stance (page does not exist)") | +4% to maximum Block chance [[1]](/wiki/Passive_Skill:Shield18~ "Passive Skill:Shield18~") |
| [Hunker Down](/wiki/Hunker_Down/edit?redlink=1 "Hunker Down (page does not exist)") | Recover 20 Life when you Block 80% less [Knockback](/wiki/Knockback "Knockback") Distance for Blocked [Hits](/wiki/Hit "Hit") +2% to maximum Block chance [[1]](/wiki/Passive_Skill:Block13 "Passive Skill:Block13") |
| [Vigilance](/wiki/Vigilance/edit?redlink=1 "Vigilance (page does not exist)") | 12% increased Block chance 10 Life gained when you Block +2% to maximum Block chance [[1]](/wiki/Passive_Skill:Shield25 "Passive Skill:Shield25") |

### Block recovery

| Name | Stats |
| --- | --- |
| [Block Recovery](/wiki/Block_Recovery/edit?redlink=1 "Block Recovery (page does not exist)") | 25% increased Block Recovery [[1]](/wiki/Passive_Skill:Block19 "Passive Skill:Block19") |
| [Shield Expertise](/wiki/Shield_Expertise/edit?redlink=1 "Shield Expertise (page does not exist)") | 12% increased Block chance 40% increased Block Recovery [[1]](/wiki/Passive_Skill:Block18 "Passive Skill:Block18") |

### Miscellany

| Name | Stats |
| --- | --- |
| Block | Recover 5 Life when you Block [[1]](/wiki/Passive_Skill:Block10 "Passive Skill:Block10") |
| [Covering Ward](/wiki/Covering_Ward/edit?redlink=1 "Covering Ward (page does not exist)") | 25% increased [Energy Shield Recharge Rate](/wiki/Energy_Shield_Recharge_Rate "Energy Shield Recharge Rate") Gain 20 [Energy Shield](/wiki/Energy_Shield "Energy Shield") when you Block [[1]](/wiki/Passive_Skill:Energy~shield~recovery15 "Passive Skill:Energy~shield~recovery15") |
| [Dazing Blocks](/wiki/Dazing_Blocks/edit?redlink=1 "Dazing Blocks (page does not exist)") | 100% chance to [Daze](/wiki/Daze "Daze") Enemies whose [Hits](/wiki/Hit "Hit") you Block with a raised [Shield](/wiki/Shield "Shield") [[1]](/wiki/Passive_Skill:Shield34 "Passive Skill:Shield34") |
| [Defensive Reflexes](/wiki/Defensive_Reflexes/edit?redlink=1 "Defensive Reflexes (page does not exist)") | 12% increased Block chance 5 Mana gained when you Block [[1]](/wiki/Passive_Skill:Shield28~ "Passive Skill:Shield28~") |
| [Favourable Odds](/wiki/Favourable_Odds/edit?redlink=1 "Favourable Odds (page does not exist)") | 30% increased Block chance while [Surrounded](/wiki/Surrounded "Surrounded") 10% increased [Deflection Rating](/wiki/Deflect "Deflect") while [Surrounded](/wiki/Surrounded "Surrounded") 40% increased [Ailment](/wiki/Ailment "Ailment") and [Stun](/wiki/Stun_Threshold "Stun Threshold") Threshold while [Surrounded](/wiki/Surrounded "Surrounded") [[1]](/wiki/Passive_Skill:Being~surrounded23 "Passive Skill:Being~surrounded23") |
| [Frightening Shield](/wiki/Frightening_Shield/edit?redlink=1 "Frightening Shield (page does not exist)") | Apply [Debilitate](/wiki/Debilitate/edit?redlink=1 "Debilitate (page does not exist)") to Enemies 3 Metres in front of you while your [Shield](/wiki/Shield "Shield") is raised [[1]](/wiki/Passive_Skill:Shield37 "Passive Skill:Shield37") |
| [Hunker Down](/wiki/Hunker_Down/edit?redlink=1 "Hunker Down (page does not exist)") | Recover 20 Life when you Block 80% less [Knockback](/wiki/Knockback "Knockback") Distance for Blocked [Hits](/wiki/Hit "Hit") +2% to maximum Block chance [[1]](/wiki/Passive_Skill:Block13 "Passive Skill:Block13") |
| [Lay Siege](/wiki/Lay_Siege/edit?redlink=1 "Lay Siege (page does not exist)") | 1% increased Damage per 1% Chance to Block [[1]](/wiki/Passive_Skill:Shield5 "Passive Skill:Shield5") |
| [Retaliation](/wiki/Retaliation/edit?redlink=1 "Retaliation (page does not exist)") | 75% increased [Thorns](/wiki/Thorns "Thorns") damage if you've Blocked [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Getting~hit10 "Passive Skill:Getting~hit10") |
| [Swift Blocking](/wiki/Swift_Blocking/edit?redlink=1 "Swift Blocking (page does not exist)") | 12% increased Block chance 1% increased Movement Speed for each time you've Blocked in the past 10 seconds [[1]](/wiki/Passive_Skill:Block16 "Passive Skill:Block16") |
| [Towering Shield](/wiki/Towering_Shield "Towering Shield") | 25% increased Chance to Block if you've Blocked with a raised [Shield](/wiki/Shield "Shield") [Recently](/wiki/Recently "Recently") 50% increased [Defences](/wiki/Defences "Defences") from Equipped [Shield](/wiki/Shield "Shield") [[1]](/wiki/Passive_Skill:Block14 "Passive Skill:Block14") |
| [Vigilance](/wiki/Vigilance/edit?redlink=1 "Vigilance (page does not exist)") | 12% increased Block chance 10 Life gained when you Block +2% to maximum Block chance [[1]](/wiki/Passive_Skill:Shield25 "Passive Skill:Shield25") |

### Paths Not Taken passive skills

The following passive skills are exclusive the [Oracle](/wiki/Oracle "Oracle") with [The Unseen Path](/wiki/The_Unseen_Path "The Unseen Path") allocated:

| Name | Stats |
| --- | --- |
| [Armour and Block Chance](/wiki/Armour_and_Block_Chance/edit?redlink=1 "Armour and Block Chance (page does not exist)") | 15% increased [Armour](/wiki/Armour "Armour") while stationary 5% increased Block chance [[1]](/wiki/Passive_Skill:Oracle~crab~claw1 "Passive Skill:Oracle~crab~claw1") |
| [Block Chance](/wiki/Block_Chance/edit?redlink=1 "Block Chance (page does not exist)") | 8% increased Block chance [[1]](/wiki/Passive_Skill:Oracle~crab~claw6 "Passive Skill:Oracle~crab~claw6") [[2]](/wiki/Passive_Skill:Oracle~crab~claw7 "Passive Skill:Oracle~crab~claw7") [[3]](/wiki/Passive_Skill:Oracle~crab~claw8 "Passive Skill:Oracle~crab~claw8") |
| [Shelter from the Rain](/wiki/Shelter_from_the_Rain "Shelter from the Rain") | 15% increased Block chance 40% [faster start of Energy Shield Recharge](/wiki/Energy_Shield "Energy Shield") [[1]](/wiki/Passive_Skill:Oracle~crab~claw9~ "Passive Skill:Oracle~crab~claw9~") |

### Ascendancy passive skills

The following [Ascendancy passive skills](/wiki/Ascendancy_passive_skill "Ascendancy passive skill") are related to block:

| Ascendancy Class | Name | Stats |
| --- | --- | --- |
| [Warbringer](/wiki/Warbringer "Warbringer") | [Block Chance](/wiki/Block_Chance/edit?redlink=1 "Block Chance (page does not exist)") | 6% increased Block chance [[1]](/wiki/Passive_Skill:AscendancyWarrior2Small8 "Passive Skill:AscendancyWarrior2Small8") [[2]](/wiki/Passive_Skill:AscendancyWarrior2Small9 "Passive Skill:AscendancyWarrior2Small9") |
| [Warbringer](/wiki/Warbringer "Warbringer") | [Renly's Training](/wiki/Renly%27s_Training "Renly's Training") | Gain 35% Base Chance to Block from [Equipped](/wiki/Equipped/edit?redlink=1 "Equipped (page does not exist)") [Shield](/wiki/Shield "Shield") instead of the Shield's value [[1]](/wiki/Passive_Skill:AscendancyWarrior2Notable8 "Passive Skill:AscendancyWarrior2Notable8") |
| [Warbringer](/wiki/Warbringer "Warbringer") | [Turtle Charm](/wiki/Turtle_Charm "Turtle Charm") | You take 20% of damage from Blocked [Hits](/wiki/Hit "Hit") Maximum Block chance is 75% [[1]](/wiki/Passive_Skill:AscendancyWarrior2Notable9 "Passive Skill:AscendancyWarrior2Notable9") |

### Keystones

The following [Keystones](/wiki/Keystone "Keystone") are related to block:
No results found for the given query.
