# Chaos

Chaos Damage

Tooltip

Chaos damage is one of the five [Damage Types](/wiki/Damage_type "Damage type"). It is reduced by [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance").
Chaos damage is the least common damage type, and removes twice as much [Energy Shield](/wiki/Energy_Shield "Energy Shield") as the damage value when taken.

**Chaos** [damage](/wiki/Damage "Damage") is one of the five [damage types](/wiki/Damage_type "Damage type"). It can be mitigated by chaos [resistance](/wiki/Resistance "Resistance"). Chaos damage has the effect of removing twice as much [energy shield](/wiki/Energy_shield "Energy shield") when dealing damage.

Chaos [damage over time](/wiki/Damage_over_time "Damage over time") is usually inflicted by [poison](/wiki/Poison "Poison") or other [debuffs](/wiki/Debuff "Debuff").

## Mechanics

Chaos damage is somewhat rarer than the other damage types, and is more often seen as damage over time rather than hit damage. It is stronger against energy shield, but a character with [Chaos Inoculation](/wiki/Chaos_Inoculation "Chaos Inoculation") is completely immune to chaos damage.

Chaos damage is usually used alongside [Withered](/wiki/Withered "Withered"), a stacking debuff that increases chaos [damage taken](/wiki/Damage_taken "Damage taken").

## Gems

A list of [gems](/wiki/Gem "Gem") with the [gem tag](/wiki/Gem_tag "Gem tag"): [Category:Chaos (gem tag)](/wiki/Category:Chaos_(gem_tag) "Category:Chaos (gem tag)")

### Skill gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Poisonburst Arrow](/wiki/Poisonburst_Arrow "Poisonburst Arrow") | *1* |  |  |  |
| [Contagion](/wiki/Contagion "Contagion") | *1* |  |  |  |
| [Skeletal Sniper](/wiki/Skeletal_Sniper "Skeletal Sniper") | *1* |  |  |  |
| [Vine Arrow](/wiki/Vine_Arrow "Vine Arrow") | *3* |  |  |  |
| [Essence Drain](/wiki/Essence_Drain "Essence Drain") | *3* |  |  |  |
| [Toxic Growth](/wiki/Toxic_Growth "Toxic Growth") | *5* |  |  |  |
| [Gas Grenade](/wiki/Gas_Grenade "Gas Grenade") | *5* |  |  |  |
| [Gas Arrow](/wiki/Gas_Arrow "Gas Arrow") | *7* |  |  |  |
| [Profane Ritual](/wiki/Profane_Ritual "Profane Ritual") | *7* |  |  |  |
| [Dark Effigy](/wiki/Dark_Effigy "Dark Effigy") | *9* |  |  |  |
| [Despair](/wiki/Despair "Despair") | *9* |  |  |  |
| [Hand of Chayula](/wiki/Hand_of_Chayula "Hand of Chayula") | *9* |  |  |  |
| [Mantra of Destruction](/wiki/Mantra_of_Destruction "Mantra of Destruction") | *9* |  |  |  |
| [Hexblast](/wiki/Hexblast "Hexblast") | *11* |  |  |  |
| [Toxic Domain](/wiki/Toxic_Domain "Toxic Domain") | *13* |  |  |  |

### Spirit gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Plague Bearer](/wiki/Plague_Bearer "Plague Bearer") | *4* |  |  |  |
| [Ravenous Swarm](/wiki/Ravenous_Swarm "Ravenous Swarm") | *4* |  |  |  |
| [Withering Presence](/wiki/Withering_Presence "Withering Presence") | *4* |  |  |  |
| [Herald of Plague](/wiki/Herald_of_Plague "Herald of Plague") | *8* |  |  |  |

### Support gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Tacati's Ire](/wiki/Tacati%27s_Ire "Tacati's Ire") | *0* |  |  |  |
| [Tul's Stillness](/wiki/Tul%27s_Stillness "Tul's Stillness") | *0* |  |  |  |
| [Doedre's Undoing](/wiki/Doedre%27s_Undoing "Doedre's Undoing") | *0* |  |  |  |
| [Esh's Radiance](/wiki/Esh%27s_Radiance "Esh's Radiance") | *0* |  |  |  |
| [Hayoxi's Fulmination](/wiki/Hayoxi%27s_Fulmination "Hayoxi's Fulmination") | *0* |  |  |  |
| [Kurgal's Leash](/wiki/Kurgal%27s_Leash "Kurgal's Leash") | *0* |  |  |  |
| [Uul-Netol's Embrace](/wiki/Uul-Netol%27s_Embrace "Uul-Netol's Embrace") | *0* |  |  |  |
| [Xoph's Pyre](/wiki/Xoph%27s_Pyre "Xoph's Pyre") | *0* |  |  |  |
| [Corrosion](/wiki/Corrosion "Corrosion") | *1* |  |  |  |
| [Escalating Poison](/wiki/Escalating_Poison "Escalating Poison") | *1* |  |  |  |
| [Poison I](/wiki/Poison_I "Poison I") | *1* |  |  |  |
| [Impending Doom](/wiki/Impending_Doom "Impending Doom") | *1* |  |  |  |
| [Profanity I](/wiki/Profanity_I "Profanity I") | *1* |  |  |  |
| [Withering Touch](/wiki/Withering_Touch "Withering Touch") | *1* |  |  |  |
| [Admixture](/wiki/Admixture "Admixture") | *2* |  |  |  |
| [Bursting Plague](/wiki/Bursting_Plague "Bursting Plague") | *2* |  |  |  |
| [Deadly Poison I](/wiki/Deadly_Poison_I "Deadly Poison I") | *2* |  |  |  |
| [Catharsis](/wiki/Catharsis "Catharsis") | *2* |  |  |  |
| [Poison II](/wiki/Poison_II "Poison II") | *3* |  |  |  |
| [Poison Spores](/wiki/Poison_Spores "Poison Spores") | *3* |  |  |  |
| [Chaos Attunement](/wiki/Chaos_Attunement "Chaos Attunement") | *3* |  |  |  |
| [Chaotic Freeze](/wiki/Chaotic_Freeze "Chaotic Freeze") | *3* |  |  |  |
| [Decaying Hex](/wiki/Decaying_Hex "Decaying Hex") | *3* |  |  |  |
| [Extraction](/wiki/Extraction "Extraction") | *3* |  |  |  |
| [Volatility](/wiki/Volatility_(support_gem) "Volatility (support gem)") | *3* |  |  |  |
| [Deadly Poison II](/wiki/Deadly_Poison_II "Deadly Poison II") | *4* |  |  |  |
| [Poison III](/wiki/Poison_III "Poison III") | *5* |  |  |  |
| [Chaos Mastery](/wiki/Chaos_Mastery "Chaos Mastery") | *5* |  |  |  |
| [Profanity II](/wiki/Profanity_II "Profanity II") | *5* |  |  |  |

## Base items

The following base items are related to chaos damage:

| Item |  | Stats |
| --- | --- | --- |
| [Cultist Bow](/wiki/Cultist_Bow "Cultist Bow") | 33 | Adds 7 to 19 Chaos Damage (Hidden) |
| [Adherent Bow](/wiki/Adherent_Bow "Adherent Bow") | 59 | Adds 14 to 32 Chaos Damage (Hidden) |
| [Fanatic Bow](/wiki/Fanatic_Bow "Fanatic Bow") | 79 | Adds 28 to 64 Chaos Damage (Hidden) |

## Unique items

The following unique items are related to chaos damage:

| Item | Stats |
| --- | --- |
| [Melting Maelstrom](/wiki/Melting_Maelstrom "Melting Maelstrom") | Effect is not removed when Unreserved Mana is Filled (200-250)% increased Duration Every 3 seconds during Effect, deal 100% of Mana spent in those seconds as [Chaos Damage](/wiki/Chaos_Damage "Chaos Damage") to Enemies within 3 metres Deals 25% of current Mana as [Chaos Damage](/wiki/Chaos_Damage "Chaos Damage") to you when Effect ends |
| [The Burden of Shadows](/wiki/The_Burden_of_Shadows "The Burden of Shadows") | (20-30)% increased Cast Speed Skill Mana Costs [Converted](/wiki/Stat_conversion "Stat conversion") to Life Costs Skills gain 1% of Damage as [Chaos Damage](/wiki/Chaos_Damage "Chaos Damage") per 3 Life Cost |
| [Voltaxic Rift](/wiki/Voltaxic_Rift "Voltaxic Rift") | Adds 28 to 64 Chaos Damage (Hidden)Adds 1 to (300-500) [Lightning](/wiki/Lightning "Lightning") Damage (10-15)% increased [Attack](/wiki/Attack "Attack") Speed 100% of [Lightning](/wiki/Lightning "Lightning") Damage [Converted](/wiki/Damage_conversion "Damage conversion") to Chaos Damage Chaos Damage from [Hits](/wiki/Hit "Hit") also [Contributes](/wiki/Contributes "Contributes") to [Shock](/wiki/Shock "Shock") Chance |

## Passive skills

### Base passive skills

The following [passive skills](/wiki/Passive_skill "Passive skill") are related to chaos damage:
No results found for the given query.

### Keystone passive skills

The following [keystone](/wiki/Keystone "Keystone") passive skills are related to chaos damage:

| Name | Stats |
| --- | --- |
| [Blackflame Covenant](/wiki/Blackflame_Covenant "Blackflame Covenant") | [Fire](/wiki/Fire "Fire") [Spells](/wiki/Spell "Spell") [Convert](/wiki/Damage_conversion "Damage conversion") 100% of Fire Damage to [Chaos Damage](/wiki/Chaos_Damage "Chaos Damage") [Chaos Damage](/wiki/Chaos_Damage "Chaos Damage") from [Fire](/wiki/Fire "Fire") [Spells](/wiki/Spell "Spell") [Contributes](/wiki/Contributes "Contributes") to [Flammability](/wiki/Flammability "Flammability") and [Ignite](/wiki/Ignite "Ignite") [Magnitudes](/wiki/Magnitude "Magnitude") [Ignite](/wiki/Ignite "Ignite") inflicted with [Fire](/wiki/Fire "Fire") [Spells](/wiki/Spell "Spell") deals [Chaos Damage](/wiki/Chaos_Damage "Chaos Damage") instead of Fire Damage [[1]](/wiki/Passive_Skill:Passive~keystone~fire~spells~to~chaos "Passive Skill:Passive~keystone~fire~spells~to~chaos") |

### Ascendancy passive skills

The following [Ascendancy passive skills](/wiki/Ascendancy_passive_skill "Ascendancy passive skill") are related to chaos damage:
No results found for the given query.
