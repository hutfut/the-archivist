# Interlude 3

Redirect to:

* [Interlude#Interlude 3 - Doryani's Contingency](/wiki/Interlude#Interlude_3_-_Doryani's_Contingency "Interlude")
