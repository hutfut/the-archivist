# Smith of Kitava

Smith of Kitava

[Warrior](/wiki/Warrior "Warrior")

|  |  |
| --- | --- |
|  | **You hunger for power, and by force of arms, you will take it.** |

Official artwork of the Smith of Kitava.

**Smith of Kitava** is an [Ascendancy class](/wiki/Ascendancy_class "Ascendancy class") for the [Warrior](/wiki/Warrior "Warrior").

## Overview

The Smith of Kitava has honed his blacksmithing with the power of the god [Kitava](https://www.poewiki.net/wiki/Kitava,_the_Insatiable "poewiki:Kitava, the Insatiable"). He can make his weapon more lethal by forging it into an ally with [Manifest Weapon](/wiki/Manifest_Weapon "Manifest Weapon"), prepping it with [Temper Weapon](/wiki/Temper_Weapon "Temper Weapon") to give it explosive hits, or make it unleash fire spells on hit with [Heat of the Forge](/wiki/Heat_of_the_Forge "Heat of the Forge"). The Smith of Kitava can scale elemental [resistances](/wiki/Resistance "Resistance") effectively thanks to [Coal Stoker](/wiki/Coal_Stoker "Coal Stoker") and [Forged in Flame](/wiki/Forged_in_Flame "Forged in Flame"), by having fire resistance scale his cold and lightning resistances as well. With [Smith's Masterwork](/wiki/Smith%27s_Masterwork "Smith's Masterwork"), he can spend passive points to add powerful mods of his choosing to a Normal body armour.

## Passive skills

### Minor skills

This class has the following minor passive skills:

| Name | Stats |
| --- | --- |
| [Fire Damage](/wiki/Fire_Damage "Fire Damage") | 20% increased [Fire](/wiki/Fire "Fire") Damage [[1]](/wiki/Passive_Skill:AscendancyWarrior3Small1 "Passive Skill:AscendancyWarrior3Small1") |
| [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") | +8% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") [[1]](/wiki/Passive_Skill:AscendancyWarrior3Small4 "Passive Skill:AscendancyWarrior3Small4") [[2]](/wiki/Passive_Skill:AscendancyWarrior3Small5 "Passive Skill:AscendancyWarrior3Small5") |
| [Melee Damage](/wiki/Melee_Damage/edit?redlink=1 "Melee Damage (page does not exist)") | 20% increased [Melee](/wiki/Melee "Melee") Damage [[1]](/wiki/Passive_Skill:AscendancyWarrior3Small3 "Passive Skill:AscendancyWarrior3Small3") |
| [Strength](/wiki/Strength "Strength") | 5% increased [Strength](/wiki/Strength "Strength") [[1]](/wiki/Passive_Skill:AscendancyWarrior3Small2 "Passive Skill:AscendancyWarrior3Small2") |

### Notable skills

This class has the following notable passive skills:

| Skill | Modifiers | Prerequisite | Preceding Passive |
| --- | --- | --- | --- |
| [Heat of the Forge](/wiki/Heat_of_the_Forge "Heat of the Forge") | Grants Skill: [Fire Spell on Hit](/wiki/Fire_Spell_on_Hit "Fire Spell on Hit") | — | Fire Damage |
| [Coal Stoker](/wiki/Coal_Stoker "Coal Stoker") | Modifiers to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") also grant [Cold and Lightning Resistance](/wiki/Resistance "Resistance") at 50% of their value | — | Fire Resistance |
| [Forged in Flame](/wiki/Forged_in_Flame "Forged in Flame") | Modifiers to [Maximum Fire Resistance](/wiki/Maximum_Fire_Resistance "Maximum Fire Resistance") also grant [Maximum Cold and Lightning Resistance](/wiki/Maximum_Resistance "Maximum Resistance") | [Coal Stoker](/wiki/Coal_Stoker "Coal Stoker") | Fire Resistance |
| [Against the Anvil](/wiki/Against_the_Anvil "Against the Anvil") | Grants Skill: [Temper Weapon](/wiki/Temper_Weapon "Temper Weapon") | — | Melee Damage |
| [Living Weapon](/wiki/Living_Weapon "Living Weapon") | Grants Skill: [Manifest Weapon](/wiki/Manifest_Weapon "Manifest Weapon") | — | Strength |
| [Smith's Masterwork](/wiki/Smith%27s_Masterwork "Smith's Masterwork") | Can only use a [Normal](/wiki/Normal "Normal") Body Armour +200 to [Armour](/wiki/Armour "Armour") for each Connected Notable Passive Skill Allocated | — | — |

### Smith's Masterwork passives

Each of the following passives only costs 1 ascendancy passive skill point.

| Skill | Modifiers |
| --- | --- |
| [Dedication to Kitava](/wiki/Dedication_to_Kitava "Dedication to Kitava") | Body Armour grants +100% of [Armour](/wiki/Armour "Armour") also applies to [Chaos Damage](/wiki/Chaos_Damage "Chaos Damage") |
| [Internal Layer](/wiki/Internal_Layer "Internal Layer") | Body Armour grants [Hits](/wiki/Hit "Hit") against you have 100% reduced [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus") |
| [Tribute to Utula](/wiki/Tribute_to_Utula "Tribute to Utula") | Body Armour grants 30% increased [Spirit](/wiki/Spirit "Spirit") |
| [Leather Bindings](/wiki/Leather_Bindings "Leather Bindings") | Body Armour grants regenerate 3% of maximum Life per second |
| [Molten Symbol](/wiki/Molten_Symbol "Molten Symbol") | Body Armour grants 25% of [Physical](/wiki/Physical "Physical") Damage from [Hits](/wiki/Hit "Hit") taken as [Fire](/wiki/Fire "Fire") Damage |
| [Flowing Metal](/wiki/Flowing_Metal "Flowing Metal") | Body Armour grants +50% of [Armour](/wiki/Armour "Armour") also applies to [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") |
| [Heatproofing](/wiki/Heatproofing "Heatproofing") | Body Armour grants [Unaffected](/wiki/Unaffected "Unaffected") by [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") |
| [Support Straps](/wiki/Support_Straps "Support Straps") | Body Armour grants 20% increased [Strength](/wiki/Strength "Strength") |
| [Kitavan Engraving](/wiki/Kitavan_Engraving "Kitavan Engraving") | Body Armour grants 15% increased maximum Life |
| [Tantalum Alloy](/wiki/Tantalum_Alloy "Tantalum Alloy") | Body Armour grants +75% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") |
| [Kitavan Imprint](/wiki/Kitavan_Imprint "Kitavan Imprint") | Body Armour grants 60% increased [Glory](/wiki/Glory "Glory") generation |
| [Spiked Plates](/wiki/Spiked_Plates "Spiked Plates") | Body Armour grants 100% increased [Thorns](/wiki/Thorns "Thorns") damage |
