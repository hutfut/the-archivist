# Huntress

The Huntress

Gender: F
[Strength](/wiki/Strength "Strength"): 7
[Dexterity](/wiki/Dexterity "Dexterity"): 15
[Intelligence](/wiki/Intelligence "Intelligence"): 7
[Weapon](/wiki/Weapon "Weapon"): [Spear](/wiki/Gemcutting#Spear "Gemcutting")

* [Hardwood Spear](/wiki/Hardwood_Spear "Hardwood Spear")
* [Leather Buckler](/wiki/Leather_Buckler "Leather Buckler")
* [Whirling Slash](/wiki/Whirling_Slash "Whirling Slash")

[Ascendancies](/wiki/Ascendancy_class "Ascendancy class"):

[Ritualist](/wiki/Ritualist "Ritualist")
 [Amazon](/wiki/Amazon "Amazon")

The **Huntress** is a [dexterity](/wiki/Dexterity "Dexterity")-oriented [class](/wiki/Character_class "Character class") that specializes in agility and [spear](/wiki/Spear "Spear") skills. She is of [Azmeri](/wiki/Azmeri/edit?redlink=1 "Azmeri (page does not exist)") heritage.

The Huntress obtains a [Hardwood Spear](/wiki/Hardwood_Spear "Hardwood Spear"), [Leather Buckler](/wiki/Leather_Buckler "Leather Buckler"), and [Whirling Slash](/wiki/Whirling_Slash "Whirling Slash") as her default starting weapon and skill in [The Riverbank](/wiki/The_Riverbank "The Riverbank").

## Ascendancy classes

Huntress can specialize into one of these three [Ascendancy classes](/wiki/Ascendancy_classes "Ascendancy classes"):

* [Ritualist](/wiki/Ritualist "Ritualist")
* [Amazon](/wiki/Amazon "Amazon")
* TBA
