# Amazon

Amazon

[Huntress](/wiki/Huntress "Huntress")

|  |  |
| --- | --- |
|  | **You became a weapon of war so that others could live in peace.** |

Official artwork of the Amazon.

**Amazon** is an [Ascendancy class](/wiki/Ascendancy_class "Ascendancy class") for the [Huntress](/wiki/Huntress "Huntress").

## Overview

The Amazon is an elite warrior trained to protect the Azmeri elders, transforming her into an offensive powerhouse with recovery and [Evasion](/wiki/Evasion "Evasion") bonuses to boot. She can learn [Elemental Infusion](/wiki/Elemental_Infusion "Elemental Infusion") to use [charges](/wiki/Charge "Charge") to infuse her attacks with lightning damage explosions (or elemental damage explosions with [Surging Avatar](/wiki/Surging_Avatar "Surging Avatar")), [Critical Strike](/wiki/Critical_Strike "Critical Strike") and [Penetrate](/wiki/Penetrate "Penetrate") to turn [Accuracy](/wiki/Accuracy "Accuracy") into a source of damage, and [Predatory Instinct](/wiki/Predatory_Instinct "Predatory Instinct") to deal more damage against enemies at certain life intervals. [Azmeri Brew](/wiki/Azmeri_Brew "Azmeri Brew") lets her [flasks](/wiki/Flask "Flask") pull double duty on life and mana recovery, and [Mystic Harvest](/wiki/Mystic_Harvest "Mystic Harvest") grants her elemental life [leech](/wiki/Leech "Leech"). Finally, [Stalking Panther](/wiki/Stalking_Panther "Stalking Panther") grants her more Evasion from her gear except the body armour.

## Passive skills

### Minor skills

This class has the following minor passive skills:

| Name | Stats |
| --- | --- |
| [Accuracy](/wiki/Accuracy "Accuracy") | 12% increased [Accuracy](/wiki/Accuracy "Accuracy") Rating [[1]](/wiki/Passive_Skill:AscendancyHuntress1Small1 "Passive Skill:AscendancyHuntress1Small1") [[2]](/wiki/Passive_Skill:AscendancyHuntress1Small2 "Passive Skill:AscendancyHuntress1Small2") |
| [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") | 12% increased [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") [[1]](/wiki/Passive_Skill:AscendancyHuntress1Small5 "Passive Skill:AscendancyHuntress1Small5") [[2]](/wiki/Passive_Skill:AscendancyHuntress1Small6 "Passive Skill:AscendancyHuntress1Small6") |
| [Evasion](/wiki/Evasion_(passive_skill) "Evasion (passive skill)") | 20% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") [[1]](/wiki/Passive_Skill:AscendancyHuntress1Small8 "Passive Skill:AscendancyHuntress1Small8") |
| [Flask Recovery](/wiki/Flask_Recovery/edit?redlink=1 "Flask Recovery (page does not exist)") | 15% increased Life and Mana Recovery from [Flasks](/wiki/Flask "Flask") [[1]](/wiki/Passive_Skill:AscendancyHuntress1Small7 "Passive Skill:AscendancyHuntress1Small7") |
| [Life Leech](/wiki/Life_Leech "Life Leech") | 12% increased amount of Life [Leeched](/wiki/Leech "Leech") [[1]](/wiki/Passive_Skill:AscendancyHuntress1Small9 "Passive Skill:AscendancyHuntress1Small9") |
| [Skill Speed](/wiki/Skill_Speed "Skill Speed") | 4% increased [Skill Speed](/wiki/Skill_Speed "Skill Speed") [[1]](/wiki/Passive_Skill:AscendancyHuntress1Small3 "Passive Skill:AscendancyHuntress1Small3") [[2]](/wiki/Passive_Skill:AscendancyHuntress1Small4~ "Passive Skill:AscendancyHuntress1Small4~") |

### Notable skills

This class has the following notable passive skills:

| Skill | Modifiers | Prerequisite | Preceding Passive |
| --- | --- | --- | --- |
| [Azmeri Brew](/wiki/Azmeri_Brew "Azmeri Brew") | Life [Flasks](/wiki/Flask "Flask") also recover Mana Mana [Flasks](/wiki/Flask "Flask") also recover Life | — | Flask Recovery |
| [Stalking Panther](/wiki/Stalking_Panther "Stalking Panther") | [Evasion](/wiki/Evasion "Evasion") Rating from Equipped Helmet, Gloves and Boots is doubled [Evasion](/wiki/Evasion "Evasion") Rating from Equipped Body Armour is halved | — | Evasion |
| [Mystic Harvest](/wiki/Mystic_Harvest "Mystic Harvest") | [Life Leech](/wiki/Life_Leech "Life Leech") recovers based on your [Elemental](/wiki/Elemental "Elemental") damage as well as [Physical](/wiki/Physical "Physical") damage | — | Life Leech |
| [Elemental Surge](/wiki/Elemental_Surge_(passive) "Elemental Surge (passive)") | Grants Skill: [Elemental Surge](/wiki/Elemental_Surge "Elemental Surge") When you Consume a [Charge](/wiki/Charge "Charge"), [Trigger](/wiki/Trigger "Trigger") Elemental Surge to gain 3 [Lightning Surges](/wiki/Elemental_Surges "Elemental Surges") | — | Evasion |
| [Surging Avatar](/wiki/Surging_Avatar "Surging Avatar") | When you Consume a [Charge](/wiki/Charge "Charge"), [Trigger](/wiki/Trigger "Trigger") Elemental Surge to gain 2 [Cold Surges](/wiki/Elemental_Surges "Elemental Surges") When you Consume a [Charge](/wiki/Charge "Charge"), [Trigger](/wiki/Trigger "Trigger") Elemental Surge to gain 2 [Fire Surges](/wiki/Elemental_Surges "Elemental Surges") Gain 1 fewer [Lightning Surge](/wiki/Elemental_Surges "Elemental Surges") from [Triggering](/wiki/Trigger "Trigger") Elemental Surge | [Elemental Infusion](/wiki/Elemental_Infusion "Elemental Infusion") | Evasion |
| [Predatory Instinct](/wiki/Predatory_Instinct "Predatory Instinct") | [Reveal Weaknesses](/wiki/Revealing_Weaknesses/edit?redlink=1 "Revealing Weaknesses (page does not exist)") against [Rare and Unique](/wiki/Rarity "Rarity") enemies 50% more damage against enemies with an [Open Weakness](/wiki/Revealing_Weaknesses/edit?redlink=1 "Revealing Weaknesses (page does not exist)") | — | Skill Speed |
| [In for the Kill](/wiki/In_for_the_Kill "In for the Kill") | 20% increased Movement Speed while an enemy with an [Open Weakness](/wiki/Revealing_Weaknesses/edit?redlink=1 "Revealing Weaknesses (page does not exist)") is in your [Presence](/wiki/Presence "Presence") 40% increased [Skill Speed](/wiki/Skill_Speed "Skill Speed") while an enemy with an [Open Weakness](/wiki/Revealing_Weaknesses/edit?redlink=1 "Revealing Weaknesses (page does not exist)") is in your [Presence](/wiki/Presence "Presence") | [Predatory Instinct](/wiki/Predatory_Instinct "Predatory Instinct") | Skill Speed |
| [Critical Strike](/wiki/Critical_Strike "Critical Strike") | Chance to [Hit](/wiki/Hit "Hit") with [Attacks](/wiki/Attack "Attack") can [exceed 100%](/wiki/Chances_in_excess_of_100%25/edit?redlink=1 "Chances in excess of 100% (page does not exist)") Gain additional [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance equal to 25% of excess chance to [Hit](/wiki/Hit "Hit") with [Attacks](/wiki/Attack "Attack") | — | Accuracy |
| [Penetrate](/wiki/Penetrate "Penetrate") | [Attacks](/wiki/Attack "Attack") using your Weapons have Added [Physical](/wiki/Physical "Physical") Damage equal to 25% of the [Accuracy](/wiki/Accuracy "Accuracy") Rating on the Weapon | [Critical Strike](/wiki/Critical_Strike "Critical Strike") | Accuracy |
