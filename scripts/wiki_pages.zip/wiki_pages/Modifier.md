# Modifier

Modifiers are properties that can be added and randomized on [items](/wiki/Items "Items") in [Path of Exile 2](/wiki/Path_of_Exile_2 "Path of Exile 2"), giving them stats, skills, and functionality. These properties provide bonuses or effects and are divided into several types:

| Term | Explanation |
| --- | --- |
| Prefix | Modifiers that typically enhance primary stats, such as increased [damage](/wiki/Damage "Damage"), [life](/wiki/Life "Life"), [mana](/wiki/Mana "Mana"), and [movement speed](/wiki/Movement_speed "Movement speed") |
| Suffix | Modifiers that usually focus on secondary stats, like [resistances](/wiki/Resistance "Resistance"), [accuracy](/wiki/Accuracy "Accuracy") |
| Affix | A term that generally describe either a prefix or suffix |
| Implicit | An innate modifier that is, by default, present on all versions of an [item](/wiki/Item "Item") |
| Explicit | A modifier generated on an item of non-normal rarity, usally via random item generation or [crafting](/wiki/Crafting "Crafting") |
| Enchantment | A modifier added to an item via specific methods that use the enchantment slot. For example, this can be via [Runes](/wiki/Rune "Rune") on weapons and armour, or via instilling an amulet with [Distilled Emotions](/wiki/Distilled_Emotion "Distilled Emotion") |
| Corruption | A special type of enchantment modifier that can apply to an item from using a [Vaal Orb](/wiki/Vaal_Orb "Vaal Orb") |
| Desecrated | Special modifiers added using [preserved bones](/wiki/Preserved_bone "Preserved bone") that are obscured by default. Can be revealed at the [Well of Souls](/wiki/Well_of_Souls "Well of Souls"). |

[Magic items](/wiki/Magic "Magic") can have up to 2 modifiers (1 prefix and 1 suffix), while [rare items](/wiki/Rare "Rare") can have up to 6 modifiers (3 prefixes and 3 suffixes). The specific combination of affixes determines the overall power and [utility](/wiki/Utility "Utility") of the item, making modifiers central to [itemization](/wiki/Itemization "Itemization") and character progression.

## Local and global modifiers

**Local modifiers** are modifiers that directly affect the item they're on. **Global modifiers** affect the character as a whole. Base stats modified by local modifiers will appear blue as opposed to grey when viewing the item. Conditional modifiers are always global.

### Local modifiers

On [martial weapons](/wiki/Martial_weapons "Martial weapons"):

* Adds # to # [Physical/Lightning/Cold/Fire/Chaos] Damage
  + This local modifier adds directly to the weapon's base added damage.
  + Global versions of this modifier may state  ... to Attacks or  ... to Spells, or neither. If neither is stated, it will apply to all spells and attacks.
* #% increased Physical Damage
  + This local modifier directly modifies the weapon's base physical damage. For example, if a weapon's base grants 50-100 Added Physical Damage, and it has the modifiers Adds 25 to 50 Physical Damage and 100% increased Physical Damage, its final base physical damage will be 150 to 300 Physical Damage.
  + If the weapon doesn't have any base physical damage, this modifier will do nothing.
  + Multiple sources of this modifier, such as by enchant from an [Iron Rune](/wiki/Iron_Rune "Iron Rune"), are additive.
  + Because this modifier directly modifies the weapon's base physical damage, even if all the physical damage is later converted to another damage type, the modifier will still be effective, as it increased the damage that got converted.
  + Global versions of this modifier may specify ... Global Physical Damage, but not always. If they are not found on a martial weapon however, they will still be global.
* #% increased Elemental Damage
  + As of early access, this modifier doesn't actually exist as a local modifier (although it appears globally on a lot of non-martial sources). If it did, it would modify the weapon's base elemental damage like #% increased Physical Damage does the physical. The global version of this modifier is #% increased Elemental Damage with Attacks - note that it specifies "with Attacks" to make it clear that it's global.
* #% increased Attack Speed
  + This modifier directly modifies the weapon's base attack speed. It is multiplicative with global sources of attack speed.
* +#% to Critical Hit Chance
  + This modifier adds directly to the base critical hit chance of the weapon.
* +#% to Critical Damage Bonus
  + This modifier adds to the base critical damage bonus for critical hits with the weapon, which is +100% by default. This new value is multiplicative with global sources of critical damage bonus.

On [sceptres](/wiki/Sceptre "Sceptre"):

* #% increased Spirit
  + This modifier directly modifies the Spirit's base stat, which grants +100 to Spirit.

On [armour (equipment)](/wiki/Armour_(equipment) "Armour (equipment)"):

* +# to [Armour/Evasion Rating/Energy Shield]
* #% increased [Armour/Evasion Rating/Energy Shield] (and any combination of the three)
  + For energy shield specifically, global versions will specify ... maximum Energy Shield

On all items:

* #% reduced Attribute Requirements is always local.
  + The global version of this modifier will be phrased Equipment and Skill Gems have #% [increased/reduced] Attribute Requirements.
