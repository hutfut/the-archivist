# Chronomancer

Chronomancer

[Sorceress](/wiki/Sorceress "Sorceress")

|  |  |
| --- | --- |
|  | **The tapestry of time is yours to weave; an element you alone may master.** |

Official artwork of the Chronomancer.

**Chronomancer** is an [Ascendancy class](/wiki/Ascendancy_class "Ascendancy class") for the [Sorceress](/wiki/Sorceress "Sorceress").

## Overview

The Chronomancer specializes in manipulating time, gaining access to a wide range of utility skills. She can learn [Temporal Rift](/wiki/Temporal_Rift "Temporal Rift") to rewind her position and life, mana and energy shield values to what it was a few seconds ago, [Inevitable Agony](/wiki/Inevitable_Agony "Inevitable Agony") to curse enemies to take a portion of all the damage taken again after a brief delay, [Time Snap](/wiki/Time_Snap "Time Snap") to refresh all [cooldowns](/wiki/Cooldown "Cooldown") on command, and [Time Freeze](/wiki/Time_Freeze "Time Freeze") to stop all enemies in their tracks. [Quicksand Hourglass](/wiki/Quicksand_Hourglass "Quicksand Hourglass") grants her a fluctuating amount of cast speed and area of effect, while [Now and Again](/wiki/Now_and_Again "Now and Again") gives her a chance to refresh [cooldowns](/wiki/Cooldown "Cooldown") instantly. The Chronomancer also has a few defensive abilities at her disposal; [Apex of the Moment](/wiki/Apex_of_the_Moment "Apex of the Moment") lets her slow nearby enemies, and [The Rapid River](/wiki/The_Rapid_River "The Rapid River") hastens the speed of [Recoup](/wiki/Recoup "Recoup") effects.

## Passive skills

### Minor skills

This class has the following minor passive skills:

| Name | Stats |
| --- | --- |
| [Buff Expiry Rate](/wiki/Buff_Expiry_Rate/edit?redlink=1 "Buff Expiry Rate (page does not exist)") | [Buffs](/wiki/Buffs "Buffs") on you expire 10% slower [[1]](/wiki/Passive_Skill:AscendancySorceress2Small1 "Passive Skill:AscendancySorceress2Small1") [[2]](/wiki/Passive_Skill:AscendancySorceress2Small2 "Passive Skill:AscendancySorceress2Small2") |
| [Cast Speed and Area of Effect](/wiki/Cast_Speed_and_Area_of_Effect/edit?redlink=1 "Cast Speed and Area of Effect (page does not exist)") | 4% increased Cast Speed 8% increased Area of Effect [[1]](/wiki/Passive_Skill:AscendancySorceress2Small8 "Passive Skill:AscendancySorceress2Small8") |
| [Cooldown Recovery Rate](/wiki/Cooldown_Recovery_Rate "Cooldown Recovery Rate") | 6% increased [Cooldown Recovery Rate](/wiki/Cooldown_Recovery_Rate "Cooldown Recovery Rate") [[1]](/wiki/Passive_Skill:AscendancySorceress2Small5 "Passive Skill:AscendancySorceress2Small5") [[2]](/wiki/Passive_Skill:AscendancySorceress2Small6 "Passive Skill:AscendancySorceress2Small6") |
| [Curse Delay](/wiki/Curse_Delay/edit?redlink=1 "Curse Delay (page does not exist)") | [Curse](/wiki/Curse "Curse") zones erupt after 10% reduced delay [[1]](/wiki/Passive_Skill:AscendancySorceress2Small3 "Passive Skill:AscendancySorceress2Small3") |
| [Life Recoup](/wiki/Life_Recoup/edit?redlink=1 "Life Recoup (page does not exist)") | 4% of Damage taken [Recouped](/wiki/Recoup "Recoup") as Life [[1]](/wiki/Passive_Skill:AscendancySorceress2Small4 "Passive Skill:AscendancySorceress2Small4") |
| [Slow Effect](/wiki/Slow_Effect/edit?redlink=1 "Slow Effect (page does not exist)") | [Debuffs](/wiki/Debuff "Debuff") you inflict have 6% increased [Slow Magnitude](/wiki/Slow_Magnitude_Modifier/edit?redlink=1 "Slow Magnitude Modifier (page does not exist)") [[1]](/wiki/Passive_Skill:AscendancySorceress2Small7 "Passive Skill:AscendancySorceress2Small7") |

### Notable skills

This class has the following notable passive skills:

| Skill | Modifiers | Prerequisite | Preceding Passive |
| --- | --- | --- | --- |
| [Footprints in the Sand](/wiki/Footprints_in_the_Sand "Footprints in the Sand") | Grants Skill: [Temporal Rift](/wiki/Temporal_Rift "Temporal Rift") | — | [Buff Expiry Rate](/wiki/Buff_Expiry_Rate_(ascendancy_passive_skill) "Buff Expiry Rate (ascendancy passive skill)") |
| [Ultimate Command](/wiki/Ultimate_Command "Ultimate Command") | Grants Skill: [Time Freeze](/wiki/Time_Freeze "Time Freeze") | [Footprints in the Sand](/wiki/Footprints_in_the_Sand "Footprints in the Sand") | [Buff Expiry Rate](/wiki/Buff_Expiry_Rate_(ascendancy_passive_skill) "Buff Expiry Rate (ascendancy passive skill)") |
| [Quicksand Hourglass](/wiki/Quicksand_Hourglass "Quicksand Hourglass") | Grants [Sands of Time](/wiki/Sands_of_Time/edit?redlink=1 "Sands of Time (page does not exist)") | — | Cast Speed and Area of Effect |
| [Inevitability](/wiki/Inevitability "Inevitability") | Grants Skill: [Inevitable Agony](/wiki/Inevitable_Agony "Inevitable Agony") | — | Curse Delay |
| [The Rapid River](/wiki/The_Rapid_River "The Rapid River") | [Recoup Effects](/wiki/Recoup "Recoup") instead occur over 4 seconds | — | Life Recoup |
| [Apex of the Moment](/wiki/Apex_of_the_Moment "Apex of the Moment") | Enemies in your [Presence](/wiki/Presence "Presence") are [Slowed](/wiki/Slow "Slow") by 20% | — | [Slow Effect](/wiki/Slow_Effect_(ascendancy_passive_skill) "Slow Effect (ascendancy passive skill)") |
| [Now and Again](/wiki/Now_and_Again "Now and Again") | Skills have 33% chance to not consume a Cooldown when used | — | [Cooldown Recovery Rate](/wiki/Cooldown_Recovery_Rate_(ascendancy_passive_skill) "Cooldown Recovery Rate (ascendancy passive skill)") |
| [Unbound Encore](/wiki/Unbound_Encore "Unbound Encore") | Grants Skill: [Time Snap](/wiki/Time_Snap "Time Snap") | [Now and Again](/wiki/Now_and_Again "Now and Again") | [Cooldown Recovery Rate](/wiki/Cooldown_Recovery_Rate_(ascendancy_passive_skill) "Cooldown Recovery Rate (ascendancy passive skill)") |
