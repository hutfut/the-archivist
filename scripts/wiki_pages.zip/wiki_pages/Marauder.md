# Marauder

This article is about unreleased content and is not yet available in the game.

The Marauder

Gender: M
[Strength](/wiki/Strength "Strength"): 15
[Dexterity](/wiki/Dexterity "Dexterity"): 7
[Intelligence](/wiki/Intelligence "Intelligence"): 7

The **Marauder** is a [strength](/wiki/Strength "Strength")-oriented [class](/wiki/Character_class "Character class") that specializes in [melee](/wiki/Melee "Melee") skills.

The Marauder obtains a **Module Error: No results found for item using search term "item\_name = "** and **Module Error: No results found for item using search term "item\_name = "** as his default starting weapon and skill in [The Riverbank](/wiki/The_Riverbank "The Riverbank").

## Ascendancy classes

Marauder can specialize into one of these three [Ascendancy classes](/wiki/Ascendancy_classes "Ascendancy classes"):

* TBA
* TBA
* TBA
