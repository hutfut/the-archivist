# Spell

Spells

Tooltip

Spells are skills that use raw magic to destroy your enemies. [Attacks](/wiki/Attack "Attack") are not Spells.

Spells have their own base damage, cast speed and [Critical Hit](/wiki/Critical_Hit "Critical Hit") chance determined by the skill. They do not benefit from a weapon's inherent damage, attack speed or [Critical Hit](/wiki/Critical_Hit "Critical Hit") chance.

**Spells** are [skills](/wiki/Skill "Skill") that are cast or triggered by the user which can deal [damage](/wiki/Damage "Damage") to an enemy or apply positive or negative effects to the caster, allies, or enemies. It is one of the two major categories for skills, the other being [attacks](/wiki/Attack "Attack"). Unlike attacks, spells are not affected by [accuracy](/wiki/Accuracy "Accuracy") or [evasion](/wiki/Evasion "Evasion").

## Gems

A list of [gems](/wiki/Gem "Gem") with the Spell [gem tag](/wiki/Gem_tag "Gem tag"):

### Skill gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Blink](/wiki/Blink_(Sands_of_Silk) "Blink (Sands of Silk)") | *0* |  |  |  |
| [Contagion](/wiki/Contagion "Contagion") | *1* |  |  |  |
| [Flame Wall](/wiki/Flame_Wall "Flame Wall") | *1* |  |  |  |
| [Frost Bomb](/wiki/Frost_Bomb "Frost Bomb") | *1* |  |  |  |
| [Ice Nova](/wiki/Ice_Nova "Ice Nova") | *1* |  |  |  |
| [Spark](/wiki/Spark "Spark") | *1* |  |  |  |
| [Unearth](/wiki/Unearth "Unearth") | *1* |  |  |  |
| [Entangle](/wiki/Entangle "Entangle") | *1* |  |  |  |
| [Volcano](/wiki/Volcano "Volcano") | *1* |  |  |  |
| [Bone Cage](/wiki/Bone_Cage "Bone Cage") | *3* |  |  |  |
| [Enfeeble](/wiki/Enfeeble "Enfeeble") | *3* |  |  |  |
| [Essence Drain](/wiki/Essence_Drain "Essence Drain") | *3* |  |  |  |
| [Fireball](/wiki/Fireball "Fireball") | *3* |  |  |  |
| [Frost Darts](/wiki/Frost_Darts "Frost Darts") | *3* |  |  |  |
| [Living Bomb](/wiki/Living_Bomb "Living Bomb") | *3* |  |  |  |
| [Orb of Storms](/wiki/Orb_of_Storms "Orb of Storms") | *3* |  |  |  |
| [Barrage](/wiki/Barrage "Barrage") | *5* |  |  |  |
| [Ice-Tipped Arrows](/wiki/Ice-Tipped_Arrows "Ice-Tipped Arrows") | *5* |  |  |  |
| [Arc](/wiki/Arc "Arc") | *5* |  |  |  |
| [Bonestorm](/wiki/Bonestorm "Bonestorm") | *5* |  |  |  |
| [Ember Fusillade](/wiki/Ember_Fusillade "Ember Fusillade") | *5* |  |  |  |
| [Frostbolt](/wiki/Frostbolt "Frostbolt") | *5* |  |  |  |
| [Snap](/wiki/Snap "Snap") | *5* |  |  |  |
| [Thunderstorm](/wiki/Thunderstorm "Thunderstorm") | *5* |  |  |  |
| [Detonate Dead](/wiki/Detonate_Dead "Detonate Dead") | *7* |  |  |  |
| [Elemental Weakness](/wiki/Elemental_Weakness "Elemental Weakness") | *7* |  |  |  |
| [Mana Tempest](/wiki/Mana_Tempest "Mana Tempest") | *7* |  |  |  |
| [Profane Ritual](/wiki/Profane_Ritual "Profane Ritual") | *7* |  |  |  |
| [Temporal Chains](/wiki/Temporal_Chains "Temporal Chains") | *7* |  |  |  |
| [Vulnerability](/wiki/Vulnerability "Vulnerability") | *7* |  |  |  |
| [Spell Totem](/wiki/Spell_Totem "Spell Totem") | *7* |  |  |  |
| [Dark Effigy](/wiki/Dark_Effigy "Dark Effigy") | *9* |  |  |  |
| [Despair](/wiki/Despair "Despair") | *9* |  |  |  |
| [Frost Wall](/wiki/Frost_Wall "Frost Wall") | *9* |  |  |  |
| [Incinerate](/wiki/Incinerate "Incinerate") | *9* |  |  |  |
| [Lightning Warp](/wiki/Lightning_Warp "Lightning Warp") | *9* |  |  |  |
| [Charged Staff](/wiki/Charged_Staff "Charged Staff") | *9* |  |  |  |
| [Thrashing Vines](/wiki/Thrashing_Vines "Thrashing Vines") | *9* |  |  |  |
| [Ball Lightning](/wiki/Ball_Lightning "Ball Lightning") | *11* |  |  |  |
| [Comet](/wiki/Comet "Comet") | *11* |  |  |  |
| [Firestorm](/wiki/Firestorm "Firestorm") | *11* |  |  |  |
| [Hexblast](/wiki/Hexblast "Hexblast") | *11* |  |  |  |
| [Tornado](/wiki/Tornado "Tornado") | *11* |  |  |  |
| [Eye of Winter](/wiki/Eye_of_Winter "Eye of Winter") | *13* |  |  |  |
| [Flameblast](/wiki/Flameblast "Flameblast") | *13* |  |  |  |
| [Lightning Conduit](/wiki/Lightning_Conduit "Lightning Conduit") | *13* |  |  |  |

### Spirit gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Arctic Armour](/wiki/Arctic_Armour "Arctic Armour") | *4* |  |  |  |
| [Convalescence](/wiki/Convalescence "Convalescence") | *4* |  |  |  |
| [Grim Feast](/wiki/Grim_Feast "Grim Feast") | *4* |  |  |  |
| [Briarpatch](/wiki/Briarpatch_(skill_gem) "Briarpatch (skill gem)") | *4* |  |  |  |
| [Blink](/wiki/Blink "Blink") | *8* |  |  |  |

### Support gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Arbiter's Ignition](/wiki/Arbiter%27s_Ignition "Arbiter's Ignition") | *0* |  |  |  |
| [Doedre's Undoing](/wiki/Doedre%27s_Undoing "Doedre's Undoing") | *0* |  |  |  |
| [Hayoxi's Fulmination](/wiki/Hayoxi%27s_Fulmination "Hayoxi's Fulmination") | *0* |  |  |  |
| [Morgana's Tempest](/wiki/Morgana%27s_Tempest "Morgana's Tempest") | *0* |  |  |  |
| [Oisín's Oath](/wiki/Ois%C3%ADn%27s_Oath "Oisín's Oath") | *0* |  |  |  |
| [Sione's Temper](/wiki/Sione%27s_Temper "Sione's Temper") | *0* |  |  |  |
| [Vilenta's Propulsion](/wiki/Vilenta%27s_Propulsion "Vilenta's Propulsion") | *0* |  |  |  |
| [Zarokh's Refrain](/wiki/Zarokh%27s_Refrain "Zarokh's Refrain") | *0* |  |  |  |
| [Zarokh's Revolt](/wiki/Zarokh%27s_Revolt "Zarokh's Revolt") | *0* |  |  |  |
| [Slow Potency](/wiki/Slow_Potency "Slow Potency") | *1* |  |  |  |
| [Arcane Surge](/wiki/Arcane_Surge_(support_gem) "Arcane Surge (support gem)") | *1* |  |  |  |
| [Controlled Destruction](/wiki/Controlled_Destruction "Controlled Destruction") | *1* |  |  |  |
| [Coursing Current](/wiki/Coursing_Current "Coursing Current") | *1* |  |  |  |
| [Impending Doom](/wiki/Impending_Doom "Impending Doom") | *1* |  |  |  |
| [Rapid Casting I](/wiki/Rapid_Casting_I "Rapid Casting I") | *1* |  |  |  |
| [Unleash](/wiki/Unleash "Unleash") | *1* |  |  |  |
| [Zenith I](/wiki/Zenith_I "Zenith I") | *1* |  |  |  |
| [Inhibitor](/wiki/Inhibitor "Inhibitor") | *2* |  |  |  |
| [Accelerated Growth I](/wiki/Accelerated_Growth_I "Accelerated Growth I") | *2* |  |  |  |
| [Considered Casting](/wiki/Considered_Casting "Considered Casting") | *2* |  |  |  |
| [Fiery Death](/wiki/Fiery_Death "Fiery Death") | *2* |  |  |  |
| [Intense Agony](/wiki/Intense_Agony "Intense Agony") | *2* |  |  |  |
| [Mana Flare](/wiki/Mana_Flare "Mana Flare") | *2* |  |  |  |
| [Potent Exposure](/wiki/Potent_Exposure "Potent Exposure") | *2* |  |  |  |
| [Spell Echo](/wiki/Spell_Echo "Spell Echo") | *2* |  |  |  |
| [Chaotic Freeze](/wiki/Chaotic_Freeze "Chaotic Freeze") | *3* |  |  |  |
| [Drain Ailments](/wiki/Drain_Ailments "Drain Ailments") | *3* |  |  |  |
| [Electromagnetism](/wiki/Electromagnetism "Electromagnetism") | *3* |  |  |  |
| [Elemental Discharge](/wiki/Elemental_Discharge "Elemental Discharge") | *3* |  |  |  |
| [Extraction](/wiki/Extraction "Extraction") | *3* |  |  |  |
| [Practical Magic I](/wiki/Practical_Magic_I "Practical Magic I") | *3* |  |  |  |
| [Static Shocks](/wiki/Static_Shocks "Static Shocks") | *3* |  |  |  |
| [Wildshards I](/wiki/Wildshards_I "Wildshards I") | *3* |  |  |  |
| [Zenith II](/wiki/Zenith_II "Zenith II") | *3* |  |  |  |
| [Advancing Storm](/wiki/Advancing_Storm "Advancing Storm") | *4* |  |  |  |
| [Concussive Spells](/wiki/Concussive_Spells "Concussive Spells") | *4* |  |  |  |
| [Rapid Casting II](/wiki/Rapid_Casting_II "Rapid Casting II") | *4* |  |  |  |
| [Charged Mark](/wiki/Charged_Mark "Charged Mark") | *5* |  |  |  |
| [Accelerated Growth II](/wiki/Accelerated_Growth_II "Accelerated Growth II") | *5* |  |  |  |
| [Catalysing Elements](/wiki/Catalysing_Elements "Catalysing Elements") | *5* |  |  |  |
| [Expand](/wiki/Expand "Expand") | *5* |  |  |  |
| [Practical Magic II](/wiki/Practical_Magic_II "Practical Magic II") | *5* |  |  |  |
| [Rapid Casting III](/wiki/Rapid_Casting_III "Rapid Casting III") | *5* |  |  |  |
| [Wildshards II](/wiki/Wildshards_II "Wildshards II") | *5* |  |  |  |

## Related passive skills

The following [passive skills](/wiki/Passive_skill "Passive skill") are related to spells:

### Spell damage

| Name | Stats |
| --- | --- |
| [Arcane Surge Spell Damage](/wiki/Arcane_Surge_Spell_Damage/edit?redlink=1 "Arcane Surge Spell Damage (page does not exist)") | 15% increased Spell Damage while you have [Arcane Surge](/wiki/Arcane_Surge "Arcane Surge") [[1]](/wiki/Passive_Skill:Mana~regeneration42 "Passive Skill:Mana~regeneration42") [[2]](/wiki/Passive_Skill:Mana~regeneration43 "Passive Skill:Mana~regeneration43") |
| [Attack and Spell Damage](/wiki/Attack_and_Spell_Damage/edit?redlink=1 "Attack and Spell Damage (page does not exist)") | 8% increased [Attack](/wiki/Attack "Attack") Damage 8% increased Spell Damage [[1]](/wiki/Passive_Skill:Attacks~and~spells10 "Passive Skill:Attacks~and~spells10") [[2]](/wiki/Passive_Skill:Attacks~and~spells11 "Passive Skill:Attacks~and~spells11") [[3]](/wiki/Passive_Skill:Attacks~and~spells5~ "Passive Skill:Attacks~and~spells5~") [[4]](/wiki/Passive_Skill:Attacks~and~spells6 "Passive Skill:Attacks~and~spells6") [[5]](/wiki/Passive_Skill:Attacks~and~spells7 "Passive Skill:Attacks~and~spells7") [[6]](/wiki/Passive_Skill:Attacks~and~spells8 "Passive Skill:Attacks~and~spells8") [[7]](/wiki/Passive_Skill:Attacks~and~spells9 "Passive Skill:Attacks~and~spells9") |
| [Infused Spell Damage](/wiki/Infused_Spell_Damage/edit?redlink=1 "Infused Spell Damage (page does not exist)") | 12% increased Spell Damage if you have consumed an [Elemental Infusion](/wiki/Elemental_Infusion "Elemental Infusion") [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Infusion14 "Passive Skill:Infusion14") [[2]](/wiki/Passive_Skill:Infusion15 "Passive Skill:Infusion15") [[3]](/wiki/Passive_Skill:Infusion19~ "Passive Skill:Infusion19~") [[4]](/wiki/Passive_Skill:Lightning6 "Passive Skill:Lightning6") [[5]](/wiki/Passive_Skill:Sorcerer~start3 "Passive Skill:Sorcerer~start3") |
| [Invocation Spell Damage](/wiki/Invocation_Spell_Damage/edit?redlink=1 "Invocation Spell Damage (page does not exist)") | [Invocated](/wiki/Invocation "Invocation") Spells deal 15% increased Damage [[1]](/wiki/Passive_Skill:Triggers22 "Passive Skill:Triggers22") [[2]](/wiki/Passive_Skill:Triggers21 "Passive Skill:Triggers21") [[3]](/wiki/Passive_Skill:Triggers15 "Passive Skill:Triggers15") [[4]](/wiki/Passive_Skill:Triggers11 "Passive Skill:Triggers11") |
| [Life Spell Damage](/wiki/Life_Spell_Damage/edit?redlink=1 "Life Spell Damage (page does not exist)") | 12% increased Spell Damage with Spells that cost Life [[1]](/wiki/Passive_Skill:Life~costs7 "Passive Skill:Life~costs7") |
| [Life Spell Damage and Costs](/wiki/Life_Spell_Damage_and_Costs/edit?redlink=1 "Life Spell Damage and Costs (page does not exist)") | 6% increased Spell Damage with Spells that cost Life 8% of Spell Mana Cost [Converted](/wiki/Stat_conversion "Stat conversion") to Life Cost [[1]](/wiki/Passive_Skill:Life~costs4 "Passive Skill:Life~costs4") |
| [Shapeshifting Spell Damage](/wiki/Shapeshifting_Spell_Damage/edit?redlink=1 "Shapeshifting Spell Damage (page does not exist)") | 12% increased Spell Damage if you have [Shapeshifted](/wiki/Shapeshifting "Shapeshifting") to Human form [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Shapeshifting15 "Passive Skill:Shapeshifting15") [[2]](/wiki/Passive_Skill:Shapeshifting16 "Passive Skill:Shapeshifting16") |
| [Spell and Attack Damage](/wiki/Spell_and_Attack_Damage/edit?redlink=1 "Spell and Attack Damage (page does not exist)") | 10% increased [Attack](/wiki/Attack "Attack") Damage 10% increased Spell Damage [[1]](/wiki/Passive_Skill:Placeholder2 "Passive Skill:Placeholder2") |
| [Spell and Minion Damage](/wiki/Spell_and_Minion_Damage/edit?redlink=1 "Spell and Minion Damage (page does not exist)") | 10% increased Spell Damage [Minions](/wiki/Minion "Minion") deal 10% increased Damage [[1]](/wiki/Passive_Skill:Spells53 "Passive Skill:Spells53") [[2]](/wiki/Passive_Skill:Spells55 "Passive Skill:Spells55") [[3]](/wiki/Passive_Skill:Spells57 "Passive Skill:Spells57") |
| [Spell Damage](/wiki/Spell_Damage_(passive_skill) "Spell Damage (passive skill)") | 8% increased Spell Damage [[1]](/wiki/Passive_Skill:Projectile~spells1 "Passive Skill:Projectile~spells1") [[2]](/wiki/Passive_Skill:Spell~criticals1 "Passive Skill:Spell~criticals1") [[3]](/wiki/Passive_Skill:Spell~criticals2~~ "Passive Skill:Spell~criticals2~~")  ---  10% increased Spell Damage [[10]](/wiki/Passive_Skill:Spells1 "Passive Skill:Spells1") [[11]](/wiki/Passive_Skill:Spells10 "Passive Skill:Spells10") [[12]](/wiki/Passive_Skill:Spells12 "Passive Skill:Spells12") [[13]](/wiki/Passive_Skill:Spells15 "Passive Skill:Spells15") [[14]](/wiki/Passive_Skill:Spells18 "Passive Skill:Spells18") [[15]](/wiki/Passive_Skill:Spells2 "Passive Skill:Spells2") [[16]](/wiki/Passive_Skill:Spells3 "Passive Skill:Spells3") [[17]](/wiki/Passive_Skill:Spells4 "Passive Skill:Spells4") [[18]](/wiki/Passive_Skill:Spells6 "Passive Skill:Spells6")  ---  12% increased Spell Damage while wielding a [Melee](/wiki/Melee "Melee") Weapon [[5]](/wiki/Passive_Skill:Spells16 "Passive Skill:Spells16") [[6]](/wiki/Passive_Skill:Spells19 "Passive Skill:Spells19")  ---  12% increased Spell Damage [[4]](/wiki/Passive_Skill:Spells9 "Passive Skill:Spells9") |
| [Spell Damage and Cast Speed](/wiki/Spell_Damage_and_Cast_Speed/edit?redlink=1 "Spell Damage and Cast Speed (page does not exist)") | 6% increased Spell Damage 2% increased Cast Speed [[1]](/wiki/Passive_Skill:Orb1 "Passive Skill:Orb1") [[2]](/wiki/Passive_Skill:Orb3 "Passive Skill:Orb3") [[3]](/wiki/Passive_Skill:Orb4 "Passive Skill:Orb4") |
| [Spell Damage and Projectile Speed](/wiki/Spell_Damage_and_Projectile_Speed/edit?redlink=1 "Spell Damage and Projectile Speed (page does not exist)") | 8% increased Spell Damage 5% reduced [Projectile](/wiki/Projectile "Projectile") Speed for Spell Skills [[1]](/wiki/Passive_Skill:Projectile~spells2 "Passive Skill:Projectile~spells2")  ---  8% increased Spell Damage 8% increased [Projectile](/wiki/Projectile "Projectile") Speed for Spell Skills [[2]](/wiki/Passive_Skill:Projectile~spells3 "Passive Skill:Projectile~spells3") |
| [Spell Damage on full Energy Shield](/wiki/Spell_Damage_on_full_Energy_Shield/edit?redlink=1 "Spell Damage on full Energy Shield (page does not exist)") | 12% increased Spell Damage while on Full [Energy Shield](/wiki/Energy_Shield "Energy Shield") [[1]](/wiki/Passive_Skill:Focus8 "Passive Skill:Focus8") |
| [Triggered Spell Damage](/wiki/Triggered_Spell_Damage/edit?redlink=1 "Triggered Spell Damage (page does not exist)") | [Triggered](/wiki/Trigger "Trigger") Spells deal 14% increased Spell Damage [[1]](/wiki/Passive_Skill:Triggers6 "Passive Skill:Triggers6") [[2]](/wiki/Passive_Skill:Triggers25~ "Passive Skill:Triggers25~") [[3]](/wiki/Passive_Skill:Triggers24~ "Passive Skill:Triggers24~") [[4]](/wiki/Passive_Skill:Triggers10 "Passive Skill:Triggers10") [[5]](/wiki/Passive_Skill:Triggers1 "Passive Skill:Triggers1")  ---  [Triggered](/wiki/Trigger "Trigger") Spells deal 16% increased Spell Damage [[3]](/wiki/Passive_Skill:Triggers4 "Passive Skill:Triggers4") [[4]](/wiki/Passive_Skill:Triggers2 "Passive Skill:Triggers2") |
| [Arcane Intensity](/wiki/Arcane_Intensity/edit?redlink=1 "Arcane Intensity (page does not exist)") | 3% increased Spell Damage per 100 maximum Mana [[1]](/wiki/Passive_Skill:Mana37 "Passive Skill:Mana37") |
| [Arcane Nature](/wiki/Arcane_Nature/edit?redlink=1 "Arcane Nature (page does not exist)") | 30% increased Spell Damage while you have [Arcane Surge](/wiki/Arcane_Surge "Arcane Surge") 12% increased Area of Effect while you have [Arcane Surge](/wiki/Arcane_Surge "Arcane Surge") [[1]](/wiki/Passive_Skill:Mana~regeneration44~ "Passive Skill:Mana~regeneration44~") |
| [Boon of the Beast](/wiki/Boon_of_the_Beast/edit?redlink=1 "Boon of the Beast (page does not exist)") | When you [Shapeshift](/wiki/Shapeshift "Shapeshift") to Human form, gain 10% increased Spell Damage per second you were [Shapeshifted](/wiki/Shapeshifting "Shapeshifting"), up to a maximum of 80%, for 8 seconds [[1]](/wiki/Passive_Skill:Shapeshifting19 "Passive Skill:Shapeshifting19") |
| [Casting Cascade](/wiki/Casting_Cascade/edit?redlink=1 "Casting Cascade (page does not exist)") | 6% increased Cast Speed for each different Non-Instant Spell you've Cast [Recently](/wiki/Recently "Recently") 15% reduced Spell Damage [[1]](/wiki/Passive_Skill:Cast~speed31 "Passive Skill:Cast~speed31") |
| [Critical Overload](/wiki/Critical_Overload/edit?redlink=1 "Critical Overload (page does not exist)") | 15% increased Spell Damage if you've dealt a [Critical Hit](/wiki/Critical_Hit "Critical Hit") [Recently](/wiki/Recently "Recently") 15% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for Spells [[1]](/wiki/Passive_Skill:Spell~criticals14 "Passive Skill:Spell~criticals14") |
| [Dreamcatcher](/wiki/Dreamcatcher/edit?redlink=1 "Dreamcatcher (page does not exist)") | 75% increased [Energy Shield](/wiki/Energy_Shield "Energy Shield") from Equipped [Focus](/wiki/Focus "Focus") 25% increased Spell Damage while on Full [Energy Shield](/wiki/Energy_Shield "Energy Shield") [[1]](/wiki/Passive_Skill:Focus10 "Passive Skill:Focus10") |
| [Empowering Infusions](/wiki/Empowering_Infusions/edit?redlink=1 "Empowering Infusions (page does not exist)") | 30% increased Spell Damage if you have consumed an [Elemental Infusion](/wiki/Elemental_Infusion "Elemental Infusion") [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Infusion4 "Passive Skill:Infusion4") |
| [Empowering Remains](/wiki/Empowering_Remains/edit?redlink=1 "Empowering Remains (page does not exist)") | 40% increased Spell Damage if one of your [Minions](/wiki/Minion "Minion") has died [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Spells60 "Passive Skill:Spells60") |
| [Enhancing Attacks](/wiki/Enhancing_Attacks/edit?redlink=1 "Enhancing Attacks (page does not exist)") | 12% increased Spell Damage for each different Non-Instant [Attack](/wiki/Attack "Attack") you've used in the past 8 seconds [[1]](/wiki/Passive_Skill:Attacks~and~spells13 "Passive Skill:Attacks~and~spells13") |
| [Invocated Efficiency](/wiki/Invocated_Efficiency/edit?redlink=1 "Invocated Efficiency (page does not exist)") | [Triggered](/wiki/Trigger "Trigger") Spells deal 40% increased Spell Damage 10% increased Mana Cost [Efficiency](/wiki/Efficiency "Efficiency") [[1]](/wiki/Passive_Skill:Triggers17 "Passive Skill:Triggers17") |
| [Lasting Incantations](/wiki/Lasting_Incantations/edit?redlink=1 "Lasting Incantations (page does not exist)") | 20% increased Spell Damage 15% increased Skill Effect Duration [[1]](/wiki/Passive_Skill:Spells31 "Passive Skill:Spells31") |
| [Mystical Rage](/wiki/Mystical_Rage/edit?redlink=1 "Mystical Rage (page does not exist)") | Every [Rage](/wiki/Rage "Rage") also grants 2% increased Spell Damage [[1]](/wiki/Passive_Skill:Rage40 "Passive Skill:Rage40") |
| [Potent Incantation](/wiki/Potent_Incantation/edit?redlink=1 "Potent Incantation (page does not exist)") | 30% increased Spell Damage 5% reduced Cast Speed [[1]](/wiki/Passive_Skill:Spells33 "Passive Skill:Spells33") |
| [Raw Power](/wiki/Raw_Power/edit?redlink=1 "Raw Power (page does not exist)") | 20% increased Spell Damage +10 to [Intelligence](/wiki/Intelligence "Intelligence") [[1]](/wiki/Passive_Skill:Witch~sorceress~notable1 "Passive Skill:Witch~sorceress~notable1") |
| [Sacrificial Blood](/wiki/Sacrificial_Blood/edit?redlink=1 "Sacrificial Blood (page does not exist)") | 40% increased Spell Damage with Spells that cost Life 15% increased Life Cost of Skills [[1]](/wiki/Passive_Skill:Life~costs10 "Passive Skill:Life~costs10") |
| [Spellblade](/wiki/Spellblade/edit?redlink=1 "Spellblade (page does not exist)") | 32% increased Spell Damage while wielding a [Melee](/wiki/Melee "Melee") Weapon +10 to [Dexterity](/wiki/Dexterity "Dexterity") [[1]](/wiki/Passive_Skill:Spells34 "Passive Skill:Spells34") |
| [Turn the Clock Back](/wiki/Turn_the_Clock_Back/edit?redlink=1 "Turn the Clock Back (page does not exist)") | 15% increased Spell Damage 10% reduced [Projectile](/wiki/Projectile "Projectile") Speed for Spell Skills [[1]](/wiki/Passive_Skill:Projectile~spells8 "Passive Skill:Projectile~spells8") |
| [Turn the Clock Forward](/wiki/Turn_the_Clock_Forward/edit?redlink=1 "Turn the Clock Forward (page does not exist)") | 20% increased Spell Damage 15% increased [Projectile](/wiki/Projectile "Projectile") Speed for Spell Skills [[1]](/wiki/Passive_Skill:Projectile~spells9 "Passive Skill:Projectile~spells9") |

### Cast speed

| Name | Stats |
| --- | --- |
| [Cast Speed](/wiki/Cast_Speed "Cast Speed") | 3% increased Cast Speed [[1]](/wiki/Passive_Skill:Cast~speed1 "Passive Skill:Cast~speed1") [[2]](/wiki/Passive_Skill:Cast~speed10 "Passive Skill:Cast~speed10") [[3]](/wiki/Passive_Skill:Cast~speed11 "Passive Skill:Cast~speed11") [[4]](/wiki/Passive_Skill:Cast~speed13 "Passive Skill:Cast~speed13") [[5]](/wiki/Passive_Skill:Cast~speed14 "Passive Skill:Cast~speed14") [[6]](/wiki/Passive_Skill:Cast~speed15~ "Passive Skill:Cast~speed15~") [[7]](/wiki/Passive_Skill:Cast~speed16 "Passive Skill:Cast~speed16") [[8]](/wiki/Passive_Skill:Cast~speed18 "Passive Skill:Cast~speed18") [[9]](/wiki/Passive_Skill:Cast~speed2 "Passive Skill:Cast~speed2") [[10]](/wiki/Passive_Skill:Cast~speed24 "Passive Skill:Cast~speed24") [[11]](/wiki/Passive_Skill:Cast~speed25 "Passive Skill:Cast~speed25") [[12]](/wiki/Passive_Skill:Cast~speed26 "Passive Skill:Cast~speed26") [[13]](/wiki/Passive_Skill:Cast~speed27 "Passive Skill:Cast~speed27") [[14]](/wiki/Passive_Skill:Cast~speed28~~ "Passive Skill:Cast~speed28~~") [[15]](/wiki/Passive_Skill:Cast~speed29 "Passive Skill:Cast~speed29") [[16]](/wiki/Passive_Skill:Cast~speed3 "Passive Skill:Cast~speed3") [[17]](/wiki/Passive_Skill:Cast~speed4 "Passive Skill:Cast~speed4") [[18]](/wiki/Passive_Skill:Cast~speed8 "Passive Skill:Cast~speed8") [[19]](/wiki/Passive_Skill:Spells17 "Passive Skill:Spells17") |
| [Elemental](/wiki/Elemental "Elemental") | 3% increased [Attack](/wiki/Attack "Attack") and Cast Speed with Elemental Skills [[1]](/wiki/Passive_Skill:Elemental10 "Passive Skill:Elemental10") |
| [Lightning Skill Speed](/wiki/Lightning_Skill_Speed/edit?redlink=1 "Lightning Skill Speed (page does not exist)") | 3% increased [Attack](/wiki/Attack "Attack") and Cast Speed with [Lightning](/wiki/Lightning "Lightning") Skills [[1]](/wiki/Passive_Skill:Lightning10 "Passive Skill:Lightning10") [[2]](/wiki/Passive_Skill:Lightning16 "Passive Skill:Lightning16") [[3]](/wiki/Passive_Skill:Lightning7 "Passive Skill:Lightning7") [[4]](/wiki/Passive_Skill:Lightning9 "Passive Skill:Lightning9") |
| [Minion Attack and Cast Speed](/wiki/Minion_Attack_and_Cast_Speed/edit?redlink=1 "Minion Attack and Cast Speed (page does not exist)") | [Minions](/wiki/Minion "Minion") have 3% increased [Attack](/wiki/Attack "Attack") and Cast Speed [[1]](/wiki/Passive_Skill:Minion~offence17 "Passive Skill:Minion~offence17") [[2]](/wiki/Passive_Skill:Minion~offence18 "Passive Skill:Minion~offence18") [[3]](/wiki/Passive_Skill:Minion~offence19 "Passive Skill:Minion~offence19")  ---  [Minions](/wiki/Minion "Minion") have 5% increased [Attack](/wiki/Attack "Attack") and Cast Speed [[3]](/wiki/Passive_Skill:Minion~offence46 "Passive Skill:Minion~offence46") [[4]](/wiki/Passive_Skill:Minion~offence48 "Passive Skill:Minion~offence48") |
| [Speed with Elemental Skills](/wiki/Speed_with_Elemental_Skills/edit?redlink=1 "Speed with Elemental Skills (page does not exist)") | 3% increased [Attack](/wiki/Attack "Attack") and Cast Speed with Elemental Skills [[1]](/wiki/Passive_Skill:Elemental6 "Passive Skill:Elemental6") [[2]](/wiki/Passive_Skill:Elemental7 "Passive Skill:Elemental7") |
| [Spell Damage and Cast Speed](/wiki/Spell_Damage_and_Cast_Speed/edit?redlink=1 "Spell Damage and Cast Speed (page does not exist)") | 6% increased Spell Damage 2% increased Cast Speed [[1]](/wiki/Passive_Skill:Orb1 "Passive Skill:Orb1") [[2]](/wiki/Passive_Skill:Orb3 "Passive Skill:Orb3") [[3]](/wiki/Passive_Skill:Orb4 "Passive Skill:Orb4") |
| [Totem Cast and Attack Speed](/wiki/Totem_Cast_and_Attack_Speed/edit?redlink=1 "Totem Cast and Attack Speed (page does not exist)") | Spells Cast by [Totems](/wiki/Totem "Totem") have 4% increased Cast Speed [Attacks](/wiki/Attack "Attack") used by Totems have 4% increased [Attack](/wiki/Attack "Attack") Speed [[1]](/wiki/Passive_Skill:Totems30 "Passive Skill:Totems30") [[2]](/wiki/Passive_Skill:Totems29 "Passive Skill:Totems29") |
| [Totem Cast Speed](/wiki/Totem_Cast_Speed/edit?redlink=1 "Totem Cast Speed (page does not exist)") | Spells Cast by [Totems](/wiki/Totem "Totem") have 4% increased Cast Speed [[1]](/wiki/Passive_Skill:Totems32 "Passive Skill:Totems32") [[2]](/wiki/Passive_Skill:Totems31 "Passive Skill:Totems31") |
| [Totem Placement Speed](/wiki/Totem_Placement_Speed/edit?redlink=1 "Totem Placement Speed (page does not exist)") | 20% increased [Totem](/wiki/Totem "Totem") Placement speed [[1]](/wiki/Passive_Skill:Totems42 "Passive Skill:Totems42") [[2]](/wiki/Passive_Skill:Totems41 "Passive Skill:Totems41") [[3]](/wiki/Passive_Skill:Totems38 "Passive Skill:Totems38") [[4]](/wiki/Passive_Skill:Totems26 "Passive Skill:Totems26") [[5]](/wiki/Passive_Skill:Totems25 "Passive Skill:Totems25") [[6]](/wiki/Passive_Skill:Totems24 "Passive Skill:Totems24") [[7]](/wiki/Passive_Skill:Totems23 "Passive Skill:Totems23") [[8]](/wiki/Passive_Skill:Totems22 "Passive Skill:Totems22") [[9]](/wiki/Passive_Skill:Totems11 "Passive Skill:Totems11") |
| [Ancestral Alacrity](/wiki/Ancestral_Alacrity/edit?redlink=1 "Ancestral Alacrity (page does not exist)") | 30% increased [Totem](/wiki/Totem "Totem") Placement speed 8% increased [Attack](/wiki/Attack "Attack") and Cast Speed if you've summoned a [Totem](/wiki/Totem "Totem") [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Totems28 "Passive Skill:Totems28") |
| [Ancestral Conduits](/wiki/Ancestral_Conduits/edit?redlink=1 "Ancestral Conduits (page does not exist)") | 12% increased [Attack](/wiki/Attack "Attack") and Cast Speed if you've summoned a [Totem](/wiki/Totem "Totem") [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Totems33~ "Passive Skill:Totems33~") |
| [Ancestral Reach](/wiki/Ancestral_Reach/edit?redlink=1 "Ancestral Reach (page does not exist)") | 25% increased [Totem](/wiki/Totem "Totem") Placement speed 50% increased [Totem](/wiki/Totem "Totem") Placement range [[1]](/wiki/Passive_Skill:Totems27 "Passive Skill:Totems27") |
| [Carved Earth](/wiki/Carved_Earth/edit?redlink=1 "Carved Earth (page does not exist)") | 20% increased [Totem](/wiki/Totem "Totem") Damage 6% increased [Attack](/wiki/Attack "Attack") and Cast Speed if you've summoned a [Totem](/wiki/Totem "Totem") [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Totems8 "Passive Skill:Totems8") |
| [Casting Cascade](/wiki/Casting_Cascade/edit?redlink=1 "Casting Cascade (page does not exist)") | 6% increased Cast Speed for each different Non-Instant Spell you've Cast [Recently](/wiki/Recently "Recently") 15% reduced Spell Damage [[1]](/wiki/Passive_Skill:Cast~speed31 "Passive Skill:Cast~speed31") |
| [Effervescent](/wiki/Effervescent/edit?redlink=1 "Effervescent (page does not exist)") | 4% increased Cast Speed for each different Non-Instant Spell you've Cast [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Cast~speed32 "Passive Skill:Cast~speed32") |
| [Equilibrium](/wiki/Equilibrium/edit?redlink=1 "Equilibrium (page does not exist)") | 30% increased [Attack](/wiki/Attack "Attack") Damage if you've Cast a Spell [Recently](/wiki/Recently "Recently") 10% increased Cast Speed if you've Attacked [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Attacks~and~spells20 "Passive Skill:Attacks~and~spells20") |
| [Erraticism](/wiki/Erraticism/edit?redlink=1 "Erraticism (page does not exist)") | 16% increased Cast Speed if you've dealt a [Critical Hit](/wiki/Critical_Hit "Critical Hit") [Recently](/wiki/Recently "Recently") 10% reduced [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") [[1]](/wiki/Passive_Skill:Cast~speed37 "Passive Skill:Cast~speed37") |
| [Final Barrage](/wiki/Final_Barrage/edit?redlink=1 "Final Barrage (page does not exist)") | 10% reduced Cast Speed when on Full Life 20% increased Cast Speed when on [Low Life](/wiki/Low_Life "Low Life") [[1]](/wiki/Passive_Skill:Cast~speed30 "Passive Skill:Cast~speed30") |
| [Flow Like Water](/wiki/Flow_Like_Water/edit?redlink=1 "Flow Like Water (page does not exist)") | 8% increased [Attack](/wiki/Attack "Attack") and Cast Speed +5 to [Dexterity](/wiki/Dexterity "Dexterity") and [Intelligence](/wiki/Intelligence "Intelligence") [[1]](/wiki/Passive_Skill:Shadow~monk~notable1 "Passive Skill:Shadow~monk~notable1") |
| [Full Recovery](/wiki/Full_Recovery/edit?redlink=1 "Full Recovery (page does not exist)") | 15% increased Mana Regeneration Rate 15% increased Life Regeneration rate 12% increased Cast Speed while on Full Mana [[1]](/wiki/Passive_Skill:Mana~regeneration18 "Passive Skill:Mana~regeneration18") |
| [General Electric](/wiki/General_Electric/edit?redlink=1 "General Electric (page does not exist)") | 40% increased chance to [Shock](/wiki/Shock "Shock") 5% increased [Attack](/wiki/Attack "Attack") and Cast Speed with [Lightning](/wiki/Lightning "Lightning") Skills [[1]](/wiki/Passive_Skill:Shock12 "Passive Skill:Shock12") |
| [Hastening Barrier](/wiki/Hastening_Barrier/edit?redlink=1 "Hastening Barrier (page does not exist)") | 10% increased Cast Speed when on Full Life 5% increased Cast Speed [[1]](/wiki/Passive_Skill:Cast~speed40 "Passive Skill:Cast~speed40") |
| [Lightning Quick](/wiki/Lightning_Quick/edit?redlink=1 "Lightning Quick (page does not exist)") | 14% increased [Lightning](/wiki/Lightning "Lightning") Damage 8% increased [Attack](/wiki/Attack "Attack") and Cast Speed with [Lightning](/wiki/Lightning "Lightning") Skills [[1]](/wiki/Passive_Skill:Lightning39 "Passive Skill:Lightning39") |
| [Mental Alacrity](/wiki/Mental_Alacrity/edit?redlink=1 "Mental Alacrity (page does not exist)") | 5% increased Cast Speed 15% increased Mana Regeneration Rate +10 to [Intelligence](/wiki/Intelligence "Intelligence") [[1]](/wiki/Passive_Skill:Cast~speed38 "Passive Skill:Cast~speed38") |
| [Overzealous](/wiki/Overzealous/edit?redlink=1 "Overzealous (page does not exist)") | 16% increased Cast Speed 15% increased Mana Cost of Skills [[1]](/wiki/Passive_Skill:Cast~speed33 "Passive Skill:Cast~speed33") |
| [Potent Incantation](/wiki/Potent_Incantation/edit?redlink=1 "Potent Incantation (page does not exist)") | 30% increased Spell Damage 5% reduced Cast Speed [[1]](/wiki/Passive_Skill:Spells33 "Passive Skill:Spells33") |
| [Practiced Signs](/wiki/Practiced_Signs/edit?redlink=1 "Practiced Signs (page does not exist)") | 6% increased Cast Speed [[1]](/wiki/Passive_Skill:Cast~speed36~ "Passive Skill:Cast~speed36~") |
| [Relentless Fallen](/wiki/Relentless_Fallen/edit?redlink=1 "Relentless Fallen (page does not exist)") | [Minions](/wiki/Minion "Minion") have 8% increased [Attack](/wiki/Attack "Attack") and Cast Speed [Minions](/wiki/Minion "Minion") have 20% increased Movement Speed 3% increased Movement Speed [[1]](/wiki/Passive_Skill:Minion~offence21~ "Passive Skill:Minion~offence21~") |
| [Spell Haste](/wiki/Spell_Haste/edit?redlink=1 "Spell Haste (page does not exist)") | 8% increased Cast Speed 15% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") [[1]](/wiki/Passive_Skill:Cast~speed35 "Passive Skill:Cast~speed35") |
| [Spiral into Mania](/wiki/Spiral_into_Mania/edit?redlink=1 "Spiral into Mania (page does not exist)") | 10% increased Cast Speed +13% to [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance") [[1]](/wiki/Passive_Skill:Cast~speed34 "Passive Skill:Cast~speed34") |
| [Sudden Escalation](/wiki/Sudden_Escalation/edit?redlink=1 "Sudden Escalation (page does not exist)") | 16% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for Spells 8% increased Cast Speed if you've dealt a [Critical Hit](/wiki/Critical_Hit "Critical Hit") [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Spell~criticals11~ "Passive Skill:Spell~criticals11~") |
| [Supportive Ancestors](/wiki/Supportive_Ancestors/edit?redlink=1 "Supportive Ancestors (page does not exist)") | 25% increased Damage while you have a [Totem](/wiki/Totem "Totem") Spells Cast by [Totems](/wiki/Totem "Totem") have 3% increased Cast Speed per Summoned [Totem](/wiki/Totem "Totem") [Attacks](/wiki/Attack "Attack") used by [Totems](/wiki/Totem "Totem") have 3% increased [Attack](/wiki/Attack "Attack") Speed per Summoned [Totem](/wiki/Totem "Totem") [[1]](/wiki/Passive_Skill:Totems7 "Passive Skill:Totems7") |
| [Wellspring](/wiki/Wellspring/edit?redlink=1 "Wellspring (page does not exist)") | 30% increased Mana Recovery from [Flasks](/wiki/Flask "Flask") 8% increased [Attack](/wiki/Attack "Attack") and Cast Speed during Effect of any Mana [Flask](/wiki/Flask "Flask") [[1]](/wiki/Passive_Skill:Mana~flasks11 "Passive Skill:Mana~flasks11") |

### Spell area damage

| Name | Stats |
| --- | --- |
| [Area Damage](/wiki/Area_Damage/edit?redlink=1 "Area Damage (page does not exist)") | 10% increased Spell Area Damage [[1]](/wiki/Passive_Skill:Area~spells1 "Passive Skill:Area~spells1") [[2]](/wiki/Passive_Skill:Area~spells16 "Passive Skill:Area~spells16") |
| [Spell Area Damage](/wiki/Spell_Area_Damage/edit?redlink=1 "Spell Area Damage (page does not exist)") | 10% increased Spell Area Damage [[1]](/wiki/Passive_Skill:Area~spells12 "Passive Skill:Area~spells12") [[2]](/wiki/Passive_Skill:Area~spells13~ "Passive Skill:Area~spells13~") [[3]](/wiki/Passive_Skill:Area~spells7 "Passive Skill:Area~spells7") |
| [Repulsion](/wiki/Repulsion/edit?redlink=1 "Repulsion (page does not exist)") | 20% increased Spell Area Damage Area Skills have 20% chance to [Knock Enemies Back](/wiki/Knockback "Knockback") on [Hit](/wiki/Hit "Hit") [[1]](/wiki/Passive_Skill:Area~spells25 "Passive Skill:Area~spells25") |
| [Roil](/wiki/Roil/edit?redlink=1 "Roil (page does not exist)") | Spell Skills have 25% increased Area of Effect 10% reduced Spell Area Damage [[1]](/wiki/Passive_Skill:Area~spells24 "Passive Skill:Area~spells24") |
| [Ruin](/wiki/Ruin/edit?redlink=1 "Ruin (page does not exist)") | Spell Skills have 10% reduced Area of Effect 35% increased Spell Area Damage [[1]](/wiki/Passive_Skill:Area~spells28 "Passive Skill:Area~spells28") |

### Spell area of effect

| Name | Stats |
| --- | --- |
| [Spell Area of Effect](/wiki/Spell_Area_of_Effect/edit?redlink=1 "Spell Area of Effect (page does not exist)") | Spell Skills have 6% increased Area of Effect [[1]](/wiki/Passive_Skill:Area~spells11 "Passive Skill:Area~spells11") [[2]](/wiki/Passive_Skill:Area~spells2 "Passive Skill:Area~spells2") [[3]](/wiki/Passive_Skill:Area~spells3 "Passive Skill:Area~spells3") [[4]](/wiki/Passive_Skill:Area~spells4~ "Passive Skill:Area~spells4~") [[5]](/wiki/Passive_Skill:Area~spells6 "Passive Skill:Area~spells6") [[6]](/wiki/Passive_Skill:Area~spells8~ "Passive Skill:Area~spells8~") [[7]](/wiki/Passive_Skill:Area~spells9 "Passive Skill:Area~spells9") |
| [Reverberation](/wiki/Reverberation/edit?redlink=1 "Reverberation (page does not exist)") | Spell Skills have 15% increased Area of Effect [[1]](/wiki/Passive_Skill:Area~spells27 "Passive Skill:Area~spells27") |
| [Roil](/wiki/Roil/edit?redlink=1 "Roil (page does not exist)") | Spell Skills have 25% increased Area of Effect 10% reduced Spell Area Damage [[1]](/wiki/Passive_Skill:Area~spells24 "Passive Skill:Area~spells24") |
| [Ruin](/wiki/Ruin/edit?redlink=1 "Ruin (page does not exist)") | Spell Skills have 10% reduced Area of Effect 35% increased Spell Area Damage [[1]](/wiki/Passive_Skill:Area~spells28 "Passive Skill:Area~spells28") |

### Spell critical hit chance

| Name | Stats |
| --- | --- |
| [Spell Critical Chance](/wiki/Spell_Critical_Chance/edit?redlink=1 "Spell Critical Chance (page does not exist)") | 10% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for Spells [[1]](/wiki/Passive_Skill:Physical15 "Passive Skill:Physical15") [[2]](/wiki/Passive_Skill:Physical18 "Passive Skill:Physical18") [[3]](/wiki/Passive_Skill:Physical~witch11 "Passive Skill:Physical~witch11") [[4]](/wiki/Passive_Skill:Physical~witch7 "Passive Skill:Physical~witch7") [[5]](/wiki/Passive_Skill:Spell~criticals10 "Passive Skill:Spell~criticals10") [[6]](/wiki/Passive_Skill:Spell~criticals12~ "Passive Skill:Spell~criticals12~") [[7]](/wiki/Passive_Skill:Spell~criticals13 "Passive Skill:Spell~criticals13") [[8]](/wiki/Passive_Skill:Spell~criticals16 "Passive Skill:Spell~criticals16") [[9]](/wiki/Passive_Skill:Spell~criticals9 "Passive Skill:Spell~criticals9") |
| [Spell Critical Chance and Critical Ailment Effect](/wiki/Spell_Critical_Chance_and_Critical_Ailment_Effect/edit?redlink=1 "Spell Critical Chance and Critical Ailment Effect (page does not exist)") | 10% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for Spells 15% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") you inflict with [Critical Hits](/wiki/Critical_Hit "Critical Hit") [[1]](/wiki/Passive_Skill:Physical17 "Passive Skill:Physical17") |
| [Controlling Magic](/wiki/Controlling_Magic/edit?redlink=1 "Controlling Magic (page does not exist)") | [Hits](/wiki/Hit "Hit") have 25% reduced [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance against you 25% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for Spells [[1]](/wiki/Passive_Skill:Spell~criticals15 "Passive Skill:Spell~criticals15") |
| [Critical Overload](/wiki/Critical_Overload/edit?redlink=1 "Critical Overload (page does not exist)") | 15% increased Spell Damage if you've dealt a [Critical Hit](/wiki/Critical_Hit "Critical Hit") [Recently](/wiki/Recently "Recently") 15% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for Spells [[1]](/wiki/Passive_Skill:Spell~criticals14 "Passive Skill:Spell~criticals14") |
| [Shredding Force](/wiki/Shredding_Force/edit?redlink=1 "Shredding Force (page does not exist)") | 15% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for Spells 15% increased [Critical Spell Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus") 15% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") you inflict with [Critical Hits](/wiki/Critical_Hit "Critical Hit") [[1]](/wiki/Passive_Skill:Physical34 "Passive Skill:Physical34") |
| [Sudden Escalation](/wiki/Sudden_Escalation/edit?redlink=1 "Sudden Escalation (page does not exist)") | 16% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for Spells 8% increased Cast Speed if you've dealt a [Critical Hit](/wiki/Critical_Hit "Critical Hit") [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Spell~criticals11~ "Passive Skill:Spell~criticals11~") |

### Spell critical damage bonus

| Name | Stats |
| --- | --- |
| [Spell Critical Damage](/wiki/Spell_Critical_Damage/edit?redlink=1 "Spell Critical Damage (page does not exist)") | 15% increased [Critical Spell Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus") [[1]](/wiki/Passive_Skill:Criticals32~ "Passive Skill:Criticals32~") [[2]](/wiki/Passive_Skill:Criticals34 "Passive Skill:Criticals34") [[3]](/wiki/Passive_Skill:Spell~criticals17~ "Passive Skill:Spell~criticals17~") [[4]](/wiki/Passive_Skill:Spell~criticals18 "Passive Skill:Spell~criticals18") [[5]](/wiki/Passive_Skill:Spell~criticals3 "Passive Skill:Spell~criticals3") [[6]](/wiki/Passive_Skill:Spell~criticals4 "Passive Skill:Spell~criticals4") [[7]](/wiki/Passive_Skill:Spell~criticals5 "Passive Skill:Spell~criticals5") [[8]](/wiki/Passive_Skill:Spell~criticals6 "Passive Skill:Spell~criticals6") [[9]](/wiki/Passive_Skill:Spell~criticals7 "Passive Skill:Spell~criticals7") [[10]](/wiki/Passive_Skill:Spell~criticals8 "Passive Skill:Spell~criticals8") |
| [Shredding Force](/wiki/Shredding_Force/edit?redlink=1 "Shredding Force (page does not exist)") | 15% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for Spells 15% increased [Critical Spell Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus") 15% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") you inflict with [Critical Hits](/wiki/Critical_Hit "Critical Hit") [[1]](/wiki/Passive_Skill:Physical34 "Passive Skill:Physical34") |

### Miscellany

| Name | Stats |
| --- | --- |
| [Additional Spell Projectiles](/wiki/Additional_Spell_Projectiles/edit?redlink=1 "Additional Spell Projectiles (page does not exist)") | 4% chance for Spell Skills to fire 2 additional [Projectiles](/wiki/Projectile "Projectile") [[1]](/wiki/Passive_Skill:Projectile~spells4 "Passive Skill:Projectile~spells4") [[2]](/wiki/Passive_Skill:Projectile~spells5 "Passive Skill:Projectile~spells5")  ---  6% chance for Spell Skills to fire 2 additional [Projectiles](/wiki/Projectile "Projectile") [[6]](/wiki/Passive_Skill:Projectile~spells6 "Passive Skill:Projectile~spells6") [[7]](/wiki/Passive_Skill:Projectile~spells7 "Passive Skill:Projectile~spells7") [[8]](/wiki/Passive_Skill:Spells13~ "Passive Skill:Spells13~") [[9]](/wiki/Passive_Skill:Spells14 "Passive Skill:Spells14") [[10]](/wiki/Passive_Skill:Spells21~ "Passive Skill:Spells21~") |
| [Armour Break](/wiki/Armour_Break "Armour Break") | [Break](/wiki/Break "Break") [Armour](/wiki/Armour "Armour") on [Critical Hit](/wiki/Critical_Hit "Critical Hit") with Spells equal to 5% of [Physical](/wiki/Physical "Physical") Damage dealt [[1]](/wiki/Passive_Skill:Physical20 "Passive Skill:Physical20") [[2]](/wiki/Passive_Skill:Physical21 "Passive Skill:Physical21") |
| [Impale Chance](/wiki/Impale_Chance/edit?redlink=1 "Impale Chance (page does not exist)") | 15% chance to [Impale](/wiki/Impale "Impale") on Spell [Hit](/wiki/Hit "Hit") [[1]](/wiki/Passive_Skill:Physical7 "Passive Skill:Physical7") [[2]](/wiki/Passive_Skill:Physical8 "Passive Skill:Physical8") |
| [Invocation Critical Damage](/wiki/Invocation_Critical_Damage/edit?redlink=1 "Invocation Critical Damage (page does not exist)") | [Invocation](/wiki/Invocation "Invocation") Spells have 20% increased [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus") [[1]](/wiki/Passive_Skill:Triggers27 "Passive Skill:Triggers27") |
| [Invocation Critical Hits](/wiki/Invocation_Critical_Hits/edit?redlink=1 "Invocation Critical Hits (page does not exist)") | [Invocated](/wiki/Invocation "Invocation") Spells have 12% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") [[1]](/wiki/Passive_Skill:Triggers29 "Passive Skill:Triggers29") |
| [Life Spell Costs](/wiki/Life_Spell_Costs/edit?redlink=1 "Life Spell Costs (page does not exist)") | 15% of Spell Mana Cost [Converted](/wiki/Stat_conversion "Stat conversion") to Life Cost [[1]](/wiki/Passive_Skill:Life~costs5 "Passive Skill:Life~costs5") |
| [Life Spell Damage and Costs](/wiki/Life_Spell_Damage_and_Costs/edit?redlink=1 "Life Spell Damage and Costs (page does not exist)") | 6% increased Spell Damage with Spells that cost Life 8% of Spell Mana Cost [Converted](/wiki/Stat_conversion "Stat conversion") to Life Cost [[1]](/wiki/Passive_Skill:Life~costs4 "Passive Skill:Life~costs4") |
| [Spell Damage and Projectile Speed](/wiki/Spell_Damage_and_Projectile_Speed/edit?redlink=1 "Spell Damage and Projectile Speed (page does not exist)") | 8% increased Spell Damage 5% reduced [Projectile](/wiki/Projectile "Projectile") Speed for Spell Skills [[1]](/wiki/Passive_Skill:Projectile~spells2 "Passive Skill:Projectile~spells2")  ---  8% increased Spell Damage 8% increased [Projectile](/wiki/Projectile "Projectile") Speed for Spell Skills [[2]](/wiki/Passive_Skill:Projectile~spells3 "Passive Skill:Projectile~spells3") |
| [Spell Hinder](/wiki/Spell_Hinder/edit?redlink=1 "Spell Hinder (page does not exist)") | 10% chance to [Hinder](/wiki/Hinder "Hinder") Enemies on Hit with Spells [[1]](/wiki/Passive_Skill:Spells8 "Passive Skill:Spells8") |
| [Blood Transfusion](/wiki/Blood_Transfusion/edit?redlink=1 "Blood Transfusion (page does not exist)") | 25% of Spell Mana Cost [Converted](/wiki/Stat_conversion "Stat conversion") to Life Cost 25% increased Life Regeneration rate [[1]](/wiki/Passive_Skill:Life~costs9 "Passive Skill:Life~costs9") |
| [Bone Chains](/wiki/Bone_Chains/edit?redlink=1 "Bone Chains (page does not exist)") | [Physical](/wiki/Physical "Physical") Spell [Critical](/wiki/Critical "Critical") [Hits](/wiki/Hit "Hit") build [Pin](/wiki/Pinned "Pinned") [[1]](/wiki/Passive_Skill:Physical~witch12 "Passive Skill:Physical~witch12") |
| [Cut to the Bone](/wiki/Cut_to_the_Bone/edit?redlink=1 "Cut to the Bone (page does not exist)") | [Break](/wiki/Break "Break") [Armour](/wiki/Armour "Armour") on [Critical Hit](/wiki/Critical_Hit "Critical Hit") with Spells equal to 10% of [Physical](/wiki/Physical "Physical") Damage dealt 20% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Impales](/wiki/Impale "Impale") inflicted with Spells 20% increased [Physical](/wiki/Physical "Physical") Damage [[1]](/wiki/Passive_Skill:Physical31 "Passive Skill:Physical31") |
| [Deadly Invocations](/wiki/Deadly_Invocations/edit?redlink=1 "Deadly Invocations (page does not exist)") | [Invocation](/wiki/Invocation "Invocation") Spells have 50% increased [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus") [[1]](/wiki/Passive_Skill:Triggers30 "Passive Skill:Triggers30") |
| [Echoing Pulse](/wiki/Echoing_Pulse/edit?redlink=1 "Echoing Pulse (page does not exist)") | Final Repeat of Spells has 30% increased Area of Effect [[1]](/wiki/Passive_Skill:Area~spells26 "Passive Skill:Area~spells26") |
| [Emboldening Casts](/wiki/Emboldening_Casts/edit?redlink=1 "Emboldening Casts (page does not exist)") | 12% increased [Attack](/wiki/Attack "Attack") Damage for each different Non-Instant Spell you've used in the past 8 seconds [[1]](/wiki/Passive_Skill:Attacks~and~spells12 "Passive Skill:Attacks~and~spells12") |
| [Invocated Echoes](/wiki/Invocated_Echoes/edit?redlink=1 "Invocated Echoes (page does not exist)") | [Invocated](/wiki/Invocation "Invocation") Spells have 40% chance to consume half as much [Energy](/wiki/Energy "Energy") [[1]](/wiki/Passive_Skill:Triggers20 "Passive Skill:Triggers20") |
| [Precise Invocations](/wiki/Precise_Invocations/edit?redlink=1 "Precise Invocations (page does not exist)") | [Invocated](/wiki/Invocation "Invocation") Spells have 30% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") [[1]](/wiki/Passive_Skill:Triggers28 "Passive Skill:Triggers28") |
| [Psychic Fragmentation](/wiki/Psychic_Fragmentation/edit?redlink=1 "Psychic Fragmentation (page does not exist)") | 12% chance for Spell Skills to fire 2 additional [Projectiles](/wiki/Projectile "Projectile") [[1]](/wiki/Passive_Skill:Projectile~spells10 "Passive Skill:Projectile~spells10") |
| [Right Hand of Darkness](/wiki/Right_Hand_of_Darkness/edit?redlink=1 "Right Hand of Darkness (page does not exist)") | [Minions](/wiki/Minion "Minion") have 20% increased Area of Effect [Minions](/wiki/Minion "Minion") have 10% chance to inflict [Withered](/wiki/Withered "Withered") on [Hit](/wiki/Hit "Hit") Spells [Gain](/wiki/Gain "Gain") 5% of Damage as extra [Chaos](/wiki/Chaos "Chaos") Damage [[1]](/wiki/Passive_Skill:Minion~offence28 "Passive Skill:Minion~offence28") |
| [Turn the Clock Back](/wiki/Turn_the_Clock_Back/edit?redlink=1 "Turn the Clock Back (page does not exist)") | 15% increased Spell Damage 10% reduced [Projectile](/wiki/Projectile "Projectile") Speed for Spell Skills [[1]](/wiki/Passive_Skill:Projectile~spells8 "Passive Skill:Projectile~spells8") |
| [Turn the Clock Forward](/wiki/Turn_the_Clock_Forward/edit?redlink=1 "Turn the Clock Forward (page does not exist)") | 20% increased Spell Damage 15% increased [Projectile](/wiki/Projectile "Projectile") Speed for Spell Skills [[1]](/wiki/Passive_Skill:Projectile~spells9 "Passive Skill:Projectile~spells9") |
| [Wasting Casts](/wiki/Wasting_Casts/edit?redlink=1 "Wasting Casts (page does not exist)") | 15% chance to [Hinder](/wiki/Hinder "Hinder") Enemies on Hit with Spells 25% increased Damage with [Hits](/wiki/Hit "Hit") against [Hindered](/wiki/Hinder "Hinder") Enemies [[1]](/wiki/Passive_Skill:Spells30 "Passive Skill:Spells30") |

### Paths Not Taken passive skills

The following passive skills are exclusive the [Oracle](/wiki/Oracle "Oracle") with [The Unseen Path](/wiki/The_Unseen_Path "The Unseen Path") allocated:

| Name | Stats |
| --- | --- |
| [Ally Attack and Cast Speed](/wiki/Ally_Attack_and_Cast_Speed/edit?redlink=1 "Ally Attack and Cast Speed (page does not exist)") | 3% reduced [Skill Speed](/wiki/Skill_Speed "Skill Speed") [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") have 6% increased [Attack](/wiki/Attack "Attack") Speed [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") have 6% increased Cast Speed [[1]](/wiki/Passive_Skill:Oracle~self~sacrificing3 "Passive Skill:Oracle~self~sacrificing3") [[2]](/wiki/Passive_Skill:Oracle~self~sacrificing4 "Passive Skill:Oracle~self~sacrificing4") |
| [Chance to Poison and Spell Damage](/wiki/Chance_to_Poison_and_Spell_Damage/edit?redlink=1 "Chance to Poison and Spell Damage (page does not exist)") | 8% chance to [Poison](/wiki/Poison "Poison") on [Hit](/wiki/Hit "Hit") 12% increased Spell Damage [[1]](/wiki/Passive_Skill:Oracle~spell~poison1~ "Passive Skill:Oracle~spell~poison1~") [[2]](/wiki/Passive_Skill:Oracle~spell~poison2 "Passive Skill:Oracle~spell~poison2") [[3]](/wiki/Passive_Skill:Oracle~spell~poison3 "Passive Skill:Oracle~spell~poison3") |
| [Impale Chance](/wiki/Impale_Chance/edit?redlink=1 "Impale Chance (page does not exist)") | 30% chance to [Impale](/wiki/Impale "Impale") on Spell [Hit](/wiki/Hit "Hit") [[1]](/wiki/Passive_Skill:Oracle~duration~physical7 "Passive Skill:Oracle~duration~physical7") |
| [Strength and Spell Damage](/wiki/Strength_and_Spell_Damage/edit?redlink=1 "Strength and Spell Damage (page does not exist)") | 10% increased Spell Damage +10 to [Strength](/wiki/Strength "Strength") [[1]](/wiki/Passive_Skill:Oracle~strength~spell1~ "Passive Skill:Oracle~strength~spell1~") [[2]](/wiki/Passive_Skill:Oracle~strength~spell2 "Passive Skill:Oracle~strength~spell2") [[3]](/wiki/Passive_Skill:Oracle~strength~spell3 "Passive Skill:Oracle~strength~spell3") |
| [Totem Cast and Attack Speed](/wiki/Totem_Cast_and_Attack_Speed/edit?redlink=1 "Totem Cast and Attack Speed (page does not exist)") | Spells Cast by [Totems](/wiki/Totem "Totem") have 4% increased Cast Speed [Attacks](/wiki/Attack "Attack") used by Totems have 4% increased [Attack](/wiki/Attack "Attack") Speed [[1]](/wiki/Passive_Skill:Oracle~totems1 "Passive Skill:Oracle~totems1") [[2]](/wiki/Passive_Skill:Oracle~totems2 "Passive Skill:Oracle~totems2") |
| [Totem Cast and Attack Speed and Elemental Resistance](/wiki/Totem_Cast_and_Attack_Speed_and_Elemental_Resistance/edit?redlink=1 "Totem Cast and Attack Speed and Elemental Resistance (page does not exist)") | Spells Cast by [Totems](/wiki/Totem "Totem") have 2% increased Cast Speed [Attacks](/wiki/Attack "Attack") used by Totems have 2% increased [Attack](/wiki/Attack "Attack") Speed [Totems](/wiki/Totem "Totem") gain +1% to all [Maximum Elemental Resistances](/wiki/Maximum_Resistance "Maximum Resistance") [[1]](/wiki/Passive_Skill:Oracle~totems9 "Passive Skill:Oracle~totems9") |
| [Totem Placement Speed](/wiki/Totem_Placement_Speed/edit?redlink=1 "Totem Placement Speed (page does not exist)") | 30% increased [Totem](/wiki/Totem "Totem") Placement speed [[1]](/wiki/Passive_Skill:Oracle~totems6 "Passive Skill:Oracle~totems6") |
| [Mentorship](/wiki/Mentorship "Mentorship") | [Minions](/wiki/Minion "Minion") deal 100% increased Damage with [Command](/wiki/Command "Command") Skills Minions have 15% reduced [Attack](/wiki/Attack "Attack") Speed Minions have 15% reduced Cast Speed [[1]](/wiki/Passive_Skill:Oracle~solo~commander3 "Passive Skill:Oracle~solo~commander3") |
| [Night's Bite](/wiki/Night%27s_Bite "Night's Bite") | Spells [Gain](/wiki/Gain "Gain") 12% of Damage as extra [Chaos](/wiki/Chaos "Chaos") Damage [[1]](/wiki/Passive_Skill:Oracle~spell~poison4 "Passive Skill:Oracle~spell~poison4") |
| [Powerful Casting](/wiki/Powerful_Casting "Powerful Casting") | 2% increased Spell Damage per 10 [Strength](/wiki/Strength "Strength") [[1]](/wiki/Passive_Skill:Oracle~strength~spell4 "Passive Skill:Oracle~strength~spell4") |
| [Rustle of the Leaves](/wiki/Rustle_of_the_Leaves "Rustle of the Leaves") | Spells Cast by [Totems](/wiki/Totem "Totem") have 6% increased Cast Speed [Attacks](/wiki/Attack "Attack") used by Totems have 6% increased [Attack](/wiki/Attack "Attack") Speed 40% increased [Totem](/wiki/Totem "Totem") Placement speed [[1]](/wiki/Passive_Skill:Oracle~totems7 "Passive Skill:Oracle~totems7") |

### Ascendancy passive skills

The following [Ascendancy passive skills](/wiki/Ascendancy_passive_skill "Ascendancy passive skill") are related to spells:

| Ascendancy Class | Name | Stats |
| --- | --- | --- |
| [Abyssal Lich](/wiki/Abyssal_Lich "Abyssal Lich") | [Steward of Kulemak](/wiki/Steward_of_Kulemak "Steward of Kulemak") | Grants Skill: [Abyssal Apparition](/wiki/Abyssal_Apparition "Abyssal Apparition") Damaging Spells consume a [Power Charge](/wiki/Power_Charge "Power Charge") if able to trigger Abyssal Apparition [[1]](/wiki/Passive_Skill:AscendancyAltWitch1Notable4 "Passive Skill:AscendancyAltWitch1Notable4") |
| [Blood Mage](/wiki/Blood_Mage "Blood Mage") | [Spell Critical Chance](/wiki/Spell_Critical_Chance/edit?redlink=1 "Spell Critical Chance (page does not exist)") | 12% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for Spells [[1]](/wiki/Passive_Skill:AscendancyWitch2Small1 "Passive Skill:AscendancyWitch2Small1") [[2]](/wiki/Passive_Skill:AscendancyWitch2Small2 "Passive Skill:AscendancyWitch2Small2") [[3]](/wiki/Passive_Skill:AscendancySorceress1Small3 "Passive Skill:AscendancySorceress1Small3") [[4]](/wiki/Passive_Skill:AscendancySorceress1Small4 "Passive Skill:AscendancySorceress1Small4") |
| [Blood Mage](/wiki/Blood_Mage "Blood Mage") | [Sunder the Flesh](/wiki/Sunder_the_Flesh "Sunder the Flesh") | Base [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for Spells is 15% [[1]](/wiki/Passive_Skill:AscendancyWitch2Notable2~ "Passive Skill:AscendancyWitch2Notable2~") |
| [Blood Mage](/wiki/Blood_Mage "Blood Mage") | [Vitality Siphon](/wiki/Vitality_Siphon "Vitality Siphon") | 10% of Spell Damage [Leeched as Life](/wiki/Life_Leech "Life Leech") [[1]](/wiki/Passive_Skill:AscendancyWitch2Notable6 "Passive Skill:AscendancyWitch2Notable6") |
| [Infernalist](/wiki/Infernalist "Infernalist") | [Spell Damage](/wiki/Spell_Damage_(passive_skill) "Spell Damage (passive skill)") | 12% increased Spell Damage [[1]](/wiki/Passive_Skill:AscendancyWitch1Small5 "Passive Skill:AscendancyWitch1Small5") [[2]](/wiki/Passive_Skill:AscendancyWitch1Small6 "Passive Skill:AscendancyWitch1Small6") [[3]](/wiki/Passive_Skill:AscendancyDruid1Small5 "Passive Skill:AscendancyDruid1Small5") |
| [Infernalist](/wiki/Infernalist "Infernalist") | [Seething Body](/wiki/Seething_Body "Seething Body") | Gain [Elemental Archon](/wiki/Elemental_Archon "Elemental Archon") when you cast a Spell while on [High Infernal Flame](/wiki/High_Infernal_Flame "High Infernal Flame") [Elemental Archon](/wiki/Elemental_Archon "Elemental Archon") does not expire while on [High Infernal Flame](/wiki/High_Infernal_Flame "High Infernal Flame") Lose [Elemental Archon](/wiki/Elemental_Archon "Elemental Archon") on reaching maximum Infernal Flame [[1]](/wiki/Passive_Skill:AscendancyWitch1Notable11~ "Passive Skill:AscendancyWitch1Notable11~") |
| [Invoker](/wiki/Invoker "Invoker") | [Triggered Spell Damage](/wiki/Triggered_Spell_Damage/edit?redlink=1 "Triggered Spell Damage (page does not exist)") | [Triggered](/wiki/Trigger "Trigger") Spells deal 16% increased Spell Damage [[1]](/wiki/Passive_Skill:AscendancyMonk2Small10~ "Passive Skill:AscendancyMonk2Small10~") |
| [Lich](/wiki/Lich "Lich") | [Eldritch Empowerment](/wiki/Eldritch_Empowerment "Eldritch Empowerment") | [Sacrifice](/wiki/Sacrifice_(keyword) "Sacrifice (keyword)") 5% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") when you Cast a Spell Spells for which this [Sacrifice](/wiki/Sacrifice_(keyword) "Sacrifice (keyword)") was fully made deal 30% more Damage [Sacrificing](/wiki/Sacrifice_(keyword) "Sacrifice (keyword)") [Energy Shield](/wiki/Energy_Shield "Energy Shield") does not interrupt [Recharge](/wiki/Energy_Shield "Energy Shield") [[1]](/wiki/Passive_Skill:AscendancyWitch3Notable8 "Passive Skill:AscendancyWitch3Notable8") |
| [Lich](/wiki/Lich "Lich") | [Price of Power](/wiki/Price_of_Power "Price of Power") | Spells consume a [Power Charge](/wiki/Power_Charge "Power Charge") if able to deal 40% more Damage [[1]](/wiki/Passive_Skill:AscendancyWitch3Notable7 "Passive Skill:AscendancyWitch3Notable7") |
| [Oracle](/wiki/Oracle "Oracle") | [Totem Cast and Attack Speed](/wiki/Totem_Cast_and_Attack_Speed/edit?redlink=1 "Totem Cast and Attack Speed (page does not exist)") | Spells Cast by [Totems](/wiki/Totem "Totem") have 5% increased Cast Speed [Attacks](/wiki/Attack "Attack") used by Totems have 5% increased [Attack](/wiki/Attack "Attack") Speed [[1]](/wiki/Passive_Skill:AscendancyDruid1Small6 "Passive Skill:AscendancyDruid1Small6") |
| [Shaman](/wiki/Shaman "Shaman") | [Druidic Champion](/wiki/Druidic_Champion "Druidic Champion") | Every 2 [Rage](/wiki/Rage "Rage") also grants 1% more Spell damage [[1]](/wiki/Passive_Skill:AscendancyDruid2Notable3 "Passive Skill:AscendancyDruid2Notable3") |
| [Smith of Kitava](/wiki/Smith_of_Kitava "Smith of Kitava") | [Heat of the Forge](/wiki/Heat_of_the_Forge "Heat of the Forge") | Grants Skill: [Fire Spell on Hit](/wiki/Fire_Spell_on_Hit "Fire Spell on Hit") [[1]](/wiki/Passive_Skill:AscendancyWarrior3Notable1 "Passive Skill:AscendancyWarrior3Notable1") |
| [Stormweaver](/wiki/Stormweaver "Stormweaver") | [Tempest Caller](/wiki/Tempest_Caller "Tempest Caller") | Grants Skill: [Elemental Storm](/wiki/Elemental_Storm "Elemental Storm") Trigger Elemental Storm on [Critical Hit](/wiki/Critical_Hit "Critical Hit") with Spells [[1]](/wiki/Passive_Skill:AscendancySorceress1Notable3 "Passive Skill:AscendancySorceress1Notable3") |

### Keystones

The following [Keystones](/wiki/Keystone "Keystone") are related to spells:

| Name | Stats |
| --- | --- |
| [Blackflame Covenant](/wiki/Blackflame_Covenant "Blackflame Covenant") | [Fire](/wiki/Fire "Fire") Spells [Convert](/wiki/Damage_conversion "Damage conversion") 100% of Fire Damage to [Chaos Damage](/wiki/Chaos_Damage "Chaos Damage") [Chaos Damage](/wiki/Chaos_Damage "Chaos Damage") from [Fire](/wiki/Fire "Fire") Spells [Contributes](/wiki/Contributes "Contributes") to [Flammability](/wiki/Flammability "Flammability") and [Ignite](/wiki/Ignite "Ignite") [Magnitudes](/wiki/Magnitude "Magnitude") [Ignite](/wiki/Ignite "Ignite") inflicted with [Fire](/wiki/Fire "Fire") Spells deals [Chaos Damage](/wiki/Chaos_Damage "Chaos Damage") instead of Fire Damage [[1]](/wiki/Passive_Skill:Passive~keystone~fire~spells~to~chaos "Passive Skill:Passive~keystone~fire~spells~to~chaos") |
| [Ritual Cadence](/wiki/Ritual_Cadence "Ritual Cadence") | [Invocation](/wiki/Invocation "Invocation") Skills instead [Trigger](/wiki/Trigger "Trigger") Spells every 2 seconds [Invocation](/wiki/Invocation "Invocation") Skills cannot gain [Energy](/wiki/Energy "Energy") while [Triggering](/wiki/Trigger "Trigger") Spells [Invoked](/wiki/Invoke "Invoke") Spells consume 50% less [Energy](/wiki/Energy "Energy") [[1]](/wiki/Passive_Skill:Passive~keystone~auto~invocation "Passive Skill:Passive~keystone~auto~invocation") |
| [Wildsurge Incantation](/wiki/Wildsurge_Incantation "Wildsurge Incantation") | [Storm](/wiki/Storm "Storm") and [Plant](/wiki/Plant "Plant") Spells: • deal 50% more damage • cost 50% less • have 75% less duration [[1]](/wiki/Passive_Skill:Passive~keystone~wildsurge~incantation "Passive Skill:Passive~keystone~wildsurge~incantation") |
