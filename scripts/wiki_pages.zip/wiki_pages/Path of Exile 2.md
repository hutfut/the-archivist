# Path of Exile 2

✍️This article is a [stub](/wiki/Category:Stubs "Category:Stubs"). Please help [improve the article](https://www.poe2wiki.net/wiki/Path_of_Exile_2/edit) by expanding it.

***Path of Exile 2*** (also known as **PoE2**) is a sequel to *[Path of Exile](https://www.poewiki.net/wiki/Path_of_Exile "poewiki:Path of Exile")*, and is developed by [Grinding Gear Games](/wiki/Grinding_Gear_Games "Grinding Gear Games").[[1]](#cite_note-Path_of_Exile_2-1). It is currently in [Early Access](/wiki/Early_Access "Early Access").

The Early Access/Public Beta period started on December 6th, 2024. It is available for PC, PlayStation 5, and Xbox Series X/S. A launch date for the game's full release has not yet been announced.

## Classes

* [Marauder](/wiki/Marauder "Marauder")
* [Warrior](/wiki/Warrior "Warrior")
* [Ranger](/wiki/Ranger "Ranger")
* [Huntress](/wiki/Huntress "Huntress")
* [Witch](/wiki/Witch "Witch")
* [Sorceress](/wiki/Sorceress "Sorceress")
* [Duelist](/wiki/Duelist "Duelist")
* [Mercenary](/wiki/Mercenary "Mercenary")
* [Shadow](/wiki/Shadow "Shadow")
* [Monk](/wiki/Monk "Monk")
* [Templar](/wiki/Templar "Templar")
* [Druid](/wiki/Druid "Druid")

## Videos

|  |  |  |
| --- | --- | --- |
| Click to load content | Click to load content | Click to load content |

## Trivia

* Path of Exile 2 was originally called "Project Chimera". This is referenced by a chimera boss in POE2 which was the first boss originally designed, and the last boss finished prior to the Early Access announcement livestream.
* The game was originally announced on November 15, 2019, during ExileCon 2019 as a major "Version 4.0" update to the first game with a new campaign and major overhauls to core game mechanics and graphics.[[2]](#cite_note-Announcement-2) In ExileCon 2023, it was announced *Path of Exile 2* will now be its own separate game that will be supported alongside the prequel.

### ExileCon 2019

The skill gem screen as seen in ExileCon 2019.

An item with a red/green hybrid socket.

When *Path of Exile 2* was first revealed in ExileCon 2019, it was planned to be an update to the first game with a new campaign and overhauled gameplay mechanics. At ExileCon 2023, it was announced that PoE2 will be its own separate game, and that many of the plans from the original preview were altered.

* The campaign would have consisted of seven Acts, rather than six.
* No new base classes were planned. The game still used the seven classes from the first game. Each class would have received three new Ascendancy classes (one the Scion) for a total of 19 new Ascendancy classes. The PoE2 Ascendancy classes would had first have to be unlocked in PoE2 in order to be used in PoE1.
  + The following Ascendancies were teased in ExileCon 2019, though they may not be relevant in the current iteration:
    - Survivalist (Ranger) - Projectile effects, Spell Avoidance
    - Tactician (Ranger) - Spears, Flare Arrow (meta "arrow rain" skill), ballistas, melee bow attacks
    - Beastmaster (Ranger) - Shapeshift (Werecat (crit), Bear); Wild Cat Companion (Cheetah, Lion, Panther), Aspect buffs
    - Arcanist (Witch) - Lightning damage and Energy system
    - Defiler (Witch)
    - Reaver (Marauder) - Melee and ally buffer
    - Unnamed Marauder - Ancestral proxies and Ancestor Totems
* While support gems could be socketed to skill gems, skill gems still had to be socketed to equipment.
  + Each equipment could have 1 to 4 sockets (4 for 2h weapons, 2 for 1h weapons/shields and body armour, 1 for helmet, gloves, and boots).
  + Most equipment dropped with fixed socket colours based on the item base, but there would have been end-game currency items that changed it.
  + Some equipment had hybrid socket colours that could support two different gem colours.
  + Certain items like [Tabula Rasa](https://www.poewiki.net/wiki/Tabula_Rasa "poewiki:Tabula Rasa") would have had additional gem sockets.
  + [Abyss sockets](https://www.poewiki.net/wiki/Abyss_socket "poewiki:Abyss socket") would have been part of the gear.
* Both PoE1 and PoE2 would've shared the same endgame system.

### Pre-EA builds

Some mechanics were changed between the ExileCon 2023 build and Early Access:

* Support gem sockets used to have colours, which could be changed individually with Chromatic Orbs.
* There was a stat called Deflection, which worked like [Spell Suppression](https://www.poewiki.net/wiki/Spell_Suppression "poewiki:Spell Suppression") but for attack damage. Deflection could be found on Dexterity-based shields. This was removed along with the removed distinction of monster attacks and spells. Note that this form of [Deflection](/wiki/Deflection "Deflection") works differently from the current game.
* Players could have 5 flasks equipped like in the first game. New utility flasks, such as the Antidote Flask, were present in the game.
* Normal monsters used to not give any flask charges.
* It was possible to open portals during boss fights. There was a 2.5 second interruptible cast time on opening portals during a boss fight.
* Crossbows had an implicit that determined its ammo type and a grenade launcher could be equipped on the off-hand which grants a grenade skill. These were later turned into individual skill gems.
