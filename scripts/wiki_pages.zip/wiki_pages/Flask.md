# Flask

Flasks

Tooltip

Flasks can be used to recover your Life or Mana. Flasks are not consumable, but require charges to use. Flask charges can be regained by killing enemies.

[Normal](/wiki/Normal "Normal") enemies grant Flask charges equal to half their [Power](/wiki/Monster_Power "Monster Power")
[Magic](/wiki/Magic "Magic") enemies grant Flask charges equal to their [Power](/wiki/Monster_Power "Monster Power")
[Rare](/wiki/Rare "Rare") and [Unique](/wiki/Unique "Unique") enemies grant Flask charges equal to twice their [Power](/wiki/Monster_Power "Monster Power")

[Checkpoints](/wiki/Checkpoints "Checkpoints") and [Wells](/wiki/Well "Well") completely refill Flasks when activated. Flasks can only hold charges while in a Flask slot.

A **flask** is a item which are used to [recover](/wiki/Recovery "Recovery") [life](/wiki/Life "Life") and [mana](/wiki/Mana "Mana"). Each use of a flask requires a certain amount of flask charges to be expended. Modifiers on flasks can adjust how it gains or uses its flask charges or add additional effects when used.

## Mechanics

There are two types of flasks: [life flasks](/wiki/Life_flask "Life flask") and [mana flasks](/wiki/Mana_flask "Mana flask"). When used, they will recover [life](/wiki/Life "Life") or [mana](/wiki/Mana "Mana"), respectively, over time. A player can have only one life flask and one mana flask equipped at a time unless otherwise specified.

Flask charges are gained by killing monsters, using the [Well](/wiki/Well "Well"), or activating a checkpoint. The amount and chance of gaining a flask charge on kill is based on the monster's rarity. There are modifiers which modify the amount of charges gained or used. Some modifiers will cause the flask to gain charges passively over time. Unequipping a flask will remove all charges on the flask.

Flasks can only be normal, magic or unique. There are no rare flasks.

## List of life flasks

Main article: [List of life flasks](/wiki/List_of_life_flasks "List of life flasks")

| Item |  | Life | Duration | Usage | Capacity |
| --- | --- | --- | --- | --- | --- |
| [Lesser Life Flask](/wiki/Lesser_Life_Flask "Lesser Life Flask") | 1 | 50 | 3.00 | 10 | 60 |
| [Medium Life Flask](/wiki/Medium_Life_Flask "Medium Life Flask") | 4 | 90 | 5.00 | 10 | 65 |
| [Greater Life Flask](/wiki/Greater_Life_Flask "Greater Life Flask") | 10 | 150 | 4.00 | 10 | 70 |
| [Grand Life Flask](/wiki/Grand_Life_Flask "Grand Life Flask") | 16 | 260 | 5.00 | 10 | 75 |
| [Giant Life Flask](/wiki/Giant_Life_Flask "Giant Life Flask") | 23 | 340 | 4.00 | 10 | 75 |
| [Colossal Life Flask](/wiki/Colossal_Life_Flask "Colossal Life Flask") | 30 | 450 | 4.00 | 10 | 75 |
| [Gargantuan Life Flask](/wiki/Gargantuan_Life_Flask "Gargantuan Life Flask") | 40 | 710 | 5.00 | 10 | 75 |
| [Transcendent Life Flask](/wiki/Transcendent_Life_Flask "Transcendent Life Flask") | 50 | 840 | 4.00 | 10 | 75 |
| [Ultimate Life Flask](/wiki/Ultimate_Life_Flask "Ultimate Life Flask") | 60 | 920 | 3.00 | 10 | 75 |

## List of mana flasks

Main article: [List of mana flasks](/wiki/List_of_mana_flasks "List of mana flasks")

| Item |  | Mana | Duration | Usage | Capacity |
| --- | --- | --- | --- | --- | --- |
| [Lesser Mana Flask](/wiki/Lesser_Mana_Flask "Lesser Mana Flask") | 1 | 50 | 2.00 | 10 | 60 |
| [Medium Mana Flask](/wiki/Medium_Mana_Flask "Medium Mana Flask") | 4 | 70 | 3.00 | 10 | 65 |
| [Greater Mana Flask](/wiki/Greater_Mana_Flask "Greater Mana Flask") | 10 | 90 | 2.50 | 10 | 70 |
| [Grand Mana Flask](/wiki/Grand_Mana_Flask "Grand Mana Flask") | 16 | 110 | 2.50 | 10 | 75 |
| [Giant Mana Flask](/wiki/Giant_Mana_Flask "Giant Mana Flask") | 23 | 165 | 3.50 | 10 | 75 |
| [Colossal Mana Flask](/wiki/Colossal_Mana_Flask "Colossal Mana Flask") | 30 | 165 | 2.50 | 10 | 75 |
| [Gargantuan Mana Flask](/wiki/Gargantuan_Mana_Flask "Gargantuan Mana Flask") | 40 | 185 | 2.00 | 10 | 75 |
| [Transcendent Mana Flask](/wiki/Transcendent_Mana_Flask "Transcendent Mana Flask") | 50 | 285 | 3.50 | 10 | 75 |
| [Ultimate Mana Flask](/wiki/Ultimate_Mana_Flask "Ultimate Mana Flask") | 60 | 310 | 3.00 | 10 | 75 |

## List of unique life flasks

Main article: [List of unique life flasks](/wiki/List_of_unique_life_flasks "List of unique life flasks")

| Item |  | Life | Duration | Usage | Capacity | Stats |
| --- | --- | --- | --- | --- | --- | --- |
| [Blood of the Warrior](/wiki/Blood_of_the_Warrior "Blood of the Warrior") | 40 | 70 | (6.25-7.50) | 10 | 75 | 90% less Life Recovered Effect is not removed when Unreserved Life is Filled Gain (3-5) [Rage](/wiki/Rage "Rage") when [Hit](/wiki/Hit "Hit") by an Enemy during effect No Inherent loss of [Rage](/wiki/Rage "Rage") during effect (15-30)% of Damage taken during effect [Recouped](/wiki/Recoup "Recoup") as Life (25-50)% increased Duration |
| [Olroth's Resolve](/wiki/Olroth%27s_Resolve "Olroth's Resolve") | 60 | 920 | 3.00 | (20-25) | 75 | Instant Recovery (100-150)% increased Charges per use Excess Life Recovery added as [Guard](/wiki/Guard "Guard") for 20 seconds |

## List of unique mana flasks

Main article: [List of unique mana flasks](/wiki/List_of_unique_mana_flasks "List of unique mana flasks")

| Item |  | Mana | Duration | Usage | Capacity | Stats |
| --- | --- | --- | --- | --- | --- | --- |
| [Lavianga's Spirits](/wiki/Lavianga%27s_Spirits "Lavianga's Spirits") | 49 | (36-55) | 2.00 | 10 | 75 | This Flask cannot be Used but applies its Effect constantly (80-70)% reduced Amount Recovered |
| [Melting Maelstrom](/wiki/Melting_Maelstrom "Melting Maelstrom") | 60 | 310 | (9.00-10.50) | 10 | 75 | Effect is not removed when Unreserved Mana is Filled (200-250)% increased Duration Every 3 seconds during Effect, deal 100% of Mana spent in those seconds as [Chaos Damage](/wiki/Chaos_Damage "Chaos Damage") to Enemies within 3 metres Deals 25% of current Mana as [Chaos Damage](/wiki/Chaos_Damage "Chaos Damage") to you when Effect ends |

## Related skills

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Acidic Concoction](/wiki/Acidic_Concoction "Acidic Concoction") | *0* |  |  |  |
| [Bleeding Concoction](/wiki/Bleeding_Concoction "Bleeding Concoction") | *0* |  |  |  |
| [Explosive Concoction](/wiki/Explosive_Concoction "Explosive Concoction") | *0* |  |  |  |
| [Fulminating Concoction](/wiki/Fulminating_Concoction "Fulminating Concoction") | *0* |  |  |  |
| [Shattering Concoction](/wiki/Shattering_Concoction "Shattering Concoction") | *0* |  |  |  |

### Persistent skills

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Alchemist's Boon](/wiki/Alchemist%27s_Boon "Alchemist's Boon") | *14* |  |  |  |
| [Dread Banner](/wiki/Dread_Banner "Dread Banner") | *14* |  |  |  |

## Related support gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Bounty I](/wiki/Bounty_I "Bounty I") | *2* |  |  |  |
| [Ambrosia I](/wiki/Ambrosia_I "Ambrosia I") | *2* |  |  |  |
| [Gorge](/wiki/Gorge "Gorge") | *2* |  |  |  |
| [Concoct I](/wiki/Concoct_I "Concoct I") | *2* |  |  |  |
| [Herbalism I](/wiki/Herbalism_I "Herbalism I") | *2* |  |  |  |
| [Ambrosia II](/wiki/Ambrosia_II "Ambrosia II") | *3* |  |  |  |
| [Bounty II](/wiki/Bounty_II "Bounty II") | *4* |  |  |  |
| [Concoct II](/wiki/Concoct_II "Concoct II") | *4* |  |  |  |
| [Herbalism II](/wiki/Herbalism_II "Herbalism II") | *4* |  |  |  |

## Related items

### Base items

| Item |  | Stats |
| --- | --- | --- |
| [Linen Belt](/wiki/Linen_Belt "Linen Belt") | 1 | Has (1-3) [Charm](/wiki/Charm "Charm") Slots (20-30)% increased Mana Recovery from Flasks |
| [Rawhide Belt](/wiki/Rawhide_Belt "Rawhide Belt") | 1 | Has (1-3) [Charm](/wiki/Charm "Charm") Slots (20-30)% increased Life Recovery from Flasks |
| [Wide Belt](/wiki/Wide_Belt "Wide Belt") | 14 | Has (1-3) [Charm](/wiki/Charm "Charm") Slots (20-30)% increased Flask Charges gained |
| [Mail Belt](/wiki/Mail_Belt "Mail Belt") | 40 | Has (1-3) [Charm](/wiki/Charm "Charm") Slots (15-10)% reduced Flask Charges used |
| [Utility Belt](/wiki/Utility_Belt "Utility Belt") | 55 | Has (1-3) [Charm](/wiki/Charm "Charm") Slots 20% of Flask Recovery applied Instantly |
| [Fine Belt](/wiki/Fine_Belt "Fine Belt") | 62 | Has (1-3) [Charm](/wiki/Charm "Charm") Slots Flasks gain 0.17 charges per Second |

### Unique items

| Item |  | Stats |
| --- | --- | --- |
| [Glowswarm](/wiki/Glowswarm "Glowswarm") | 1 | +(20-30) to maximum Mana+(40-60) to maximum Mana (20-30)% increased Flask Mana Recovery rate Mana Flasks gain (0.17-0.25) charges per Second |
| [Heart of the Well](/wiki/Heart_of_the_Well "Heart of the Well") | 1 | <Custom Desecrated prefix> <Custom Desecrated prefix> <Custom Desecrated suffix> <Custom Desecrated suffix>   | <List of mods> | | --- | | (5-10)% chance to [Aggravate](/wiki/Aggravate "Aggravate") [Bleeding](/wiki/Bleeding "Bleeding") on targets you [Hit](/wiki/Hit "Hit") with [Attacks](/wiki/Attack "Attack")  ---  (5-8)% increased [Attack](/wiki/Attack "Attack") Speed while a [Rare or Unique](/wiki/Rarity "Rarity") Enemy is in your [Presence](/wiki/Presence "Presence")  ---  (40-60)% increased [Armour](/wiki/Armour "Armour") from Equipped Body Armour  ---  (30-50)% chance to [Pierce](/wiki/Pierce "Pierce") an Enemy  ---  (10-15)% chance when a [Charm](/wiki/Charm "Charm") is used to use another Charm without consuming Charges  ---  [Charms](/wiki/Charm "Charm") applied to you have (15-25)% increased Effect  ---  Recover (5-10)% of maximum Mana when a [Charm](/wiki/Charm "Charm") is used  ---  (15-25)% increased [Culling Strike](/wiki/Culling_Strike "Culling Strike") Threshold  ---  [Gain](/wiki/Gain "Gain") (9-15)% of Damage as Extra [Lightning](/wiki/Lightning "Lightning") Damage  ---  [Gain](/wiki/Gain "Gain") (7-13)% of Damage as Extra [Chaos](/wiki/Chaos "Chaos") Damage  ---  [Gain](/wiki/Gain "Gain") (9-15)% of Damage as Extra [Fire](/wiki/Fire "Fire") Damage  ---  [Gain](/wiki/Gain "Gain") (9-15)% of Damage as Extra [Cold](/wiki/Cold "Cold") Damage  ---  (15-25)% increased Damage while your [Companion](/wiki/Companion "Companion") is in your [Presence](/wiki/Presence "Presence")  ---  (15-25)% increased [Exposure](/wiki/Exposure "Exposure") Effect  ---  (40-60)% increased [Evasion](/wiki/Evasion "Evasion") Rating from Equipped Body Armour  ---  Regenerate (1-1.5)% of maximum Life per Second if you've used a Life Flask in the past 10 seconds  ---  (10-18)% increased [Cooldown Recovery Rate](/wiki/Cooldown_Recovery_Rate "Cooldown Recovery Rate")  ---  (40-60)% increased [Ice Crystal](/wiki/Ice_Crystal "Ice Crystal") Life  ---  (4-8)% increased [Skill Speed](/wiki/Skill_Speed "Skill Speed")  ---  (15-25)% chance for [Lightning](/wiki/Lightning "Lightning") Damage with [Hits](/wiki/Hit "Hit") to be [Lucky](/wiki/Lucky "Lucky")  ---  (8-16)% increased Mana Cost [Efficiency](/wiki/Efficiency "Efficiency")  ---  (20-30)% increased Mana Regeneration Rate while moving  ---  +1% to all [Maximum Elemental Resistances](/wiki/Maximum_Resistance "Maximum Resistance")  ---  (40-60)% increased [Energy Shield](/wiki/Energy_Shield "Energy Shield") from Equipped Body Armour  ---  [Minions](/wiki/Minion "Minion") gain (10-15)% of their maximum Life as Extra maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield")  ---  [Minions](/wiki/Minion "Minion") Regenerate (1-3)% of maximum Life per second  ---  [Minions](/wiki/Minion "Minion") [Revive](/wiki/Reviving_Minions "Reviving Minions") (5-10)% faster  ---  (8-15)% of Leech is Instant  ---  (5-10)% of Physical Damage prevented [Recouped](/wiki/Recoup "Recoup") as Life  ---  (8-14)% increased speed of [Recoup](/wiki/Recoup "Recoup") Effects  ---  Recover (2-4)% of maximum Life on Killing a [Poisoned](/wiki/Poison "Poison") Enemy  ---  (10-15)% increased Skill Effect Duration  ---  +(2-4)% to Thorns [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance  ---  Gain [Physical](/wiki/Physical "Physical") [Thorns](/wiki/Thorns "Thorns") damage equal to (4-6)% of [Item Armour](/wiki/Defences "Defences") on [Equipped](/wiki/Equipped/edit?redlink=1 "Equipped (page does not exist)") Body Armour  ---  (6-12)% chance for [Trigger](/wiki/Trigger "Trigger") skills to refund half of [Energy](/wiki/Energy "Energy") Spent  ---  (4-8)% increased chance to inflict [Ailments](/wiki/Ailments "Ailments")  ---  Gain additional [Ailment Threshold](/wiki/Ailment_Threshold "Ailment Threshold") equal to (4-10)% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield")  ---  (5-10)% chance to inflict [Bleeding](/wiki/Bleeding "Bleeding") on [Hit](/wiki/Hit "Hit")  ---  (5-10)% chance to [Poison](/wiki/Poison "Poison") on [Hit](/wiki/Hit "Hit")  ---  (4-8)% increased [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance  ---  (6-12)% increased [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus")  ---  (2-3)% of Damage is taken from Mana before Life  ---  [Debuffs](/wiki/Debuff "Debuff") on you expire (4-8)% faster  ---  [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") deal damage (2-4)% faster  ---  (4-8)% increased Flask Effect Duration  ---  Gain (1-2) [Rage](/wiki/Rage "Rage") when [Hit](/wiki/Hit "Hit") by an Enemy  ---  (2-3)% increased [Cooldown Recovery Rate](/wiki/Cooldown_Recovery_Rate "Cooldown Recovery Rate")  ---  (6-12)% increased [Elemental Ailment Threshold](/wiki/Ailment "Ailment")  ---  (2-3)% increased [Attack](/wiki/Attack "Attack") Speed  ---  (2-3)% increased Cast Speed  ---  (4-8)% increased Flask Charges gained  ---  (5-10)% increased [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold")  ---  (2-3)% of Skill Mana Costs [Converted](/wiki/Stat_conversion "Stat conversion") to Life Costs  ---  (2-3)% of Damage taken [Recouped](/wiki/Recoup "Recoup") as Life  ---  (6-12)% increased Life Regeneration rate  ---  Recover (1-2)% of maximum Mana on Kill  ---  (4-8)% increased Mana Regeneration Rate  ---  +1% to [Maximum Cold Resistance](/wiki/Maximum_Cold_Resistance "Maximum Cold Resistance")  ---  +1% to [Maximum Fire Resistance](/wiki/Maximum_Fire_Resistance "Maximum Fire Resistance")  ---  Recover (1-2)% of maximum Life on Kill  ---  +1% to [Maximum Lightning Resistance](/wiki/Maximum_Lightning_Resistance "Maximum Lightning Resistance")  ---  [Minions](/wiki/Minion "Minion") have (2-3)% increased [Attack](/wiki/Attack "Attack") and Cast Speed  ---  [Minions](/wiki/Minion "Minion") have (6-12)% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance")  ---  [Minions](/wiki/Minion "Minion") have +(3-4)% to all Elemental [Resistances](/wiki/Resistances "Resistances")  ---  [Minions](/wiki/Minion "Minion") have (3-12)% additional [Physical](/wiki/Physical "Physical") Damage Reduction  ---  (1-2)% increased Movement Speed  ---  Gain 1 [Rage](/wiki/Rage "Rage") on [Melee](/wiki/Melee "Melee") [Hit](/wiki/Hit "Hit")  ---  (3-8)% increased Skill Effect Duration  ---  (10-5)% reduced [Slowing](/wiki/Slow "Slow") Potency of [Debuffs](/wiki/Debuff "Debuff") on You  ---  (4-8)% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for [Spells](/wiki/Spell "Spell")  ---  (6-12)% increased [Critical Spell Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus")  ---  (6-12)% increased [Stun](/wiki/Stun "Stun") Buildup  ---  Gain additional [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") equal to (4-10)% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") | |
| [Keelhaul](/wiki/Keelhaul "Keelhaul") | 1 | Has (1-3) [Charm](/wiki/Charm "Charm") Slots (20-30)% increased Mana Recovery from Flasks(-25-25)% increased Flask Life Recovery rate (-25-25)% increased Flask Mana Recovery rate Life Flasks gain 0.25 charges per Second Mana Flasks gain 0.25 charges per Second |
| [Meginord's Girdle](/wiki/Meginord%27s_Girdle "Meginord's Girdle") | 1 | Has (1-3) [Charm](/wiki/Charm "Charm") Slots (20-30)% increased Life Recovery from Flasks+(40-50) to [Strength](/wiki/Strength "Strength") +(10-15)% to [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance") 50% increased Flask Charges used 100% increased Flask Charges gained |
| [Midnight Braid](/wiki/Midnight_Braid "Midnight Braid") | 1 | Has (1-3) [Charm](/wiki/Charm "Charm") Slots (20-30)% increased Life Recovery from Flasks+(30-50) to maximum Mana +(5-10)% to all [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") 50% of Damage taken [Recouped](/wiki/Recoup "Recoup") as Mana |
| [Bitterbloom](/wiki/Bitterbloom "Bitterbloom") | 5 | (50-100)% increased [Energy Shield](/wiki/Energy_Shield "Energy Shield") +(50-100) to maximum Mana 50% increased [Energy Shield Recharge Rate](/wiki/Energy_Shield_Recharge_Rate "Energy Shield Recharge Rate") [Energy Shield Recharge](/wiki/Energy_Shield_Recharge "Energy Shield Recharge") starts when you use a Mana Flask |
| [Revered Resin](/wiki/Revered_Resin "Revered Resin") | 8 | +(10-15) to [Strength](/wiki/Strength "Strength")+(40-60) to maximum Life (20-30)% increased Flask Life Recovery rate Life Flasks gain (0.17-0.25) charges per Second |
| [Birthright Buckle](/wiki/Birthright_Buckle "Birthright Buckle") | 14 | Has (1-3) [Charm](/wiki/Charm "Charm") Slots (20-30)% increased Flask Charges gained+(100-150) to [Armour](/wiki/Armour "Armour") (15-10)% reduced Flask Charges used (20-30)% increased Flask Charges gained Life Flasks used while on [Low Life](/wiki/Low_Life "Low Life") apply Recovery Instantly Mana Flasks used while on [Low Mana](/wiki/Low_Mana "Low Mana") apply Recovery Instantly |
| [Byrnabas](/wiki/Byrnabas "Byrnabas") | 14 | Has (1-3) [Charm](/wiki/Charm "Charm") Slots (20-30)% increased Flask Charges gained+(40-60) to maximum Mana +(30-40)% to [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance") (7-12) Life Regeneration per second Cannot be [Shocked](/wiki/Shock "Shock") |
| [Killjoy](/wiki/Killjoy "Killjoy") | 16 | (30-60)% increased [Evasion](/wiki/Evasion "Evasion") and [Energy Shield](/wiki/Energy_Shield "Energy Shield") +(30-50) to maximum Life (20-30)% increased [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus") Life Flasks do not recover Life On-Kill Effects happen twice |
| [The Lethal Draw](/wiki/The_Lethal_Draw "The Lethal Draw") | 16 | Gain (2-3) Life per Enemy Hit with [Attacks](/wiki/Attack "Attack")(5-10)% increased [Attack](/wiki/Attack "Attack") Speed Gain 5 Life per Enemy Hit with [Attacks](/wiki/Attack "Attack") (15-25)% chance to [Pierce](/wiki/Pierce "Pierce") an Enemy [Bow](/wiki/Bow "Bow") [Attacks](/wiki/Attack "Attack") consume 10% of your maximum Life Flask Charges if possible to deal added [Physical](/wiki/Physical "Physical") damage equal to (5-10)% of Flask's Life Recovery amount |
| [Briskwrap](/wiki/Briskwrap "Briskwrap") | 22 | (60-100)% increased [Evasion](/wiki/Evasion "Evasion") Rating (40-60)% increased Flask Life Recovery rate (40-60)% increased Flask Mana Recovery rate +(20-30) to [Dexterity](/wiki/Dexterity "Dexterity") +(20-30)% to [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance") Gain [Deflection Rating](/wiki/Deflect "Deflect") equal to (20-30)% of [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") |
| [Arakaali's Gift](/wiki/Arakaali%27s_Gift "Arakaali's Gift") | 24 | Used when you become [Poisoned](/wiki/Poison "Poison")Recover Life equal to (15-20)% of Mana Flask's Recovery Amount when used Recover Mana equal to (15-20)% of Life Flask's Recovery Amount when used |
| [Umbilicus Immortalis](/wiki/Umbilicus_Immortalis "Umbilicus Immortalis") | 24 | Has (1-3) [Charm](/wiki/Charm "Charm") Slots (20-30)% increased Mana Recovery from Flasks(40-30)% reduced Flask Effect Duration +(20-30) to [Intelligence](/wiki/Intelligence "Intelligence") [Minions](/wiki/Minion "Minion") have (20-30)% increased maximum Life Your Life Flask also applies to your [Minions](/wiki/Minion "Minion") [Minions](/wiki/Minion "Minion") cannot Die while affected by a Life Flask (20-30)% increased Flask Charges gained |
| [Husk of Dreams](/wiki/Husk_of_Dreams "Husk of Dreams") | 28 | (100-150)% increased [Armour](/wiki/Armour "Armour") and [Energy Shield](/wiki/Energy_Shield "Energy Shield") -10% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") +(17-23)% to [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance") (20-30)% increased Flask Charges gained 50% less Flask Charges used |
| [Ryslatha's Coil](/wiki/Ryslatha%27s_Coil "Ryslatha's Coil") | 31 | Has (1-3) [Charm](/wiki/Charm "Charm") Slots (15-10)% reduced [Charm](/wiki/Charm "Charm") Charges used+(80-100) to maximum Life (30-50)% increased Flask Life Recovery rate (30-40)% more maximum [Physical](/wiki/Physical "Physical") [Attack](/wiki/Attack "Attack") Damage (40-30)% less minimum [Physical](/wiki/Physical "Physical") [Attack](/wiki/Attack "Attack") Damage |
| [Belly of the Beast](/wiki/Belly_of_the_Beast "Belly of the Beast") | 33 | (100-150)% increased [Armour](/wiki/Armour "Armour") and [Evasion](/wiki/Evasion "Evasion") +(100-150) to maximum Life +(100-150) to [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") Life Recovery from Flasks is instant (25-30) to (35-40) [Physical](/wiki/Physical "Physical") [Thorns](/wiki/Thorns "Thorns") damage |
| [Coward's Legacy](/wiki/Coward%27s_Legacy "Coward's Legacy") | 40 | Has (1-3) [Charm](/wiki/Charm "Charm") Slots (15-10)% reduced Flask Charges used-(20-10) to [Strength](/wiki/Strength "Strength") +(20-30) to [Dexterity](/wiki/Dexterity "Dexterity") (30-40)% increased Life and Mana Recovery from Flasks You are considered on [Low Life](/wiki/Low_Life "Low Life") while at 75% of maximum Life or below instead |
| [Waistgate](/wiki/Waistgate "Waistgate") | 50 | Has (1-3) [Charm](/wiki/Charm "Charm") Slots (20-30)% increased [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold")+(50-80) to maximum Life +(50-80) to maximum Mana (20-30)% increased Flask Life Recovery rate (20-30)% increased Flask Mana Recovery rate Life and Mana Flasks can be equipped in either slot |
| [Ingenuity](/wiki/Ingenuity "Ingenuity") | 55 | Has (1-3) [Charm](/wiki/Charm "Charm") Slots 20% of Flask Recovery applied Instantly(-20-20)% increased [Charm](/wiki/Charm "Charm") Charges gained (-10-10)% increased [Charm](/wiki/Charm "Charm") Charges used (20-30)% increased bonuses gained from left Equipped Ring (20-30)% increased bonuses gained from right Equipped Ring |
| [Zerphi's Genesis](/wiki/Zerphi%27s_Genesis "Zerphi's Genesis") | 56 | Has (1-3) [Charm](/wiki/Charm "Charm") Slots (20-30)% increased [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold")+(10-30) to [Strength](/wiki/Strength "Strength") [Corrupted Blood](/wiki/Corrupted_Blood "Corrupted Blood") cannot be inflicted on you 50% of charges used by [Charms](/wiki/Charm "Charm") granted to your Life Flasks (10-30)% increased [Charm](/wiki/Charm "Charm") Charges used |
| [The Gnashing Sash](/wiki/The_Gnashing_Sash "The Gnashing Sash") | 60 | Has (1-3) [Charm](/wiki/Charm "Charm") Slots (20-30)% increased Flask Charges gained(15-35)% increased Flask Life Recovery rate +(17-23)% to [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance") [Lose](/wiki/Life_Loss "Life Loss") 5% of maximum Life per second Life Recovery from Flasks can [Overflow](/wiki/Overflow "Overflow") Maximum Life |
| [Darkness Enthroned](/wiki/Darkness_Enthroned "Darkness Enthroned") | 62 | Has (1-3) [Charm](/wiki/Charm "Charm") Slots Flasks gain 0.17 charges per Second(50-100)% increased effect of Socketed Items Has 2 Augment Sockets (Hidden)   | This item gains bonuses from Socketed Items as though it was <Random socketable equipment type> | | --- | | This item gains bonuses from Socketed Items as though it was a Body Armour  ---  This item gains bonuses from Socketed Items as though it was a Body Armour  ---  This item gains bonuses from Socketed Items as though it was Boots  ---  This item gains bonuses from Socketed Items as though it was Gloves  ---  This item gains bonuses from Socketed Items as though it was a Helmet  ---  This item gains bonuses from Socketed Items as though it was a Shield | |
| [Shavronne's Satchel](/wiki/Shavronne%27s_Satchel "Shavronne's Satchel") | 62 | Has (1-3) [Charm](/wiki/Charm "Charm") Slots Flasks gain 0.17 charges per Second(30-20)% reduced Flask Life Recovery rate +(20-30) to [Intelligence](/wiki/Intelligence "Intelligence") (20-30)% increased Flask Charges gained Life Recovery from Flasks also applies to [Energy Shield](/wiki/Energy_Shield "Energy Shield") |

## Related passive skills

The following [passive skills](/wiki/Passive_skill "Passive skill") are related to flasks:

### Flask life recovery

| Name | Stats |
| --- | --- |
| [Flask Recovery](/wiki/Flask_Recovery/edit?redlink=1 "Flask Recovery (page does not exist)") | 10% increased Life and Mana Recovery from Flasks [[1]](/wiki/Passive_Skill:Flasks16 "Passive Skill:Flasks16") [[2]](/wiki/Passive_Skill:Flasks17 "Passive Skill:Flasks17") |
| [Life and Mana Flask Recovery](/wiki/Life_and_Mana_Flask_Recovery/edit?redlink=1 "Life and Mana Flask Recovery (page does not exist)") | 10% increased Life and Mana Recovery from Flasks [[1]](/wiki/Passive_Skill:Flasks19~ "Passive Skill:Flasks19~") [[2]](/wiki/Passive_Skill:Flasks20~ "Passive Skill:Flasks20~") |
| [Life Flask Charge Generation](/wiki/Life_Flask_Charge_Generation/edit?redlink=1 "Life Flask Charge Generation (page does not exist)") | 10% increased Life Recovery from Flasks [[1]](/wiki/Passive_Skill:Life~flasks11 "Passive Skill:Life~flasks11") [[2]](/wiki/Passive_Skill:Life~flasks8 "Passive Skill:Life~flasks8") [[3]](/wiki/Passive_Skill:Life~flasks9 "Passive Skill:Life~flasks9") |
| [Life Flask Charges](/wiki/Life_Flask_Charges/edit?redlink=1 "Life Flask Charges (page does not exist)") | 10% increased Life Recovery from Flasks [[1]](/wiki/Passive_Skill:Azmerianimals63 "Passive Skill:Azmerianimals63") |
| [Life Flask Recovery](/wiki/Life_Flask_Recovery/edit?redlink=1 "Life Flask Recovery (page does not exist)") | 10% increased Life Recovery from Flasks [[1]](/wiki/Passive_Skill:Life~flasks20 "Passive Skill:Life~flasks20") [[2]](/wiki/Passive_Skill:Life~flasks21 "Passive Skill:Life~flasks21") [[3]](/wiki/Passive_Skill:Life~flasks23~ "Passive Skill:Life~flasks23~") |
| [Life Flasks](/wiki/Life_Flasks/edit?redlink=1 "Life Flasks (page does not exist)") | 10% increased Life Recovery from Flasks [[1]](/wiki/Passive_Skill:Life~flasks1 "Passive Skill:Life~flasks1") [[2]](/wiki/Passive_Skill:Life~flasks13 "Passive Skill:Life~flasks13") [[3]](/wiki/Passive_Skill:Life~flasks15 "Passive Skill:Life~flasks15") [[4]](/wiki/Passive_Skill:Life~flasks16 "Passive Skill:Life~flasks16") [[5]](/wiki/Passive_Skill:Life~flasks18~ "Passive Skill:Life~flasks18~") [[6]](/wiki/Passive_Skill:Life~flasks24 "Passive Skill:Life~flasks24") [[7]](/wiki/Passive_Skill:Life~flasks26 "Passive Skill:Life~flasks26") [[8]](/wiki/Passive_Skill:Life~flasks29 "Passive Skill:Life~flasks29") [[9]](/wiki/Passive_Skill:Life~flasks33 "Passive Skill:Life~flasks33") [[10]](/wiki/Passive_Skill:Life~flasks38 "Passive Skill:Life~flasks38") [[11]](/wiki/Passive_Skill:Life~flasks39 "Passive Skill:Life~flasks39") [[12]](/wiki/Passive_Skill:Life~flasks4 "Passive Skill:Life~flasks4")  ---  25% increased Life Recovery from Flasks used when on [Low Life](/wiki/Low_Life "Low Life") [[3]](/wiki/Passive_Skill:Life~flasks14 "Passive Skill:Life~flasks14") [[4]](/wiki/Passive_Skill:Life~flasks17 "Passive Skill:Life~flasks17")  ---  15% increased Life Recovery from Flasks [[5]](/wiki/Passive_Skill:Life~flasks34 "Passive Skill:Life~flasks34") [[6]](/wiki/Passive_Skill:Life~flasks35 "Passive Skill:Life~flasks35") |
| [Combat Alchemy](/wiki/Combat_Alchemy/edit?redlink=1 "Combat Alchemy (page does not exist)") | 20% increased Life and Mana Recovery from Flasks 10% chance for Flasks you use to not consume Charges [[1]](/wiki/Passive_Skill:Flasks21 "Passive Skill:Flasks21") |
| [Desperate Times](/wiki/Desperate_Times/edit?redlink=1 "Desperate Times (page does not exist)") | Regenerate 1.5% of maximum Life per second while on [Low Life](/wiki/Low_Life "Low Life") 40% increased Life Recovery from Flasks used when on [Low Life](/wiki/Low_Life "Low Life") [[1]](/wiki/Passive_Skill:Life~regeneration8~ "Passive Skill:Life~regeneration8~") |
| [Efficient Alchemy](/wiki/Efficient_Alchemy/edit?redlink=1 "Efficient Alchemy (page does not exist)") | 40% increased Life and Mana Recovery from Flasks while you have an active [Charm](/wiki/Charm "Charm") 20% increased Flask and [Charm](/wiki/Charm "Charm") Charges gained [[1]](/wiki/Passive_Skill:Flasks9 "Passive Skill:Flasks9") |
| [Hale Traveller](/wiki/Hale_Traveller/edit?redlink=1 "Hale Traveller (page does not exist)") | 20% increased Life Recovery from Flasks Life Flasks gain 0.1 charges per Second [[1]](/wiki/Passive_Skill:Life~flasks5~ "Passive Skill:Life~flasks5~") |
| [Hard to Kill](/wiki/Hard_to_Kill/edit?redlink=1 "Hard to Kill (page does not exist)") | Regenerate 0.75% of maximum Life per second 40% increased Flask Life Recovery rate [[1]](/wiki/Passive_Skill:Life~regeneration17~ "Passive Skill:Life~regeneration17~") |
| [Heavy Drinker](/wiki/Heavy_Drinker/edit?redlink=1 "Heavy Drinker (page does not exist)") | 20% increased Life Recovery from Flasks Life Flasks applied to you grant [Guard](/wiki/Guard "Guard") for 4 seconds equal to 8% of the Life Recovery per Second they apply [[1]](/wiki/Passive_Skill:Life~flasks32 "Passive Skill:Life~flasks32") |
| [Nurturing Guardian](/wiki/Nurturing_Guardian/edit?redlink=1 "Nurturing Guardian (page does not exist)") | Life Recovery from your Flasks also applies to your [Companions](/wiki/Companion "Companion") [[1]](/wiki/Passive_Skill:Companions3 "Passive Skill:Companions3") |

### Flask mana recovery

| Name | Stats |
| --- | --- |
| [Energy Shield Recharge and Mana Flask Recovery](/wiki/Energy_Shield_Recharge_and_Mana_Flask_Recovery/edit?redlink=1 "Energy Shield Recharge and Mana Flask Recovery (page does not exist)") | 10% increased [Energy Shield Recharge Rate](/wiki/Energy_Shield_Recharge_Rate "Energy Shield Recharge Rate") 10% increased Mana Recovery from Flasks [[1]](/wiki/Passive_Skill:Energy~shield~recovery23 "Passive Skill:Energy~shield~recovery23") [[2]](/wiki/Passive_Skill:Energy~shield~recovery36 "Passive Skill:Energy~shield~recovery36") |
| [Flask Recovery](/wiki/Flask_Recovery/edit?redlink=1 "Flask Recovery (page does not exist)") | 10% increased Life and Mana Recovery from Flasks [[1]](/wiki/Passive_Skill:Flasks16 "Passive Skill:Flasks16") [[2]](/wiki/Passive_Skill:Flasks17 "Passive Skill:Flasks17") |
| [Life and Mana Flask Recovery](/wiki/Life_and_Mana_Flask_Recovery/edit?redlink=1 "Life and Mana Flask Recovery (page does not exist)") | 10% increased Life and Mana Recovery from Flasks [[1]](/wiki/Passive_Skill:Flasks19~ "Passive Skill:Flasks19~") [[2]](/wiki/Passive_Skill:Flasks20~ "Passive Skill:Flasks20~") |
| [Mana Flask Recovery](/wiki/Mana_Flask_Recovery/edit?redlink=1 "Mana Flask Recovery (page does not exist)") | 10% increased Mana Recovery from Flasks [[1]](/wiki/Passive_Skill:Mana~flasks1 "Passive Skill:Mana~flasks1") [[2]](/wiki/Passive_Skill:Mana~flasks3 "Passive Skill:Mana~flasks3") [[3]](/wiki/Passive_Skill:Mana~flasks4~ "Passive Skill:Mana~flasks4~") [[4]](/wiki/Passive_Skill:Mana~flasks5 "Passive Skill:Mana~flasks5") [[5]](/wiki/Passive_Skill:Mana~flasks6 "Passive Skill:Mana~flasks6") [[6]](/wiki/Passive_Skill:Mana~flasks8 "Passive Skill:Mana~flasks8") |
| [Mana Flasks](/wiki/Mana_Flasks/edit?redlink=1 "Mana Flasks (page does not exist)") | 10% increased Mana Recovery from Flasks [[1]](/wiki/Passive_Skill:Life~flasks40 "Passive Skill:Life~flasks40") [[2]](/wiki/Passive_Skill:Life~flasks41 "Passive Skill:Life~flasks41") |
| [Altered Brain Chemistry](/wiki/Altered_Brain_Chemistry/edit?redlink=1 "Altered Brain Chemistry (page does not exist)") | 25% increased Mana Recovery from Flasks 10% increased Mana Recovery Rate during Effect of any Mana Flask [[1]](/wiki/Passive_Skill:Mana~flasks10 "Passive Skill:Mana~flasks10") |
| [Combat Alchemy](/wiki/Combat_Alchemy/edit?redlink=1 "Combat Alchemy (page does not exist)") | 20% increased Life and Mana Recovery from Flasks 10% chance for Flasks you use to not consume Charges [[1]](/wiki/Passive_Skill:Flasks21 "Passive Skill:Flasks21") |
| [Efficient Alchemy](/wiki/Efficient_Alchemy/edit?redlink=1 "Efficient Alchemy (page does not exist)") | 40% increased Life and Mana Recovery from Flasks while you have an active [Charm](/wiki/Charm "Charm") 20% increased Flask and [Charm](/wiki/Charm "Charm") Charges gained [[1]](/wiki/Passive_Skill:Flasks9 "Passive Skill:Flasks9") |
| [Wellspring](/wiki/Wellspring/edit?redlink=1 "Wellspring (page does not exist)") | 30% increased Mana Recovery from Flasks 8% increased [Attack](/wiki/Attack "Attack") and Cast Speed during Effect of any Mana Flask [[1]](/wiki/Passive_Skill:Mana~flasks11 "Passive Skill:Mana~flasks11") |

### Flask charges gained

| Name | Stats |
| --- | --- |
| [Flask Charges Gained](/wiki/Flask_Charges_Gained/edit?redlink=1 "Flask Charges Gained (page does not exist)") | 10% increased Flask Charges gained [[1]](/wiki/Passive_Skill:Flasks1 "Passive Skill:Flasks1") [[2]](/wiki/Passive_Skill:Flasks15 "Passive Skill:Flasks15") [[3]](/wiki/Passive_Skill:Flasks2 "Passive Skill:Flasks2") [[4]](/wiki/Passive_Skill:Flasks3 "Passive Skill:Flasks3")  ---  15% increased Flask Charges gained [[3]](/wiki/Passive_Skill:Flasks22 "Passive Skill:Flasks22") [[4]](/wiki/Passive_Skill:Flasks23 "Passive Skill:Flasks23") |
| [Life Flask Charges](/wiki/Life_Flask_Charges/edit?redlink=1 "Life Flask Charges (page does not exist)") | 15% increased Life Flask Charges gained [[1]](/wiki/Passive_Skill:Life~flasks10 "Passive Skill:Life~flasks10") [[2]](/wiki/Passive_Skill:Life~flasks19 "Passive Skill:Life~flasks19") [[3]](/wiki/Passive_Skill:Life~flasks27~ "Passive Skill:Life~flasks27~") [[4]](/wiki/Passive_Skill:Life~flasks28 "Passive Skill:Life~flasks28") [[5]](/wiki/Passive_Skill:Life~flasks7 "Passive Skill:Life~flasks7") |
| [Mana Flask Charges](/wiki/Mana_Flask_Charges/edit?redlink=1 "Mana Flask Charges (page does not exist)") | 15% increased Mana Flask Charges gained [[1]](/wiki/Passive_Skill:Mana~flasks2 "Passive Skill:Mana~flasks2") |
| [Cautious Concoctions](/wiki/Cautious_Concoctions/edit?redlink=1 "Cautious Concoctions (page does not exist)") | 15% increased Flask Effect Duration 15% increased Flask Charges gained [[1]](/wiki/Passive_Skill:Flasks24 "Passive Skill:Flasks24") |

### Flask duration

| Name | Stats |
| --- | --- |
| [Attack Speed and Flask Duration](/wiki/Attack_Speed_and_Flask_Duration/edit?redlink=1 "Attack Speed and Flask Duration (page does not exist)") | 2% increased [Attack](/wiki/Attack "Attack") Speed 5% increased Flask Effect Duration [[1]](/wiki/Passive_Skill:Attack~speed15 "Passive Skill:Attack~speed15") [[2]](/wiki/Passive_Skill:Attack~speed16 "Passive Skill:Attack~speed16") [[3]](/wiki/Passive_Skill:Attack~speed17 "Passive Skill:Attack~speed17") |
| [Flask Duration](/wiki/Flask_Duration/edit?redlink=1 "Flask Duration (page does not exist)") | 10% increased Flask Effect Duration [[1]](/wiki/Passive_Skill:Life~flasks22 "Passive Skill:Life~flasks22") |
| [Cautious Concoctions](/wiki/Cautious_Concoctions/edit?redlink=1 "Cautious Concoctions (page does not exist)") | 15% increased Flask Effect Duration 15% increased Flask Charges gained [[1]](/wiki/Passive_Skill:Flasks24 "Passive Skill:Flasks24") |
| [Savouring](/wiki/Savouring/edit?redlink=1 "Savouring (page does not exist)") | 20% chance for Flasks you use to not consume Charges 20% increased Flask Effect Duration [[1]](/wiki/Passive_Skill:Flasks18 "Passive Skill:Flasks18") |

### Flask charges gained per second

| Name | Stats |
| --- | --- |
| [Arcane Alchemy](/wiki/Arcane_Alchemy/edit?redlink=1 "Arcane Alchemy (page does not exist)") | Mana Flasks gain 0.1 charges per Second +10 to [Intelligence](/wiki/Intelligence "Intelligence") [[1]](/wiki/Passive_Skill:Mana~flasks12 "Passive Skill:Mana~flasks12") |
| [Arcane Mixtures](/wiki/Arcane_Mixtures/edit?redlink=1 "Arcane Mixtures (page does not exist)") | 25% increased [Energy Shield Recharge Rate](/wiki/Energy_Shield_Recharge_Rate "Energy Shield Recharge Rate") Mana Flasks gain 0.1 charges per Second [[1]](/wiki/Passive_Skill:Energy~shield~recovery25~ "Passive Skill:Energy~shield~recovery25~") |
| [Hale Traveller](/wiki/Hale_Traveller/edit?redlink=1 "Hale Traveller (page does not exist)") | 20% increased Life Recovery from Flasks Life Flasks gain 0.1 charges per Second [[1]](/wiki/Passive_Skill:Life~flasks5~ "Passive Skill:Life~flasks5~") |
| [Refills](/wiki/Refills/edit?redlink=1 "Refills (page does not exist)") | Life Flasks gain 0.15 charges per Second [[1]](/wiki/Passive_Skill:Life~flasks3 "Passive Skill:Life~flasks3") |
| [Staunching](/wiki/Staunching/edit?redlink=1 "Staunching (page does not exist)") | Life Flasks gain 0.1 charges per Second +10 to [Strength](/wiki/Strength "Strength") [[1]](/wiki/Passive_Skill:Life~flasks12~ "Passive Skill:Life~flasks12~") |
| [The Ancient Serpent](/wiki/The_Ancient_Serpent/edit?redlink=1 "The Ancient Serpent (page does not exist)") | Life Flasks gain 0.1 charges per Second 40% reduced [Poison](/wiki/Poison "Poison") Duration on you +10 to [Intelligence](/wiki/Intelligence "Intelligence") [[1]](/wiki/Passive_Skill:Azmerianimals66 "Passive Skill:Azmerianimals66") |
| [Waters of Life](/wiki/Waters_of_Life/edit?redlink=1 "Waters of Life (page does not exist)") | Recover 2% of maximum Life when you use a Mana Flask Mana Flasks gain 0.1 charges per Second [[1]](/wiki/Passive_Skill:Mana~flasks14 "Passive Skill:Mana~flasks14") |

### Flask charges used

| Name | Stats |
| --- | --- |
| [Flask Charges Used](/wiki/Flask_Charges_Used/edit?redlink=1 "Flask Charges Used (page does not exist)") | 5% reduced Flask Charges used [[1]](/wiki/Passive_Skill:Flasks5 "Passive Skill:Flasks5") |
| [Mana Flask Charges Used](/wiki/Mana_Flask_Charges_Used/edit?redlink=1 "Mana Flask Charges Used (page does not exist)") | 4% reduced Flask Charges used from Mana Flasks [[1]](/wiki/Passive_Skill:Mana~flasks7 "Passive Skill:Mana~flasks7") [[2]](/wiki/Passive_Skill:Mana~flasks9 "Passive Skill:Mana~flasks9") |
| [Warding Potions](/wiki/Warding_Potions/edit?redlink=1 "Warding Potions (page does not exist)") | 10% reduced Flask Charges used from Mana Flasks Remove a [Curse](/wiki/Curse "Curse") when you use a Mana Flask [[1]](/wiki/Passive_Skill:Mana~flasks13 "Passive Skill:Mana~flasks13") |

### During flask effect

| Name | Stats |
| --- | --- |
| [Altered Brain Chemistry](/wiki/Altered_Brain_Chemistry/edit?redlink=1 "Altered Brain Chemistry (page does not exist)") | 25% increased Mana Recovery from Flasks 10% increased Mana Recovery Rate during Effect of any Mana Flask [[1]](/wiki/Passive_Skill:Mana~flasks10 "Passive Skill:Mana~flasks10") |
| [Crystal Elixir](/wiki/Crystal_Elixir/edit?redlink=1 "Crystal Elixir (page does not exist)") | 40% increased Elemental Damage with [Attack](/wiki/Attack "Attack") Skills during any Flask Effect [[1]](/wiki/Passive_Skill:Elemental~attacks9 "Passive Skill:Elemental~attacks9") |
| [Imbibed Power](/wiki/Imbibed_Power/edit?redlink=1 "Imbibed Power (page does not exist)") | 25% increased Damage during any Flask Effect 6% increased [Attack](/wiki/Attack "Attack") Speed during any Flask Effect [[1]](/wiki/Passive_Skill:Attack46 "Passive Skill:Attack46") |
| [Lavianga's Brew](/wiki/Lavianga%27s_Brew/edit?redlink=1 "Lavianga's Brew (page does not exist)") | 30% increased Mana Cost [Efficiency](/wiki/Efficiency "Efficiency") of [Attacks](/wiki/Attack "Attack") during any Mana Flask Effect [[1]](/wiki/Passive_Skill:Life~flasks42 "Passive Skill:Life~flasks42") |
| [Stimulants](/wiki/Stimulants/edit?redlink=1 "Stimulants (page does not exist)") | 16% increased [Attack](/wiki/Attack "Attack") Speed during any Flask Effect [[1]](/wiki/Passive_Skill:Attack~speed31 "Passive Skill:Attack~speed31") |
| [Succour](/wiki/Succour/edit?redlink=1 "Succour (page does not exist)") | 30% increased Life Regeneration rate during Effect of any Life Flask [[1]](/wiki/Passive_Skill:Life~flasks25~ "Passive Skill:Life~flasks25~") |
| [Tukohama's Brew](/wiki/Tukohama%27s_Brew/edit?redlink=1 "Tukohama's Brew (page does not exist)") | 50% of Skill Mana costs [Converted](/wiki/Stat_conversion "Stat conversion") to Life Costs during any Life Flask Effect [[1]](/wiki/Passive_Skill:Life~flasks43 "Passive Skill:Life~flasks43") |
| [Wellspring](/wiki/Wellspring/edit?redlink=1 "Wellspring (page does not exist)") | 30% increased Mana Recovery from Flasks 8% increased [Attack](/wiki/Attack "Attack") and Cast Speed during Effect of any Mana Flask [[1]](/wiki/Passive_Skill:Mana~flasks11 "Passive Skill:Mana~flasks11") |

### Miscellany

| Name | Stats |
| --- | --- |
| [Attack Damage while no remaining Life Flasks](/wiki/Attack_Damage_while_no_remaining_Life_Flasks/edit?redlink=1 "Attack Damage while no remaining Life Flasks (page does not exist)") | 20% increased [Attack](/wiki/Attack "Attack") Damage while you have no Life Flask uses left [[1]](/wiki/Passive_Skill:Attack40 "Passive Skill:Attack40") |
| [Blood of Rage](/wiki/Blood_of_Rage/edit?redlink=1 "Blood of Rage (page does not exist)") | Gain 8 [Rage](/wiki/Rage "Rage") when you use a Life Flask [[1]](/wiki/Passive_Skill:Life~flasks37 "Passive Skill:Life~flasks37") |
| [Combat Alchemy](/wiki/Combat_Alchemy/edit?redlink=1 "Combat Alchemy (page does not exist)") | 20% increased Life and Mana Recovery from Flasks 10% chance for Flasks you use to not consume Charges [[1]](/wiki/Passive_Skill:Flasks21 "Passive Skill:Flasks21") |
| [Heavy Drinker](/wiki/Heavy_Drinker/edit?redlink=1 "Heavy Drinker (page does not exist)") | 20% increased Life Recovery from Flasks Life Flasks applied to you grant [Guard](/wiki/Guard "Guard") for 4 seconds equal to 8% of the Life Recovery per Second they apply [[1]](/wiki/Passive_Skill:Life~flasks32 "Passive Skill:Life~flasks32") |
| [Last Stand](/wiki/Last_Stand/edit?redlink=1 "Last Stand (page does not exist)") | 25% increased [Attack](/wiki/Attack "Attack") Damage while on [Low Life](/wiki/Low_Life "Low Life") 25% increased [Attack](/wiki/Attack "Attack") Damage while [Surrounded](/wiki/Surrounded "Surrounded") 25% increased [Attack](/wiki/Attack "Attack") Damage if you have been [Heavy Stunned](/wiki/Heavy_Stun "Heavy Stun") [Recently](/wiki/Recently "Recently") 25% increased [Attack](/wiki/Attack "Attack") Damage while you have no Life Flask uses left [[1]](/wiki/Passive_Skill:Attack21 "Passive Skill:Attack21") |
| [Reinvigoration](/wiki/Reinvigoration/edit?redlink=1 "Reinvigoration (page does not exist)") | Regenerate 1% of maximum Life per Second if you've used a Life Flask in the past 10 seconds [[1]](/wiki/Passive_Skill:Life~flasks6 "Passive Skill:Life~flasks6") |
| [Savouring](/wiki/Savouring/edit?redlink=1 "Savouring (page does not exist)") | 20% chance for Flasks you use to not consume Charges 20% increased Flask Effect Duration [[1]](/wiki/Passive_Skill:Flasks18 "Passive Skill:Flasks18") |
| [Warding Potions](/wiki/Warding_Potions/edit?redlink=1 "Warding Potions (page does not exist)") | 10% reduced Flask Charges used from Mana Flasks Remove a [Curse](/wiki/Curse "Curse") when you use a Mana Flask [[1]](/wiki/Passive_Skill:Mana~flasks13 "Passive Skill:Mana~flasks13") |
| [Waters of Life](/wiki/Waters_of_Life/edit?redlink=1 "Waters of Life (page does not exist)") | Recover 2% of maximum Life when you use a Mana Flask Mana Flasks gain 0.1 charges per Second [[1]](/wiki/Passive_Skill:Mana~flasks14 "Passive Skill:Mana~flasks14") |

### Ascendancy passive skills

The following [Ascendancy passive skills](/wiki/Ascendancy_passive_skill "Ascendancy passive skill") are related to flasks:

| Ascendancy Class | Name | Stats |
| --- | --- | --- |
| [Amazon](/wiki/Amazon "Amazon") | [Flask Recovery](/wiki/Flask_Recovery/edit?redlink=1 "Flask Recovery (page does not exist)") | 15% increased Life and Mana Recovery from Flasks [[1]](/wiki/Passive_Skill:AscendancyHuntress1Small7 "Passive Skill:AscendancyHuntress1Small7")  ---  12% increased Life and Mana Recovery from Flasks [[2]](/wiki/Passive_Skill:AscendancyDruid2Small7 "Passive Skill:AscendancyDruid2Small7") |
| [Amazon](/wiki/Amazon "Amazon") | [Azmeri Brew](/wiki/Azmeri_Brew "Azmeri Brew") | Life Flasks also recover Mana Mana Flasks also recover Life [[1]](/wiki/Passive_Skill:AscendancyHuntress1Notable7 "Passive Skill:AscendancyHuntress1Notable7") |
| [Blood Mage](/wiki/Blood_Mage "Blood Mage") | [Life Flasks](/wiki/Life_Flasks/edit?redlink=1 "Life Flasks (page does not exist)") | 15% increased Life Flask Charges gained [[1]](/wiki/Passive_Skill:AscendancyWitch2Small9 "Passive Skill:AscendancyWitch2Small9") |
| [Blood Mage](/wiki/Blood_Mage "Blood Mage") | [Sanguine Tides](/wiki/Sanguine_Tides "Sanguine Tides") | Gain 1 Life Flask Charge per 4% Life spent On [Hitting](/wiki/Hit "Hit") an Enemy while a Life Flask is at full Charges, 40% of its Charges are consumed [Gain](/wiki/Gain "Gain") 1% of damage as [Physical](/wiki/Physical "Physical") damage for 3 seconds per Charge consumed this way 50% less Life Recovery from Flasks [[1]](/wiki/Passive_Skill:AscendancyWitch2Notable9 "Passive Skill:AscendancyWitch2Notable9") |
| [Pathfinder](/wiki/Pathfinder "Pathfinder") | [Life Flask Charges](/wiki/Life_Flask_Charges/edit?redlink=1 "Life Flask Charges (page does not exist)") | 20% increased Life Flask Charges gained [[1]](/wiki/Passive_Skill:AscendancyRanger3Small6 "Passive Skill:AscendancyRanger3Small6") |
| [Pathfinder](/wiki/Pathfinder "Pathfinder") | [Mana Flask Charges](/wiki/Mana_Flask_Charges/edit?redlink=1 "Mana Flask Charges (page does not exist)") | 20% increased Mana Flask Charges gained [[1]](/wiki/Passive_Skill:AscendancyRanger3Small7 "Passive Skill:AscendancyRanger3Small7") |
| [Pathfinder](/wiki/Pathfinder "Pathfinder") | [Enduring Elixirs](/wiki/Enduring_Elixirs "Enduring Elixirs") | Life Flask Effects are not removed when [Unreserved](/wiki/Reservation "Reservation") Life is Filled Life Flask Effects do not Queue [[1]](/wiki/Passive_Skill:AscendancyRanger3Notable6 "Passive Skill:AscendancyRanger3Notable6") |

### Keystones

The following [Keystones](/wiki/Keystone "Keystone") are related to flasks:

| Name | Stats |
| --- | --- |
| [Eternal Youth](/wiki/Eternal_Youth "Eternal Youth") | Life [Recharges](/wiki/Life_Recharge "Life Recharge") instead of [Energy Shield](/wiki/Energy_Shield "Energy Shield") 50% less Life Recovery from Flasks [[1]](/wiki/Passive_Skill:Passive~keystone~eternal~youth "Passive Skill:Passive~keystone~eternal~youth") |
| [Oasis](/wiki/Oasis "Oasis") | Cannot use [Charms](/wiki/Charm "Charm") 30% more Recovery from Flasks [[1]](/wiki/Passive_Skill:Passive~keystone~oasis "Passive Skill:Passive~keystone~oasis") |
| [Vaal Pact](/wiki/Vaal_Pact "Vaal Pact") | [Life Leech](/wiki/Life_Leech "Life Leech") is Instant Cannot use Life Flasks [[1]](/wiki/Passive_Skill:Passive~keystone~vaal~pact "Passive Skill:Passive~keystone~vaal~pact") |
