# Currency

Redirect to:

* [Currency item](/wiki/Currency_item "Currency item")
