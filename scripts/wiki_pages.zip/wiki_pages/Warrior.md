# Warrior

The Warrior

Gender: M
[Strength](/wiki/Strength "Strength"): 15
[Dexterity](/wiki/Dexterity "Dexterity"): 7
[Intelligence](/wiki/Intelligence "Intelligence"): 7
[Weapon](/wiki/Weapon "Weapon"): [Mace](/wiki/Gemcutting#Mace "Gemcutting")

* [Wooden Club](/wiki/Wooden_Club "Wooden Club")
* [Splintered Tower Shield](/wiki/Splintered_Tower_Shield "Splintered Tower Shield")
* [Rolling Slam](/wiki/Rolling_Slam "Rolling Slam")

[Ascendancies](/wiki/Ascendancy_class "Ascendancy class"):

[Titan](/wiki/Titan "Titan")
 [Warbringer](/wiki/Warbringer "Warbringer")
 [Smith of Kitava](/wiki/Smith_of_Kitava "Smith of Kitava")

> I wanted very little for myself. A forge, a bed. They took that all away when they burned down my home. Give me one good hammer, and they will find that there is nothing more dangerous than a man of peace roused to war.

The **Warrior** is a [strength](/wiki/Strength "Strength")-oriented [class](/wiki/Character_class "Character class") that specializes in [axe](/wiki/Axe "Axe"), [mace](/wiki/Mace "Mace"), and [shield](/wiki/Shield "Shield") skills. He is of [Karui](/wiki/Karui/edit?redlink=1 "Karui (page does not exist)") heritage, but was adopted by an [Ezomyte](/wiki/Ezomyte/edit?redlink=1 "Ezomyte (page does not exist)") [Renly](/wiki/Renly "Renly") as an orphan.

The Warrior obtains a [Wooden Club](/wiki/Wooden_Club "Wooden Club"), [Splintered Tower Shield](/wiki/Splintered_Tower_Shield "Splintered Tower Shield") and [Rolling Slam](/wiki/Rolling_Slam "Rolling Slam") as his default starting weapon set and skill in [The Riverbank](/wiki/The_Riverbank "The Riverbank").

## Ascendancy classes

Warriors can specialize into one of these three [Ascendancy classes](/wiki/Ascendancy_classes "Ascendancy classes"):

* [Warbringer](/wiki/Warbringer "Warbringer")
* [Titan](/wiki/Titan "Titan")
* [Smith of Kitava](/wiki/Smith_of_Kitava "Smith of Kitava")

## Trivia

The Warrior class was originally called "the Brute".
