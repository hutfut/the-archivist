# Interlude

**Interlude** is a temporary [act](/wiki/Act "Act"). The player and [The Hooded One](/wiki/The_Hooded_One "The Hooded One") seek out allies to recruit before heading to Oriath and wage war against the Twilight Order.

The Interlude consists of three sub-sections across three regions. These areas can be visited in any order and area levels will permanently scale with progress across the three interludes based on the number of bosses killed in the other two interludes, excluding the penultimate bosses ([Sigbert](/wiki/Sigbert "Sigbert")/[Godwin](/wiki/Godwin "Godwin") and [Stormgore](/wiki/Stormgore "Stormgore")). This results in +8 to area level by the end of the interludes.

[Resistance](/wiki/Resistance "Resistance") penalties are based on zone level, as follows:

* Level 54-59: -40%
* Level 60-64: -50%
* Level 65+: -60%

The Interlude will only be available during [Early Access](/wiki/Early_Access "Early Access"), serving to fill the gap between Act 4 and endgame. They will be removed with the release of Acts 5 and 6.

## Quests

* [Recruit the Ezomytes](/wiki/Recruit_the_Ezomytes "Recruit the Ezomytes")
* [Recruit the Maraketh](/wiki/Recruit_the_Maraketh "Recruit the Maraketh")
* [Recruit the Vaal](/wiki/Recruit_the_Vaal "Recruit the Vaal")

## Progression

### Interlude 1 - The Curse of Holten

The player returns to Ogham to recruit the Ezomytes to battle, but they must put a stop to Thane Wulfric and his mad cult's reign of terror first.

|  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| → | [The Refuge](/wiki/The_Refuge "The Refuge") | ↔ | [Scorched Farmlands](/wiki/Scorched_Farmlands "Scorched Farmlands")   54-62  Boss: [Isolde of the White Shroud](/wiki/Isolde_of_the_White_Shroud "Isolde of the White Shroud") and [Heldra of the Black Pyre](/wiki/Heldra_of_the_Black_Pyre "Heldra of the Black Pyre") | ↔ | [The Blackwood](/wiki/The_Blackwood "The Blackwood")   55-63 | ↔ | [Holten](/wiki/Holten "Holten")   55-63  Boss: [Sigbert of the Sullied Oath](/wiki/Sigbert_of_the_Sullied_Oath "Sigbert of the Sullied Oath") and [Godwin of the Shattered Creed](/wiki/Godwin_of_the_Shattered_Creed "Godwin of the Shattered Creed") | ↔ | [Holten Estate](/wiki/Holten_Estate "Holten Estate")   56-64  Boss: [Thane Wulfric](/wiki/Thane_Wulfric "Thane Wulfric") and [Lady Elswyth](/wiki/Lady_Elswyth "Lady Elswyth") |
|  |  |  | ↕ |  |  |  | ↕ |
|  |  |  | [Stones of Serle](/wiki/Stones_of_Serle "Stones of Serle")   54-62  Boss: [Siora, Blade of the Mists](/wiki/Siora,_Blade_of_the_Mists "Siora, Blade of the Mists") |  |  |  | [Wolvenhold](/wiki/Wolvenhold "Wolvenhold")   56-64  Boss: [Oswin, the Dread Warden](/wiki/Oswin,_the_Dread_Warden "Oswin, the Dread Warden") |

### Interlude 2 - The Stolen Barya

The player seeks out Sekhema Asala to enlist her aid. She aims to complete the Ritual of Water to make alliances with other Maraketh tribes, but something has interrupted the ritual.

|  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| → | [The Khari Bazaar](/wiki/The_Khari_Bazaar "The Khari Bazaar") | ↔ | [The Khari Crossing](/wiki/The_Khari_Crossing "The Khari Crossing")   54-62  Boss: [Akthi, the Final Sting](/wiki/Akthi,_the_Final_Sting "Akthi, the Final Sting") and [Anundr, the Sandworm](/wiki/Anundr,_the_Sandworm "Anundr, the Sandworm") | ↔ | [The Galai Gates](/wiki/The_Galai_Gates "The Galai Gates")   56-64  Boss: [Vornas, the Fell Flame](/wiki/Vornas,_the_Fell_Flame "Vornas, the Fell Flame") | ↔ | [Qimah](/wiki/Qimah "Qimah")   56-64 | ↔ | [Qimah Reservoir](/wiki/Qimah_Reservoir "Qimah Reservoir")   56-64  Boss: [Azmadi, the Faridun Prince](/wiki/Azmadi,_the_Faridun_Prince "Azmadi, the Faridun Prince") |
|  |  |  | ↕ |
|  |  |  | [Pools of Khatal](/wiki/Pools_of_Khatal "Pools of Khatal")   55-63 | ↔ | [Sel Khari Sanctuary](/wiki/Sel_Khari_Sanctuary "Sel Khari Sanctuary")   55-63  Boss: [Elzarah, the Cobra Lord](/wiki/Elzarah,_the_Cobra_Lord "Elzarah, the Cobra Lord") |

### Interlude 3 - Doryani's Contingency

The player makes their way up the Azmeri mountains to seek out the Cuachic Vault, where Doryani sealed away several Vaal as a contingency.

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| → | [The Glade](/wiki/The_Glade "The Glade") | ↔ | [Ashen Forest](/wiki/Ashen_Forest "Ashen Forest")   54-62 | ↔ | [Kriar Village](/wiki/Kriar_Village "Kriar Village")   54-62  Boss: [Lythara, the Wayward Spear](/wiki/Lythara,_the_Wayward_Spear "Lythara, the Wayward Spear") | ➝ | [Glacial Tarn](/wiki/Glacial_Tarn "Glacial Tarn")   55-63  Boss: [Rakkar, the Frozen Talon](/wiki/Rakkar,_the_Frozen_Talon "Rakkar, the Frozen Talon") | ↔ | [Kriar Peaks](/wiki/Kriar_Peaks "Kriar Peaks")   56-64 | ↔ | [Etched Ravine](/wiki/Etched_Ravine "Etched Ravine")   56-64  Boss: [Stormgore, the Guardian](/wiki/Stormgore,_the_Guardian "Stormgore, the Guardian") | ↔ | [The Cuachic Vault](/wiki/The_Cuachic_Vault "The Cuachic Vault")   56-64  Boss: [Zelina, Blood Priestess](/wiki/Zelina,_Blood_Priestess "Zelina, Blood Priestess") and [Zolin, Blood Priest](/wiki/Zolin,_Blood_Priest "Zolin, Blood Priest") |
|  |  |  |  |  |  |  | ↕ |
|  |  |  |  |  |  |  | [Howling Caves](/wiki/Howling_Caves "Howling Caves")   55-63  Boss: [The Abominable Yeti](/wiki/The_Abominable_Yeti "The Abominable Yeti") |
