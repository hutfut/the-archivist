# Quality

Quality

Tooltip

Quality grants small bonuses to an item depending on the type of item, up to a [maximum](/wiki/Maximum_Quality/edit?redlink=1 "Maximum Quality (page does not exist)").

[Martial Weapons](/wiki/Martial_Weapons "Martial Weapons") gain 1% more [Physical](/wiki/Physical "Physical") damage per Quality.
Armours gain 1% more [Defences](/wiki/Defences "Defences") per Quality.
Rings and Amulets have a number of possible quality types that provide bonuses to specific modifiers on the item.
[Flasks](/wiki/Flask "Flask") gain 1% more Life and Mana recovery per Quality.
[Charms](/wiki/Charm "Charm") gain 1% increased duration per Quality.
Skill Gems or equipment that grant Skills grant a specific bonus to their Skill based on their Quality.

**Quality** is a stat that improves the signature stats of an [Equipment](/wiki/Equipment "Equipment") or adds additional bonuses to [Skill Gems](/wiki/Skill_Gem "Skill Gem"). Each item type has a [Currency Item](/wiki/Currency "Currency") associated with it that increases its Quality.

## Mechanics

Quality can be applied to most [Equipment](/wiki/Equipment "Equipment") ([Quivers](/wiki/Quiver "Quiver"), [Jewels](/wiki/Jewel "Jewel"), and [Belts](/wiki/Belt "Belt") are the exceptions), [Flasks](/wiki/Flask "Flask"), [Charms](/wiki/Charm "Charm"), and [Skill Gems](/wiki/Skill_Gem "Skill Gem"). Any item with at least 1% quality will state "Superior" in front of the base type when dropped on the ground but not when in your inventory.

Quality is a unique multiplier, applying its effect to the related stat after all other modifiers, including [Corruption](/wiki/Corrupted "Corrupted")/[Sanctification](/wiki/Sanctified "Sanctified") magnitude modifiers. Once Quality is applied, the values are then truncated.

### Amount

All Items that can have Quality applied to it have a default limit of 20% Quality. Certain effects allow Quality to be increased beyond this limit. Quality cannot go below 0%.

When applying Quality to an item using Currency, the Equipment's [Item Level](/wiki/Item_level "Item level") will determine how much Quality you get. The higher the Item Level, the less Quality each Currency Item will apply.

[Gemcutter's Prisms](/wiki/Gemcutter%27s_Prism "Gemcutter's Prism") always add 5% Quality to Skill Gems.

### Obtaining items with over 20% quality

* Normal and Unique equipment (including boss drops) of at least item level 78 can rarely drop with Quality over 20% (up to 30%). These items will have the "Exceptional" prefix in front of the base type until it is upgraded/identified.
* [Corrupting](/wiki/Corrupted "Corrupted") a Flask, Charm, or Skill Gem may cause it to gain or lose up to 10% Quality, and can exceed the 20% limit, up to 23%.
* [Breach Rings](/wiki/Breach_Ring "Breach Ring") have an implicit modifier that increases its maximum quality to 40%.
* A [Vaal Infuser](/wiki/Vaal_Infuser "Vaal Infuser") can increase an equipment's quality by a random amount, capping at 30%. This process has a chance to corrupt the item, but won't modify it unpredictably.

### Skill gems

All [Skill Gems](/wiki/Skill_Gem "Skill Gem") have varying Quality effects, providing bonuses to that skill. [Skill Gems](/wiki/Skill_Gem "Skill Gem") cannot drop with Quality, due to the fact that [Uncut Gems](/wiki/Uncut_Gem "Uncut Gem") do not have Quality. [Support Gems](/wiki/Gem#Support_gems "Gem") cannot have Quality added to them.

Effects which grant a global increase to Gem Quality apply independently of the default 20% limit. Quality above 20% continue to add to these bonuses.

### Ascendancy skills

Skills granted by [Ascendancy class](/wiki/Ascendancy_class "Ascendancy class") passives cannot have Quality added to them using Currency. The only way to add Quality to these skills is with modifiers that grant a Global Quality increase to skills (e.g. [The Cunning Fox](/wiki/The_Cunning_Fox "The Cunning Fox")), and support gems that add quality to the socketed skill (e.g. [Dialla's Desire](/wiki/Dialla%27s_Desire "Dialla's Desire")).

### Skills granted through items

Adding Quality to items that grant an [Inherent Skill](/wiki/Granted_skills "Granted skills") as an implicit modifier, also adds Quality to the attached Skill.

* [Inherent Skills](/wiki/Granted_skill "Granted skill") from Amulets do not inherit the Quality of the Amulet.

### Equipment

* [Martial Weapons](/wiki/Martial_Weapon "Martial Weapon") gain more base Physical Damage with Quality. Any Non-Physical Damage on the weapon, whether as Added Damage or as a hidden [damage conversion](/wiki/Damage_conversion "Damage conversion") modifier, does not get increased.

* [Wands](/wiki/Wand "Wand"), [Staves](/wiki/Staff "Staff"), and [Sceptres](/wiki/Sceptre "Sceptre") do not gain any stats from Quality. Their [Inherent Skills](/wiki/Granted_skill "Granted skill") receive the Quality instead.

* [Armour (equipment)](/wiki/Armour_(equipment) "Armour (equipment)") gain more base [Defence](/wiki/Defence "Defence") with Quality.

### Charms

Charm Quality increases the Local Duration of the Charm, making the effect last for longer. Charms can naturally drop with Quality, although there is no way to manually add Quality to it at the moment. However their Quality can be modified through [Corruption](/wiki/Corrupted "Corrupted"), potentially adding/removing Quality.

### Amulets and rings

[Catalysts](/wiki/Catalyst "Catalyst") are used to add Quality to Amulets and Rings, up to a maximum of 20%. These currency items vary in effects, and using a different type overrides the previous Quality effect.

[Breach Rings](/wiki/Breach_Ring "Breach Ring") are special, as they can have up to 40% quality.

## Quality effects

| Item type | Currency | Effect per % quality |
| --- | --- | --- |
| [Martial weapons](/wiki/Martial_weapon "Martial weapon") | [Blacksmith's Whetstone](/wiki/Blacksmith%27s_Whetstone "Blacksmith's Whetstone") | 1% more local Physical Damage |
| [Wands](/wiki/Wand "Wand"), [Sceptres](/wiki/Sceptre "Sceptre"), and [Staves](/wiki/Staff "Staff") | [Arcanist's Etcher](/wiki/Arcanist%27s_Etcher "Arcanist's Etcher") | +1% to inherent skill quality[[a]](#cite_note-Skill_quality-1) |
| [Armour (equipment)](/wiki/Armour_(equipment) "Armour (equipment)") | [Armourer's Scrap](/wiki/Armourer%27s_Scrap "Armourer's Scrap") | 1% more local [Defence](/wiki/Defence "Defence") |
| [Amulets](/wiki/Amulet "Amulet") and [Rings](/wiki/Ring "Ring") | [Catalyst](/wiki/Catalyst "Catalyst") | 1% increased modifier magnitude Modifier tag varies by catalyst |
| [Flasks](/wiki/Flask "Flask") | [Glassblower's Bauble](/wiki/Glassblower%27s_Bauble "Glassblower's Bauble") | 1% more local Life/Mana Recovery |
| [Charms](/wiki/Charm "Charm") |  | 1% increased local Duration |
| [Skill gems](/wiki/Skill_gem "Skill gem") | [Gemcutter's Prism](/wiki/Gemcutter%27s_Prism "Gemcutter's Prism") | Varies by skill |

## Related items

### Base items

| Item |  | Stats |
| --- | --- | --- |
| [Breach Ring](/wiki/Breach_Ring "Breach Ring") | 40 | Maximum Quality is 40% |

### Unique items

No results found

## Related support gems

| Gem | Stats |  |  |  |
| --- | --- | --- | --- | --- |
| [Dialla's Desire](/wiki/Dialla%27s_Desire "Dialla's Desire") | *+1 to Level of Supported Skill Gems +10% to Quality of Supported Skills* |  |  |  |

## Related passive skills

| Name | Stats |
| --- | --- |
| [The Cunning Fox](/wiki/The_Cunning_Fox "The Cunning Fox") | +5% to Quality of all Skills [[1]](/wiki/Passive_Skill:Azmerianimals24~ "Passive Skill:Azmerianimals24~") |

### Ascendancy passive skills

| Ascendancy Class | Name | Stats |
| --- | --- | --- |
| [Gemling Legionnaire](/wiki/Gemling_Legionnaire "Gemling Legionnaire") | [Skill Gem Quality](/wiki/Skill_Gem_Quality/edit?redlink=1 "Skill Gem Quality (page does not exist)") | +2% to Quality of all Skills [[1]](/wiki/Passive_Skill:AscendancyMercenary3Small1 "Passive Skill:AscendancyMercenary3Small1") [[2]](/wiki/Passive_Skill:AscendancyMercenary3Small2 "Passive Skill:AscendancyMercenary3Small2") [[3]](/wiki/Passive_Skill:AscendancyMercenary3Small4 "Passive Skill:AscendancyMercenary3Small4") |
| [Gemling Legionnaire](/wiki/Gemling_Legionnaire "Gemling Legionnaire") | [Crystalline Potential](/wiki/Crystalline_Potential "Crystalline Potential") | +10% to Quality of all Skills [[1]](/wiki/Passive_Skill:AscendancyMercenary3Notable1~ "Passive Skill:AscendancyMercenary3Notable1~") |

## Notes

1. [↑](#cite_ref-Skill_quality_1-0) As of [version 0.2.0](/wiki/Version_0.2.0 "Version 0.2.0"), inherent skills found on [wands](/wiki/Wand "Wand"), [sceptres](/wiki/Sceptre "Sceptre"), and [staves](/wiki/Staves "Staves") now gain an equivalent amount of quality as the weapon itself. This is correctly reflected in the Skills Panel, but is currently not reflected in the gem's hover tooltip.[Likely due to a [bug](https://www.pathofexile.com/forum/view-forum/2214)] Global quality effects apply to Wand/Sceptres/Staves and are reflected in both gem's hover tooltip as well as Skills Panel.
