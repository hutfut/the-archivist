# Interlude 2

Redirect to:

* [Interlude#Interlude 2 - The Stolen Barya](/wiki/Interlude#Interlude_2_-_The_Stolen_Barya "Interlude")
