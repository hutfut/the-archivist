# Tactician

Tactician

[Mercenary](/wiki/Mercenary "Mercenary")

|  |  |
| --- | --- |
|  | **Countless wars have left you with skills somewhat resembling a decent officer...** |

Official artwork of the Tactician.

**Tactician** is an [Ascendancy class](/wiki/Ascendancy_class "Ascendancy class") for the [Mercenary](/wiki/Mercenary "Mercenary").

## Overview

The Tactician is a class specializing in defenses and empowering [allies](/wiki/Ally "Ally"). He has access to lower [reservation](/wiki/Reservation "Reservation") costs and the ability to give bonus damage to allies using his weapon or placing down [Banners](/wiki/Banner "Banner") without limit. The Tactician can specialize in crowd control, improving his ability to [immobilise](/wiki/Immobilise "Immobilise") enemies and turn [Pin](/wiki/Pin "Pin") into a full disable. He also lends well to [Armour](/wiki/Armour "Armour")/[Evasion](/wiki/Evasion "Evasion") hybrid builds and enhancing the survivability they provide. He can also specialize in [totems](/wiki/Totem "Totem") or call down [Supporting Fire](/wiki/Supporting_Fire "Supporting Fire") to rain down a volley of arrows on his foes.

## Passive skills

### Minor skills

This class has the following minor passive skills:

| Name | Stats |
| --- | --- |
| [Armour and Evasion](/wiki/Armour_and_Evasion/edit?redlink=1 "Armour and Evasion (page does not exist)") | 15% increased [Armour](/wiki/Armour "Armour") and [Evasion](/wiki/Evasion "Evasion") Rating [[1]](/wiki/Passive_Skill:AscendancyMercenary1Small6 "Passive Skill:AscendancyMercenary1Small6") [[2]](/wiki/Passive_Skill:AscendancyMercenary1Small7~ "Passive Skill:AscendancyMercenary1Small7~") |
| [Banner Area](/wiki/Banner_Area/edit?redlink=1 "Banner Area (page does not exist)") | [Banner](/wiki/Banner "Banner") Skills have 20% increased Area of Effect [[1]](/wiki/Passive_Skill:AscendancyMercenary1Small2 "Passive Skill:AscendancyMercenary1Small2") |
| [Minion Damage](/wiki/Minion_Damage/edit?redlink=1 "Minion Damage (page does not exist)") | [Minions](/wiki/Minion "Minion") deal 20% increased Damage [[1]](/wiki/Passive_Skill:AscendancyMercenary1Small9 "Passive Skill:AscendancyMercenary1Small9") |
| [Pin Buildup](/wiki/Pin_Buildup/edit?redlink=1 "Pin Buildup (page does not exist)") | 20% increased [Pin](/wiki/Pinned "Pinned") Buildup [[1]](/wiki/Passive_Skill:AscendancyMercenary1Small4 "Passive Skill:AscendancyMercenary1Small4") [[2]](/wiki/Passive_Skill:AscendancyMercenary1Small5~ "Passive Skill:AscendancyMercenary1Small5~") |
| [Presence Area](/wiki/Presence_Area/edit?redlink=1 "Presence Area (page does not exist)") | 20% increased [Presence](/wiki/Presence "Presence") Area of Effect [[1]](/wiki/Passive_Skill:AscendancyMercenary1Small3 "Passive Skill:AscendancyMercenary1Small3") |
| [Spirit](/wiki/Spirit "Spirit") | 8% increased [Spirit](/wiki/Spirit "Spirit") [[1]](/wiki/Passive_Skill:AscendancyMercenary1Small1 "Passive Skill:AscendancyMercenary1Small1") |
| [Totem Damage](/wiki/Totem_Damage/edit?redlink=1 "Totem Damage (page does not exist)") | 20% increased [Totem](/wiki/Totem "Totem") Damage [[1]](/wiki/Passive_Skill:AscendancyMercenary1Small10 "Passive Skill:AscendancyMercenary1Small10") [[2]](/wiki/Passive_Skill:AscendancyMercenary1Small8 "Passive Skill:AscendancyMercenary1Small8") |

### Notable skills

This class has the following notable passive skills:

| Skill | Modifiers | Prerequisite | Preceding Passive |
| --- | --- | --- | --- |
| [A Solid Plan](/wiki/A_Solid_Plan "A Solid Plan") | [Persistent](/wiki/Persistent "Persistent") [Buffs](/wiki/Buffs "Buffs") have 50% less [Reservation](/wiki/Reservation "Reservation") | — | Spirit |
| [Watch How I Do It](/wiki/Watch_How_I_Do_It "Watch How I Do It") | [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") gain added [Attack](/wiki/Attack "Attack") Damage equal to 25% of your main hand Weapon's Damage | [A Solid Plan](/wiki/A_Solid_Plan "A Solid Plan") | Presence Area |
| [Whoever Pays Best](/wiki/Whoever_Pays_Best "Whoever Pays Best") | There is no [Limit](/wiki/Limit "Limit") on the number of [Banners](/wiki/Banner "Banner") you can place [Banners](/wiki/Banner "Banner") gain 5 [Glory](/wiki/Glory "Glory") per second | [A Solid Plan](/wiki/A_Solid_Plan "A Solid Plan") | Banner Area |
| [Suppressing Fire](/wiki/Suppressing_Fire "Suppressing Fire") | 40% more [Immobilisation](/wiki/Immobilised "Immobilised") buildup | — | Pin Buildup |
| [Right Where We Want Them](/wiki/Right_Where_We_Want_Them "Right Where We Want Them") | [Pinned](/wiki/Pinned "Pinned") enemies cannot perform actions [Projectile](/wiki/Projectile "Projectile") Damage builds [Pin](/wiki/Pinned "Pinned") | [Suppressing Fire](/wiki/Suppressing_Fire "Suppressing Fire") | Pin Buildup |
| [Polish That Gear](/wiki/Polish_That_Gear "Polish That Gear") | Gain [Deflection Rating](/wiki/Deflect "Deflect") equal to 20% of [Armour](/wiki/Armour "Armour") [Gain](/wiki/Gain "Gain") 100% of [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") as extra [Ailment Threshold](/wiki/Ailment_Threshold "Ailment Threshold") | — | Armour and Evasion |
| [Stay Light, Use Cover](/wiki/Stay_Light,_Use_Cover "Stay Light, Use Cover") | Defend with 200% of [Armour](/wiki/Armour "Armour") Enemies have an [Accuracy](/wiki/Accuracy "Accuracy") Penalty against you based on Distance Maximum Chance to [Evade](/wiki/Evasion "Evasion") is 50% Maximum [Physical Damage](/wiki/Physical_Damage "Physical Damage") Reduction is 50% | [Polish That Gear](/wiki/Polish_That_Gear "Polish That Gear") | Armour and Evasion |
| [Unleash Hell!](/wiki/Unleash_Hell! "Unleash Hell!") | Grants Skill: [Supporting Fire](/wiki/Supporting_Fire "Supporting Fire") | — | Minion Damage |
| [Cannons, Ready!](/wiki/Cannons,_Ready! "Cannons, Ready!") | Skills used by [Totems](/wiki/Totem "Totem") have 30% more [Skill Speed](/wiki/Skill_Speed "Skill Speed") [Totems](/wiki/Totem "Totem") only use Skills when you fire an [Attack](/wiki/Attack "Attack") [Projectile](/wiki/Projectile "Projectile") +1 to maximum number of Summoned [Totems](/wiki/Totem "Totem") | — | Totem Damage |
| [Strategic Embankments](/wiki/Strategic_Embankments "Strategic Embankments") | [Totems](/wiki/Totem "Totem") you place grant [Embankment Auras](/wiki/Embankment_Auras "Embankment Auras") | [Cannons, Ready!](/wiki/Cannons,_Ready! "Cannons, Ready!") | Totem Damage |
