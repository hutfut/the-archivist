# Monk

The Monk

Gender: M
[Strength](/wiki/Strength "Strength"): 7
[Dexterity](/wiki/Dexterity "Dexterity"): 11
[Intelligence](/wiki/Intelligence "Intelligence"): 11
[Weapon](/wiki/Weapon "Weapon"): [Quarterstaff](/wiki/Gemcutting#Quarterstaff "Gemcutting")

* [Wrapped Quarterstaff](/wiki/Wrapped_Quarterstaff "Wrapped Quarterstaff")
* [Falling Thunder](/wiki/Falling_Thunder "Falling Thunder")

[Ascendancies](/wiki/Ascendancy_class "Ascendancy class"):

[Invoker](/wiki/Invoker "Invoker")
 [Acolyte of Chayula](/wiki/Acolyte_of_Chayula "Acolyte of Chayula")

> My life has been naught but discipline and focus, preparing me for this. I fight for the Benevolent Dreamer. Free my hands, and those who seek chaos will fall before me!

The **Monk** is a [dexterity](/wiki/Dexterity "Dexterity")/[intelligence](/wiki/Intelligence "Intelligence")-oriented [class](/wiki/Character_class "Character class") that specializes in [unarmed](/wiki/Unarmed "Unarmed") and [quarterstaff](/wiki/Quarterstaff "Quarterstaff") skills.

The Monk obtains a [Wrapped Quarterstaff](/wiki/Wrapped_Quarterstaff "Wrapped Quarterstaff") and [Falling Thunder](/wiki/Falling_Thunder "Falling Thunder") as his default starting weapon and skill in [The Riverbank](/wiki/The_Riverbank "The Riverbank").

## Ascendancy classes

Monks can specialize into one of these three [Ascendancy classes](/wiki/Ascendancy_classes "Ascendancy classes"):

* [Invoker](/wiki/Invoker "Invoker")
* [Acolyte of Chayula](/wiki/Acolyte_of_Chayula "Acolyte of Chayula")
* TBA
