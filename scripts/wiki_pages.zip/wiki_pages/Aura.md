# Aura

Auras

Tooltip

Auras apply [Buffs](/wiki/Buffs "Buffs") to [Allies](/wiki/Allies "Allies") within a radius, or [Debuffs](/wiki/Debuff "Debuff") to enemies within a radius of the source of the Aura.

**Auras** are [skills](/wiki/Skill "Skill") that apply [buffs](/wiki/Buff "Buff") to [Allies](/wiki/Allies "Allies") within a radius, or [debuffs](/wiki/Debuff "Debuff") to [enemies](/wiki/Enemies "Enemies") within your [Presence](/wiki/Presence "Presence") radius.

## Related skills

The following [skills](/wiki/Skill "Skill") have the Aura [gem tag](/wiki/Gem_tag "Gem tag"):

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |

### Persistent skills

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Discipline](/wiki/Discipline "Discipline") | *0* |  |  |  |
| [Fulmination](/wiki/Fulmination "Fulmination") | *0* |  |  |  |
| [Heart of Ice](/wiki/Heart_of_Ice "Heart of Ice") | *0* |  |  |  |
| [Impurity](/wiki/Impurity "Impurity") | *0* |  |  |  |
| [Malice](/wiki/Malice "Malice") | *0* |  |  |  |
| [Purity of Fire](/wiki/Purity_of_Fire "Purity of Fire") | *0* |  |  |  |
| [Purity of Ice](/wiki/Purity_of_Ice "Purity of Ice") | *0* |  |  |  |
| [Purity of Lightning](/wiki/Purity_of_Lightning "Purity of Lightning") | *0* |  |  |  |
| [Withering Presence](/wiki/Withering_Presence "Withering Presence") | *4* |  |  |  |
| [War Banner](/wiki/War_Banner "War Banner") | *4* |  |  |  |
| [Blasphemy](/wiki/Blasphemy "Blasphemy") | *8* |  |  |  |
| [Defiance Banner](/wiki/Defiance_Banner "Defiance Banner") | *8* |  |  |  |
| [Overwhelming Presence](/wiki/Overwhelming_Presence "Overwhelming Presence") | *8* |  |  |  |
| [Alchemist's Boon](/wiki/Alchemist%27s_Boon "Alchemist's Boon") | *14* |  |  |  |
| [Dread Banner](/wiki/Dread_Banner "Dread Banner") | *14* |  |  |  |

## Support gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |

## Related unique items

No results found

## Related passive skills

The following [passive skills](/wiki/Passive_skill "Passive skill") are related to auras:

| Name | Stats |
| --- | --- |
| [Aura Effect](/wiki/Aura_Effect/edit?redlink=1 "Aura Effect (page does not exist)") | Aura Skills have 5% increased [Magnitudes](/wiki/Magnitude "Magnitude") [[1]](/wiki/Passive_Skill:Auras1 "Passive Skill:Auras1") [[2]](/wiki/Passive_Skill:Auras14 "Passive Skill:Auras14") [[3]](/wiki/Passive_Skill:Auras26 "Passive Skill:Auras26") [[4]](/wiki/Passive_Skill:Auras27 "Passive Skill:Auras27") [[5]](/wiki/Passive_Skill:Auras29 "Passive Skill:Auras29") [[6]](/wiki/Passive_Skill:Auras3 "Passive Skill:Auras3") [[7]](/wiki/Passive_Skill:Auras4 "Passive Skill:Auras4") |
| [Aura Magnitude](/wiki/Aura_Magnitude/edit?redlink=1 "Aura Magnitude (page does not exist)") | Aura Skills have 5% increased [Magnitudes](/wiki/Magnitude "Magnitude") [[1]](/wiki/Passive_Skill:Azmerianimals57 "Passive Skill:Azmerianimals57") [[2]](/wiki/Passive_Skill:Azmerianimals58 "Passive Skill:Azmerianimals58") |
| [Banner Aura Effect](/wiki/Banner_Aura_Effect/edit?redlink=1 "Banner Aura Effect (page does not exist)") | Banner Skills have 12% increased Aura [Magnitudes](/wiki/Magnitude "Magnitude") [[1]](/wiki/Passive_Skill:Banners2 "Passive Skill:Banners2") [[2]](/wiki/Passive_Skill:Banners8 "Passive Skill:Banners8") |
| [Bolstering Presence](/wiki/Bolstering_Presence/edit?redlink=1 "Bolstering Presence (page does not exist)") | Aura Skills have 12% increased [Magnitudes](/wiki/Magnitude "Magnitude") [[1]](/wiki/Passive_Skill:Auras18 "Passive Skill:Auras18") |
| [Enveloping Presence](/wiki/Enveloping_Presence/edit?redlink=1 "Enveloping Presence (page does not exist)") | 30% increased [Presence](/wiki/Presence "Presence") Area of Effect Aura Skills have 6% increased [Magnitudes](/wiki/Magnitude "Magnitude") [[1]](/wiki/Passive_Skill:Auras17 "Passive Skill:Auras17") |
| [Lone Warrior](/wiki/Lone_Warrior/edit?redlink=1 "Lone Warrior (page does not exist)") | Aura Skills have 14% increased [Magnitudes](/wiki/Magnitude "Magnitude") Your Aura [Buffs](/wiki/Buffs "Buffs") do not affect [Allies](/wiki/Allies "Allies") [[1]](/wiki/Passive_Skill:Auras30 "Passive Skill:Auras30") |
| [The Howling Primate](/wiki/The_Howling_Primate/edit?redlink=1 "The Howling Primate (page does not exist)") | 15% increased [Presence](/wiki/Presence "Presence") Area of Effect Aura Skills have 10% increased [Magnitudes](/wiki/Magnitude "Magnitude") +10 to [Intelligence](/wiki/Intelligence "Intelligence") [[1]](/wiki/Passive_Skill:Azmerianimals60~ "Passive Skill:Azmerianimals60~") |
