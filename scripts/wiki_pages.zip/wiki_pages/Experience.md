# Experience

✍️This article is a [stub](/wiki/Category:Stubs "Category:Stubs"). Please help [improve the article](https://www.poe2wiki.net/wiki/Experience/edit) by expanding it.

**Experience** is granted to [characters](/wiki/Character "Character") whenever they kill [monsters](/wiki/Monster "Monster"). The amount earned depends on the level and rarity of the monster.

Gaining enough experience allows a character to [level](/wiki/Character_level "Character level") up. The amount of experience needed increases with each level.

[Characters](/wiki/Character "Character") lose an amount of experience equal to 10% of the current level if they die in any area accessed by a [map device](/wiki/Map_device "Map device"). This experience loss cannot result in a change of character [level](/wiki/Character_level "Character level").

## Related unique items

| Item |  | Stats |
| --- | --- | --- |
| [Cornathaum](/wiki/Cornathaum "Cornathaum") | 33 | (10-20)% increased [Rarity of Items](/wiki/Rarity "Rarity") found +(40-50) to [Intelligence](/wiki/Intelligence "Intelligence") 30% increased [Light Radius](/wiki/Light_Radius "Light Radius") 5% increased Experience gain |
