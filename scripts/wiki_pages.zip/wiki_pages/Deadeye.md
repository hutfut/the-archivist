# Deadeye

Deadeye

[Ranger](/wiki/Ranger "Ranger")

|  |  |
| --- | --- |
|  | **A woman can change the world with a single well-placed arrow.** |

Official artwork of the Deadeye.

**Deadeye** is an [Ascendancy class](/wiki/Ascendancy_class "Ascendancy class") for the [Ranger](/wiki/Ranger "Ranger").

## Overview

The Deadeye is a class focused around ranged offense. She can make her [projectile](/wiki/Projectile "Projectile") skills more effective by giving them more damage at close or far range and adding an extra projectile. The Deadeye can also gain access to [Tailwind](/wiki/Tailwind "Tailwind"), which improves her speed, evasion, and deflection amount as long as she avoids taking damage, or improve her [frenzy charge](/wiki/Frenzy_charge "Frenzy charge") generation and consumption. The Deadeye can also specialize in [marks](/wiki/Mark "Mark") by learning [Called Shots](/wiki/Called_Shots "Called Shots") to autonomously apply marks on enemies or [Bullseye](/wiki/Bullseye "Bullseye") to apply [Critical Weakness](/wiki/Critical_Weakness "Critical Weakness") to marked enemies. She can also summon mirages that fire more projectiles with [Mirage Deadeye](/wiki/Mirage_Deadeye "Mirage Deadeye").

## Passive skills

### Minor skills

This class has the following minor passive skills:

| Name | Stats |
| --- | --- |
| [Frenzy Charge Duration](/wiki/Frenzy_Charge_Duration/edit?redlink=1 "Frenzy Charge Duration (page does not exist)") | 25% increased [Frenzy Charge](/wiki/Frenzy_Charge "Frenzy Charge") Duration [[1]](/wiki/Passive_Skill:AscendancyRanger1Small5 "Passive Skill:AscendancyRanger1Small5") [[2]](/wiki/Passive_Skill:AscendancyRanger1Small6 "Passive Skill:AscendancyRanger1Small6") |
| [Mark Effect](/wiki/Mark_Effect/edit?redlink=1 "Mark Effect (page does not exist)") | 12% increased Effect of your [Mark](/wiki/Mark "Mark") Skills [[1]](/wiki/Passive_Skill:AscendancyRanger1Small4 "Passive Skill:AscendancyRanger1Small4") [[2]](/wiki/Passive_Skill:AscendancyRanger1Small7 "Passive Skill:AscendancyRanger1Small7") |
| [Projectile Damage](/wiki/Projectile_Damage/edit?redlink=1 "Projectile Damage (page does not exist)") | 12% increased [Projectile](/wiki/Projectile "Projectile") Damage [[1]](/wiki/Passive_Skill:AscendancyRanger1Small8 "Passive Skill:AscendancyRanger1Small8") |
| [Projectile Speed](/wiki/Projectile_Speed/edit?redlink=1 "Projectile Speed (page does not exist)") | 10% increased [Projectile](/wiki/Projectile "Projectile") Speed [[1]](/wiki/Passive_Skill:AscendancyRanger1Small1~~ "Passive Skill:AscendancyRanger1Small1~~") [[2]](/wiki/Passive_Skill:AscendancyRanger1Small2 "Passive Skill:AscendancyRanger1Small2") |
| [Skill Speed](/wiki/Skill_Speed "Skill Speed") | 4% increased [Skill Speed](/wiki/Skill_Speed "Skill Speed") [[1]](/wiki/Passive_Skill:AscendancyRanger1Small3 "Passive Skill:AscendancyRanger1Small3") |

### Notable skills

This class has the following notable passive skills:

| Skill | | Modifiers | Prerequisite | Preceding Passive |
| --- | --- | --- | --- | --- |
| [Avidity](/wiki/Avidity "Avidity") | | 50% chance when you gain a [Frenzy Charge](/wiki/Frenzy_Charge "Frenzy Charge") to gain an additional [Frenzy Charge](/wiki/Frenzy_Charge "Frenzy Charge") | — | [Frenzy Charge Duration](/wiki/Frenzy_Charge_Duration_(ascendancy_passive_skill) "Frenzy Charge Duration (ascendancy passive skill)") |
| [Thrilling Chase](/wiki/Thrilling_Chase "Thrilling Chase") | | Benefits from consuming [Frenzy Charges](/wiki/Frenzy_Charge "Frenzy Charge") for your Skills have 50% chance to be doubled | [Avidity](/wiki/Avidity "Avidity") | [Frenzy Charge Duration](/wiki/Frenzy_Charge_Duration_(ascendancy_passive_skill) "Frenzy Charge Duration (ascendancy passive skill)") |
| [Mirage Deadeye](/wiki/Mirage_Deadeye_(passive) "Mirage Deadeye (passive)") | | Grants Skill: [Mirage Deadeye](/wiki/Mirage_Deadeye "Mirage Deadeye") | — | Projectile Damage |
| [Projectile Proximity Specialisation](/wiki/Projectile_Proximity_Specialisation "Projectile Proximity Specialisation") | [Point Blank](/wiki/Point_Blank "Point Blank") | [Projectiles](/wiki/Projectile "Projectile") deal 20% more [Hit](/wiki/Hit "Hit") damage to targets in the first 3.5 metres of their movement, scaling down with distance travelled to reach 0% after 7 metres | — | [Projectile Speed](/wiki/Projectile_Speed_(ascendancy_passive_skill) "Projectile Speed (ascendancy passive skill)") |
| [Far Shot](/wiki/Far_Shot "Far Shot") | [Projectiles](/wiki/Projectile "Projectile") deal 0% more [Hit](/wiki/Hit "Hit") damage to targets in the first 3.5 metres of their movement, scaling up with distance travelled to reach 20% after 7 metres |
| [Endless Munitions](/wiki/Endless_Munitions "Endless Munitions") | | Skills fire an additional [Projectile](/wiki/Projectile "Projectile") | [Projectile Proximity Specialisation](/wiki/Projectile_Proximity_Specialisation "Projectile Proximity Specialisation") | [Projectile Speed](/wiki/Projectile_Speed_(ascendancy_passive_skill) "Projectile Speed (ascendancy passive skill)") |
| [Gathering Winds](/wiki/Gathering_Winds "Gathering Winds") | | Gain [Tailwind](/wiki/Tailwind "Tailwind") on Skill use Lose all [Tailwind](/wiki/Tailwind "Tailwind") when [Hit](/wiki/Hit "Hit") | — | [Skill Speed](/wiki/Skill_Speed_(ascendancy_passive_skill) "Skill Speed (ascendancy passive skill)") |
| [Called Shots](/wiki/Called_Shots_(passive) "Called Shots (passive)") | | Grants Skill: [Called Shots](/wiki/Called_Shots "Called Shots") | — | [Mark Effect](/wiki/Mark_Effect_(ascendancy_passive_skill) "Mark Effect (ascendancy passive skill)") |
| [Bullseye](/wiki/Bullseye "Bullseye") | | Apply 10 [Critical Weakness](/wiki/Critical_Weakness "Critical Weakness") to Enemies when [Consuming](/wiki/Effect_Consumption "Effect Consumption") a [Mark](/wiki/Mark "Mark") on them | [Called Shots](/wiki/Called_Shots "Called Shots") | [Mark Effect](/wiki/Mark_Effect_(ascendancy_passive_skill) "Mark Effect (ascendancy passive skill)") |
