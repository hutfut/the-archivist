# Heavy Stun

Redirect to:

* [Stun#Heavy stun](/wiki/Stun#Heavy_stun "Stun")
