# Gemling Legionnaire

Gemling Legionnaire

[Mercenary](/wiki/Mercenary "Mercenary")

|  |  |
| --- | --- |
|  | **The more you embrace virtue gems, the more power they offer...** |

Official artwork of the Gemling Legionnaire.

**Gemling Legionnaire** is an [Ascendancy class](/wiki/Ascendancy_class "Ascendancy class") for the [Mercenary](/wiki/Mercenary "Mercenary").

## Overview

The Gemling Legionnaire is a class that's all about enhancing the power and functionality of [gems](/wiki/Gem "Gem"). The Gemling Legionnaire's passives can not only improve the level and quality of his gems, he can also gain a variety of bonuses based on his gem configuration, gaining offensive or defensive bonuses or [charge](/wiki/Charge "Charge") generation depending on gem colour. The class also lends well to builds that stack a large amount of [attributes](/wiki/Attribute "Attribute").

## Passive skills

### Minor skills

This class has the following minor passive skills:

| Name | Stats |
| --- | --- |
| [Attributes](/wiki/Attributes_(ascendancy_passive_skill) "Attributes (ascendancy passive skill)") | 3% increased [Attributes](/wiki/Attributes "Attributes") [[1]](/wiki/Passive_Skill:AscendancyMercenary3Small5 "Passive Skill:AscendancyMercenary3Small5") [[2]](/wiki/Passive_Skill:AscendancyMercenary3Small6 "Passive Skill:AscendancyMercenary3Small6") |
| [Reduced Attribute Requirements](/wiki/Reduced_Attribute_Requirements/edit?redlink=1 "Reduced Attribute Requirements (page does not exist)") | Equipment and Skill Gems have 4% reduced [Attribute](/wiki/Attribute "Attribute") Requirements [[1]](/wiki/Passive_Skill:AscendancyMercenary3Small3 "Passive Skill:AscendancyMercenary3Small3") [[2]](/wiki/Passive_Skill:AscendancyMercenary3Small7~ "Passive Skill:AscendancyMercenary3Small7~") [[3]](/wiki/Passive_Skill:AscendancyMercenary3Small8 "Passive Skill:AscendancyMercenary3Small8") |
| [Skill Gem Quality](/wiki/Skill_Gem_Quality/edit?redlink=1 "Skill Gem Quality (page does not exist)") | +2% to [Quality](/wiki/Quality "Quality") of all Skills [[1]](/wiki/Passive_Skill:AscendancyMercenary3Small1 "Passive Skill:AscendancyMercenary3Small1") [[2]](/wiki/Passive_Skill:AscendancyMercenary3Small2 "Passive Skill:AscendancyMercenary3Small2") [[3]](/wiki/Passive_Skill:AscendancyMercenary3Small4 "Passive Skill:AscendancyMercenary3Small4") |

### Notable skills

This class has the following notable passive skills:

| Skill | | Modifiers | Prerequisite | Preceding Passive |
| --- | --- | --- | --- | --- |
| [Crystalline Potential](/wiki/Crystalline_Potential "Crystalline Potential") | | +10% to [Quality](/wiki/Quality "Quality") of all Skills | — | [Skill Gem Quality](/wiki/Skill_Gem_Quality_(ascendancy_passive_skill) "Skill Gem Quality (ascendancy passive skill)") |
| [Implanted Gems](/wiki/Implanted_Gems "Implanted Gems") | [Bolstering Implants](/wiki/Bolstering_Implants "Bolstering Implants") | +2 to Level of all Skills with a [Strength](/wiki/Strength "Strength") requirement | [Crystalline Potential](/wiki/Crystalline_Potential "Crystalline Potential") | [Skill Gem Quality](/wiki/Skill_Gem_Quality_(ascendancy_passive_skill) "Skill Gem Quality (ascendancy passive skill)") |
| [Motoric Implants](/wiki/Motoric_Implants "Motoric Implants") | +2 to Level of all Skills with a [Dexterity](/wiki/Dexterity "Dexterity") requirement |
| [Neurological Implants](/wiki/Neurological_Implants "Neurological Implants") | +2 to Level of all Skills with an [Intelligence](/wiki/Intelligence "Intelligence") requirement |
| [Advanced Thaumaturgy](/wiki/Advanced_Thaumaturgy "Advanced Thaumaturgy") | | Grants [Thaumaturgical Dynamism](/wiki/Thaumaturgical_Dynamism "Thaumaturgical Dynamism") | [Crystalline Potential](/wiki/Crystalline_Potential "Crystalline Potential") | [Skill Gem Quality](/wiki/Skill_Gem_Quality_(ascendancy_passive_skill) "Skill Gem Quality (ascendancy passive skill)") |
| [Gem Studded](/wiki/Gem_Studded "Gem Studded") | | For each colour of Socketed Support Gem that is most numerous, gain: •Red: [Hits](/wiki/Hit "Hit") against you have no [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus") •Blue: Skills have 30% less cost •Green: 40% less Movement Speed Penalty from using Skills while Moving | — | [Reduced Attribute Requirements](/wiki/Reduced_Attribute_Requirements_(ascendancy_passive_skill) "Reduced Attribute Requirements (ascendancy passive skill)") |
| [Integrated Efficiency](/wiki/Integrated_Efficiency "Integrated Efficiency") | | Skills deal 20% increased Damage per [Connected](/wiki/Connected_Support_Gems "Connected Support Gems") Red [Support Gem](/wiki/Support_Gem "Support Gem") Skills have 6% increased [Skill Speed](/wiki/Skill_Speed "Skill Speed") per [Connected](/wiki/Connected_Support_Gems "Connected Support Gems") Green [Support Gem](/wiki/Support_Gem "Support Gem") Skills have 20% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") per [Connected](/wiki/Connected_Support_Gems "Connected Support Gems") Blue [Support Gem](/wiki/Support_Gem "Support Gem") | [Gem Studded](/wiki/Gem_Studded "Gem Studded") | [Reduced Attribute Requirements](/wiki/Reduced_Attribute_Requirements_(ascendancy_passive_skill) "Reduced Attribute Requirements (ascendancy passive skill)") |
| [Thaumaturgical Infusion](/wiki/Thaumaturgical_Infusion "Thaumaturgical Infusion") | | +1% to [Maximum Fire Resistance](/wiki/Maximum_Fire_Resistance "Maximum Fire Resistance") per 3 Red [Support Gems](/wiki/Support_Gem "Support Gem") Socketed +1% to [Maximum Lightning Resistance](/wiki/Maximum_Lightning_Resistance "Maximum Lightning Resistance") per 3 Green [Support Gems](/wiki/Support_Gem "Support Gem") Socketed +1% to [Maximum Cold Resistance](/wiki/Maximum_Cold_Resistance "Maximum Cold Resistance") per 3 Blue [Support Gems](/wiki/Support_Gem "Support Gem") Socketed | [Gem Studded](/wiki/Gem_Studded "Gem Studded") | [Reduced Attribute Requirements](/wiki/Reduced_Attribute_Requirements_(ascendancy_passive_skill) "Reduced Attribute Requirements (ascendancy passive skill)") |
| [Adaptive Capability](/wiki/Adaptive_Capability "Adaptive Capability") | | [Attribute](/wiki/Attribute "Attribute") Requirements of Gems can be satisified by your highest Attribute | — | [Attributes](/wiki/Attributes_(ascendancy_passive_skill) "Attributes (ascendancy passive skill)") |
| [Enhanced Effectiveness](/wiki/Enhanced_Effectiveness "Enhanced Effectiveness") | | Inherent bonuses gained from [Attributes](/wiki/Attributes "Attributes") are doubled 20% less [Attributes](/wiki/Attributes "Attributes") | [Adaptive Capability](/wiki/Adaptive_Capability "Adaptive Capability") | [Attributes](/wiki/Attributes_(ascendancy_passive_skill) "Attributes (ascendancy passive skill)") |
