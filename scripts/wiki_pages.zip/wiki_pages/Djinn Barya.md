# Djinn Barya

Djinn BaryaArea Level: #
Number of Trials: #"Take me to the Trial of the Sekhemas.
I will serve."Take this item to the Relic Altar at the Trial of the Sekhemas.

*Acquisition*
Drop level: *24**Metadata*
Item class: *Trial Coin*
Metadata ID: *Metadata/Items/Sanctum/SanctumKey*

**Djinn Barya** is an item that can be used to gain entry to the [Trial of the Sekhemas](/wiki/Trial_of_the_Sekhemas "Trial of the Sekhemas"). Higher levels of Djinn Barya increase the number of trial floors up to a maximum of 4.

## Mechanics

Djinn Baryas can range from Area Level 24 to 80. The number of Trials corresponds to the Area Level:

* Area Level 24-44: 1 Trial
* Area Level 45-59: 2 Trials
* Area Level 60-74: 3 Trials
* Area Level 75-80: 4 Trials

## Item acquisition

Djinn Barya can drop anywhere.
