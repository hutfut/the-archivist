# Titan

Titan

[Warrior](/wiki/Warrior "Warrior")

|  |  |
| --- | --- |
|  | **Incredible might has always laid buried within you. Now is the time to rise.** |

Official artwork of the Titan.

**Titan** is an [Ascendancy class](/wiki/Ascendancy_class "Ascendancy class") for the [Warrior](/wiki/Warrior "Warrior").

## Overview

The Titan is a class that possesses tremendous vitality and might. He can deliver powerful [slams](/wiki/Slam "Slam") that can be ancestrally boosted and leave extra aftershocks, and improve his [Heavy Stuns](/wiki/Heavy_Stun "Heavy Stun") by making them easier to apply and dealing more damage to stunned enemies. The Titan can also be built to be very resilient with access to more [life](/wiki/Life "Life") and [armour](/wiki/Armour "Armour"). He can also gain extra inventory space from [Colossal Capacity](/wiki/Colossal_Capacity "Colossal Capacity"), which unlocks the ability to improve the power of his small passive skills from [Hulking Form](/wiki/Hulking_Form "Hulking Form").

## Passive skills

### Minor skills

This class has the following minor passive skills:

| Name | Stats |
| --- | --- |
| [Armour](/wiki/Armour "Armour") | 20% increased [Armour](/wiki/Armour "Armour") [[1]](/wiki/Passive_Skill:AscendancyWarrior1Small8 "Passive Skill:AscendancyWarrior1Small8") |
| [Life Regeneration](/wiki/Life_Regeneration/edit?redlink=1 "Life Regeneration (page does not exist)") | Regenerate 0.5% of maximum Life per second [[1]](/wiki/Passive_Skill:AscendancyWarrior1Small7 "Passive Skill:AscendancyWarrior1Small7") |
| [Slam Area of Effect](/wiki/Slam_Area_of_Effect/edit?redlink=1 "Slam Area of Effect (page does not exist)") | [Slam](/wiki/Slam "Slam") Skills have 8% increased Area of Effect [[1]](/wiki/Passive_Skill:AscendancyWarrior1Small1 "Passive Skill:AscendancyWarrior1Small1") [[2]](/wiki/Passive_Skill:AscendancyWarrior1Small2 "Passive Skill:AscendancyWarrior1Small2") |
| [Strength](/wiki/Strength "Strength") | 4% increased [Strength](/wiki/Strength "Strength") [[1]](/wiki/Passive_Skill:AscendancyWarrior1Small5 "Passive Skill:AscendancyWarrior1Small5") [[2]](/wiki/Passive_Skill:AscendancyWarrior1Small6 "Passive Skill:AscendancyWarrior1Small6") |
| [Stun Buildup](/wiki/Stun_Buildup/edit?redlink=1 "Stun Buildup (page does not exist)") | 18% increased [Stun](/wiki/Stun "Stun") Buildup [[1]](/wiki/Passive_Skill:AscendancyWarrior1Small3 "Passive Skill:AscendancyWarrior1Small3") [[2]](/wiki/Passive_Skill:AscendancyWarrior1Small4 "Passive Skill:AscendancyWarrior1Small4") |

### Notable skills

This class has the following notable passive skills:

| Skill | Modifiers | Prerequisite | Preceding Passive |
| --- | --- | --- | --- |
| [Stone Skin](/wiki/Stone_Skin "Stone Skin") | 50% more [Armour](/wiki/Armour "Armour") from Equipped Body Armour | — | [Armour](/wiki/Armour_(ascendancy_passive_skill) "Armour (ascendancy passive skill)") |
| [Earthbreaker](/wiki/Earthbreaker "Earthbreaker") | 25% chance for [Slam](/wiki/Slam "Slam") Skills you use yourself to cause an additional [Aftershock](/wiki/Aftershock "Aftershock") | — | [Slam Area of Effect](/wiki/Slam_Area_of_Effect_(ascendancy_passive_skill) "Slam Area of Effect (ascendancy passive skill)") |
| [Ancestral Empowerment](/wiki/Ancestral_Empowerment "Ancestral Empowerment") | Every second [Slam](/wiki/Slam "Slam") Skill you use yourself is [Ancestrally Boosted](/wiki/Ancestrally_Boosted "Ancestrally Boosted") | [Earthbreaker](/wiki/Earthbreaker "Earthbreaker") | [Slam Area of Effect](/wiki/Slam_Area_of_Effect_(ascendancy_passive_skill) "Slam Area of Effect (ascendancy passive skill)") |
| [Colossal Capacity](/wiki/Colossal_Capacity "Colossal Capacity") | Carry a Chest which adds 20 Inventory Slots | — | [Strength](/wiki/Strength_(ascendancy_passive_skill) "Strength (ascendancy passive skill)") |
| [Hulking Form](/wiki/Hulking_Form "Hulking Form") | 50% increased effect of [Small Passive](/wiki/Small_Passives/edit?redlink=1 "Small Passives (page does not exist)") Skills | [Colossal Capacity](/wiki/Colossal_Capacity "Colossal Capacity") | [Strength](/wiki/Strength_(ascendancy_passive_skill) "Strength (ascendancy passive skill)") |
| [Mysterious Lineage](/wiki/Mysterious_Lineage "Mysterious Lineage") | 15% more Maximum Life | — | [Life Regeneration](/wiki/Life_Regeneration_(ascendancy_passive_skill) "Life Regeneration (ascendancy passive skill)") |
| [Crushing Impacts](/wiki/Crushing_Impacts "Crushing Impacts") | Your [Hits](/wiki/Hit "Hit") are [Crushing Blows](/wiki/Crushing_Blow "Crushing Blow") 25% more Damage against [Heavy Stunned](/wiki/Heavy_Stun "Heavy Stun") Enemies | — | [Stun Buildup](/wiki/Stun_Buildup_(ascendancy_passive_skill) "Stun Buildup (ascendancy passive skill)") |
| [Mountain Splitter](/wiki/Mountain_Splitter "Mountain Splitter") | Every Third [Slam](/wiki/Slam "Slam") skill that doesn't create Fissures which you use yourself causes 3 additional [Aftershocks](/wiki/Aftershock "Aftershock") ahead and to each side of the initial area | [Crushing Impact](/wiki/Crushing_Impact "Crushing Impact") | [Stun Buildup](/wiki/Stun_Buildup_(ascendancy_passive_skill) "Stun Buildup (ascendancy passive skill)") |
