# Early Access

**Early Access** refers to [the period](/wiki/Version_history#Early_Access "Version history") of [Path of Exile 2](/wiki/Path_of_Exile_2 "Path of Exile 2") between the first release of the game for public download on December 6, 2024, to the official release of the game in [Version 1.0.0](/wiki/Version_1.0.0/edit?redlink=1 "Version 1.0.0 (page does not exist)").

## Eligibility

In order to play Early Access, players have to redeem a key on the official website that can be obtained through a few methods:

* Have spent a total of $480 USD equivalent or more on micro-transactions on an account during the lifetime of [Path of Exile](/wiki/Path_of_Exile "Path of Exile") prior to the release of the new Supporter Packs for the second game[[1]](#cite_note-1)
* Purchase the first tier ($30 USD) or higher Core Path of Exile 2 Access Supporter Pack launched prior to the release of Early Access[[2]](#cite_note-2)
* Gifted by GGG to users with significant contributions to the game/community eg. Streamers, Tool developers and Youtubers.

Random keys may also be given away throughout the Early Access period.

A PC, Xbox Series X, or PlayStation 5 is required to play. Early Access Keys do not transfer across platforms. If you want to play Path of Exile 2 Early Access on a certain platform (PC / PlayStation / Xbox), you will need to purchase a Supporter Pack on that same platform. PlayStation Plus is not required for the early access, Xbox Game Pass Core is required.

Additional information can be found in the official [FAQ](https://www.pathofexile.com/forum/view-thread/3587981).

## Major features

Early Access launched with six [character classes](/wiki/Character_classes "Character classes"), each with two distinct [ascendancies](/wiki/Ascendancy_class "Ascendancy class"):

* [Warrior](/wiki/Warrior "Warrior"): [Titan](/wiki/Titan "Titan") and [Warbringer](/wiki/Warbringer "Warbringer")
* [Ranger](/wiki/Ranger "Ranger"): [Deadeye](/wiki/Deadeye "Deadeye") and [Pathfinder](/wiki/Pathfinder "Pathfinder")
* [Witch](/wiki/Witch "Witch"): [Infernalist](/wiki/Infernalist "Infernalist") and [Blood Mage](/wiki/Blood_Mage "Blood Mage")
* [Sorceress](/wiki/Sorceress "Sorceress"): [Stormweaver](/wiki/Stormweaver "Stormweaver") and [Chronomancer](/wiki/Chronomancer "Chronomancer")
* [Mercenary](/wiki/Mercenary "Mercenary"): [Witchhunter](/wiki/Witchhunter "Witchhunter") and [Gemling Legionnaire](/wiki/Gemling_Legionnaire "Gemling Legionnaire")
* [Monk](/wiki/Monk "Monk"): [Invoker](/wiki/Invoker "Invoker") and [Acolyte of Chayula](/wiki/Acolyte_of_Chayula "Acolyte of Chayula")

Additional classes, ascendancies, campaign acts, and endgame content will be released in subsequent patches leading up to the official release.

Previously purchased [stash tabs](/wiki/Stash_tab "Stash tab") and [microtransactions](/wiki/Microtransaction "Microtransaction") from [Path of Exile 1](/wiki/Path_of_Exile_1 "Path of Exile 1") that are compatible with content released in Path of Exile 2 are automatically applied from the start of Early Access.

## Game structure

Early Access launched with Acts 1, 2, and 3.

To bridge the temporary gap between Act 3 and endgame content, the players would repeat Acts 1-3 in [Cruel](/wiki/Cruel "Cruel") difficulty, with scaled up enemies and new item drops.

In [Version 0.3.0](/wiki/Version_0.3.0 "Version 0.3.0"), the Cruel difficulty was removed and replaced with three [Interlude](/wiki/Interludes "Interludes") acts to temporarily bridge the gap between Act 4 and endgame.

## Unreleased content

The following is a list of content not available to Path of Exile 2 at the moment, but are expected to release at or before the official release.

* Acts 5-6
* Third [Ascension Trial](/wiki/Ascension_Trial "Ascension Trial")
* [Divination cards](/wiki/Divination_card "Divination card")

### Classes

* [Marauder](/wiki/Marauder "Marauder")
* [Duelist](/wiki/Duelist "Duelist")
* [Templar](/wiki/Templar "Templar")
* [Shadow](/wiki/Shadow "Shadow")
* 3rd Ascendancy class for [Ranger](/wiki/Ranger "Ranger"), [Monk](/wiki/Monk "Monk"), [Huntress](/wiki/Huntress "Huntress"), and [Druid](/wiki/Druid "Druid")

### Weapons

* [Sword](/wiki/Sword "Sword")
* [Axe](/wiki/Axe "Axe")
* [Dagger](/wiki/Dagger "Dagger")
* [Flail](/wiki/Flail "Flail")
* [Trap](/wiki/Trap "Trap")

### Skills

* Skills for unreleased classes/weapons

## Trivia

The Early Access launch was originally scheduled for November 15, 2024, but was pushed out 3 weeks to December 6 due to the GGG team needing more time for backend activities with cross-platform account merging.
