# Crafting

**Crafting** is a mechanic in [Path of Exile 2](/wiki/Path_of_Exile_2 "Path of Exile 2") that involves using [currency](/wiki/Currency "Currency") or certain game mechanics to modify the inherit stats and [modifiers](/wiki/Modifiers "Modifiers") of [items](/wiki/Item "Item"). Almost all items can be "crafted" to change and enhance the item- the current exceptions being [corrupted](/wiki/Corrupted "Corrupted") and [mirrored](/wiki/Mirrored "Mirrored") items, which because of their status as "corrupted" or "mirrored" cannot have normal crafting currencies or processes done upon them (Note: it is still possible to add [runes](/wiki/Runes "Runes") and [soul cores](/wiki/Soul_cores "Soul cores") to their rune sockets).

## Mechanics

The process of crafting is the addition or augmentation of [modifiers](/wiki/Modifiers "Modifiers") (or the rerolling of the value of those modifiers- see [§ Randomising numerical values](#Randomising_numerical_values)) onto an item through various chance-based or deterministic steps. Certain currencies and crafting items can alter the odds for a specific outcome to occur.

### Upgrading rarity

"Upgrading" refers to changing an item's rarity.

| Currency | Restrictions | Effects |
| --- | --- | --- |
| [Orb of Transmutation](/wiki/Orb_of_Transmutation "Orb of Transmutation") | Only usable on normal items | Upgrades an item from normal to magic, adding 1 modifier |
| [Orb of Alchemy](/wiki/Orb_of_Alchemy "Orb of Alchemy") | Only usable on normal items Cannot be used on [flasks](/wiki/Flask "Flask")/[charms](/wiki/Charm "Charm")/[relics](/wiki/Relic "Relic") | Upgrades an item from normal to rare, adding 4 modifiers |
| [Orb of Chance](/wiki/Orb_of_Chance "Orb of Chance") | Only usable on normal items | Either upgrades an item from normal to unique or destroys it |
| [Regal Orb](/wiki/Regal_Orb "Regal Orb") | Only usable on magic items | Upgrades an item from magic to rare, adding 1 modifier |
| Regular [Essence](/wiki/Essence "Essence") | Only usable on normal items | Upgrades an item from normal to magic, adding one modifier of a certain modifier tag |
| Greater [Essence](/wiki/Essence "Essence") | Only usable on magic items | Upgrades an item from magic to rare, adding one modifier of a certain modifier tag |
| [Vaal Orb](/wiki/Vaal_Orb "Vaal Orb") |  | [Corrupts](/wiki/Corrupted "Corrupted") an item; has a chance to upgrade [waystones](/wiki/Waystone "Waystone") into rare |

Other methods to involving upgrading an item's rarity include:

* [Omens](/wiki/Omen "Omen"):
  + [Omen of Sinistral Alchemy](/wiki/Omen_of_Sinistral_Alchemy "Omen of Sinistral Alchemy") causes the next used Orb of Alchemy to add the maximum number of prefix modifiers.
  + [Omen of Dextral Alchemy](/wiki/Omen_of_Dextral_Alchemy "Omen of Dextral Alchemy") causes the next used Orb of Alchemy to add the maximum number of suffix modifiers.
  + [Omen of Sinistral Coronation](/wiki/Omen_of_Sinistral_Coronation "Omen of Sinistral Coronation") causes the next used Regal Orb to add a prefix modifier.
  + [Omen of Dextral Coronation](/wiki/Omen_of_Dextral_Coronation "Omen of Dextral Coronation") causes the next used Regal Orb to add a suffix modifier.

### Augmenting and removing modifiers

"Augmenting" refers to adding an explicit modifier to an item without changing its rarity. Magic items (this includes almost all [flasks](/wiki/Flasks "Flasks"), [charms](/wiki/Charms "Charms"), and [relics](/wiki/Relics "Relics")) have a default modifier limit of 2 (1 prefix and 1 suffix) , while almost all rare items have a default modifier limit of 6 (3 prefixes and 3 suffixes)- the exception being rare jewels, which have a limit of 4 (2 prefixes and 2 suffixes).

| Currency | Restrictions | Effects |
| --- | --- | --- |
| [Orb of Augmentation](/wiki/Orb_of_Augmentation "Orb of Augmentation") | Only usable on magic items | Adds an explicit modifier to a magic item, up to its modifier limit |
| [Exalted Orb](/wiki/Exalted_Orb "Exalted Orb") | Only usable on rare items | Adds an explicit modifier to a rare item, up to its modifier limit |
| [Orb of Annulment](/wiki/Orb_of_Annulment "Orb of Annulment") | Only usable on magic or rare items | Removes an explicit modifier from a magic or rare item without affecting rarity |
| [Chaos Orb](/wiki/Chaos_Orb "Chaos Orb") | Only usable on magic or rare items | Removes an explicit modifier from a magic or rare item without affecting rarity, then adds an explicit modifier. |
| [Vaal Orb](/wiki/Vaal_Orb "Vaal Orb") |  | [Corrupts](/wiki/Corrupted "Corrupted") an item; has a chance to reroll up to 3 random modifiers on [equipment](/wiki/Equipment "Equipment") and [jewels](/wiki/Jewel "Jewel"); has a chance to add or remove an extra explicit modifier on [jewels](/wiki/Jewel "Jewel"), bypassing modifier limits |

Other methods to augment or remove modifiers on items include:

* [Omens](/wiki/Omen "Omen"):
  + [Omen of Greater Exaltation](/wiki/Omen_of_Greater_Exaltation "Omen of Greater Exaltation") causes the next used Exalted Orb to add two modifiers.
  + [Omen of Sinistral Exaltation](/wiki/Omen_of_Sinistral_Exaltation "Omen of Sinistral Exaltation") causes the next used Exalted Orb to add a prefix modifier.
  + [Omen of Dextral Exaltation](/wiki/Omen_of_Dextral_Exaltation "Omen of Dextral Exaltation") causes the next used Exalted Orb to add a suffix modifier.
  + [Omen of Greater Annulment](/wiki/Omen_of_Greater_Annulment "Omen of Greater Annulment") causes the next used Orb of Annulment to remove two modifiers.
  + [Omen of Sinistral Annulment](/wiki/Omen_of_Sinistral_Annulment "Omen of Sinistral Annulment") causes the next used Orb of Annulment to remove a prefix modifier.
  + [Omen of Dextral Annulment](/wiki/Omen_of_Dextral_Annulment "Omen of Dextral Annulment") causes the next used Orb of Annulment to remove a suffix modifier.
  + [Omen of Sinistral Erasure](/wiki/Omen_of_Sinistral_Erasure "Omen of Sinistral Erasure") causes the next used Chaos Orb to remove a prefix modifier.
  + [Omen of Dextral Erasure](/wiki/Omen_of_Dextral_Erasure "Omen of Dextral Erasure") causes the next used Chaos Orb to remove a suffix modifier.
  + [Omen of Whittling](/wiki/Omen_of_Whittling "Omen of Whittling") causes the next used Chaos Orb to remove the lowest level modifier.

### Randomising numerical values

Certain currencies can adjust the numerical values of stats found on items within a designated range without reforging or changing their current modifiers.

| Currency | Restrictions | Effects |
| --- | --- | --- |
| [Divine Orb](/wiki/Divine_Orb "Divine Orb") |  | Randomises the values of implicit and explicit modifiers |
| [Vaal Orb](/wiki/Vaal_Orb "Vaal Orb") |  | [Corrupts](/wiki/Corrupted "Corrupted") an item; has a chance to randomise the values of explicit modifiers, then apply a 1.22-0.78x explicit modifier magnitude multiplier |

### Modifying quality

[Quality](/wiki/Quality "Quality") affects certain inherent stats of an item. The amount of quality gained on using quality currency depends on the [item level](/wiki/Item_level "Item level") of the item or if the item is unique.

| Currency | Restrictions | Effects |
| --- | --- | --- |
| [Armourer's Scrap](/wiki/Armourer%27s_Scrap "Armourer's Scrap") | Only usable on armours | Improves quality of an armour, causing it to have more base defences. |
| [Blacksmith's Whetstone](/wiki/Blacksmith%27s_Whetstone "Blacksmith's Whetstone") | Only usable on martial weapons | Improves quality of a martial weapon, causing it to have more base physical damage. |
| [Arcanist's Etcher](/wiki/Arcanist%27s_Etcher "Arcanist's Etcher") | Only usable on [wands](/wiki/Wand "Wand"), [sceptres](/wiki/Sceptre "Sceptre"), and [staves](/wiki/Staves "Staves") | Improves quality of a caster weapon. |
| [Glassblower's Bauble](/wiki/Glassblower%27s_Bauble "Glassblower's Bauble") | Only usable on flasks | Improves quality of a flask, causing it to recover more mana or life per second. |
| [Gemcutter's Prism](/wiki/Gemcutter%27s_Prism "Gemcutter's Prism") | Only usable on gems | Improves quality of a gem. |
| [Catalysts](/wiki/Catalyst "Catalyst") | Only usable on rings or amulets | Improves quality of rings and amulets and adds a random quality type, enhancing the magnitude of modifiers with certain modifier tags. The default maximum is 20%. |
| [Vaal Orb](/wiki/Vaal_Orb "Vaal Orb") |  | [Corrupts](/wiki/Corrupted "Corrupted") an item; has a chance to add or remove up to 10% quality from caster weapons, [gems](/wiki/Gem "Gem"), [flasks](/wiki/Flask "Flask"), and [charms](/wiki/Charm "Charm"), up to a maximum of 23% |

### Modifying sockets

[Skill gems](/wiki/Skill_gem "Skill gem") can have up to 5 sockets for [support gems](/wiki/Support_gem "Support gem") or other skill gems in the case of meta gems.

[Weapon](/wiki/Weapon "Weapon") and [armour](/wiki/Armour_(equipment) "Armour (equipment)") items have sockets which can be modified to socket [runes](/wiki/Rune "Rune") or [soul cores](/wiki/Soul_core "Soul core"). Certain [jewellery](/wiki/Jewellery "Jewellery") base types may also have a socket.

| Currency | Restrictions | Effects |
| --- | --- | --- |
| [Lesser Jeweller's Orb](/wiki/Lesser_Jeweller%27s_Orb "Lesser Jeweller's Orb") | Only usable on skill gems with 2 sockets | Adds a gem socket to a skill gem, causing it to have 3 sockets |
| [Greater Jeweller's Orb](/wiki/Greater_Jeweller%27s_Orb "Greater Jeweller's Orb") | Only usable on skill gems with 3 sockets | Adds a gem socket to a skill gem, causing it to have 4 sockets |
| [Perfect Jeweller's Orb](/wiki/Perfect_Jeweller%27s_Orb "Perfect Jeweller's Orb") | Only usable on skill gems with 4 sockets | Adds a gem socket to a skill gem, causing it to have the maximum 5 sockets |
| [Artificer's Orb](/wiki/Artificer%27s_Orb "Artificer's Orb") | Only usable on martial weapon and armour equipment | Adds an item socket up to the item's maximum: 2 for [two-handed](/wiki/Two-handed "Two-handed") weapons or body armours, 1 for [one-handed](/wiki/One-handed "One-handed") weapons and other types of armour |
| [Vaal Orb](/wiki/Vaal_Orb "Vaal Orb") |  | [Corrupts](/wiki/Corrupted "Corrupted") an item; has a chance to add or remove an item socket to [armour](/wiki/Armour_(equipment) "Armour (equipment)") and [martial weapons](/wiki/Martial_weapon "Martial weapon"), ignoring the socket limit |

### Enchantments

Certain currencies can add an [enchantment](/wiki/Enchantment "Enchantment") to an item which are separate from implicit or explicit modifiers.

| Currency | Restrictions | Effects |
| --- | --- | --- |
| [Rune](/wiki/Rune "Rune") | Only usable on equipment with sockets | When inserted into an item socket, permanently adds a specific enchantment modifier. These modifiers are typically generic stats. Runes cannot be removed once socketed. |
| [Soul Core](/wiki/Soul_Core "Soul Core") | Only usable on equipment with sockets | When inserted into an item socket, permanently adds a specific enchantment modifier. These modifiers are typically rare or unusual stats. Soul Cores cannot be removed once socketed. |
| [Distilled Emotion](/wiki/Distilled_Emotion "Distilled Emotion") | Only usable on amulets or [waystones](/wiki/Waystone "Waystone") | Amulet: instilling a combination of three distilled emotions adds or replaces an enchantment that grants a [notable](/wiki/Notable "Notable") passive skill Waystones: instilling a combination of one to three emotions adds or replaces an enchantment that adds layers of [Delirium](/wiki/Delirium "Delirium") and reward modifiers on a waystone affecting the [map](/wiki/Map "Map") you open. |
| [Vaal Orb](/wiki/Vaal_Orb "Vaal Orb") |  | [Corrupts](/wiki/Corrupted "Corrupted") an item; has a chance to add a special Vaal enchantment to [equipment](/wiki/Equipment "Equipment") and [jewels](/wiki/Jewel "Jewel") |

### Miscellaneous

The following currencies provide unique crafting effects.

| Currency | Restrictions | Effects |
| --- | --- | --- |
| [Vaal Orb](/wiki/Vaal_Orb "Vaal Orb") |  | For a full list of effects, see [Corrupted](/wiki/Corrupted "Corrupted") |
| [Mirror of Kalandra](/wiki/Mirror_of_Kalandra "Mirror of Kalandra") |  | Creates a [mirrored](/wiki/Mirrored "Mirrored") copy of an item with reflected artwork. The mirrored copy cannot be modified. |

Other miscellaneous crafting methods include:

* [Omens](/wiki/Omen "Omen"):
  + [Omen of Corruption](/wiki/Omen_of_Corruption "Omen of Corruption") causes the next used Vaal Orb will be more unpredictable (typically removing the chance for no change to occur).

### Crafting benches and vendors

Crafting benches are interactable objects that provide a variety of different crafting options, and may offer exclusive effects or a greater degree of control with crafting.

* [Gwennen](/wiki/Gwennen "Gwennen") - unlocked through [Expedition](/wiki/Expedition "Expedition") encounters, Gwennen offers specially crafted [weapons](/wiki/Weapon "Weapon"), [quivers](/wiki/Quiver "Quiver"), and [foci](/wiki/Foci "Foci") by spending [Broken Circle Artifacts](/wiki/Broken_Circle_Artifact "Broken Circle Artifact") and [Exotic Coinage](/wiki/Exotic_Coinage "Exotic Coinage").
* [Rog](/wiki/Rog "Rog") - unlocked through [Expedition](/wiki/Expedition "Expedition") encounters, Rog offers specially crafted [armour](/wiki/Armour_(equipment) "Armour (equipment)") and [shields](/wiki/Shield "Shield") by spending [Order Artifacts](/wiki/Order_Artifact "Order Artifact") and [Exotic Coinage](/wiki/Exotic_Coinage "Exotic Coinage").
* [Tujen](/wiki/Tujen "Tujen") - unlocked through [Expedition](/wiki/Expedition "Expedition") encounters, Tujen offers specially crafted [jewellery](/wiki/Jewellery "Jewellery") by spending [Black Scythe Artifacts](/wiki/Black_Scythe_Artifact "Black Scythe Artifact") and [Exotic Coinage](/wiki/Exotic_Coinage "Exotic Coinage").
* [Salvage Bench](/wiki/Salvage_Bench "Salvage Bench") - unlocked through [Finding the Forge](/wiki/Finding_the_Forge "Finding the Forge"), converts armour or weapons with quality or rune sockets into their respective quality currency. Does not work on flasks, jewellery, or gems. Does not refund socketed currency.
* [Reforging Bench](/wiki/Reforging_Bench "Reforging Bench") - destroys three items of the same [base type](/wiki/Base_type/edit?redlink=1 "Base type (page does not exist)"), providing a similar item back. Can be used to upgrade or randomize certain items like [Distilled Emotions](/wiki/Distilled_Emotion "Distilled Emotion") (+1 tier), [waystones](/wiki/Waystone "Waystone") (+1 tier), [Essences](/wiki/Essence "Essence") (random), or [Catalysts](/wiki/Catalyst "Catalyst") (random).
* Corruption Altar - found in [Jiquani's Sanctum](/wiki/Jiquani%27s_Sanctum "Jiquani's Sanctum"), functions identically to a [Vaal Orb](/wiki/Vaal_Orb "Vaal Orb"). Can only be used once per character.
