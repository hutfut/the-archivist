# Damage

**Damage** is the process by which a player or monster's [life](/wiki/Life "Life") or [energy shield](/wiki/Energy_shield "Energy shield") is reduced.

Damage is always one of 5 damage types: [physical](/wiki/Physical "Physical"), [chaos](/wiki/Chaos "Chaos"), [fire](/wiki/Fire "Fire"), [cold](/wiki/Cold "Cold") or [lightning](/wiki/Lightning "Lightning").

Damage can be mitigated or prevented by various [defences](/wiki/Defences "Defences").

Damage can have various [keywords](/wiki/Keywords/edit?redlink=1 "Keywords (page does not exist)") which affect its calculation.

[Receiving damage](/wiki/Receiving_damage "Receiving damage")
