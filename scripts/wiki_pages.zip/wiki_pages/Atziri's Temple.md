# Atziri's Temple

Atziri's Temple

area

|  |  |
| --- | --- |
| Id | [IncursionTemple](/wiki/Area:IncursionTemple "Area:IncursionTemple") |
| Act | 3 |
| Area level | 46 |
| Tags | VaalStrongbox, vaal\_shrine |

Lost Temple

area

|  |  |
| --- | --- |
| Id | [IncursionTemplePresent](/wiki/Area:IncursionTemplePresent "Area:IncursionTemplePresent") |
| Act | 1 |
| Area level | 65 |
| Tags | VaalStrongbox, vaal\_shrine |

Energised Crystal

Tooltip

Energised Crystals are collected by energizing Beacons throughout Wraeclast, and are required to access Atziri's Temple.

6 Energised Crystals are required to power the Temple Console.

More Energised Crystals may be stored by collecting Medallions from those of royal Vaal blood.

**Atziri's Temple** is the primary league mechanic introduced in [Fate of the Vaal league](/wiki/Fate_of_the_Vaal_league "Fate of the Vaal league"). As an area, **Atziri's Temple** is specifically the past version of the temple unlocked from [Act 4](/wiki/Act_4 "Act 4"); the present version of the temple encountered initially is called **Lost Temple**.

## Related quests

* [Ancient Beacons](/wiki/Ancient_Beacons "Ancient Beacons")
* [Fate of the Vaal](/wiki/Fate_of_the_Vaal_(quest) "Fate of the Vaal (quest)")

## Entry

An Ancient Beacon.

Mysterious Vaal machinery called an "Ancient Beacon" can be found throughout the [campaign](/wiki/Campaign "Campaign") (up to area levels no lower than 10 below the character's level) and in [maps](/wiki/Map "Map"). After reaching character level 86+, Ancient Beacons will exclusively only be found in maps (of any tier). These beacons can be energised by defeating monsters affected by it and then approaching the beacon. Completing the encounter will cause a "Vaal Chest" to rise, which contains rewards such as [uncut gems](/wiki/Uncut_gem "Uncut gem") and [currency](/wiki/Currency "Currency"). The chest is always magic during the campaign, and magic or rare in maps. Sometimes, the beacon may summon corrupted Vaal monsters, or the device may lift up a unique monster:

* [Corrupted Abomination](/wiki/Corrupted_Abomination "Corrupted Abomination")
* [High Priest](/wiki/High_Priest "High Priest")
* [Quadrilla Sergeant](/wiki/Quadrilla_Sergeant "Quadrilla Sergeant")
* [Royal Colossus](/wiki/Royal_Colossus "Royal Colossus")
* [Royal Sentinel](/wiki/Royal_Sentinel "Royal Sentinel")
* [Unchained Beast](/wiki/Unchained_Beast "Unchained Beast")
* [Bloodrite Guard](/wiki/Bloodrite_Guard "Bloodrite Guard")
* [Bloodrite Priest](/wiki/Bloodrite_Priest "Bloodrite Priest")

After energising 6 beacons, it will open a portal to the [Vaal Ruins](/wiki/Vaal_Ruins "Vaal Ruins"), an area with a [waypoint](/wiki/Waypoint "Waypoint") and the Temple Console. Interacting with it will allow construction and exploration of the Lost Temple in the present day. Afterwards, each ancient beacon will grant 1 Energised Crystal; 6 crystals are required to activate the Temple Console again.

In [Act 3](/wiki/Act_3 "Act 3"), [Alva](/wiki/Alva "Alva") can be summoned to the temple.

In [Act 4](/wiki/Act_4 "Act 4"), [Doryani](/wiki/Doryani "Doryani") can be summoned to the temple, and will permanently change the temple into the past version of Atziri's Temple, unlocking access to a variety of new rooms and mechanics. Additionally, it unlocks the ability to fight the Architect and obtain Medallions.

After reaching [maps](/wiki/Map "Map"), it is possible to increase the maximum number of Energised Crystals by obtaining Xopec's Medallions inside the temple. This can be used multiple times, up to a maximum of 60 Energised Crystals. Regardless of the number of crystals stored, only 6 will be used at a time at the Temple Console, and only 6 Room Cards will be generated each time, but the temple can be re-opened consecutively. Additionally, the number of Energised Crystals obtained increases based on the Tier of map and number of map modifiers, up to two Crystals per 6-mod T15+ map.

## Mechanics

### Temple Console

The temple console displays the layout of the Temple of Atziri in a 9x9 grid, plus the Foyer entrance and Atziri's Chamber on opposite sides. After energizing the Temple Console, six "Room Cards" will be generated from the left menu can be placed on the grid to build the temple. Approximately 50% of Room Cards will be Paths. Rooms can only be placed adjacent to Paths or rooms they interact with; Paths can be placed adjacent to other Paths with an exit in that direction. Paths have a fixed orientation, but will automatically connect to non-Path rooms it is adjacent to. Additionally, most rooms can connect automatically to specific other rooms, typically those that also increase the tier of one or both of these rooms or otherwise interact with other rooms; these upgrade interactions are shown with a brighter green outline on the grid with squares in the corners, compared to regular placeable spots.

* Juatalotli's Medallion can be used to prevent a room or path from destabilising one time.
* Puhuarte's Medallion can be used to reroll all unplaced Room Cards offered.
* Quipolatl's Medallion can be used to upgrade the Tier of a room of your choice by 1.
* Uromoti's Medallion can be used to add a specified Room Card.

By default, at least one Room Card must be placed to run the temple. However, it is possible to bypass this restriction by using `CTRL`+`LMB` when clicking "Run Temple" (Gamepad users will instead get a confirmation prompt). Not all Room Cards need to be placed to run the temple, but any unused Room Cards will be discarded. Afterwards, open the temple to explore inside.

Note: the Temple and its progression, the current number of stored Energised Crystals, and current Medallions are independent for each [character](/wiki/Character "Character"). However, upgrades to maximum Energised Crystals and maximum Medallions are shared between characters in the same league.

### Medallions

After completing the Architect's Chamber for the first time, defeating certain minibosses or bosses in the temple can generate a medallion, which can modify rooms at the Temple Console in certain ways or grant other benefits related to the temple. Players can keep a number of medallions at once, up to 6 by upgrading using Azcapa's Medallion. This limit is shared across your characters. Each room can only be affected by 1 medallion at a time, thus it is not possible to upgrade a room from level 1 to level 3 by applying multiple Quipolatl's Medallion, or to use Juatalotli's Medallion to prevent destabilization of a room that has been upgraded by Quipolatl's Medallion.

List of medallions

| Medallion | Effect | Flavour text |
| --- | --- | --- |
| Azcapa's Medallion | Use to increase Maximum Medallion Capacity by 1 (up to 6) | *The Architect of the Guild was more than happy to create a continual stream of trinkets and baubles to distract the Queen, but, in truth, she barely looked at any of them.* |
| Estazunti's Medallion | Use to place an extra Restricted Room Card after defeating the Architect | *The Architect of the Vault pleaded with nobles and suitors, begging them to stop sending treasure to the Queen. He could never go home until his task was complete...* |
| Hayoxi's Medallion | Use to reroll the reward of a Restricted Room Card | *The Architect of Destruction ensured his own demise in an 'accidental' explosion. She ordered his pieces gathered, his body reassembled and transcended. Death was no escape.* |
| Juatalotli's Medallion | Use to prevent the next Destabilisation of a Room | *The Architect of the Hoard gathered every piece of Vaal history he could, hoping to preserve them against the end. She allowed him this, for it served her ends as well.* |
| Puhuarte's Medallion | Use to reroll the Room Cards available for placement Restricted Room Cards may not be rerolled this way | *The Architect of the Forge kept his hearth busy, for the Queen's eye lingered on the idle. Her halls stood adorned with his desperate artisanship.* |
| Quipolatl's Medallion | Use to improve the Tier of a Room (up to a maximum of 3) | *The Architect of the Nexus proposed the Temple of Atzoatl as a prototype. He thought the project would keep him safe. Instead, all he achieved was building her another seat of power.* |
| Uromoti's Medallion | Use to add Room: <random room> | *The Architect of Expansion was always distant, working on projects at the edge of the Empire. His excuses vanished soon after his daughter was... given... a position at the Royal Temple.* |
| Xopec's Medallion | Use to increase Maximum Crystal Capacity by 6 (up to 60) | *The Architect of Power chose to bury himself in his work, seeking freedom of the mind. She followed him even there, learning the theories, ensuring he did not stray in his intent.* |
| Zantipi's Medallion | Use to add one to the number of random Waystone Modifiers added to your Temple. This number reduces by 1 for every 10 Temples opened. Modifiers will be randomised each time you open a new Temple. Temples can be affected by up to 8 Modifiers. | *The Architect of Concealment wove secrets into stone, with passages and powers none were meant to see. His renown rose in the shadows of his designs.* |

### Area level

Area level of the temple is based on the level of the character that opened it; area level will be equal to character level until level 64, after which the rate of area level increase slows slightly, reaching the maximum area level of 81 when the character is level 90+. The area level of completed Ancient Beacon encounters do not impact the area level of the temple. The number of magic and rare monsters in the temple scales with area level.

Temple of Atziri
area level scaling

| Character level | Area level |
| --- | --- |
| 1-64 | 1-64 |
| 65-66 | 65 |
| 67 | 66 |
| 68 | 67 |
| 69-70 | 68 |
| 71 | 69 |
| 72 | 70 |
| 73-74 | 71 |
| 75 | 72 |
| 76 | 73 |
| 77-78 | 74 |
| 79 | 75 |
| 80 | 76 |
| 81-82 | 77 |
| 83 | 78 |
| 84 | 79 |
| 85-89 | 80 |
| 90-100 | 81 |

### Party mechanics

When in a [party](/wiki/Party "Party"), Ancient Beacons have a 50% chance to grant an Energized Crystal to each party member other than the instance owner (who always gets a Crystal). This chance is rolled independently for each player.

In the temple proper, only the owner of the temple gets access to the crafting benches found in rooms. Other players cannot interact with these benches, and will not drop additional copies of itemised crafting benches if taken as an item.

## Running the Temple

Most temple rooms' entrances will usually close until the room is completed, typically by defeating the miniboss or encounter inside. The temple does not reset after it has been opened. Some rooms that create a dead end have a [checkpoint](/wiki/Checkpoint "Checkpoint"), as well as a guaranteed one at the Entrance room. Choosing to "Respawn at Checkpoint" does not reset the health or location of enemies in the temple, but will open the doors of any currently closed room allowing the player to re-enter and complete it. Respawning while in the Architect's Chamber or Atziri's Chamber will respawn a new instance of the temple with most other content removed, allowing the bosses to be re-attempted but reducing the rewards in the current temple.

Most rooms grant global modifiers to the entire temple, affecting monster [effectiveness](/wiki/Effectiveness/edit?redlink=1 "Effectiveness (page does not exist)") or rewards. These modifiers are subject to diminishing returns starting with the 4th copy of the same room type, prioritizing diminishing lower tier rooms first. It can be calculated by sorting rooms first by tier, then applying the following formula:

```
ModEffectMultiplier = 0.9 ^ (Room# - 3)
```

In addition to modifiers added by various rooms within the temple, using a Zantipi's Medallion will cause the temple to roll an additional random [waystone](/wiki/Waystone "Waystone") modifier. The modifiers are randomized each time the temple is opened, and the number of waystone modifiers reduce by 1 every 10 temples opened. Area modifiers do not affect Xipocado and Atziri.

Players can leave the temple at any time by opening a [Portal](/wiki/Portal "Portal"). This portal will take them to the same Vaal Ruins instance the temple was opened from. The temple can still be re-entered through the main door, but no return portal will be available. Note that if the [character](/wiki/Character "Character") dies or otherwise leaves the area while fighting [Xipocado, Royal Architect](/wiki/Xipocado,_Royal_Architect "Xipocado, Royal Architect") or [Atziri, the Red Queen](/wiki/Atziri,_the_Red_Queen "Atziri, the Red Queen"), the temple will close automatically instead (causing destabilisation).

### Destabilisation

Temple Destabilisation

Tooltip

Each time you enter the Temple a random selection of non-[Restricted Rooms](/wiki/Restricted_Room/edit?redlink=1 "Restricted Room (page does not exist)") are Destabilised, removing them permanently when you next exit.

In addition to the randomly selected rooms, some rooms are Destabilised upon completion.

Defeating the Architect or Atziri causes greater Destabilisation.

The temple can be closed by exiting via the main door, or choosing "Close Temple" from the Temple Console after portaling out. When the temple is closed, some rooms (approximately 10% of the temple) will randomly destabilise and be removed from the grid. The temple can continue to be built with the remaining layout after obtaining more Energized Crystals.

The temple will destabilise more significantly if either [Xipocado](/wiki/Xipocado "Xipocado") or [Atziri](/wiki/Atziri "Atziri") are fought against. The destabilisation will occur after closing the temple, or immediately upon dying to either encounter.

* After Xipocado, many non-Path rooms (except for reward rooms from Xipocado's Console) and some Path rooms (approximately 30% of the temple) will be removed and the location of the Architect's Chamber will be randomised.
* After Atziri, many non-Path rooms, the Royal Access Chamber, and most Path rooms will be removed.

Destabilisation can target any "loose" unprotected non-Reward rooms or Paths and cannot leave a previously connected room dependent on a given disconnected. In other words, in a long linear chain of rooms (referred to as the "snake" method), it will only attempt to destabilise the chain starting from the room furthest (via connections) to the entrance and will not normally "break" the chain.

Juatalotl's Medallion can be used to protect a Tier 3 room of the player's choice one time.

## List of general rooms

### Entrance

This room is always the first room of the temple, connected to [Vaal Ruins](/wiki/Vaal_Ruins "Vaal Ruins"). It is functionally identical to a 4-way Path. This room cannot be removed or replaced.

The entrance contains a large statue of Atziri, with different text appearing depending on whether you interact with it in the present or the past:

* Crumbling Plaque (Present): "Behold [......*illegible*........] be awed! [.................] Queen, and you [..................] Never forget this, and you [...................................] shines from within all Vaal."
* Atziri's Glory (Past): "Behold my glory, and be awed! I am your Queen, and you live to serve me. Never forget this, and you shall walk in the light that shines from within all Vaal."

### Path

An example of a 3-way Path automatically forming (visually invalid) connections. The Path to the northwest has a wall facing the Room Tile's exit, and the Path to the Southwest has an exit facing the Room Tile's wall, but both will become connected (effectively turning the tile into a 4-way Path once placed).

Paths are simple connecting rooms that comes in 2-way, 3-way, and 4-way variants. The orientation of the Paths is fixed and cannot be rotated. To be placed, the Path must be placed such that one of its exits is facing an adjacent Path (the exits do not need to match). However, once placed, Paths will automatically create exits to any other adjacent Path or room regardless of the Room Tile's exit directions (see example to the right). Because of this, the orientation of the Path is only relevant when determining which tile the Path can be placed on. The one exception to this is Generator, which can only be placed adjacent to a Path with a corresponding exit, and other rooms will not automatically create exits to the Generator except those which upgrade Generator.

### Architect's Chamber

Restricted Room

Tooltip

Restricted Rooms are those that are placed by using Xipocado's Console in the Architect's Chamber

The Architect's Chamber is a fixed room that automatically generates in the temple on a random grid, typically in the far half of the temple. After defeating [Xipocado, Royal Architect](/wiki/Xipocado,_Royal_Architect "Xipocado, Royal Architect"), three chests called "Xipocado's Hoard" will be unlocked. It also unlocks access to Xipocado's Console, a special variant of the Temple Console that provides the ability to place exclusive reward rooms (Restricted Room Card) from a random selection of 6, one of which is always a Royal Access Chamber if it has not already been placed and the temple is Area Level 75+. However, they can only be placed on a limited number of pre-selected tiles on the grid, typically along the outer edge. It is possible that there may not be sufficient tiles to place all six reward rooms. After defeating Xipocado, many non-reward rooms and some Paths will be destabilised, with Xipocado's Chamber's location randomised.

* Estazunti's Medallion can be used to add an additional grid slot to place a Restricted Room Card on.
* Hayoxi's Medallion can be used to reroll a single Restricted Room (Reward Vault).
* Juatalotli's Medallion can be used to prevent a room from destabilising one time.

Note: The Architect's Chamber in the present version of the temple (before recruiting Doryani) does not contain the Xipocado miniboss. Additionally, the Xipocado's Console inside does not contain a Royal Access Chamber, and the reward Room Cards are limited to Kishara's Vault, Ancient Reliquary Vault, and Jiquani's Vault. Notably, Jiquani's Vault contains only a regular [rune](/wiki/Rune "Rune"), not an endgame one.

Architect's Chamber

| Room | Description | Encounters and rewards |
| --- | --- | --- |
| Architect's Chamber | Defeating the Architect allows a Selection of Rewarding Vaults, and unlocks Medallions High chance for Xopec's and Azcapa's Medallions | Contains [Xipocado, Royal Architect](/wiki/Xipocado,_Royal_Architect "Xipocado, Royal Architect") Xipocado's Console can be used to add exclusive reward rooms which cannot be obtained normally Significantly destabilizes the temple when completed |

### Atziri's Chamber

Atziri's Chamber is a fixed room on the Temple Console outside of the grid on the opposite end of the entrance. It can connect to any adjacent room. The area contains a locked chests called "Atziri's Vault", as well as a locked room called "Atziri's Chambers". The Royal Access Chamber (placed via Xipocado's Console) must be completed first in order to unlock the door to access the pinnacle boss fight with [Atziri, the Red Queen](/wiki/Atziri,_the_Red_Queen "Atziri, the Red Queen"). Atziri's Vaults are unlocked after defeating Atziri; these contain drops exclusive to Atziri (she herself does not drop items) as well as several currency items, including those exclusive to the Temple's reward rooms. After defeating Atziri, most non-reward rooms, the Royal Access Chamber, and many Paths will be destabilised.

Atziri's Chamber

| Room | Description | Encounters and rewards |
| --- | --- | --- |
| Atziri's Chamber | Complete the Royal Access Chamber to unlock | Contains [Atziri, the Red Queen](/wiki/Atziri,_the_Red_Queen "Atziri, the Red Queen") Significantly destabilizes the temple when completed |

### Armoury

Upgraded by: Smithy, Alchemy Lab

Armoury

| Room | Tier | Description | Encounters and rewards |
| --- | --- | --- | --- |
| Depot | Tier 1 | Humanoid Monsters have 15% increased Effectiveness Contains Equipment | * Contains 4x Vaal Armoury Rack chests |
| Arsenal | Tier 2 | Humanoid Monsters have 30% increased Effectiveness Contains many pieces of Equipment |
| Gallery | Tier 3 | Humanoid Monsters have 60% increased Effectiveness Contains Rare pieces of Equipment |

### Commander

Upgraded by: (Garrison or Transcendent Barracks) x2, (Garrison or Transcendent Barracks) x3

Note: Spymaster cannot be placed in a linear chain ("snake") that already contains a Commander. However, Commander can be placed in a chain that already contains a Spymaster.

Commander

| Room | Tier | Description | Encounters and rewards |
| --- | --- | --- | --- |
| Commander's Chamber | Tier 1 | Rare Monsters have 15% increased Effectiveness May contain a bench allowing modification of equipment Low chance for Quipolatl's Medallion | * Contains <Name>, the Forgotten (present)/<Name>, Commander (past) * May contain Regal Workbench: Upgrades a Magic Equipment item to a Rare item, adding 1 modifier * May contain Alchemy Workbench: Upgrades a Normal or Magic Equipment item to a Rare item with 4 random modifiers * May contain Exalted Workbench: Augments a Rare Equipment item with a new random modifier |
| Commander's Hall | Tier 2 | Rare Monsters have 30% increased Effectiveness May contain a bench allowing modification of equipment Low chance for Quipolatl's Medallion | * Contains <Name>, the Forgotten (present)/<Name>, Commander (past) * May contain Regal Workbench: Upgrades a Magic Equipment item to a Rare item, adding 1 modifier * May contain Alchemy Workbench: Upgrades a Normal or Magic Equipment item to a Rare item with 4 random modifiers * May contain Exalted Workbench: Augments a Rare Equipment item with a new random modifier |
| Commander's Headquarters | Tier 3 | Rare Monsters have 60% increased Effectiveness May contain a bench allowing modification of equipment Low chance for advanced Medallions | * Contains [Royal Commander](/wiki/Royal_Commander "Royal Commander") * May contain Regal Workbench: Upgrades a Magic Equipment item to a Rare item, adding 1 modifier * May contain Alchemy Workbench: Upgrades a Normal or Magic Equipment item to a Rare item with 4 random modifiers * May contain Exalted Workbench: Augments a Rare Equipment item with a new random modifier |

### Garrison

Upgraded by: Commander, Armoury, Synthflesh Lab (convert), Spymaster (convert)

* The Garrison will be converted into a Tier 2 Transcendent Barracks when placed adjacent to a Synthflesh Lab.
* The Garrison will be converted into a Tier 2 Legion Barracks when placed adjacent to a Spymaster.
  + Legion Barracks cannot connect with Commander, and will automatically break any pre-existing connections to Commanders when converted.

Garrison

| Room | Tier | Description | Encounters and rewards |
| --- | --- | --- | --- |
| Guardhouse | Tier 1 | 10% increased number of Monster Packs May contain a bench allowing modification of equipment | * May contain Regal Workbench: Upgrades a Magic Equipment item to a Rare item, adding 1 modifier * May contain Alchemy Workbench: Upgrades a Normal or Magic Equipment item to a Rare item with 4 random modifiers * May contain Exalted Workbench: Augments a Rare Equipment item with a new random modifier |
| Barracks | Tier 2 | 15% increased number of Monster Packs Normal Monsters have 15% increased Effectiveness May contain a bench allowing modification of equipment | * May contain Regal Workbench: Upgrades a Magic Equipment item to a Rare item, adding 1 modifier * May contain Alchemy Workbench: Upgrades a Normal or Magic Equipment item to a Rare item with 4 random modifiers * May contain Exalted Workbench: Augments a Rare Equipment item with a new random modifier |
| Hall of War | Tier 3 | 20% increased number of Monster Packs Normal Monsters have 30% increased Effectiveness May contain a bench allowing modification of equipment | * Contains <Name>, Drill Sergeant * May contain Regal Workbench: Upgrades a Magic Equipment item to a Rare item, adding 1 modifier * May contain Alchemy Workbench: Upgrades a Normal or Magic Equipment item to a Rare item with 4 random modifiers * May contain Exalted Workbench: Augments a Rare Equipment item with a new random modifier |

The Tier 3 room unlocks a hidden special dialogue in the form of a randomized Vaal war chant by the enemies inside. The final line plays when the enemies initiate combat with the character.[[1]](#cite_note-1)

* Drill Sergeant:
  + Otsuks! Máax ka ti a'tul?
  + Máax ka ti cheyel?
  + Máax tlayeb mucane?
  + Ela tlayeb ukto! Máax ka ti a'tul?
  + Otsuks! Tzokan'te u'te ik'el...
  + A'te Kuxkal tlayeb kutsen.
* Vaal Regiment:
  + U'te mucane!
  + Atziri!
* Drill Sergeant: Otsuks, quxzeh!

### Generator

Upgraded by: Thaumaturge, Sacrificial Chamber

Generator rooms do not automatically connect to most other rooms; instead, they must be connected via Paths, Thaumaturge, or Sacrificial Chamber, and can only supply power to connected rooms within a total distance of 3-5 rooms depending on tier. Power cannot travel through powerable rooms, and is blocked by non-powerable rooms and walls without exits.

Generator rooms can only be placed adjacent to a Path with a corresponding exit.

Generator

| Room | Tier | Description | Encounters and rewards |
| --- | --- | --- | --- |
| Dynamo | Tier 1 | Construct Monsters have 15% increased Effectiveness Provides power to nearby rooms, increasing in range every tier May contain a bench allowing modification of equipment | * Supplies power to a total distance of 3 rooms * May contain Regal Workbench: Upgrades a Magic Equipment item to a Rare item, adding 1 modifier * May contain Alchemy Workbench: Upgrades a Normal or Magic Equipment item to a Rare item with 4 random modifiers * May contain Exalted Workbench: Augments a Rare Equipment item with a new random modifier |
| Shrine of Empowerment | Tier 2 | Construct Monsters have 30% increased Effectiveness Provides power to nearby rooms, increasing in range every tier May contain a bench allowing modification of equipment | * Supplies power to a total distance of 4 rooms * May contain Regal Workbench: Upgrades a Magic Equipment item to a Rare item, adding 1 modifier * May contain Alchemy Workbench: Upgrades a Normal or Magic Equipment item to a Rare item with 4 random modifiers * May contain Exalted Workbench: Augments a Rare Equipment item with a new random modifier |
| Solar Nexus | Tier 3 | Construct Monsters have 60% increased Effectiveness Area contains an additional Corrupted Abomination Provides power to nearby rooms, increasing in range every tier May contain a bench allowing modification of equipment | * A random room contains [Corrupted Abomination](/wiki/Corrupted_Abomination "Corrupted Abomination") * Supplies power to a total distance of 5 rooms * May contain Regal Workbench: Upgrades a Magic Equipment item to a Rare item, adding 1 modifier * May contain Alchemy Workbench: Upgrades a Normal or Magic Equipment item to a Rare item with 4 random modifiers * May contain Exalted Workbench: Augments a Rare Equipment item with a new random modifier |

### Golem Works

Upgraded by: Generator (Power), Generator (Power) x2

In-game, Tier 3 Golem Works (Stone Legion) incorrectly states that it spawns an additional High Priest instead of a Royal Sentinel.[Likely due to a [bug](https://www.pathofexile.com/forum/view-forum/2214)][[2]](#cite_note-2)

Golem Works

| Room | Tier | Description | Encounters and rewards |
| --- | --- | --- | --- |
| Workshop | Tier 1 | 8% increased effect of Temple Mods from Generators, Synthflesh Labs, Flesh Surgeons, Transcendent Barracks, and Alchemy Labs May contain a bench allowing modification of equipment Low chance for Quipolatl's Medallion |  |
| Automaton Lab | Tier 2 | 15% increased effect of Temple Mods from Generators, Synthflesh Labs, Flesh Surgeons, Transcendent Barracks, and Alchemy Labs May contain a bench allowing modification of equipment Low chance for Quipolatl's Medallion |  |
| Stone Legion | Tier 3 | 30% increased effect of Temple Mods from Generators, Synthflesh Labs, Flesh Surgeons, Transcendent Barracks, and Alchemy Labs Area contains an additional Royal Sentinel May contain a bench allowing modification of equipment High chance for Quipolatl's Medallion | * Contains [Imitation Triumph](/wiki/Imitation_Triumph "Imitation Triumph") * A random room contains [Royal Sentinel](/wiki/Royal_Sentinel "Royal Sentinel") |

### Smithy

Upgraded by: Golem Works, Generator (Power)

Smithy

| Room | Tier | Description | Encounters and rewards |
| --- | --- | --- | --- |
| Bronzeworks | Tier 1 | Chests have 15% more Item Rarity Contains a bench to improve equipment quality Tier 3 allows further improvement of equipment quality above 20% Low chance for Quipolatl's Medallion | * Contains <Name>, Kamasan Smith * Forging Workbench: Greatly improves the quality of a Martial Weapon, Caster Weapon or Armour. |
| Chamber of Iron | Tier 2 | Chests have 30% more Item Rarity Contains a bench to add an augment socket to equipment Tier 3 allows further improvement of equipment quality above 20% Low chance for Quipolatl's Medallion | * Contains <Name>, Kamasan Smith * Contains <Name>, the Forgehand * Forging Mechanism: Adds an Augment Socket to a Martial Weapon, wand, staff or Armour. |
| Golden Forge | Tier 3 | Chests have 60% more Item Rarity Contains a bench to improve Equipment Quality above 20% High chance for advanced Medallions | * Contains [Calzari, Masterwork Smith](/wiki/Calzari,_Masterwork_Smith "Calzari, Masterwork Smith") * Contains <Name>, the Forgehand * Masterwork Forge: Improves the quality of a Martial Weapon, Caster Weapon or Armour above 20% with a chance of Corrupting it. Can be taken as a [Vaal Infuser](/wiki/Vaal_Infuser "Vaal Infuser"). |

### Thaumaturge

Upgraded by: Sacrificial Chamber (Tier 2), Sacrificial Chamber (Tier 3)

Sacrificial Chamber can connect to Alchemy Lab, but is not upgraded by it.

Thaumaturge

| Room | Tier | Description | Encounters and rewards |
| --- | --- | --- | --- |
| Thaumaturge's Laboratory | Tier 1 | 8% increased effect of Temple Mods from Corruption Chambers, Treasure Vaults, and Sacrificial Chambers Contains a device to set a gem to have 3 support gem sockets Tier 3 allows Further Corruption of Gems Low chance for Quipolatl's Medallion | * Gemcutting Workbench: Sets a Skill Gem to have 3 Support Gem Sockets. Can be taken as a [Lesser Jeweller's Orb](/wiki/Lesser_Jeweller%27s_Orb "Lesser Jeweller's Orb"). |
| Thaumaturge's Cuttery | Tier 2 | 15% increased effect of Temple Mods from Corruption Chambers, Treasure Vaults, and Sacrificial Chambers Contains a device to improve the quality of a skill gem Tier 3 allows Further Corruption of Gems Low chance for Quipolatl's Medallion | * Gemcutting Mechanism: Greatly improves the quality of a Skill Gem |
| Thaumaturge's Cathedral | Tier 3 | Area contains an additional Quadrilla Sergeant 30% increased effect of Temple Mods from Corruption Chambers, Treasure Vaults, and Sacrificial Chambers Contains a device to further Corrupt Gems Room Destabilizes once device is used High chance for advanced Medallions | * A random room contains [Quadrilla Sergeant](/wiki/Quadrilla_Sergeant "Quadrilla Sergeant") * Gem Corrupter: Modifies a Corrupted Skill Gem unpredictably or destroys it, granting a 50% chance each to either add a second corruption outcome (level, quality, sockets) or destroy an already corrupted skill gem. Gems corrupted this way become Twice Corrupted. Can be taken as a [Crystallised Corruption](/wiki/Crystallised_Corruption "Crystallised Corruption"). |

### Treasure Vault

Treasure Vault

| Room | Tier | Description | Encounters and rewards |
| --- | --- | --- | --- |
| Sealed Vault | Tier 1 | 25% increased Rarity of Items Dropped by Monsters Contains Many Chests Room Destabilizes once the central Vault is opened | * Contains several Vault Chests which can drop random rewards like [currency](/wiki/Currency "Currency"), [uncut gems](/wiki/Uncut_gem "Uncut gem"), etc. |

## List of past-exclusive rooms

### Alchemy Lab

Upgraded by: Thaumaturge, Thaumaturge x2

Alchemy Lab

| Room | Tier | Description | Encounters and rewards |
| --- | --- | --- | --- |
| Chamber of Souls | Tier 1 | 15% increased Rarity of Items Dropped by Monsters Tier 3 allows Soul Core Corruption Low chance for Quipolatl's Medallion | * Contains a Soul Core Cache which drops a random [soul core](/wiki/Soul_core "Soul core") |
| Core Machinarium | Tier 2 | 50% increased Gold found in this Area 30% increased Rarity of Items Dropped by Monsters Tier 3 allows Soul Core Corruption Low chance for Quipolatl's Medallion | * Contains a Soul Core Cache which drops a random [soul core](/wiki/Soul_core "Soul core") |
| Grand Phylactory | Tier 3 | 60% increased Rarity of Items Dropped by Monsters Contains a device to Corrupt Soul Cores Room Destabilizes once device is used High chance for advanced Medallions | * Contains [Guardian Construct](/wiki/Guardian_Construct "Guardian Construct") (activates on using/taking the Soul Core Infuser) * Soul Core Infuser: Modifies a Soul Core unpredictably, with a chance to destroy it, which can double the soul core, transform it into a random soul core, transform it into an [ancient soul core](/wiki/Ancient_soul_core "Ancient soul core"), or destroy it. Can be taken as a [Core Destabiliser](/wiki/Core_Destabiliser "Core Destabiliser"). * Contains a Soul Core Cache which drops a random [soul core](/wiki/Soul_core "Soul core") |

### Corruption Chamber

Upgraded by: Thaumaturge, Sacrificial Chamber

Corruption Chamber

| Room | Tier | Description | Encounters and rewards |
| --- | --- | --- | --- |
| Crimson Hall | Tier 1 | Rare Monsters have a 15% chance to have an additional Modifier Contains a device to Corrupt Items Tier 3 allows Further Corruption of Equipment | * Corruption Altar: Modifies an item unpredictably and Corrupts it, identically to a [Vaal Orb](/wiki/Vaal_Orb "Vaal Orb"). |
| Catalyst of Corruption | Tier 2 | Rare Monsters have a 30% chance to have an additional Modifier Contains a device to Corrupt Items Tier 3 allows Further Corruption of Equipment | * Corruption Altar: Modifies an item unpredictably and Corrupts it, identically to a [Vaal Orb](/wiki/Vaal_Orb "Vaal Orb"). |
| Locus of Corruption | Tier 3 | Area contains an additional Royal Sentinel Rare Monsters have a 60% chance to have an additional Modifier Contains a device to further Corrupt Equipment Room Destabilizes once device is used | * A random room contains [Royal Sentinel](/wiki/Royal_Sentinel "Royal Sentinel") * Corruption Instiller: Modifies a Corrupted Equipment or Jewel item unpredictably or destroys it, granting a 50% chance each to either add a second enchantment to or destroy an already corrupted item. Items corrupted this way become Twice Corrupted. Can be taken as an [Architect's Orb](/wiki/Architect%27s_Orb "Architect's Orb"). |

### Flesh Surgeon

Upgraded by: Synthflesh Lab, Synthflesh Lab (Powered)

Flesh Surgeon

| Room | Tier | Description | Encounters and rewards |
| --- | --- | --- | --- |
| Surgeon's Ward | Tier 1 | Unique Monsters have 10% increased Effectiveness Tier 3 allows Limb Modification Low chance for Quipolatl's Medallion |
| Surgeon's Theatre | Tier 2 | Unique Monsters have 20% increased Effectiveness Tier 3 allows Limb Modification Low chance for Quipolatl's Medallion |
| Surgeon's Symphony | Tier 3 | Unique Monsters have 40% increased Effectiveness Contains a device allowing Limb Modification High chance for advanced Medallions | * Contains [Master Flesh Surgeon](/wiki/Master_Flesh_Surgeon "Master Flesh Surgeon") * Contains [The Remade](/wiki/The_Remade "The Remade") * Transcension Device: replaces one of the character's arms or legs with a [transcendent limb](/wiki/Transcendent_limb "Transcendent limb") that grants a modifier. If the character dies, any current transcendent limbs are removed. |

### Sacrificial Chamber

Upgraded by: Sacrificing other placed rooms

Only 1 Sacrificial Chamber can exist in a temple. Sacrificial Chamber can connect to Generator, Corruption Chamber and Thaumaturge, but is not upgraded by them.

Instead, if a Tier 1 Sacrificial Chamber is placed on the grid, an additional special "Sacrifice Room" Room Card  will be obtained that can be used to sacrifice (immediately destabilise) an eligible room to upgrade the Sacrificial Chamber to Tier 2. If the Sacrificial Chamber is Tier 2, there is a high chance for the "Sacrifice Room" Room Card to appear when generating new Room Cards to upgrade the room to Tier 3.

Sacrificial Chamber

| Room | Tier | Description | Encounters and rewards |
| --- | --- | --- | --- |
| Altar of Sacrifice | Tier 1 | 15% increased amount of Rare Chests Contains a Unique Item Tier 3 allows Further Modification of Vaal Uniques Low chance for Quipolatl's Medallion |
| Hall of Offerings | Tier 2 | 30% increased amount of Rare Chests Contains a Unique Item Tier 3 allows Further Modification of Vaal Uniques Low chance for Quipolatl's Medallion |
| Apex of Oblation | Tier 3 | 60% increased amount of Rare Chests Area contains an additional Unchained Beast Contains a Unique Item Contains a device to Modify Vaal Uniques Room Destabilizes once device is used High chance for advanced Medallions | * Contains [Huitzil, Royal Blood Priest](/wiki/Huitzil,_Royal_Blood_Priest "Huitzil, Royal Blood Priest") * A random room contains [Unchained Beast](/wiki/Unchained_Beast "Unchained Beast") * Morphology Mechanism: Replaces up to 2 modifiers on a Corrupted Vaal Unique or Replaces other Uniques with a Corrupted Unique of the same Item Class. Specifically for [Vaal-themed uniques](/wiki/List_of_Vaal_unique/edit?redlink=1 "List of Vaal unique (page does not exist)"), 1 or 2 explicit modifiers will be replaced with another exclusive modifer; the new modifier is dependent on the modifier replaced. Can be taken as a [Vaal Cultivation Orb](/wiki/Vaal_Cultivation_Orb "Vaal Cultivation Orb"). |

### Spymaster

Upgraded by: Assasinating other Spymasters

When placed adjacent to a Garrison, it will convert the Garrison into a Tier 2 Legion Barracks.

This room does not (and cannot) upgrade by being adjacent to other Spymasters. Instead, as long as two or more Spymasters are placed anywhere in a temple when it is opened, one of the Spymasters that can be destabilised will be "assassinated", causing the room to be empty and automatically completed on entry, and upgrades another Spymaster by 1 Tier upon closing the temple. Spymasters can only be upgraded one time this way.

Spymasters that are locked by a Juataloltli's Medallion before entering the temple or protected due to being in a chain cannot be assassinated. However, it is possible to assassinate a Spymaster, then use a lock medallion on that room while inside the temple to prevent it from destabilising. This will result in both the other Spymaster being upgraded and the assassinated Spymaster to persist on the grid (and be un-assassinated).[[3]](#cite_note-3)

Note: Spymaster cannot be placed in a linear chain ("snake") that already contains a Commander. However, Commander can be placed in a chain that already contains a Spymaster.

Spymaster

| Room | Tier | Description | Encounters and rewards |
| --- | --- | --- | --- |
| Spymaster's Study | Tier 1 | 8% increased effect of Temple Mods from Garrisons, Commanders, Armouries, Smithies, and Legion Barracks Can assassinate other Spymasters to level up Low chance for Juatalotli's Medallion |  |
| Hall of Shadows | Tier 2 | 15% increased effect of Temple Mods from Garrisons, Commanders, Armouries, Smithies, and Legion Barracks Can assassinate other Spymasters to level up Low chance for Juatalotli's Medallion |  |
| Omnipresent Panopticon | Tier 3 | Area contains an additional [Royal Colossus](/wiki/Royal_Colossus "Royal Colossus") 30% increased effect of Temple Mods from Garrisons, Commanders, Armouries, Smithies, and Legion Barracks Can assassinate other Spymasters High chance for Juatalotli's Medallion | * Contains [Royal Spy Master](/wiki/Royal_Spy_Master "Royal Spy Master") * A random room contains [Royal Colossus](/wiki/Royal_Colossus "Royal Colossus") |

### Synthflesh Lab

Upgraded by: Flesh Surgeon, Generator (Power)

When placed adjacent to a Garrison, it will convert the Garrison into a Tier 2 Transcendent Barracks.

Synthflesh Lab

| Room | Tier | Description | Encounters and rewards |
| --- | --- | --- | --- |
| Prosthetic Research | Tier 1 | Monsters grant 10% increased Experience |
| Synthflesh Sanctum | Tier 1 | Monsters grant 20% increased Experience |
| Crucible of Transcendence | Tier 1 | Monsters grant 40% increased Experience |

### Legion Barracks

Upgraded by: Armoury

Converted to from a Garrison adjacent to a Spymaster. Legion Barracks can connect to Spymaster but is not further upgraded by them.

Note: Legion Barracks *cannot* connect to Commander. If a Garrison is connected to a Commander, Spymaster cannot be placed adjacently to the Garrison.

Legion Barracks

| Room | Tier | Description | Encounters and rewards |
| --- | --- | --- | --- |
| Viper's Loyals | Tier 2 | 30% increased number of Rare Monsters Low chance for Quipolatl's Medallion | * Contains <Name>, Drill Sergeant |
| Collective Legion | Tier 3 | 60% increased number of Rare Monsters High chance for advanced Medallions |  |

### Transcendent Barracks

Converted to from a Garrison adjacent to a Synthflesh Lab. Transcendent Barracks can connect to Synthflesh Lab and Commander but is not further upgraded by them. A Medallion is required to upgrade to Tier 3.

Transcendent Barracks

| Room | Tier | Description | Encounters and rewards |
| --- | --- | --- | --- |
| Steelflesh Quarters | Tier 2 | 30% increased number of Magic Monsters | * Contains <Name>, Drill Sergeant |
| Collective Legion | Tier 3 | 60% increased number of Magic Monsters |  |

## List of Restricted Rooms

### Royal Access Chamber

Only 1 Royal Access Chamber can exist in a temple.

Royal Access Chamber

| Room | Tier | Description | Encounters and rewards |
| --- | --- | --- | --- |
| Royal Access Chamber | Tier 1 | Allows Access to Atziri's Chamber Room Destabilizes once complete | * Required to unlock the door in Atziri's Chamber to fight against [Atziri, the Red Queen](/wiki/Atziri,_the_Red_Queen "Atziri, the Red Queen"). Atziri's Chamber must be connected to the entrance in order to use the Access Chamber Ritual. |

### Extraction Chamber

Extraction Chamber

| Room | Tier | Description | Encounters and rewards |
| --- | --- | --- | --- |
| Extraction Chamber | Tier 1 | Contains a Device to Salvage Socketed Augments Room Destabilizes once complete | * Extraction Workbench: Destroys an Equipment item, returning any Augments socketed in it. Can be taken as a [Orb of Extraction](/wiki/Orb_of_Extraction "Orb of Extraction"). |

### Augments Vault

If placed at the present day version of Xipocado's Console (before Doryani is recruited), this room will contain a regular rune, not an endgame one.

Augments Vault

| Room | Tier | Description | Encounters and rewards |
| --- | --- | --- | --- |
| Jiquani's Vault | Tier 1 | Contains a random high level Rune Room Destabilizes once complete | * Rune Cache: Contains an [endgame rune](/wiki/Rune#List_of_endgame_runes "Rune") |

### Currency Vault

Currency Vault

| Room | Tier | Description | Encounters and rewards |
| --- | --- | --- | --- |
| Kishara's Vault | Tier 1 | Contains a large stash of Currency Room Destabilizes once complete | * Contains two Treasury Chests containing random [currency](/wiki/Currency "Currency"). |

### Lineage Gems Vault

Lineage Gems Vault

| Room | Tier | Description | Encounters and rewards |
| --- | --- | --- | --- |
| Hall of Reverence | Tier 1 | Contains a random Lineage Support Room Destabilizes once complete |  |

### Tablets Vault

Tablets Vault

| Room | Tier | Description | Encounters and rewards |
| --- | --- | --- | --- |
| Tablet Research Vault | Tier 1 | Contains a device allowing the corruption of tablets Room Destabilizes once complete | \* Corrupted Precursor Machine: Modifies a Precursor Tablet unpredictably, with a chance to destroy it. Can be taken as an [Ancient Infuser](/wiki/Ancient_Infuser "Ancient Infuser"). |

### Uniques Vault

The Uniques Vault Room Card specifies the random unique it contains. More common uniques are blocked from rolling at higher area level temples.

Uniques Vault

| Room | Tier | Description | Encounters and rewards |
| --- | --- | --- | --- |
| Ancient Reliquary Vault | Tier 1 | Contains a Unique Item: <Specific unique item> Room Destabilizes once complete | * Contains a Reliquary Display holding a specified random [unique item](/wiki/Unique_item "Unique item"). |

## Room interactions

Certain rooms will be upgraded when other room types are placed adjacent to it, making the monsters harder but also increasing the room's rewards. Rooms that interact with each other will automatically connect to each other, except for Generator which requires a Path connection to most rooms and a maximum total distance of 3-5, depending on tier.

Room interactions

| Placed room type | Upgraded room type | Notes |
| --- | --- | --- |
| Commander | ⇑Garrison |  |
| Armoury | ⇑Garrison |  |
| Synthflesh Lab | ⇑Garrison | Upgrades into a Tier 2 Transcendent Barracks instead |
| Spymaster | ⇑Garrison | Upgrades into a Tier 2 Legion Barracks instead |
| Garrison | ⇑Commander | Commander only upgraded if adjacent to 2 or 3+ Garrison and/or Transcendent Barracks |
| Transcendent Barracks | ⇑Commander | Commander only upgraded if adjacent to 2 or 3+ Garrison and/or Transcendent Barracks |
| Smithy | ⇑Armoury |  |
| Alchemy Lab | ⇑Armoury |  |
| Golem Works | ⇑Smithy |  |
| Generator | ⇑Smithy | Does not connect directly Does not need to be directly adjacent Must be connected within 3-5 tiles depending on Generator tier |
| Generator | ⇑Golem Works | Does not connect directly Does not need to be directly adjacent Must be connected within 3-5 tiles depending on Generator tier +2 Tier if connected to two Generators |
| Generator | ⇑Synthflesh Lab | Does not connect directly Does not need to be directly adjacent Must be connected within 3-5 tiles depending on Generator tier |
| Synthflesh Lab | ⇑Flesh Surgeon | Both rooms are upgraded +2 Tier if Synthflesh Lab is powered by Generator |
| Flesh Surgeon | ⇑Synthflesh Lab | Both rooms are upgraded |
| Thaumaturge | ⇑Generator |  |
| Thaumaturge | ⇑Corruption Chamber |  |
| Sacrificial Chamber | ⇑Corruption Chamber |  |
| Sacrificial Chamber | ⇑Thaumaturge | No upgrade if Sacrificial Chamber is Tier 1 +1 Tier if Sacrificial Chamber is Tier 2 +2 Tier if Sacrificial Chamber is Tier 3 |
| — | ⇑Sacrificial Chamber | Sacrificial Chamber only upgraded after sacrificing another room (does not have to be adjacent), destabilising it. Can be done up to Tier 3. |
| Spymaster | ⇑Spymaster | Spymaster only upgraded after assassinating another Spymaster (does not have to be adjacent), destabilising it on next temple closing. Can be done up to Tier 3. |

The following diagram can serve as a visual reference of all room interactions. It shows what rooms connect to each other. Keep in mind that rooms that connect don't necessarily upgrade each other, the upgrade requirements can be found above.

## Trivia

Many of the rooms found here share names with Incursion rooms in [Path of Exile](/wiki/Path_of_Exile "Path of Exile")'s [Temple of Atzoatl](https://www.poewiki.net/wiki/The_Temple_of_Atzoatl "poewiki:The Temple of Atzoatl"), and the grid system is similar to the one featured in [Synthesis league](https://www.poewiki.net/wiki/Synthesis "poewiki:Synthesis"). Because of this, the mechanic has been nicknamed "Synthcursion" by the community[[4]](#cite_note-4).

During [version 0.4.0c](/wiki/Version_0.4.0c "Version 0.4.0c"), four unreleased currency orbs (Brutal, Fortified, Profane, and Royal Orb of Sacrifice) were added to the [currency exchange market](/wiki/Currency_exchange_market "Currency exchange market") interface, but were not datamine-able or visible on the trade website. These items had the description Upgrades a Corruption Enchantment on a Rare <Weapon or Quiver/Armour/Amulet, Ring or Belt/Jewel> And removes a random Modifier respectively.
