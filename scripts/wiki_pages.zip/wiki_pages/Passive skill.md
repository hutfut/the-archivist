# Passive skill

Redirect to:

* [Passive Skill Tree](/wiki/Passive_Skill_Tree "Passive Skill Tree")
