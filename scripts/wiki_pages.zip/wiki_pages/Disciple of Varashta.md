# Disciple of Varashta

Disciple of Varashta

[Sorceress](/wiki/Sorceress "Sorceress")

|  |  |
| --- | --- |
|  | **By your command, they will earn redemption...one duty at a time.** |

Official artwork of the Disciple of Varashta.

**Disciple of Varashta** is an [Ascendancy class](/wiki/Ascendancy_class "Ascendancy class") for the [Sorceress](/wiki/Sorceress "Sorceress").

## Overview

The Disciple of Varashta can employ the services of Djinns who are bound to serve the great Sekhema Varashta as penance. Each the Djinn are invulnerable [minions](/wiki/Minion "Minion") that remain inert in their Baryas until the Disciple commands them to unleash their powers. The three Djinns are [Ruzhan](/wiki/Ruzhan,_the_Blazing_Sword "Ruzhan, the Blazing Sword") the fire Djinn, [Navira](/wiki/Navira,_the_Last_Mirage "Navira, the Last Mirage") the water Djinn, and [Kelari](/wiki/Kelari,_the_Tainted_Sands "Kelari, the Tainted Sands") the assassin Djinn. Each Djinn comes with their own set of abilities and additional [Command](/wiki/Command "Command") skills.

Aside from the Djinns, the Disciple can also learn defensive bonuses through [The Fourth Teaching](/wiki/The_Fourth_Teaching "The Fourth Teaching") to enhance [energy shield](/wiki/Energy_shield "Energy shield") recharge, [Sacred Rituals](/wiki/Sacred_Rituals "Sacred Rituals") to allow [energy shield](/wiki/Energy_shield "Energy shield") to contribute towards [armour](/wiki/Armour "Armour")'s damage reduction, and [Varashta's Intuition](/wiki/Varashta%27s_Intuition "Varashta's Intuition") to absorb elemental damage using mana. Alternatively, [Baryanic Leylines](/wiki/Baryanic_Leylines "Baryanic Leylines") can enhance socketed [Time-Lost Jewels](/wiki/Time-Lost_Jewel "Time-Lost Jewel") and [Instruments of Power](/wiki/Instruments_of_Power "Instruments of Power") grants the ability to equip a [staff](/wiki/Staff "Staff") and [focus](/wiki/Focus "Focus") together.

## Passive skills

### Minor skills

This class has the following minor passive skills:

| Name | Stats |
| --- | --- |
| [Area of Effect](/wiki/Area_of_Effect "Area of Effect") | 8% increased Area of Effect [[1]](/wiki/Passive_Skill:AscendancySorceress3Small6~ "Passive Skill:AscendancySorceress3Small6~") |
| [Cast Speed](/wiki/Cast_Speed "Cast Speed") | 4% increased Cast Speed [[1]](/wiki/Passive_Skill:AscendancySorceress3Small3 "Passive Skill:AscendancySorceress3Small3") [[2]](/wiki/Passive_Skill:AscendancySorceress3Small4 "Passive Skill:AscendancySorceress3Small4") |
| [Energy Shield](/wiki/Energy_Shield "Energy Shield") | 20% increased maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") [[1]](/wiki/Passive_Skill:AscendancySorceress3Small1 "Passive Skill:AscendancySorceress3Small1") [[2]](/wiki/Passive_Skill:AscendancySorceress3Small2 "Passive Skill:AscendancySorceress3Small2") |
| [Mana](/wiki/Mana_(passive_skill) "Mana (passive skill)") | 3% increased maximum Mana [[1]](/wiki/Passive_Skill:AscendancySorceress3Small5 "Passive Skill:AscendancySorceress3Small5") |

### Notable skills

This class has the following notable passive skills:

| Skill | Modifiers | Prerequisite | Preceding Passive |
| --- | --- | --- | --- |
| [Barya of Ruzhan](/wiki/Barya_of_Ruzhan "Barya of Ruzhan") | Grants Skill: [Ruzhan, the Blazing Sword](/wiki/Ruzhan,_the_Blazing_Sword "Ruzhan, the Blazing Sword") | — | — |
| [Ruzhan's Trap](/wiki/Ruzhan%27s_Trap_(passive) "Ruzhan's Trap (passive)") | Grants Skill: [Ruzhan's Trap](/wiki/Ruzhan%27s_Trap "Ruzhan's Trap") | [Barya of Ruzhan](/wiki/Barya_of_Ruzhan "Barya of Ruzhan") | — |
| [Ruzhan's Reckoning](/wiki/Ruzhan%27s_Reckoning_(passive) "Ruzhan's Reckoning (passive)") | Grants Skill: [Ruzhan's Reckoning](/wiki/Ruzhan%27s_Reckoning "Ruzhan's Reckoning") | [Barya of Ruzhan](/wiki/Barya_of_Ruzhan "Barya of Ruzhan") | — |
| [Ruzhan's Fury](/wiki/Ruzhan%27s_Fury_(passive) "Ruzhan's Fury (passive)") | Grants Skill: [Ruzhan's Fury](/wiki/Ruzhan%27s_Fury "Ruzhan's Fury") | [Barya of Ruzhan](/wiki/Barya_of_Ruzhan "Barya of Ruzhan") | — |
| [Barya of Navira](/wiki/Barya_of_Navira "Barya of Navira") | Grants Skill: [Navira, the Last Mirage](/wiki/Navira,_the_Last_Mirage "Navira, the Last Mirage") | — | — |
| [Navira's Fracturing](/wiki/Navira%27s_Fracturing_(passive) "Navira's Fracturing (passive)") | Grants Skill: [Navira's Fracturing](/wiki/Navira%27s_Fracturing "Navira's Fracturing") | [Barya of Navira](/wiki/Barya_of_Navira "Barya of Navira") | — |
| [Navira's Well](/wiki/Navira%27s_Well_(passive) "Navira's Well (passive)") | Grants Skill: [Navira's Well](/wiki/Navira%27s_Well "Navira's Well") | [Barya of Navira](/wiki/Barya_of_Navira "Barya of Navira") | — |
| [Navira's Oasis](/wiki/Navira%27s_Oasis_(passive) "Navira's Oasis (passive)") | Grants Skill: [Navira's Oasis](/wiki/Navira%27s_Oasis "Navira's Oasis") | [Barya of Navira](/wiki/Barya_of_Navira "Barya of Navira") | — |
| [Barya of Kelari](/wiki/Barya_of_Kelari "Barya of Kelari") | Grants Skill: [Kelari, the Tainted Sands](/wiki/Kelari,_the_Tainted_Sands "Kelari, the Tainted Sands") | — | — |
| [Kelari's Deception](/wiki/Kelari%27s_Deception_(passive) "Kelari's Deception (passive)") | Grants Skill: [Kelari's Deception](/wiki/Kelari%27s_Deception "Kelari's Deception") | [Barya of Kelari](/wiki/Barya_of_Kelari "Barya of Kelari") | — |
| [Kelari's Judgment](/wiki/Kelari%27s_Judgment_(passive) "Kelari's Judgment (passive)") | Grants Skill: [Kelari's Judgment](/wiki/Kelari%27s_Judgment "Kelari's Judgment") | [Barya of Kelari](/wiki/Barya_of_Kelari "Barya of Kelari") | — |
| [Kelari's Malediction](/wiki/Kelari%27s_Malediction_(passive) "Kelari's Malediction (passive)") | Grants Skill: [Kelari's Malediction](/wiki/Kelari%27s_Malediction "Kelari's Malediction") | [Barya of Kelari](/wiki/Barya_of_Kelari "Barya of Kelari") | — |
| [The Fourth Teaching](/wiki/The_Fourth_Teaching "The Fourth Teaching") | 40% more [Energy Shield Recharge Rate](/wiki/Energy_Shield "Energy Shield") while on [Low Energy Shield](/wiki/Low_Energy_Shield/edit?redlink=1 "Low Energy Shield (page does not exist)") -1 second to base [Energy Shield Recharge](/wiki/Energy_Shield_Recharge "Energy Shield Recharge") delay | — | Energy Shield |
| [Sacred Rituals](/wiki/Sacred_Rituals "Sacred Rituals") | 60% of your current [Energy Shield](/wiki/Energy_Shield "Energy Shield") is added to your [Armour](/wiki/Armour "Armour") for determining your Physical Damage Reduction from [Armour](/wiki/Armour "Armour") | [The Fourth Teaching](/wiki/The_Fourth_Teaching "The Fourth Teaching") | Energy Shield |
| [Varashta's Intuition](/wiki/Varashta%27s_Intuition "Varashta's Intuition") | 100% of [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") is taken from Mana before Life | — | Mana |
| [Instruments of Power](/wiki/Instruments_of_Power "Instruments of Power") | You can equip a [Focus](/wiki/Focus "Focus") while wielding a [Staff](/wiki/Staff "Staff") 50% reduced bonuses gained from Equipped [Focus](/wiki/Focus "Focus") | — | Cast Speed |
| [Baryanic Leylines](/wiki/Baryanic_Leylines "Baryanic Leylines") | Non-[Unique](/wiki/Unique "Unique") Time-Lost [Jewels](/wiki/Jewels "Jewels") have 40% increased radius | — | Area of Effect |
