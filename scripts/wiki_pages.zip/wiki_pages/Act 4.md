# Act 4

[File:Waypoint map act 4.jpg](/index.php?title=Special:Upload&wpDestFile=Waypoint_map_act_4.jpg "File:Waypoint map act 4.jpg")

Example overworld map of Act 4

**Act Four** is [Path of Exile 2](/wiki/Path_of_Exile_2 "Path of Exile 2")'s fourth storyline [act](/wiki/Act "Act"), taking place in the [Karui](/wiki/Karui/edit?redlink=1 "Karui (page does not exist)") archipelago of Ngamakanui. The player must search for three parts of the precursor weapon and a way to assemble it in order to subdue the Beast.

## Quests

* [The Search](/wiki/The_Search "The Search")
* [Shrike Island](/wiki/Shrike_Island_(Quest) "Shrike Island (Quest)") (rotating requirement)
* [Land of the Kin](/wiki/Land_of_the_Kin "Land of the Kin") (rotating requirement)
* [Whakapanu Island](/wiki/Whakapanu_Island_(Quest) "Whakapanu Island (Quest)") (rotating requirement)
* [Abandoned Prison](/wiki/Abandoned_Prison_(Quest) "Abandoned Prison (Quest)") (rotating requirement)
* [Dark Mists](/wiki/Dark_Mists "Dark Mists") (rotating requirement)
* [Utopia](/wiki/Utopia "Utopia")
* [Tribal Medicine](/wiki/Tribal_Medicine "Tribal Medicine") (optional)
* [Forgotten Bounty](/wiki/Forgotten_Bounty "Forgotten Bounty") (optional)
* [Trial of the Ancestors](/wiki/Trial_of_the_Ancestors_(Quest) "Trial of the Ancestors (Quest)") (optional)
* [Tawhoa's Test](/wiki/Tawhoa%27s_Test "Tawhoa's Test") (optional)
* [Tasalio's Test](/wiki/Tasalio%27s_Test "Tasalio's Test") (optional)
* [Ngamahu's Test](/wiki/Ngamahu%27s_Test "Ngamahu's Test") (optional)
* [Hostile Takeover](/wiki/Hostile_Takeover "Hostile Takeover") (optional)

## Progression

The first part of Act 4 is divided into several islands, each containing its own subset of zones. The player can visit most of these islands in any order.

Four out of five of the islands ([Abandoned Prison](/wiki/Abandoned_Prison "Abandoned Prison"), [Isle of Kin](/wiki/Isle_of_Kin "Isle of Kin"), [Kedge Bay](/wiki/Kedge_Bay "Kedge Bay"), [Shrike Island](/wiki/Shrike_Island "Shrike Island"), [Whakapanu Island](/wiki/Whakapanu_Island "Whakapanu Island")) contain either one of three precursor weapon pieces required to progress the main quest or [Matiki](/wiki/Matiki "Matiki"). These are randomized with each new [league](/wiki/League "League"). The area levels of these islands (and [Eye of Hinekora](/wiki/Eye_of_Hinekora "Eye of Hinekora")) are increased by completing each of the other islands.

[Arastas](/wiki/Arastas "Arastas") and [Ngakanu](/wiki/Ngakanu "Ngakanu") are also visitable initially, but most of the areas are locked behind act progression in the previously mentioned islands. They comprise the latter part of the act.

[Eye of Hinekora](/wiki/Eye_of_Hinekora "Eye of Hinekora") cannot be accessed until the player rescues [Matiki](/wiki/Matiki "Matiki"), and [Plunder's Point](/wiki/Plunder%27s_Point "Plunder's Point") cannot be accessed until the player finds all four [Torn Map Pieces](/wiki/Torn_Map_Piece "Torn Map Piece") from [Isle of Kin](/wiki/Isle_of_Kin "Isle of Kin"), [Kedge Bay](/wiki/Kedge_Bay "Kedge Bay"), [Whakapanu Island](/wiki/Whakapanu_Island "Whakapanu Island"), and [Shrike Island](/wiki/Shrike_Island "Shrike Island"). Neither of these islands are required to progress the act, however.

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  |  |  | ↓ |
| [Solitary Confinement](/wiki/Solitary_Confinement "Solitary Confinement")   47-52  Boss: [The Prisoner](/wiki/The_Prisoner "The Prisoner") | ↔ | [Abandoned Prison](/wiki/Abandoned_Prison "Abandoned Prison")   46-51 | ↔ | [Kingsmarch](/wiki/Kingsmarch "Kingsmarch") | | | ↔ | [Isle of Kin](/wiki/Isle_of_Kin "Isle of Kin")   46-51  Boss: [The Blind Beast](/wiki/The_Blind_Beast "The Blind Beast") | ↔ | [Volcanic Warrens](/wiki/Volcanic_Warrens "Volcanic Warrens")   47-52  Boss: [Krutog, Lord of Kin](/wiki/Krutog,_Lord_of_Kin "Krutog, Lord of Kin") |
|  |
|  |  | [Shrike Island](/wiki/Shrike_Island "Shrike Island")   46-51  Boss: [Scourge of the Skies](/wiki/Scourge_of_the_Skies "Scourge of the Skies") | ↔ | ↔ | [Kedge Bay](/wiki/Kedge_Bay "Kedge Bay")   46-51 | ↔ | [Journey's End](/wiki/Journey%27s_End "Journey's End")   47-52  Boss: [Captain Hartlin](/wiki/Captain_Hartlin "Captain Hartlin") |
|  |
|  |  | [Plunder's Point](/wiki/Plunder%27s_Point "Plunder's Point")   53 | ↔ | ↔ | [Whakapanu Island](/wiki/Whakapanu_Island "Whakapanu Island")   46-51  Boss: [Great White One](/wiki/Great_White_One "Great White One") | ↔ | [Singing Caverns](/wiki/Singing_Caverns "Singing Caverns")   47-52  Boss: [Diamora, Song of Death](/wiki/Diamora,_Song_of_Death "Diamora, Song of Death") |
|  |
| [Halls of the Dead](/wiki/Halls_of_the_Dead "Halls of the Dead")   47-52  Boss: [Yama The White](/wiki/Yama_The_White "Yama The White") | ↔ | [Eye of Hinekora](/wiki/Eye_of_Hinekora "Eye of Hinekora")   46-51 | ↔ | ↔ | [Arastas](/wiki/Arastas "Arastas")   52  Boss: [Torvian, Hand of the Saviour](/wiki/Torvian,_Hand_of_the_Saviour "Torvian, Hand of the Saviour") | → | [The Excavation](/wiki/The_Excavation "The Excavation")   52  Boss: [Benedictus, First Herald of Utopia](/wiki/Benedictus,_First_Herald_of_Utopia "Benedictus, First Herald of Utopia") |
| ↕ |  |  |  | ↕ |
| [Trial of the Ancestors](/wiki/Trial_of_the_Ancestors "Trial of the Ancestors")   46-51 |  |  |  | [Ngakanu](/wiki/Ngakanu "Ngakanu")   53 |
|  |  |  |  | ↕ |
|  |  |  |  | [Heart of the Tribe](/wiki/Heart_of_the_Tribe "Heart of the Tribe")   53   Act Boss: [Tavakai, the Chieftain](/wiki/Tavakai,_the_Chieftain "Tavakai, the Chieftain") |

## Videos

Click to load content
