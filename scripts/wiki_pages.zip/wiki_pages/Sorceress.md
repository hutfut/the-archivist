# Sorceress

The Sorceress

Gender: F
[Strength](/wiki/Strength "Strength"): 7
[Dexterity](/wiki/Dexterity "Dexterity"): 7
[Intelligence](/wiki/Intelligence "Intelligence"): 15
[Weapon](/wiki/Weapon "Weapon"): [Elemental Spells](/wiki/Gemcutting#Elemental "Gemcutting")

* [Ashen Staff](/wiki/Ashen_Staff "Ashen Staff")
* [Spark](/wiki/Spark "Spark")

[Ascendancies](/wiki/Ascendancy_class "Ascendancy class"):

[Stormweaver](/wiki/Stormweaver "Stormweaver")
 [Chronomancer](/wiki/Chronomancer "Chronomancer")
 [Disciple of Varashta](/wiki/Disciple_of_Varashta "Disciple of Varashta")

> The elements are mine to control. I know why lightning strikes, why fire burns, and why cold freezes. They do so because I command it. The vengeance of the Maraketh will find those who have transgressed no matter where they run.

The **Sorceress** is an [intelligence](/wiki/Intelligence "Intelligence")-oriented [class](/wiki/Character_class "Character class") that specializes in elemental spells. She is of [Maraketh](/wiki/Maraketh "Maraketh") heritage.

The Sorceress obtains a [Ashen Staff](/wiki/Ashen_Staff "Ashen Staff") and [Spark](/wiki/Spark "Spark") as her default starting weapon and skill in [The Riverbank](/wiki/The_Riverbank "The Riverbank").

## Ascendancy classes

Sorceresses can specialize into one of these three [Ascendancy classes](/wiki/Ascendancy_classes "Ascendancy classes"):

* [Stormweaver](/wiki/Stormweaver "Stormweaver")
* [Chronomancer](/wiki/Chronomancer "Chronomancer")
* [Disciple of Varashta](/wiki/Disciple_of_Varashta "Disciple of Varashta")
