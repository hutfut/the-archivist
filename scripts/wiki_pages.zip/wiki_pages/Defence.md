# Defence

Redirect to:

* [Defences](/wiki/Defences "Defences")
