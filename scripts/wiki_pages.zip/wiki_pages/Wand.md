# Wand

Wands

Tooltip

Wands are [One-Handed](/wiki/One-Handed "One-Handed") [Spellcasting](/wiki/Spell "Spell") weapons that require [Intelligence](/wiki/Intelligence "Intelligence") to equip.

Wands cannot be [Dual Wielded](/wiki/Dual_wielding "Dual wielding") and cannot be used to [Attack](/wiki/Attack "Attack") directly. However, they grant inbuilt [Spells](/wiki/Spell "Spell") based on the wand type and powerful bonuses to spells.

**Wand** is an [item class](/wiki/Item_class "Item class") of one-handed [weapons](/wiki/Weapons "Weapons") that require [intelligence](/wiki/Intelligence "Intelligence") to equip. They have no local attack stats, and instead roll modifiers for [spells](/wiki/Spell "Spell"). Wands come with an [implicit](/wiki/Implicit/edit?redlink=1 "Implicit (page does not exist)") modifier that grants a specific spell; this spell is used instead of a [default attack](/wiki/Default_attack "Default attack"). This inherent spell will also receive any bonuses to skill level that correctly applies to that skill's tags.

A wand's level and intelligence requirement is based on the level of its [granted skill](/wiki/Granted_skill "Granted skill") implicit.

## Mechanics

It is not possible to [dual wield](/wiki/Dual_wield "Dual wield") wands.

### Modifier affinity

Explicit modifiers on wands (and [staves](/wiki/Staves "Staves")) have some internal restrictions. Firstly, certain base types may have an "affinity" to a specific [damage type](/wiki/Damage_type "Damage type") which prevents certain modifiers without that affinity from being able to roll. The modifiers that are affected are:

* +# to Level of <Fire/Cold/Lightning/Physical/Chaos> Spell Skills (Modifier affinity: Fire/Cold/Lightning/Physical/Chaos)
* #% increased <Fire/Cold/Lightning/Chaos> Damage (Modifier affinity: Fire/Cold/Lightning/Chaos)
* #% increased Spell Physical Damage (Modifier affinity: Physical)
* Ailment modifiers
  + #% increased chance to Ignite (Modifier affinity: Fire+Physical)
  + #% increased Freeze Buildup (Modifier affinity: Cold+Physical)
  + #% increased chance to Shock (Modifier affinity: Lightning+Physical)

where X represents a damage type. For example, a [Volatile Wand](/wiki/Volatile_Wand "Volatile Wand") with a fire affinity can roll increased fire damage and chance to ignite, but not increased cold damage or chance to shock.

Other wand base types that do not have an affinity (e.g. [Attuned Wand](/wiki/Attuned_Wand "Attuned Wand")), can temporarily gain an affinity if it rolls any of the above modifiers, restricting its modifier pool. This affinity can be removed by removing any related modifiers. The [recombinator](/wiki/Recombinator "Recombinator") ignores temporary affinity, allowing a base without affinity to have non-matching mods, but respects item affinity and will not move a mod to a base it could not naturally roll on.

This affinity mechanic is unrelated to the modifier tags visible in the item's advanced description. It instead applies and uses spawn weight tags (e.g. "no\_fire\_spell\_mods").

## List of wands

Main article: [List of wands](/wiki/List_of_wands "List of wands")

| Item |  |  | Stats | Granted skills |
| --- | --- | --- | --- | --- |
| [Withered Wand](/wiki/Withered_Wand "Withered Wand") | 1 | 0 | — | Grants Skill: Level (1-20) [Chaos Bolt](/wiki/Chaos_Bolt "Chaos Bolt") |
| [Attuned Wand](/wiki/Attuned_Wand "Attuned Wand") | 2 | 0 | — | Grants Skill: Level (1-20) [Mana Drain](/wiki/Mana_Drain "Mana Drain") |
| [Bone Wand](/wiki/Bone_Wand "Bone Wand") | 2 | 0 | — | Grants Skill: Level (1-20) [Bone Blast](/wiki/Bone_Blast "Bone Blast") |
| [Siphoning Wand](/wiki/Siphoning_Wand "Siphoning Wand") | 11 | 0 | — | Grants Skill: Level (4-20) [Power Siphon](/wiki/Power_Siphon "Power Siphon") |
| [Volatile Wand](/wiki/Volatile_Wand "Volatile Wand") | 16 | 0 | — | Grants Skill: Level (5-20) [Volatile Dead](/wiki/Volatile_Dead "Volatile Dead") |
| [Galvanic Wand](/wiki/Galvanic_Wand "Galvanic Wand") | 25 | 0 | — | Grants Skill: Level (7-20) [Galvanic Field](/wiki/Galvanic_Field "Galvanic Field") |
| [Dueling Wand](/wiki/Dueling_Wand "Dueling Wand") | 65 | 0 | — | Grants Skill: Level (15-20) [Spellslinger](/wiki/Spellslinger "Spellslinger") |

## List of unique wands

Main article: [List of unique wands](/wiki/List_of_unique_wands "List of unique wands")

| Item |  |  | Stats | Granted skills |
| --- | --- | --- | --- | --- |
| [The Wicked Quill](/wiki/The_Wicked_Quill "The Wicked Quill") | 1 | 0 | (60-100)% increased [Spell](/wiki/Spell "Spell") Damage +(60-100) to maximum Mana +(7-13)% to [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance") [Spells](/wiki/Spell "Spell") have a 25% chance to inflict [Withered](/wiki/Withered "Withered") for 4 seconds on [Hit](/wiki/Hit "Hit") | Grants Skill: Level (1-20) [Chaos Bolt](/wiki/Chaos_Bolt "Chaos Bolt") |
| [Lifesprig](/wiki/Lifesprig "Lifesprig") | 2 | 0 | +(10-20) to maximum Mana +(1-3) to Level of all [Spell](/wiki/Spell "Spell") Skills (5-10)% increased Cast Speed [Leeches](/wiki/Leech "Leech") 1% of maximum Life when you Cast a [Spell](/wiki/Spell "Spell") | Grants Skill: Level (1-20) [Mana Drain](/wiki/Mana_Drain "Mana Drain") |
| [Sanguine Diviner](/wiki/Sanguine_Diviner "Sanguine Diviner") | 2 | 0 | (80-100)% increased [Spell](/wiki/Spell "Spell") Damage Gain (10-15) Life per enemy killed 25% chance to inflict [Bleeding](/wiki/Bleeding "Bleeding") on [Hit](/wiki/Hit "Hit") 25% of [Spell](/wiki/Spell "Spell") Mana Cost [Converted](/wiki/Stat_conversion "Stat conversion") to Life Cost | Grants Skill: Level (1-20) [Bone Blast](/wiki/Bone_Blast "Bone Blast") |
| [Enezun's Charge](/wiki/Enezun%27s_Charge "Enezun's Charge") | 16 | 0 | (80-100)% increased [Spell](/wiki/Spell "Spell") Damage (30-50)% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for [Spells](/wiki/Spell "Spell") Gain (10-15) Mana per enemy killed 25% chance to not destroy [Corpses](/wiki/Corpse "Corpse") when Consuming [Corpses](/wiki/Corpse "Corpse") | Grants Skill: Level (5-20) [Volatile Dead](/wiki/Volatile_Dead "Volatile Dead") |
| [Cursecarver](/wiki/Cursecarver "Cursecarver") | 33 | 0 | (80-100)% increased [Spell](/wiki/Spell "Spell") Damage (10-20)% increased Cast Speed Lose 10 Life per enemy killed (30-50)% increased Mana Regeneration Rate   | +4 to Level of <Random Curse> Skills | | --- | | +4 to Level of [Despair](/wiki/Despair "Despair") Skills  ---  +4 to Level of [Elemental Weakness](/wiki/Elemental_Weakness "Elemental Weakness") Skills  ---  +4 to Level of [Enfeeble](/wiki/Enfeeble "Enfeeble") Skills  ---  +4 to Level of [Temporal Chains](/wiki/Temporal_Chains "Temporal Chains") Skills  ---  +4 to Level of [Vulnerability](/wiki/Vulnerability "Vulnerability") Skills | | Grants Skill: Level (9-20) [Decompose](/wiki/Decompose "Decompose") |
| [Adonia's Ego](/wiki/Adonia%27s_Ego "Adonia's Ego") | 65 | 0 | +(100-150) to maximum Mana +3 to Level of all [Spell](/wiki/Spell "Spell") Skills (15-30)% increased Cast Speed -10% to all [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") per [Power Charge](/wiki/Power_Charge "Power Charge") +(-1-1) to Maximum [Power Charges](/wiki/Power_Charge "Power Charge") | Grants Skill: Level (15-20) [Power Siphon](/wiki/Power_Siphon "Power Siphon") Grants Skill: Level 20 [Pinnacle of Power](/wiki/Pinnacle_of_Power "Pinnacle of Power") |
