# Armour (equipment)

For the defence stat, see [Armour](/wiki/Armour "Armour").

**Armour** are a category of [equipment](/wiki/Equipment "Equipment") equipped to slots associated with different body parts to provide both defensive and offensive benefits.

Armour as a category encompasses several [item classes](/wiki/Item_class "Item class"): [helmets](/wiki/Helmet "Helmet"), [body armours](/wiki/Body_armour "Body armour"), [gloves](/wiki/Gloves "Gloves"), [boots](/wiki/Boots "Boots"), and [shields](/wiki/Shield "Shield")/[foci](/wiki/Foci "Foci").

Armour base types follow a specific naming pattern based on their attribute alignments.

Additionally, all primary attribute shields face left in their 2D artwork, while all hybrid attribute shields face right.

Armour attribute alignment

| Base type name | [Strength](/wiki/Strength "Strength") | [Dexterity](/wiki/Dexterity "Dexterity") | [Intelligence](/wiki/Intelligence "Intelligence") |
| --- | --- | --- | --- |
| [Greathelm](/wiki/Helmet#Armour_(Strength) "Helmet") [Plate](/wiki/Body_armour#Armour_(Strength) "Body armour") • [Cuirass](/wiki/Body_armour#Armour_(Strength) "Body armour") [Mitts](/wiki/Gloves#Armour_(Strength) "Gloves") [Greaves](/wiki/Boots#Armour_(Strength) "Boots") [Tower Shield](/wiki/Shield#Armour_(Strength) "Shield") | 100% | 0% | 0% |
| [Hood](/wiki/Helmet#Evasion_(Dexterity) "Helmet") • [Cap](/wiki/Helmet#Evasion_(Dexterity) "Helmet") [Vest](/wiki/Body_armour#Evasion_(Dexterity) "Body armour") • [Coat](/wiki/Body_armour#Evasion_(Dexterity) "Body armour") [Bracers](/wiki/Gloves#Evasion_(Dexterity) "Gloves") [Boots](/wiki/Boots#Evasion_(Dexterity) "Boots") [Buckler](/wiki/Shield#Evasion_(Dexterity) "Shield") | 0% | 100% | 0% |
| [Tiara](/wiki/Helmet#Energy_Shield_(Intelligence) "Helmet") • [Circlet](/wiki/Helmet#Energy_Shield_(Intelligence) "Helmet") [Robe](/wiki/Body_armour#Energy_Shield_(Intelligence) "Body armour") • [Raiment](/wiki/Body_armour#Energy_Shield_(Intelligence) "Body armour") [Gloves](/wiki/Gloves#Energy_Shield_(Intelligence) "Gloves") [Sandals](/wiki/Boots#Energy_Shield_(Intelligence) "Boots") [Focus](/wiki/Focus "Focus") | 0% | 0% | 100% |
| [Helm](/wiki/Helmet#Armour/Evasion_(Strength/Dexterity) "Helmet") [Armour](/wiki/Body_armour#Armour/Evasion_(Strength/Dexterity) "Body armour") • [Mail](/wiki/Body_armour#Armour/Evasion_(Strength/Dexterity) "Body armour") [Gauntlets](/wiki/Gloves#Armour/Evasion_(Strength/Dexterity) "Gloves") [Sabatons](/wiki/Boots#Armour/Energy_Shield_(Strength/Intelligence) "Boots") [Targe](/wiki/Shield#Armour/Evasion_(Strength/Dexterity) "Shield") | 50% | 50% | 0% |
| [Crown](/wiki/Helmet#Armour/Energy_Shield_(Strength/Intelligence) "Helmet") [Vestments](/wiki/Body_armour#Armour/Energy_Shield_(Strength/Intelligence) "Body armour") • [Mantle](/wiki/Body_armour#Armour/Energy_Shield_(Strength/Intelligence) "Body armour") [Cuffs](/wiki/Gloves#Armour/Energy_Shield_(Strength/Intelligence) "Gloves") [Leggings](/wiki/Boots#Armour/Energy_Shield_(Strength/Intelligence) "Boots") [Crest Shield](/wiki/Shield#Armour/Energy_Shield_(Strength/Intelligence) "Shield") | 50% | 0% | 50% |
| [Mask](/wiki/Helmet#Evasion/Energy_Shield_(Dexterity/Intelligence) "Helmet") [Garb](/wiki/Body_armour#Evasion/Energy_Shield_(Dexterity/Intelligence) "Body armour") • [Jacket](/wiki/Body_armour#Evasion/Energy_Shield_(Dexterity/Intelligence) "Body armour") [Wraps](/wiki/Gloves#Evasion/Energy_Shield_(Dexterity/Intelligence) "Gloves") [Shoes](/wiki/Boots#Evasion/Energy_Shield_(Dexterity/Intelligence) "Boots") N/A | 0% | 50% | 50% |
