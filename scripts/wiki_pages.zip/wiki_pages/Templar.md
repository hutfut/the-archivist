# Templar

This article is about unreleased content and is not yet available in the game.

The Templar

Gender: M
[Strength](/wiki/Strength "Strength"): 11
[Dexterity](/wiki/Dexterity "Dexterity"): 7
[Intelligence](/wiki/Intelligence "Intelligence"): 11

The **Templar** is a [strength](/wiki/Strength "Strength")/[intelligence](/wiki/Intelligence "Intelligence")-oriented [class](/wiki/Character_class "Character class") that specializes in ? skills.

The Templar obtains a **Module Error: No results found for item using search term "item\_name = "** and **Module Error: No results found for item using search term "item\_name = "** as his default starting weapon and skill in [The Riverbank](/wiki/The_Riverbank "The Riverbank").

## Ascendancy classes

Templars can specialize into one of these three [Ascendancy classes](/wiki/Ascendancy_classes "Ascendancy classes"):

* TBA
* TBA
* TBA
