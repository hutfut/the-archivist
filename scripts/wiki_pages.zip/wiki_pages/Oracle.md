# Oracle

Oracle

[Druid](/wiki/Druid "Druid")

|  |  |
| --- | --- |
|  | **There are many paths to achieve your goals... and you see them all.** |

Official artwork of the Oracle

**Oracle** is an [Ascendancy class](/wiki/Ascendancy_class "Ascendancy class") for the [Druid](/wiki/Druid "Druid").

## Overview

The Oracle uses the power of Foresight to outmatch his foes and unlock new abilities. With [Fateful Vision](/wiki/Fateful_Vision "Fateful Vision"), the Oracle can see his future self using a random skill, which gets empowered if he does the same. With [Converging Paths](/wiki/Converging_Paths "Converging Paths"), he can bring a future vision of an enemy about to become [immobilised](/wiki/Immobilise "Immobilise") into the present to harm it while it's vulnerable. The Oracle can manipulate the odds in his favor with [The Lesser Harm](/wiki/The_Lesser_Harm "The Lesser Harm") to make enemy damage and critical hit chance [unlucky](/wiki/Luck "Luck"), and [Forced Outcome](/wiki/Forced_Outcome "Forced Outcome") to always guarantee his hits become [critical hits](/wiki/Critical_hit "Critical hit"), at the cost of potential damage. [The Unseen Path](/wiki/The_Unseen_Path "The Unseen Path") allows the Oracle to take passives on the [passive skill tree](/wiki/Passive_skill_tree "Passive skill tree") no other classes have access to, and [Entwined Realities](/wiki/Entwined_Realities "Entwined Realities") to allocate unconnected passives near [keystones](/wiki/Keystone "Keystone"). Additionally, [Unnamed Heartwood](/wiki/Unnamed_Heartwood "Unnamed Heartwood") grants additional [totem](/wiki/Totem "Totem") limit and delays their death, and [Harmony Within](/wiki/Harmony_Within "Harmony Within") grants an alternative way to use [mana](/wiki/Mana "Mana") as a life pool.

## Passive skills

### Minor skills

This class has the following minor passive skills:

| Name | Stats |
| --- | --- |
| [Critical Damage Bonus on You](/wiki/Critical_Damage_Bonus_on_You/edit?redlink=1 "Critical Damage Bonus on You (page does not exist)") | Hits against you have 12% reduced [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus") [[1]](/wiki/Passive_Skill:AscendancyDruid1Small7 "Passive Skill:AscendancyDruid1Small7") |
| [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") | 12% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") [[1]](/wiki/Passive_Skill:AscendancyDruid1Small8 "Passive Skill:AscendancyDruid1Small8") |
| [Immobilisation Buildup](/wiki/Immobilisation_Buildup/edit?redlink=1 "Immobilisation Buildup (page does not exist)") | 20% increased [Immobilisation](/wiki/Immobilised "Immobilised") buildup [[1]](/wiki/Passive_Skill:AscendancyDruid1Small4 "Passive Skill:AscendancyDruid1Small4") |
| [Life and Mana Regeneration Rate](/wiki/Life_and_Mana_Regeneration_Rate/edit?redlink=1 "Life and Mana Regeneration Rate (page does not exist)") | 8% increased Life Regeneration rate 8% increased Mana Regeneration Rate [[1]](/wiki/Passive_Skill:AscendancyDruid1Small3 "Passive Skill:AscendancyDruid1Small3") |
| [Passive Point](/wiki/Passive_Point/edit?redlink=1 "Passive Point (page does not exist)") | Grants 1 Passive Skill Point [[1]](/wiki/Passive_Skill:AscendancyDruid1Small1 "Passive Skill:AscendancyDruid1Small1") [[2]](/wiki/Passive_Skill:AscendancyDruid1Small2 "Passive Skill:AscendancyDruid1Small2") |
| [Spell Damage](/wiki/Spell_Damage_(passive_skill) "Spell Damage (passive skill)") | 12% increased [Spell](/wiki/Spell "Spell") Damage [[1]](/wiki/Passive_Skill:AscendancyDruid1Small5 "Passive Skill:AscendancyDruid1Small5") |
| [Totem Cast and Attack Speed](/wiki/Totem_Cast_and_Attack_Speed/edit?redlink=1 "Totem Cast and Attack Speed (page does not exist)") | [Spells](/wiki/Spell "Spell") Cast by [Totems](/wiki/Totem "Totem") have 5% increased Cast Speed [Attacks](/wiki/Attack "Attack") used by Totems have 5% increased [Attack](/wiki/Attack "Attack") Speed [[1]](/wiki/Passive_Skill:AscendancyDruid1Small6 "Passive Skill:AscendancyDruid1Small6") |

### Notable skills

This class has the following notable passive skills:

| Skill | Modifiers | Prerequisite | Preceding Passive |
| --- | --- | --- | --- |
| [The Lesser Harm](/wiki/The_Lesser_Harm "The Lesser Harm") | Damage of Enemies [Hitting](/wiki/Hit "Hit") you is [Unlucky](/wiki/Unlucky "Unlucky") Enemy [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") against you is [Unlucky](/wiki/Unlucky "Unlucky") | — | Critical Damage Bonus on You |
| [Forced Outcome](/wiki/Forced_Outcome "Forced Outcome") | [Inevitable Critical Hits](/wiki/Inevitable_Critical_Hits "Inevitable Critical Hits") | [The Lesser Harm](/wiki/The_Lesser_Harm "The Lesser Harm") | Critical Hit Chance |
| [Unnamed Heartwood](/wiki/Unnamed_Heartwood "Unnamed Heartwood") | +1 to maximum number of Summoned [Totems](/wiki/Totem "Totem") [Totems](/wiki/Totem "Totem") die 6 seconds after their Life is reduced to 0 | — | Totem Cast and Attack Speed |
| [Converging Paths](/wiki/Converging_Paths "Converging Paths") | Grants Skill: [Moment of Vulnerability](/wiki/Moment_of_Vulnerability "Moment of Vulnerability") | — | Immobilisation Buildup |
| [Harmony Within](/wiki/Harmony_Within "Harmony Within") | [Hit](/wiki/Hit "Hit") damage is taken from Mana before Life if your current Mana is higher than your current Life 15% less maximum Life 15% less maximum Mana | — | Life and Mana Regeneration Rate |
| [Fateful Vision](/wiki/Fateful_Vision "Fateful Vision") | Grants Skill: [Align Fate](/wiki/Align_Fate "Align Fate") | — | Spell Damage |
| [The Unseen Path](/wiki/The_Unseen_Path "The Unseen Path") | Walk the [Paths Not Taken](/wiki/Paths_Not_Taken "Paths Not Taken") | — | Passive Point |
| [Entwined Realities](/wiki/Entwined_Realities "Entwined Realities") | Non-Keystone Passive Skills in Medium Radius of allocated Keystone Passive Skills can be allocated without being connected to your tree | [The Unseen Path](/wiki/The_Unseen_Path "The Unseen Path") | Passive Point |
