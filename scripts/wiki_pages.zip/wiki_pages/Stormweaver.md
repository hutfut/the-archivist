# Stormweaver

Stormweaver

[Sorceress](/wiki/Sorceress "Sorceress")

|  |  |
| --- | --- |
|  | **The rumble of thunder heralds your approach. Woe to those that draw your ire.** |

Official artwork of the Stormweaver.

**Stormweaver** is an [Ascendancy class](/wiki/Ascendancy_class "Ascendancy class") for the [Sorceress](/wiki/Sorceress "Sorceress").

## Overview

The Stormweaver is an arcane master of the elements. The Stormweaver can be built around [chill](/wiki/Chill "Chill") or [shock](/wiki/Shock "Shock") by allowing them to stack twice and having all damage types to contribute towards their application. She is able to generate [Elemental Storms](/wiki/Elemental_Storm "Elemental Storm") on [critical hits](/wiki/Critical_hit "Critical hit") to devastate the battlefield, and improve her ability to collect and generate [Elemental Infusions](/wiki/Elemental_Infusion "Elemental Infusion"). She can also gain permanent [Arcane Surge](/wiki/Arcane_Surge "Arcane Surge") and use some of her [mana](/wiki/Mana "Mana") to protect her life.

## Passive skills

### Minor skills

This class has the following minor passive skills:

| Name | Stats |
| --- | --- |
| [Chill Duration](/wiki/Chill_Duration/edit?redlink=1 "Chill Duration (page does not exist)") | 25% increased [Chill](/wiki/Chill "Chill") Duration on Enemies [[1]](/wiki/Passive_Skill:AscendancySorceress1Small7 "Passive Skill:AscendancySorceress1Small7") [[2]](/wiki/Passive_Skill:AscendancySorceress1Small8 "Passive Skill:AscendancySorceress1Small8") |
| [Mana Regeneration](/wiki/Mana_Regeneration/edit?redlink=1 "Mana Regeneration (page does not exist)") | 12% increased Mana Regeneration Rate [[1]](/wiki/Passive_Skill:AscendancySorceress1Small1 "Passive Skill:AscendancySorceress1Small1") [[2]](/wiki/Passive_Skill:AscendancySorceress1Small2 "Passive Skill:AscendancySorceress1Small2") |
| [Remnant Range](/wiki/Remnant_Range/edit?redlink=1 "Remnant Range (page does not exist)") | [Remnants](/wiki/Remnant "Remnant") can be collected from 25% further away [[1]](/wiki/Passive_Skill:AscendancySorceress1Small10 "Passive Skill:AscendancySorceress1Small10") [[2]](/wiki/Passive_Skill:AscendancySorceress1Small9 "Passive Skill:AscendancySorceress1Small9") |
| [Shock Chance](/wiki/Shock_Chance "Shock Chance") | 20% increased chance to [Shock](/wiki/Shock "Shock") [[1]](/wiki/Passive_Skill:AscendancySorceress1Small5 "Passive Skill:AscendancySorceress1Small5") [[2]](/wiki/Passive_Skill:AscendancySorceress1Small6 "Passive Skill:AscendancySorceress1Small6") |
| [Spell Critical Chance](/wiki/Spell_Critical_Chance/edit?redlink=1 "Spell Critical Chance (page does not exist)") | 12% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for [Spells](/wiki/Spell "Spell") [[1]](/wiki/Passive_Skill:AscendancySorceress1Small3 "Passive Skill:AscendancySorceress1Small3") [[2]](/wiki/Passive_Skill:AscendancySorceress1Small4 "Passive Skill:AscendancySorceress1Small4") |

### Notable skills

This class has the following notable passive skills:

| Skill | Modifiers | Prerequisite | Preceding Passive |
| --- | --- | --- | --- |
| [Refracted Infusion](/wiki/Refracted_Infusion "Refracted Infusion") | When collecting an [Elemental Infusion](/wiki/Elemental_Infusion "Elemental Infusion"), gain another different [Elemental Infusion](/wiki/Elemental_Infusion "Elemental Infusion") | — | Remnant Range |
| [Constant Gale](/wiki/Constant_Gale "Constant Gale") | You have [Arcane Surge](/wiki/Arcane_Surge "Arcane Surge") | — | [Mana Regeneration Rate](/wiki/Mana_Regeneration_Rate_(ascendancy_passive_skill) "Mana Regeneration Rate (ascendancy passive skill)") |
| [Force of Will](/wiki/Force_of_Will "Force of Will") | 20% increased [Effect](/wiki/Buff "Buff") of [Arcane Surge](/wiki/Arcane_Surge "Arcane Surge") on you per ten percent missing Mana 20% of Damage is taken from Mana before Life | [Constant Gale](/wiki/Constant_Gale "Constant Gale") | [Mana Regeneration Rate](/wiki/Mana_Regeneration_Rate_(ascendancy_passive_skill) "Mana Regeneration Rate (ascendancy passive skill)") |
| [Strike Twice](/wiki/Strike_Twice "Strike Twice") | Targets can be affected by two of your [Shocks](/wiki/Shock "Shock") at the same time 25% less [Magnitude](/wiki/Magnitude "Magnitude") of [Shock](/wiki/Shock "Shock") you inflict | — | [Shock Chance](/wiki/Shock_Chance_(ascendancy_passive_skill) "Shock Chance (ascendancy passive skill)") |
| [Shaper of Storms](/wiki/Shaper_of_Storms "Shaper of Storms") | [All Damage](/wiki/Damage_type "Damage type") from [Hits](/wiki/Hit "Hit") [Contributes](/wiki/Contributes "Contributes") to [Shock](/wiki/Shock "Shock") Chance | [Strike Twice](/wiki/Strike_Twice "Strike Twice") | [Shock Chance](/wiki/Shock_Chance_(ascendancy_passive_skill) "Shock Chance (ascendancy passive skill)") |
| [Heavy Snows](/wiki/Heavy_Snows "Heavy Snows") | Targets can be affected by two of your [Chills](/wiki/Chill "Chill") at the same time 25% less [Magnitude](/wiki/Magnitude "Magnitude") of [Chill](/wiki/Chill "Chill") you inflict Your [Chills](/wiki/Chill "Chill") can [Slow](/wiki/Slow "Slow") targets by up to a maximum of 35% | — | [Chill Duration](/wiki/Chill_Duration_(ascendancy_passive_skill) "Chill Duration (ascendancy passive skill)") |
| [Shaper of Winter](/wiki/Shaper_of_Winter "Shaper of Winter") | [All Damage](/wiki/Damage_type "Damage type") from [Hits](/wiki/Hit "Hit") [Contributes](/wiki/Contributes "Contributes") to [Chill](/wiki/Chill "Chill") Magnitude | [Heavy Snows](/wiki/Heavy_Snows "Heavy Snows") | [Chill Duration](/wiki/Chill_Duration_(ascendancy_passive_skill) "Chill Duration (ascendancy passive skill)") |
| [Tempest Caller](/wiki/Tempest_Caller "Tempest Caller") | Grants Skill: [Elemental Storm](/wiki/Elemental_Storm "Elemental Storm") Trigger Elemental Storm on [Critical Hit](/wiki/Critical_Hit "Critical Hit") with [Spells](/wiki/Spell "Spell") | — | [Spell Critical Chance](/wiki/Spell_Critical_Chance_(ascendancy_passive_skill) "Spell Critical Chance (ascendancy passive skill)") |
| [Multiplying Squalls](/wiki/Multiplying_Squalls "Multiplying Squalls") | +2 to [Limit](/wiki/Limit "Limit") for [Elemental](/wiki/Elemental "Elemental") Skills | [Tempest Caller](/wiki/Tempest_Caller "Tempest Caller") | [Spell Critical Chance](/wiki/Spell_Critical_Chance_(ascendancy_passive_skill) "Spell Critical Chance (ascendancy passive skill)") |
| [Storm's Recollection](/wiki/Storm%27s_Recollection "Storm's Recollection") | [Remnants](/wiki/Remnant "Remnant") you create reappear once, 3 seconds after being collected [Remnants](/wiki/Remnant "Remnant") can be collected from 50% further away | — | Remnant Range |
