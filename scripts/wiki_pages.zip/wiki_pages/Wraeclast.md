# Wraeclast

✍️This article is a [stub](/wiki/Category:Stubs "Category:Stubs"). Please help [improve the article](https://www.poe2wiki.net/wiki/Wraeclast/edit) by expanding it.

**Wraeclast** is the continent on which the story of Path of Exile 2 takes place (at least so far). Many areas which were previously visited in Path of Exile 1 have been expanded or reimagined for this game, and even more new areas are now available to explore as your proceed through the [Campaign](/wiki/Act "Act").

An example of another continent shown in Path of Exile 1 is Oriath.
