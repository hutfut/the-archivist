# Endgame

✍️This article is a [stub](/wiki/Category:Stubs "Category:Stubs"). Please help [improve the article](https://www.poe2wiki.net/wiki/Endgame/edit) by expanding it.

**Endgame** in [Path of Exile 2](/wiki/Path_of_Exile_2 "Path of Exile 2") is the epilogue of the storyline's [acts](/wiki/Act "Act"), which currently takes place within [The Ziggurat Refuge](/wiki/The_Ziggurat_Refuge "The Ziggurat Refuge"). Here, players are introduced to [the Atlas](/wiki/The_Atlas "The Atlas") and the endgame [map](/wiki/Map "Map") system.

The player and [The Hooded One](/wiki/The_Hooded_One "The Hooded One") head for [Oriath](/wiki/Oriath/edit?redlink=1 "Oriath (page does not exist)") with allies in tow, but by the time they arrive, they're too late - the Beast had awoken and caused a new Cataclysm. Few manage to survive, but the Weapon is destroyed and the Hooded One is left in a comatose state. Taking refuge in the Ziggurat Refuge, yet another one of [Doryani](/wiki/Doryani "Doryani")'s contingency plan, the player must work with Doryani and traverse across Wraeclast using the [Map Device](/wiki/Map_Device "Map Device") to undo as much damage the Cataclysm had caused.

## NPCs

### Guaranteed NPCs

This section is [transcluded](/wiki/Help:Transclusion "Help:Transclusion") from [The Ziggurat Refuge#Guaranteed NPCs](/wiki/The_Ziggurat_Refuge#Guaranteed_NPCs "The Ziggurat Refuge"). ([edit](https://www.poe2wiki.net/wiki/The_Ziggurat_Refuge/edit#Guaranteed_NPCs) | [history](https://www.poe2wiki.net/wiki/The_Ziggurat_Refuge/history#Guaranteed_NPCs))

| NPC | Buy/Sell Vendor Type | Other services |
| --- | --- | --- |
| [Doryani](/wiki/Doryani "Doryani") | [Waystones](/wiki/Waystone "Waystone") | Identifies [items](/wiki/Items "Items") Refunds [passive skill points](/wiki/Passive_Skill_Tree#Refunding "Passive Skill Tree") Refunds [Atlas passive skill points](/wiki/Atlas_Passive_Tree "Atlas Passive Tree") |
| [Zelina](/wiki/Zelina "Zelina") | Martial [weapons](/wiki/Weapon "Weapon") [Armour](/wiki/Armour_(equipment) "Armour (equipment)") |  |
| [Zolin](/wiki/Zolin "Zolin") | [Caster weapons](/wiki/Weapon#Non-martial_weapons "Weapon") [Charms](/wiki/Charm "Charm") • [Flasks](/wiki/Flask "Flask") [Scrolls of Wisdom](/wiki/Scroll_of_Wisdom "Scroll of Wisdom") | Item [Disenchanting](/wiki/Disenchanting "Disenchanting") |
| [Alva](/wiki/Alva "Alva") |  | Change [Hideout](/wiki/Hideout "Hideout") |
| [Ange](/wiki/Ange "Ange") |  | [Gambling](/wiki/Vendor#Gambling "Vendor") [Currency exchange](/wiki/Currency_exchange "Currency exchange") [Asynchronous trading](/wiki/Asynchronous_trading "Asynchronous trading") |

### Expedition NPCs

This section is [transcluded](/wiki/Help:Transclusion "Help:Transclusion") from [Expedition#NPCs](/wiki/Expedition#NPCs "Expedition"). ([edit](https://www.poe2wiki.net/wiki/Expedition/edit#NPCs) | [history](https://www.poe2wiki.net/wiki/Expedition/history#NPCs))

*These NPCs will appear if previously interacted with:*

| Vendor | Faction | Currency | Crafting type |
| --- | --- | --- | --- |
| [Dannig](/wiki/Dannig "Dannig") | Knights of the Sun | * [Sun Artifact](/wiki/Sun_Artifact "Sun Artifact") | [Expedition Artifacts](/wiki/Expedition_Artifact "Expedition Artifact") |
| [Gwennen](/wiki/Gwennen "Gwennen") | Druids of the Broken Circle | * [Broken Circle Artifact](/wiki/Broken_Circle_Artifact "Broken Circle Artifact") * [Exotic Coinage](/wiki/Exotic_Coinage "Exotic Coinage") | [Weapons](/wiki/Weapons "Weapons") [Focus](/wiki/Focus "Focus") [Quivers](/wiki/Quivers "Quivers") |
| [Rog](/wiki/Rog "Rog") | Order of the Chalice | * [Order Artifact](/wiki/Order_Artifact "Order Artifact") * [Exotic Coinage](/wiki/Exotic_Coinage "Exotic Coinage") | [Armours](/wiki/Armour_(equipement) "Armour (equipement)") [Shields](/wiki/Shield "Shield") |
| [Tujen](/wiki/Tujen "Tujen") | Black Scythe Mercenaries | * [Black Scythe Artifact](/wiki/Black_Scythe_Artifact "Black Scythe Artifact") * [Exotic Coinage](/wiki/Exotic_Coinage "Exotic Coinage") | [Jewellery](/wiki/Jewellery "Jewellery") [Belts](/wiki/Belt "Belt") |

## Quests

* [Legacy of the Vaal](/wiki/Legacy_of_the_Vaal "Legacy of the Vaal")
* [Cataclysm's Wake](/wiki/Cataclysm%27s_Wake "Cataclysm's Wake")
* [The Pinnacle of Flame](/wiki/The_Pinnacle_of_Flame "The Pinnacle of Flame")
* [Ezomyte Infiltration](/wiki/Ezomyte_Infiltration "Ezomyte Infiltration")
* [Faridun Foray](/wiki/Faridun_Foray "Faridun Foray")
* [Vaal Incursion](/wiki/Vaal_Incursion "Vaal Incursion")
* [Power Awaits You](/wiki/Power_Awaits_You "Power Awaits You")
