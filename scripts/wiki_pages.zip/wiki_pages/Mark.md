# Mark

Mark

Tooltip

Marks are a family of [Debuffs](/wiki/Debuff "Debuff") that apply powerful effects to a single enemy, usually for a limited duration. You can have multiple Marked enemies at once, but each individual enemy can only have a single Mark applied to them at once.

Marks can be [Activated](/wiki/Activating_Marks/edit?redlink=1 "Activating Marks (page does not exist)") when specific conditions occur, which will case some extra effect and then [Consume](/wiki/Effect_Consumption "Effect Consumption") the Mark.

**Mark** is a gem tag for [skills](/wiki/Skill "Skill") which place a specific type of [debuff](/wiki/Debuff "Debuff") on an enemy. You can place the same mark on multiple enemies, but each enemy can only have one Mark on them at a time by default. Marks have a conditional effect that causes them to activate, triggering that effect and then consuming the mark from that target.

## Related skills

The following [skills](/wiki/Skill "Skill") have the Mark [gem tag](/wiki/Gem_tag "Gem tag"):

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Pounce](/wiki/Pounce "Pounce") | *3* |  |  |  |
| [Sniper's Mark](/wiki/Sniper%27s_Mark "Sniper's Mark") | *7* |  |  |  |
| [Voltaic Mark](/wiki/Voltaic_Mark "Voltaic Mark") | *7* |  |  |  |
| [Freezing Mark](/wiki/Freezing_Mark "Freezing Mark") | *7* |  |  |  |
| [Bloodhound's Mark](/wiki/Bloodhound%27s_Mark "Bloodhound's Mark") | *9* |  |  |  |

The following skills interact with marks:

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Cross Slash](/wiki/Cross_Slash "Cross Slash") | *7* |  |  |  |
| [Hand of Chayula](/wiki/Hand_of_Chayula "Hand of Chayula") | *9* |  |  |  |

### Persistent skills

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Called Shots](/wiki/Called_Shots "Called Shots") | *0* |  |  |  |
| [Rhoa Mount](/wiki/Rhoa_Mount "Rhoa Mount") | *14* |  |  |  |

## Related support gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Mark of Siphoning I](/wiki/Mark_of_Siphoning_I "Mark of Siphoning I") | *1* |  |  |  |
| [Mark for Death I](/wiki/Mark_for_Death_I "Mark for Death I") | *2* |  |  |  |
| [Eternal Mark](/wiki/Eternal_Mark "Eternal Mark") | *3* |  |  |  |
| [Mark of Siphoning II](/wiki/Mark_of_Siphoning_II "Mark of Siphoning II") | *4* |  |  |  |
| [Mark for Death II](/wiki/Mark_for_Death_II "Mark for Death II") | *4* |  |  |  |
| [Charged Mark](/wiki/Charged_Mark "Charged Mark") | *5* |  |  |  |

## Related unique items

No results found

## Related augments

No results found

## Related passive skills

The following [passive skills](/wiki/Passive_skill "Passive skill") are related to marks:

| Name | Stats |
| --- | --- |
| [Mark Duration](/wiki/Mark_Duration/edit?redlink=1 "Mark Duration (page does not exist)") | Mark Skills have 25% increased Skill Effect Duration [[1]](/wiki/Passive_Skill:Marks13 "Passive Skill:Marks13") [[2]](/wiki/Passive_Skill:Marks15 "Passive Skill:Marks15") |
| [Mark Effect](/wiki/Mark_Effect/edit?redlink=1 "Mark Effect (page does not exist)") | 10% increased Effect of your Mark Skills [[1]](/wiki/Passive_Skill:Marks16 "Passive Skill:Marks16") [[2]](/wiki/Passive_Skill:Marks5~ "Passive Skill:Marks5~") |
| [Mark Effect and Blind Chance](/wiki/Mark_Effect_and_Blind_Chance/edit?redlink=1 "Mark Effect and Blind Chance (page does not exist)") | 8% increased Effect of your Mark Skills 5% chance to [Blind](/wiki/Blind "Blind") Enemies on [Hit](/wiki/Hit "Hit") with [Attacks](/wiki/Attack "Attack") [[1]](/wiki/Passive_Skill:Marks30 "Passive Skill:Marks30") |
| [Mark Effect and Blind Effect](/wiki/Mark_Effect_and_Blind_Effect/edit?redlink=1 "Mark Effect and Blind Effect (page does not exist)") | 8% increased Effect of your Mark Skills 10% increased [Blind](/wiki/Blind "Blind") Effect [[1]](/wiki/Passive_Skill:Marks29 "Passive Skill:Marks29") |
| [Mark Use Speed](/wiki/Mark_Use_Speed/edit?redlink=1 "Mark Use Speed (page does not exist)") | Mark Skills have 10% increased Use Speed [[1]](/wiki/Passive_Skill:Marks14 "Passive Skill:Marks14") [[2]](/wiki/Passive_Skill:Marks28 "Passive Skill:Marks28") [[3]](/wiki/Passive_Skill:Marks32 "Passive Skill:Marks32") [[4]](/wiki/Passive_Skill:Marks8 "Passive Skill:Marks8") |
| [Marked Agility](/wiki/Marked_Agility/edit?redlink=1 "Marked Agility (page does not exist)") | 60% increased Mana Cost [Efficiency](/wiki/Efficiency "Efficiency") of Marks 4% increased Movement Speed if you've used a Mark [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Marks17 "Passive Skill:Marks17") |
| [Marked for Death](/wiki/Marked_for_Death/edit?redlink=1 "Marked for Death (page does not exist)") | [Culling Strike](/wiki/Culling_Strike "Culling Strike") against Enemies you Mark [[1]](/wiki/Passive_Skill:Marks9 "Passive Skill:Marks9") |
| [Marked for Sickness](/wiki/Marked_for_Sickness/edit?redlink=1 "Marked for Sickness (page does not exist)") | Enemies you Mark take 10% increased Damage Enemies you Mark have 10% reduced [Accuracy Rating](/wiki/Accuracy "Accuracy") [[1]](/wiki/Passive_Skill:Marks12 "Passive Skill:Marks12") |
| [The Noble Wolf](/wiki/The_Noble_Wolf/edit?redlink=1 "The Noble Wolf (page does not exist)") | 25% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Ailments](/wiki/Ailments "Ailments") you inflict against Marked Enemies 20% increased [Critical](/wiki/Critical "Critical") Hit Chance against Marked Enemies +10 to [Dexterity](/wiki/Dexterity "Dexterity") [[1]](/wiki/Passive_Skill:Azmerianimals48 "Passive Skill:Azmerianimals48") |
| [Unsight](/wiki/Unsight/edit?redlink=1 "Unsight (page does not exist)") | Enemies you Mark cannot deal [Critical Hits](/wiki/Critical_Hit "Critical Hit") Enemies near Enemies you Mark are [Blinded](/wiki/Blind "Blind") [[1]](/wiki/Passive_Skill:Marks27 "Passive Skill:Marks27") |

### Ascendancy passive skills

The following [Ascendancy passive skills](/wiki/Ascendancy_passive_skill "Ascendancy passive skill") are related to marks:

| Ascendancy Class | Name | Stats |
| --- | --- | --- |
| [Deadeye](/wiki/Deadeye "Deadeye") | [Mark Effect](/wiki/Mark_Effect/edit?redlink=1 "Mark Effect (page does not exist)") | 12% increased Effect of your Mark Skills [[1]](/wiki/Passive_Skill:AscendancyRanger1Small4 "Passive Skill:AscendancyRanger1Small4") [[2]](/wiki/Passive_Skill:AscendancyRanger1Small7 "Passive Skill:AscendancyRanger1Small7") |
| [Deadeye](/wiki/Deadeye "Deadeye") | [Bullseye](/wiki/Bullseye "Bullseye") | Apply 10 [Critical Weakness](/wiki/Critical_Weakness "Critical Weakness") to Enemies when [Consuming](/wiki/Effect_Consumption "Effect Consumption") a Mark on them [[1]](/wiki/Passive_Skill:AscendancyRanger1Notable8 "Passive Skill:AscendancyRanger1Notable8") |
| [Deadeye](/wiki/Deadeye "Deadeye") | [Called Shots](/wiki/Called_Shots_(passive) "Called Shots (passive)") | Grants Skill: [Called Shots](/wiki/Called_Shots "Called Shots") [[1]](/wiki/Passive_Skill:AscendancyRanger1Notable7 "Passive Skill:AscendancyRanger1Notable7") |
