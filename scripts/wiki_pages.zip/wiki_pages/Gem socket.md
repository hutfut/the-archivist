# Gem socket

A **gem socket** is a socket in a gem which can have another type of gem socketed into it to modify the original gem.

## Mechanics

[Skill gems](/wiki/Skill_gem "Skill gem") can be socketed with [support gems](/wiki/Support_gem "Support gem"). [Meta gems](/wiki/Meta_gem "Meta gem") can be socketed with [skill gems](/wiki/Skill_gem "Skill gem").

Skill gems can have 2-5 sockets. The number of sockets can be increased with [Jeweller's Orbs](/wiki/Jeweller%27s_Orb "Jeweller's Orb"). They may colloquially be referred to as "links" instead (terminology from [Path of Exile](/wiki/Path_of_Exile "Path of Exile")), in which case they would be considered 3-6 linked skills or gems.

## Skills granted by items and passive skills

Skills not granted by a skill gem cannot gain sockets from [Jeweller's Orbs](/wiki/Jeweller%27s_Orb "Jeweller's Orb"). These include:

* [Granted skills](/wiki/Granted_skill "Granted skill") from [items](/wiki/Item "Item")
* Granted skills from [passive skills](/wiki/Passive_skill "Passive skill") (e.g. [Ascendancy](/wiki/Ascendancy "Ascendancy") notables)
* [Default attacks](/wiki/Default_attack "Default attack")

[Default attacks](/wiki/Default_attack "Default attack"), skills from passive skills, and certain item [inherent skills](/wiki/Inherent_skill "Inherent skill") such as [Spear Throw](/wiki/Spear_Throw "Spear Throw") have their skill level determined by the [character](/wiki/Character "Character")'s [level](/wiki/Level "Level"). These skills automatically gain their 3rd, 4th, and 5th socket at skill level 10/15/20, or character level 36/64/90 respectively. This is not affected by gem level modifiers.

Character level skill scaling

| Character Level | Skill Level | Sockets |
| --- | --- | --- |
| 1 | 1 | 2 |
| 3 | 2 | 2 |
| 6 | 3 | 2 |
| 10 | 4 | 2 |
| 14 | 5 | 2 |
| 18 | 6 | 2 |
| 22 | 7 | 2 |
| 26 | 8 | 2 |
| 31 | 9 | 2 |
| 36 | 10 | **3** |
| 41 | 11 | 3 |
| 46 | 12 | 3 |
| 52 | 13 | 3 |
| 58 | 14 | 3 |
| 64 | 15 | **4** |
| 66 | 16 | 4 |
| 72 | 17 | 4 |
| 78 | 18 | 4 |
| 84 | 19 | 4 |
| **90** | 20 | **5** |

Other item granted skills, such as those granted by caster weapons or unique items, have a level that is determined when the item drops. It is not possible to directly increase an item skill's sockets or levels; the only way to have an improved version of the skill is to find a new, higher item level version of the base type or [unique item](/wiki/Unique_item "Unique item"). This will also usually increase the item's level and attribute requirements. Starting from item level 62, the possible skill level that drops overlaps, and can result in the item having a higher required level than its item level. Skills granted this way have their socket count determined by the level of the granted skill. These skills will have 3, 4, or 5 sockets if at least skill level 10/15/20, which start dropping at item level 36/62/80 respectively. Regardless of the item level, the skill must meet be of the appropriate skill level in order to have the additional sockets. This is not affected by gem level modifiers.

Item level skill scaling

| Skill Level | Item level range | Sockets |
| --- | --- | --- |
| 1 | 1-2 | 2 |
| 2 | 3-5 | 2 |
| 3 | 6-9 | 2 |
| 4 | 10-13 | 2 |
| 5 | 14-17 | 2 |
| 6 | 18-21 | 2 |
| 7 | 22-25 | 2 |
| 8 | 26-30 | 2 |
| 9 | 31-35 | 2 |
| 10 | 36-40 | 3 |
| 11 | 41-45 | 3 |
| 12 | 46-51 | 3 |
| 13 | 52-57 | 3 |
| 14 | 58-69 | 3 |
| 15 | 62-73 | 4 |
| 16 | 66-77 | 4 |
| 17 | 70-81 | 4 |
| 18 | 74-84 | 4 |
| 19 | 78+ | 4 |
| 20 | 80+ | 5 |
