# Buff

For a list of skills with the Buff gem tag, see [Buff (gem tag)](/wiki/Buff_(gem_tag) "Buff (gem tag)").

Buffs

Tooltip

Buffs are effects that boost a player or monster's stats for a duration or while a condition is met.

Unless otherwise stated, Buffs of the same type do not stack — only the copy with the strongest effect applies.

Buff/Debuff Effect

Tooltip

Modifiers to the Effect of [Buffs](/wiki/Buffs "Buffs") or [Debuffs](/wiki/Debuff "Debuff") usually come from the target it affects and are multiplicative with modifiers to the [Magnitudes](/wiki/Magnitude "Magnitude") of the [Buff](/wiki/Buffs "Buffs") or [Debuff](/wiki/Debuff "Debuff"), which come from its creator.

A **buff** is a status effect that applies a beneficial bonus on the entity. This could be produced by a [skill](/wiki/Skill "Skill") or by interacting with certain mechanics such as [shrines](/wiki/Shrine "Shrine"). Buffs can be temporary (with a [duration](/wiki/Duration "Duration")) or [persistent](/wiki/Persistent "Persistent"); persistent buffs can be toggled in the skills panel. Most buffs will have a green border around their icons, though status effects with a green border are not necessarily buffs.

Unless otherwise stated, buffs of the same type do not stack - only the copy with the strongest effect applies.

## Buff Expiry Rate

Sources of "Buffs on you expire slower" such as the [Prolonged Assault](/wiki/Prolonged_Assault/edit?redlink=1 "Prolonged Assault (page does not exist)"), [Lasting Boons](/wiki/Lasting_Boons/edit?redlink=1 "Lasting Boons (page does not exist)") notables or [Debuff Expiry Rate (ascendancy passive skill)](/wiki/Debuff_Expiry_Rate_(ascendancy_passive_skill) "Debuff Expiry Rate (ascendancy passive skill)") appear to be additive with one another[[1]](#cite_note-1). There is, however, a cap of 75% slower, making all buffs on you last 4 times as long.

## Related effects

* All green border effects from [Shrines](/wiki/Shrine "Shrine")

* [Arcane Surge](/wiki/Arcane_Surge "Arcane Surge")
* [Elemental Archon](/wiki/Archon "Archon")
* [Onslaught](/wiki/Onslaught "Onslaught")
* [Tailwind](/wiki/Tailwind "Tailwind")
* [Unholy Might](/wiki/Unholy_Might "Unholy Might")

* [Surges](/wiki/Surge "Surge")
* [Infusions](/wiki/Infusion "Infusion")
* Purple [Flame of Chayula](/wiki/Flame_of_Chayula "Flame of Chayula")

## Skills

Main article: [Buff (gem tag)](/wiki/Buff_(gem_tag) "Buff (gem tag)")

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Galvanic Field](/wiki/Galvanic_Field "Galvanic Field") | *0* |  |  |  |
| [Sigil of Power](/wiki/Sigil_of_Power "Sigil of Power") | *0* |  |  |  |
| [Unleash](/wiki/Unleash_(skill) "Unleash (skill)") | *0* |  |  |  |
| [Pinnacle of Power](/wiki/Pinnacle_of_Power "Pinnacle of Power") | *0* |  |  |  |
| [Rend](/wiki/Rend "Rend") | *0* |  |  |  |
| [Staggering Palm](/wiki/Staggering_Palm "Staggering Palm") | *3* |  |  |  |
| [Barrage](/wiki/Barrage "Barrage") | *5* |  |  |  |
| [Ice-Tipped Arrows](/wiki/Ice-Tipped_Arrows "Ice-Tipped Arrows") | *5* |  |  |  |
| [Arctic Howl](/wiki/Arctic_Howl "Arctic Howl") | *5* |  |  |  |
| [Voltaic Mark](/wiki/Voltaic_Mark "Voltaic Mark") | *7* |  |  |  |
| [Mana Tempest](/wiki/Mana_Tempest "Mana Tempest") | *7* |  |  |  |
| [Freezing Mark](/wiki/Freezing_Mark "Freezing Mark") | *7* |  |  |  |
| [Charged Staff](/wiki/Charged_Staff "Charged Staff") | *9* |  |  |  |
| [Mantra of Destruction](/wiki/Mantra_of_Destruction "Mantra of Destruction") | *9* |  |  |  |
| [Emergency Reload](/wiki/Emergency_Reload "Emergency Reload") | *11* |  |  |  |
| [Soul Offering](/wiki/Soul_Offering "Soul Offering") | *13* |  |  |  |
| [Lunar Blessing](/wiki/Lunar_Blessing "Lunar Blessing") | *13* |  |  |  |
| [Walking Calamity](/wiki/Walking_Calamity "Walking Calamity") | *13* |  |  |  |

### Persistent skills

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Barkskin](/wiki/Barkskin "Barkskin") | *8* |  |  |  |
| [Shard Scavenger](/wiki/Shard_Scavenger "Shard Scavenger") | *8* |  |  |  |
| [Elemental Conflux](/wiki/Elemental_Conflux "Elemental Conflux") | *14* |  |  |  |
| [Trinity](/wiki/Trinity "Trinity") | *14* |  |  |  |

## Support gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Danse Macabre](/wiki/Danse_Macabre "Danse Macabre") | *2* |  |  |  |
| [Sacrificial Offering](/wiki/Sacrificial_Offering "Sacrificial Offering") | *3* |  |  |  |
| [Thrill of the Kill II](/wiki/Thrill_of_the_Kill_II "Thrill of the Kill II") | *3* |  |  |  |
| [Perfection](/wiki/Perfection "Perfection") | *4* |  |  |  |

## Related unique items

The table below lists [unique items](/wiki/Unique_item "Unique item") that are related to buffs:

| Item | Base item |  | Stats |
| --- | --- | --- | --- |
| [Death Rush](/wiki/Death_Rush "Death Rush") | [Emerald Ring](/wiki/Emerald_Ring "Emerald Ring") | 26 | +(120-160) to [Accuracy](/wiki/Accuracy "Accuracy") Rating+(75-125) to [Accuracy](/wiki/Accuracy "Accuracy") Rating +(75-125) to [Evasion](/wiki/Evasion "Evasion") Rating [Leech](/wiki/Leech "Leech") 5% of [Physical](/wiki/Physical "Physical") [Attack](/wiki/Attack "Attack") Damage as Life You gain [Onslaught](/wiki/Onslaught "Onslaught") for 4 seconds on Kill |
| [Prism Guardian](/wiki/Prism_Guardian "Prism Guardian") | [Intricate Crest Shield](/wiki/Intricate_Crest_Shield "Intricate Crest Shield") | 65 | (150-200)% increased [Armour](/wiki/Armour "Armour") and [Energy Shield](/wiki/Energy_Shield "Energy Shield") +(20-30) to [Dexterity](/wiki/Dexterity "Dexterity") +(10-20)% to all [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") 1% increased [Spirit](/wiki/Spirit "Spirit") [Reservation](/wiki/Reservation "Reservation") [Efficiency](/wiki/Efficiency "Efficiency") of Buff Skills per 100 Maximum Life +50 to [Spirit](/wiki/Spirit "Spirit") |
| [The Hammer of Faith](/wiki/The_Hammer_of_Faith "The Hammer of Faith") | [Giant Maul](/wiki/Giant_Maul "Giant Maul") | 65 | (300-350)% increased [Physical](/wiki/Physical "Physical") Damage 10% reduced [Attack](/wiki/Attack "Attack") Speed +10% to all [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") 50% increased Mana Regeneration Rate Every 10 seconds, gain a random non-damaging [Shrine](/wiki/Shrine "Shrine") buff for 20 seconds |

## Related passive skills

The following [passive skills](/wiki/Passive_skill "Passive skill") are related to buffs:

| Name | Stats |
| --- | --- |
| [Lasting Boons](/wiki/Lasting_Boons/edit?redlink=1 "Lasting Boons (page does not exist)") | [Buffs](/wiki/Buffs "Buffs") on you expire 10% slower 20% reduced [Slowing](/wiki/Slow "Slow") Potency of [Debuffs](/wiki/Debuff "Debuff") on You [[1]](/wiki/Passive_Skill:Slowed~enemies18 "Passive Skill:Slowed~enemies18") |
| [Prolonged Assault](/wiki/Prolonged_Assault/edit?redlink=1 "Prolonged Assault (page does not exist)") | 16% increased [Attack](/wiki/Attack "Attack") Damage 16% increased Skill Effect Duration [Buffs](/wiki/Buffs "Buffs") on you expire 10% slower [[1]](/wiki/Passive_Skill:Attack11 "Passive Skill:Attack11") |

### Ascendancy passive skills

The following [Ascendancy passive skills](/wiki/Ascendancy_passive_skill "Ascendancy passive skill") are related to buff:

| Ascendancy Class | Name | Stats |
| --- | --- | --- |
| [Chronomancer](/wiki/Chronomancer "Chronomancer") | [Buff Expiry Rate](/wiki/Buff_Expiry_Rate/edit?redlink=1 "Buff Expiry Rate (page does not exist)") | [Buffs](/wiki/Buffs "Buffs") on you expire 10% slower [[1]](/wiki/Passive_Skill:AscendancySorceress2Small1 "Passive Skill:AscendancySorceress2Small1") [[2]](/wiki/Passive_Skill:AscendancySorceress2Small2 "Passive Skill:AscendancySorceress2Small2") |
