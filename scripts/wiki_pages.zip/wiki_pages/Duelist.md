# Duelist

This article is about unreleased content and is not yet available in the game.

The Duelist

Gender: M
[Strength](/wiki/Strength "Strength"): 11
[Dexterity](/wiki/Dexterity "Dexterity"): 11
[Intelligence](/wiki/Intelligence "Intelligence"): 7

The **Duelist** is a [strength](/wiki/Strength "Strength")/[dexterity](/wiki/Dexterity "Dexterity")-oriented [class](/wiki/Character_class "Character class") that specializes in [melee](/wiki/Melee "Melee") skills.

The Duelist obtains a **Module Error: No results found for item using search term "item\_name = "** and **Module Error: No results found for item using search term "item\_name = "** as his default starting weapon and skill in [The Riverbank](/wiki/The_Riverbank "The Riverbank").

## Ascendancy classes

Duelists can specialize into one of these three [Ascendancy classes](/wiki/Ascendancy_classes "Ascendancy classes"):

* TBA
* TBA
* TBA
