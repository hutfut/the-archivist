# Weapon set

Weapon Sets

Tooltip

Your character has two Weapon Sets that can be used independently by equipping items into both sets.

By default your Skills will use the currently active Weapon Set if possible, or automatically swap to your other Weapon Set if required to use the Skill. You can also specify the Weapon Set you want to automatically swap to for each Skill in that Skill's information panel.

In addition to changing your active items, Weapon Sets also have [dedicated Passive Skill Points](/wiki/Weapon_Set_Passive_Skill_Points "Weapon Set Passive Skill Points") that can be allocated differently in each Weapon Set.

Weapon Sets can have differing amounts of available [Spirit](/wiki/Spirit "Spirit"), due to weapons with Spirit (such as [Sceptres](/wiki/Sceptre "Sceptre")), [Weapon Set Passive Skills](/wiki/Weapon_Set_Passive_Skill_Points "Weapon Set Passive Skill Points"), or [Persistent](/wiki/Persistent_Skills "Persistent Skills") Skills that are active in specific Weapon Sets.

**Weapon sets** are two sets of different main hand and off hand slots that can be swapped between during gameplay. Players can also assign a certain amount of [passive skill](/wiki/Passive_skill "Passive skill") points to weapon sets individually.

## Mechanics

Characters can equip two sets of [weapons](/wiki/Weapon "Weapon") or [off hands](/wiki/Off_hand "Off hand"). Each of your [skills](/wiki/Skill "Skill") can be assigned one or both specific weapon sets as long as they are compatible with the equipped items; if a skill is assigned to the opposite weapon set only, the weapon set is swapped automatically when using that skill. Certain skills such as [Blink](/wiki/Blink_(disambiguation) "Blink (disambiguation)") must be assigned to both weapon slots to be usable.

It is also possible to switch between them manually through a keybind for weapon swapping or in the inventory panel. The default weapon swap keybind is `X`.

You can set an equipment to be used in both weapon slots by right-clicking the weapon set button from the Equipment menu.

## Weapon set passive skill points

Weapon Set Passive Skill Points

Tooltip

Weapon Set Passive Skill Points can be allocated differently in each of your Weapon Set Passive Trees, including your default Passive Tree.

Players can assign [passive skills](/wiki/Passive_skill "Passive skill") for a specific weapon set by using **Weapon Set Passive Skill Points** to flexibly allocate different passive skills for different skills. Weapon set passives require an equivalent number of unallocated regular passive skill points to allocate. They do not inherently grant extra passive skill points. Instead, they convert a number of your passive skill points into weapon set passive skill points. [Keystone passive skills](/wiki/Keystone_passive_skill "Keystone passive skill") and [jewel](/wiki/Jewel "Jewel") sockets cannot be assigned to separate weapon sets.

These can be obtained from certain [bosses](/wiki/Boss "Boss") or [quests](/wiki/Quest "Quest") in the [acts](/wiki/Act "Act") which reward a [Book of Specialisation](/wiki/Book_of_Specialisation "Book of Specialisation"), or certain bonus objectives. A total of **24 points** can be earned across the campaign:

Act 1

* Defeat [The Crowbell](/wiki/The_Crowbell "The Crowbell")
* Complete [The Lost Lute](/wiki/The_Lost_Lute "The Lost Lute")

Act 2

* Defeat [Kabala, Constrictor Queen](/wiki/Kabala,_Constrictor_Queen "Kabala, Constrictor Queen")
* Complete [Tradition's Toll](/wiki/Tradition%27s_Toll "Tradition's Toll")

Act 3

* Defeat [Mighty Silverfist](/wiki/Mighty_Silverfist "Mighty Silverfist")
* Perform the Blood Sacrifice in [Aggorat](/wiki/Aggorat "Aggorat") with the [Sacrificial Heart](/wiki/Sacrificial_Heart "Sacrificial Heart")

Act 4

* Complete [Dark Mists](/wiki/Dark_Mists "Dark Mists") ([Mist-shrouded Tome](/wiki/Mist-shrouded_Tome "Mist-shrouded Tome"))
* Speak to Hinekora in the [Trial of the Ancestors](/wiki/Trial_of_the_Ancestors "Trial of the Ancestors") ([Tattoo of Hinekora](/wiki/Tattoo_of_Hinekora "Tattoo of Hinekora"))

Interlude

* Defeat [Oswin, the Dread Warden](/wiki/Oswin,_the_Dread_Warden "Oswin, the Dread Warden") ([Warden's Ledger](/wiki/Warden%27s_Ledger "Warden's Ledger"))
* Defeat [Akthi, the Final Sting](/wiki/Akthi,_the_Final_Sting "Akthi, the Final Sting") and [Anundr, the Sandworm](/wiki/Anundr,_the_Sandworm "Anundr, the Sandworm") then speak to [Risu](/wiki/Risu "Risu")
* Defeat [The Abominable Yeti](/wiki/The_Abominable_Yeti "The Abominable Yeti") then speak to [Hilda](/wiki/Hilda "Hilda")
* Complete all three Interlude areas then speak to [The Hooded One](/wiki/The_Hooded_One "The Hooded One") in [Kingsmarch](/wiki/Kingsmarch "Kingsmarch")

These points can be distributed as follows:

* **Set 1:** Up to a maximum of **24 points**.
* **Set 2:** Up to a maximum of **24 points**.

The [Witchhunter](/wiki/Witchhunter "Witchhunter") notable [Weapon Master](/wiki/Weapon_Master "Weapon Master") converts an additional 100 regular passive points into weapon set passive points.

The same number of weapon set passive skill points must be unspecced in order to reallocate them as a regular passive skill point.
