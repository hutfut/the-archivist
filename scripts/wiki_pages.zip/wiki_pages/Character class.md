# Character class

Path of Exile 2 uses three main [attributes](/wiki/Attributes "Attributes") - [strength](/wiki/Strength "Strength"), [dexterity](/wiki/Dexterity "Dexterity"), and [intelligence](/wiki/Intelligence "Intelligence") - and its twelve playable **character classes** (or simply **classes**) are each associated with one or more attributes in pairs. The character creation screen allows the player to choose between six characters, each with a choice of two classes. Canonically, each pair of classes is the same person, but with a different upbringing[[1]](#cite_note-1).

Each pair of character classes has a different starting location on the [passive skill tree](/wiki/Passive_skill_tree "Passive skill tree") and starting attributes, and each character gets different [quest rewards](/wiki/Quest_rewards "Quest rewards"). Additionally, the starting areas of the passive tree can differ between three variants depending on which class was (or was not) chosen. Later, upon completing a [trial](/wiki/Trial "Trial") for the first time, players can specialize their character by choosing an [Ascendancy subclass](/wiki/Ascendancy_class "Ascendancy class"). The subclasses available depend on the character class chosen.

Players can use any [items](/wiki/Item "Item") or [skills](/wiki/Skill "Skill"), providing they meet the relevant attribute and level requirements. This allows players to customize their characters and design creative builds with unusual play styles. For new players, however, it is generally easiest to invest in the attributes appropriate to their character class.

Click to load content

## Strength

### Marauder

The [Marauder](/wiki/Marauder "Marauder") specializes in [axe](/wiki/Axe "Axe") skills.

### Warrior

The [Warrior](/wiki/Warrior "Warrior") specializes in [mace](/wiki/Mace "Mace"), [warcry](/wiki/Warcry "Warcry"), and [shield](/wiki/Shield "Shield") skills. His ascendancy classes are the [Titan](/wiki/Titan "Titan"), [Warbringer](/wiki/Warbringer "Warbringer"), and [Smith of Kitava](/wiki/Smith_of_Kitava "Smith of Kitava").

## Dexterity

### Ranger

The [Ranger](/wiki/Ranger "Ranger") specializes in [bow](/wiki/Bow "Bow") skills. Her ascendancy classes are the [Deadeye](/wiki/Deadeye "Deadeye") and [Pathfinder](/wiki/Pathfinder "Pathfinder").

### Huntress

The [Huntress](/wiki/Huntress "Huntress") specializes in [spear](/wiki/Spear "Spear") skills. Her ascendancy classes are the [Ritualist](/wiki/Ritualist "Ritualist") and [Amazon](/wiki/Amazon "Amazon").

## Intelligence

### Witch

The [Witch](/wiki/Witch "Witch") specializes in occult spells, which includes undead [minions](/wiki/Minion "Minion") and [chaos](/wiki/Chaos "Chaos") spells. Her Ascendancy classes are the [Infernalist](/wiki/Infernalist "Infernalist"), [Blood Mage](/wiki/Blood_Mage "Blood Mage"), and [Lich](/wiki/Lich "Lich").

### Sorceress

The [Sorceress](/wiki/Sorceress "Sorceress") specializes in [elemental](/wiki/Elemental "Elemental") spells. Her ascendancy classes are the [Stormweaver](/wiki/Stormweaver "Stormweaver"), [Chronomancer](/wiki/Chronomancer "Chronomancer"), and [Disciple of Varashta](/wiki/Disciple_of_Varashta "Disciple of Varashta").

## Strength/Dexterity

### Duelist

The [Duelist](/wiki/Duelist "Duelist") specializes in [sword](/wiki/Sword "Sword") skills.

### Mercenary

The [Mercenary](/wiki/Mercenary "Mercenary") specializes in [crossbow](/wiki/Crossbow "Crossbow") and [grenade](/wiki/Grenade "Grenade") skills. His ascendancy classes are the [Witchhunter](/wiki/Witchhunter "Witchhunter"), [Gemling Legionnaire](/wiki/Gemling_Legionnaire "Gemling Legionnaire"), and [Tactician](/wiki/Tactician "Tactician").

## Dexterity/Intelligence

### Shadow

The [Shadow](/wiki/Shadow "Shadow") specializes in [dagger](/wiki/Dagger "Dagger") and [trap](/wiki/Trap "Trap") skills.

### Monk

The [Monk](/wiki/Monk "Monk") specializes in [unarmed](/wiki/Unarmed "Unarmed") and [quarterstaff](/wiki/Quarterstaff "Quarterstaff") skills. His ascendancy classes are the [Invoker](/wiki/Invoker "Invoker") and [Acolyte of Chayula](/wiki/Acolyte_of_Chayula "Acolyte of Chayula").

## Strength/Intelligence

### Templar

The [Templar](/wiki/Templar "Templar") specializes in [flail](/wiki/Flail "Flail") skills and holy spells.

### Druid

The [Druid](/wiki/Druid "Druid") specializes in primal skills, which include [shapeshifting](/wiki/Shapeshifting "Shapeshifting"), animal [minions](/wiki/Minion "Minion"), and nature spells. His ascendancy classes are the [Shaman](/wiki/Shaman "Shaman") and [Oracle](/wiki/Oracle "Oracle").

## Trivia

The Duelist and Shadow were intended to be renamed to the Gladiator and Assassin, respectively, instead of keeping their [Path of Exile](/wiki/Path_of_Exile "Path of Exile") counterparts' class names, but this decision was reversed before the game's [Early Access](/wiki/Early_Access "Early Access") release.[[2]](#cite_note-2)
