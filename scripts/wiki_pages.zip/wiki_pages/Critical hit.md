# Critical hit

Not to be confused with [Critical Strike](/wiki/Critical_Strike "Critical Strike").

Critical Hits

Tooltip

Critical Hits deal +100% extra damage (i.e. twice as much damage) by default. [Critical Damage Bonuses](/wiki/Critical_Damage_Bonus "Critical Damage Bonus") can further modify this value.

[Attacks](/wiki/Attack "Attack") usually use your weapon's base Critical Hit Chance, while [Spells](/wiki/Spell "Spell") and some other skills have their base Critical Hit Chance listed on the skill.

Most modifiers to Critical Hit Chance are percentage based. For example, gaining 100% increased Critical Hit Chance on a base Critical Hit Chance of 7% would result in a final Critical Hit Chance of 14%.

A **critical hit**, or simply **crit**, is a property of [hits](/wiki/Hit "Hit") that gains a damage multiplier based on its **critical damage bonus**. Additionally, critical hits can often enable or [trigger](/wiki/Trigger "Trigger") other effects from [items](/wiki/Item "Item") or [passive skills](/wiki/Passive_skill "Passive skill").

## Mechanics

Rerolling Critical Hit Chance

Tooltip

Any mechanic where the calculation of a single [Hit](/wiki/Hit "Hit") would roll [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance more than once is considered to be Rerolling. This includes anything that makes [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance [Lucky](/wiki/Lucky "Lucky"), [Unlucky](/wiki/Unlucky "Unlucky"), [Bifurcated](/wiki/Bifurcated_Critical_Hits "Bifurcated Critical Hits"), or [Inevitable](/wiki/Inevitable_Critical_Hits "Inevitable Critical Hits").

[Sustained](/wiki/Sustained_Skills/edit?redlink=1 "Sustained Skills (page does not exist)") Skills using an independent [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance roll for each different time they deal damage is not Rerolling.

Bifurcated Critical Hits

Tooltip

Hits with this weapon roll against their [Critical Hit](/wiki/Critical_Hit "Critical Hit") chance twice when determining if they are a [Critical Hit](/wiki/Critical_Hit "Critical Hit").

If either roll succeeds, the hit will be a [Critical Hit](/wiki/Critical_Hit "Critical Hit"), and thus the [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus") will apply as normal.

If both rolls succeed, the hit will be a [Critical Hit](/wiki/Critical_Hit "Critical Hit"), and the [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus") will apply twice to that Hit.

If a modifier makes your Critical Hit Chance [Lucky](/wiki/Lucky "Lucky"), that Luck will apply individually to both of these rolls.

Inevitable Critical Hits

Tooltip

[Hits](/wiki/Hit "Hit") which could potentially be a [Critical Hit](/wiki/Critical_Hit "Critical Hit") but do not roll a [Critical Hit](/wiki/Critical_Hit "Critical Hit") will re-roll [Critical Hit](/wiki/Critical_Hit "Critical Hit") chance until they succeed.

Hits have 30% less [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus") for each time [Critical Hit](/wiki/Critical_Hit "Critical Hit") chance was re-rolled.

### Critical hit check

When a skill is used or [triggered](/wiki/Trigger "Trigger"), it performs a critical hit check by rolling a number. This roll ranges from 0 to 99.99, determining a threshold the skill's critical hit chance must exceed to deal a critical hit successfully.[[1]](#cite_note-cite1-1)

:   For example: A player casts a spell and rolls a 12. When enemies are hit, those hits require a critical strike chance of 12.01% or greater to deal a critical hit.

While hits from the same skill will usually have the same critical hit chance, resulting in all-or-nothing behaviour, conditional modifiers and [buffs](/wiki/Buff "Buff")/[debuffs](/wiki/Debuff "Debuff") can cause critical hit chance to differ between enemies.

* Critical hits are rolled for all hits from that skill. If a critical hit chance roll succeeds, all hits from that skill will be a critical hit.
  + This does not apply to [Sustained](/wiki/Sustained "Sustained") and [Channelling](/wiki/Channelling "Channelling") skills which hit continuously while channelling. Sustained skill will roll critical hit chance for each hit individually, and channelling skills will roll critical hit chance for each cast interval of the channelled skill.
* Multi-[projectile](/wiki/Projectile "Projectile") skills from players and allies roll crit independently, but projectiles from a [monster](/wiki/Monster "Monster")'s skill will either all crit or not crit.[[2]](#cite_note-2)
* If critical hit chance is [lucky](/wiki/Lucky "Lucky"), skills perform two crit checks and keep the lower requirement. If it is unlucky, the higher requirement is kept.
* If the user has Inevitable Critical Hits from [Forced Outcome](/wiki/Forced_Outcome "Forced Outcome"), failed critical hit chance rolls will be rerolled until it succeeds. Each time crit chance is rerolled, 30% less critical damage bonus will be applied to the final hit.
* If critical hit chance bifurcates ([Tangletongue](/wiki/Tangletongue "Tangletongue") or [Garukhan's Resolve](/wiki/Garukhan%27s_Resolve "Garukhan's Resolve")), skills perform two crit checks that apply independently. If both are successful, critical hit damage bonus is applied twice. Luck applies to each bifurcated critical hit independently.
* If a critical hit can be [evaded](/wiki/Evaded "Evaded"), such as from an [attacks](/wiki/Attack "Attack") or by a [monster](/wiki/Monster "Monster"), but the evasion check fails and lands a hit, evasion is checked again; if the the evasion check succeeds, the hit is downgraded to a non-critical hit. This does not affect the evasion entropy value.

### Critical hit chance

* [Martial weapons](/wiki/Martial_weapon "Martial weapon") have a base critical hit chance which is used for almost all [attack](/wiki/Attack "Attack") [skills](/wiki/Skill "Skill"). [Unarmed](/wiki/Unarmed "Unarmed") skills have a base critical hit chance of 5%.
  + Skills that use two weapons simultaneously calculate each hand's crit chance and damage separately, which are later combined into a single instance of damage. If either hand crits, the combined hit is considered a single crit. This does not retroactively scale a hand that non-crits, however.
  + Skills that use two weapons independently calculate crit chance independently for each hit.
* [Spells](/wiki/Spell "Spell") instead specify a base critical hit chance on the skill itself which can then be further modified.
* Other [allies](/wiki/Allies "Allies") including [minions](/wiki/Minion "Minion") have an independent critical hit chance separate from the player.
* Modifiers that grant additional base critical hit chance (e.g. [Critical Weakness](/wiki/Critical_Weakness "Critical Weakness"), [Critical Strike](/wiki/Critical_Strike "Critical Strike")) are applied before modifiers that grant increased/decreased/more/less critical hit chance.

Effects which prevent critical strikes (e.g. [Resolute Technique](/wiki/Resolute_Technique "Resolute Technique")) take priority over effects that causes you to always deal critical strikes.

### Critical damage bonus

Critical Damage Bonus

Tooltip

Multiplies the damage dealt by Critical Hits. Default value is +100% (i.e. twice as much damage).

Critical hits deal extra damage compared to a non-critical hit, the magnitude of which is determined by a stat called **critical damage bonus**, equivalent to "critical strike multiplier" or "crit multi" from [Path of Exile 1](/wiki/Path_of_Exile_1 "Path of Exile 1"). Critical damage bonus is a unique multiplier independent of all other damage multipliers. The default critical damage bonus for players and minions is +100%, or 200% of base damage. Monsters have 40% less bonus critical damage.

Critical damage bonus is calculated by first adding any sources of +#% to Critical Damage Bonus (e.g. on [weapons](/wiki/Weapon "Weapon") or from [Sniper's Mark](/wiki/Sniper%27s_Mark "Sniper's Mark")) to the base critical damage bonus of +100%, then applying any other modifiers such as increases or reductions or more/less multipliers.[[3]](#cite_note-3) Note that the modifier found on weapons and from [Soul Core of Ticaba](/wiki/Soul_Core_of_Ticaba "Soul Core of Ticaba") are [local](/wiki/Local "Local") modifiers and only apply to that hits with that weapon.

## Related skills

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Reap](/wiki/Reap "Reap") | *0* |  |  |  |
| [Elemental Storm](/wiki/Elemental_Storm "Elemental Storm") | *0* |  |  |  |
| [Kelari's Deception](/wiki/Kelari%27s_Deception "Kelari's Deception") | *0* |  |  |  |
| [Kelari, the Tainted Sands](/wiki/Kelari,_the_Tainted_Sands "Kelari, the Tainted Sands") | *0* |  |  |  |
| [Sniper's Mark](/wiki/Sniper%27s_Mark "Sniper's Mark") | *7* |  |  |  |

### Persistent skills

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Malice](/wiki/Malice "Malice") | *0* |  |  |  |
| [Mana Remnants](/wiki/Mana_Remnants "Mana Remnants") | *4* |  |  |  |
| [Cast on Critical](/wiki/Cast_on_Critical "Cast on Critical") | *14* |  |  |  |
| [Charge Regulation](/wiki/Charge_Regulation "Charge Regulation") | *14* |  |  |  |

## Related support gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Garukhan's Resolve](/wiki/Garukhan%27s_Resolve "Garukhan's Resolve") | *0* |  |  |  |
| [Blindside](/wiki/Blindside "Blindside") | *1* |  |  |  |
| [Ambush](/wiki/Ambush "Ambush") | *1* |  |  |  |
| [Controlled Destruction](/wiki/Controlled_Destruction "Controlled Destruction") | *1* |  |  |  |
| [Battershout](/wiki/Battershout "Battershout") | *1* |  |  |  |
| [Bursting Plague](/wiki/Bursting_Plague "Bursting Plague") | *2* |  |  |  |
| [Overextend](/wiki/Overextend "Overextend") | *2* |  |  |  |
| [Pin II](/wiki/Pin_II "Pin II") | *2* |  |  |  |
| [Shocking Leap](/wiki/Shocking_Leap "Shocking Leap") | *2* |  |  |  |
| [Excise](/wiki/Excise "Excise") | *2* |  |  |  |
| [Pinpoint Critical](/wiki/Pinpoint_Critical "Pinpoint Critical") | *2* |  |  |  |
| [Inexorable Critical I](/wiki/Inexorable_Critical_I "Inexorable Critical I") | *3* |  |  |  |
| [Supercritical](/wiki/Supercritical "Supercritical") | *3* |  |  |  |
| [Volatility](/wiki/Volatility_(support_gem) "Volatility (support gem)") | *3* |  |  |  |
| [Blazing Critical](/wiki/Blazing_Critical "Blazing Critical") | *4* |  |  |  |
| [Cold Exposure](/wiki/Cold_Exposure "Cold Exposure") | *4* |  |  |  |
| [Concussive Spells](/wiki/Concussive_Spells "Concussive Spells") | *4* |  |  |  |
| [Inexorable Critical II](/wiki/Inexorable_Critical_II "Inexorable Critical II") | *4* |  |  |  |
| [Eternal Flame III](/wiki/Eternal_Flame_III "Eternal Flame III") | *4* |  |  |  |

## Related unique items

### Local critical hit chance

Items that have increases to their local critical hit chance.

| Item | Item class |  | Crit | +% crit chance |
| --- | --- | --- | --- | --- |
| [Hoghunt](/wiki/Hoghunt "Hoghunt") | *[Two Hand Mace](/wiki/Two_Hand_Mace "Two Hand Mace")* | 1 | 20.00% | +1500\*0.01% |
| [Frostbreath](/wiki/Frostbreath "Frostbreath") | *[One Hand Mace](/wiki/One_Hand_Mace "One Hand Mace")* | 10 | 10.00% | +500\*0.01% |
| [Double Vision](/wiki/Double_Vision "Double Vision") | *[Crossbow](/wiki/Crossbow "Crossbow")* | 20 | 10.00% | +500\*0.01% |
| [Matsya](/wiki/Matsya "Matsya") | *[Quarterstaff](/wiki/Quarterstaff "Quarterstaff")* | 20 | (13.00-15.00)% | +(300-500)\*0.01% |
| [Tangletongue](/wiki/Tangletongue "Tangletongue") | *[Spear](/wiki/Spear "Spear")* | 26 | (10.00-13.00)% | +(500-800)\*0.01% |
| [Slivertongue](/wiki/Slivertongue "Slivertongue") | *[Bow](/wiki/Bow "Bow")* | 39 | (9.00-11.00)% | +(400-600)\*0.01% |
| [Collapsing Horizon](/wiki/Collapsing_Horizon "Collapsing Horizon") | *[Quarterstaff](/wiki/Quarterstaff "Quarterstaff")* | 65 | (15.00-20.00)% | +(500-1000)\*0.01% |

### Global critical hit chance

Items that have global critical hit chance or other interactions with global critical hit chance.

| Item |  | Generic Crit. Chance | Attack Crit. Chance | Spell Crit. Chance |
| --- | --- | --- | --- | --- |
| [Grip of Kulemak](/wiki/Grip_of_Kulemak "Grip of Kulemak") | 1 | (25-40)% | 0% | 0% |
| [Heart of the Well](/wiki/Heart_of_the_Well "Heart of the Well") | 1 | (4-8)% | 0% | (4-8)% |
| [Seed of Cataclysm](/wiki/Seed_of_Cataclysm "Seed of Cataclysm") | 1 | 0% | 0% | (30-50)% |
| [Mask of the Sanguimancer](/wiki/Mask_of_the_Sanguimancer "Mask of the Sanguimancer") | 10 | 0% | 0% | (20-40)% |
| [Erian's Cobble](/wiki/Erian%27s_Cobble "Erian's Cobble") | 11 | (0-30)% | 0% | 0% |
| [Rondel of Fragility](/wiki/Rondel_of_Fragility "Rondel of Fragility") | 14 | (20-30)% | 0% | 0% |
| [Enezun's Charge](/wiki/Enezun%27s_Charge "Enezun's Charge") | 16 | 0% | 0% | (30-50)% |
| [Visage of Ayah](/wiki/Visage_of_Ayah "Visage of Ayah") | 16 | (20-30)% | 0% | 0% |
| [Fixation of Yix](/wiki/Fixation_of_Yix "Fixation of Yix") | 24 | 0% | 0% | 0% |
| [Ungil's Harmony](/wiki/Ungil%27s_Harmony "Ungil's Harmony") | 25 | (100-200)% | 0% | 0% |
| [The Smiling Knight](/wiki/The_Smiling_Knight "The Smiling Knight") | 26 | (15-25)% | 0% | 0% |
| [Atsak's Sight](/wiki/Atsak%27s_Sight "Atsak's Sight") | 28 | (30-40)% | 0% | 0% |
| [Atziri's Acuity](/wiki/Atziri%27s_Acuity "Atziri's Acuity") | 33 | (30-50)% | 0% | 0% |
| [The Vertex](/wiki/The_Vertex "The Vertex") | 33 | (20-30)% | 0% | 0% |
| [Gifts from Above](/wiki/Gifts_from_Above "Gifts from Above") | 35 | (20-30)% | 0% | 0% |
| [Assailum](/wiki/Assailum "Assailum") | 45 | (30-50)% | 0% | 0% |
| [Maligaro's Virtuosity](/wiki/Maligaro%27s_Virtuosity "Maligaro's Virtuosity") | 45 | (20-30)% | 0% | 0% |
| [Nightscale](/wiki/Nightscale "Nightscale") | 45 | (30-50)% | 0% | 0% |
| [Starkonja's Head](/wiki/Starkonja%27s_Head "Starkonja's Head") | 50 | (15-25)% | 0% | 0% |
| [The Bringer of Rain](/wiki/The_Bringer_of_Rain "The Bringer of Rain") | 52 | 100% | 0% | 0% |
| [Beyond Reach](/wiki/Beyond_Reach "Beyond Reach") | 65 | 0% | (20-30)% | 0% |
| [Rathpith Globe](/wiki/Rathpith_Globe "Rathpith Globe") | 75 | 0% | 0% | 0% |

### Critical damage bonus

Items that have global critical hit damage bonus or other interactions with global critical damage.

| Item |  | + crit bonus | % crit bonus | % spell crit bonus |
| --- | --- | --- | --- | --- |
| [Grip of Kulemak](/wiki/Grip_of_Kulemak "Grip of Kulemak") | 1 | +0% | (15-25)% | 0% |
| [Heart of the Well](/wiki/Heart_of_the_Well "Heart of the Well") | 1 | +0% | (6-12)% | (6-12)% |
| [Northpaw](/wiki/Northpaw "Northpaw") | 1 | +0% | (10-15)% | 0% |
| [Seed of Cataclysm](/wiki/Seed_of_Cataclysm "Seed of Cataclysm") | 1 | +0% | 0% | (30-50)% |
| [Killjoy](/wiki/Killjoy "Killjoy") | 16 | +0% | (20-30)% | 0% |
| [Fixation of Yix](/wiki/Fixation_of_Yix "Fixation of Yix") | 24 | +0% | 0% | 0% |
| [Ungil's Harmony](/wiki/Ungil%27s_Harmony "Ungil's Harmony") | 25 | +0% | 0% | 0% |
| [Dreadfist](/wiki/Dreadfist "Dreadfist") | 27 | +0% | (20-30)% | 0% |
| [Death's Harp](/wiki/Death%27s_Harp "Death's Harp") | 28 | +(20-25)% | 0% | 0% |
| [Powertread](/wiki/Powertread "Powertread") | 33 | +0% | 0% | 0% |
| [Quecholli](/wiki/Quecholli "Quecholli") | 38 | +0% | 0% | 0% |
| [Maligaro's Virtuosity](/wiki/Maligaro%27s_Virtuosity "Maligaro's Virtuosity") | 45 | +0% | 0% | 0% |
| [Nebuloch](/wiki/Nebuloch "Nebuloch") | 55 | +(20-30)% | 0% | 0% |

### Other

Items with miscellaneous interactions with critical hits.

| Item |  | Stats |
| --- | --- | --- |
| [Bristleboar](/wiki/Bristleboar "Bristleboar") | 1 | 50% reduced [Evasion](/wiki/Evasion "Evasion") Rating +(40-60) to maximum Life (3-5) Life Regeneration per second Gain 5 [Rage](/wiki/Rage "Rage") when [Hit](/wiki/Hit "Hit") by an Enemy Gain 10 [Rage](/wiki/Rage "Rage") when [Critically Hit](/wiki/Critically_Hit "Critically Hit") by an Enemy |
| [Effigy of Cruelty](/wiki/Effigy_of_Cruelty "Effigy of Cruelty") | 10 | +(20-30) to maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") (40-50)% increased [Spell](/wiki/Spell "Spell") Damage +10 to [Intelligence](/wiki/Intelligence "Intelligence") +(7-13)% to [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance") [Critical Hits](/wiki/Critical_Hit "Critical Hit") with [Spells](/wiki/Spell "Spell") apply (1-3) Stacks of [Critical Weakness](/wiki/Critical_Weakness "Critical Weakness") |
| [Trephina](/wiki/Trephina "Trephina") | 11 | [Crushes](/wiki/Crushed "Crushed") Enemies on HitAdds (12-15) to (22-25) [Physical](/wiki/Physical "Physical") Damage (10-15)% increased [Attack](/wiki/Attack "Attack") Speed Causes (30-50)% increased [Stun](/wiki/Stun "Stun") Buildup Always deals [Critical Hits](/wiki/Critical_Hit "Critical Hit") against [Heavy Stunned](/wiki/Heavy_Stun "Heavy Stun") Enemies |
| [Sculpted Suffering](/wiki/Sculpted_Suffering "Sculpted Suffering") | 22 | +(10-15)% to Critical Damage BonusAdds (21-26) to (25-31) [Physical](/wiki/Physical "Physical") Damage (10-15)% increased [Attack](/wiki/Attack "Attack") Speed [Breaks Armour](/wiki/Breaks_Armour/edit?redlink=1 "Breaks Armour (page does not exist)") equal to 40% of damage from [Hits](/wiki/Hits "Hits") with this weapon [Fully Armour Broken](/wiki/Fully_Armour_Broken "Fully Armour Broken") enemies you kill with [Hits](/wiki/Hits "Hits") [Shatter](/wiki/Shatter "Shatter") |
| [Dreadfist](/wiki/Dreadfist "Dreadfist") | 27 | (60-100)% increased [Armour](/wiki/Armour "Armour") (20-30)% increased [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus") [Critical Hits](/wiki/Critical_Hit "Critical Hit") inflict [Impale](/wiki/Impale "Impale") [Critical Hits](/wiki/Critical_Hit "Critical Hit") cannot Extract [Impale](/wiki/Impale "Impale") (20-31) to (31-49) [Physical](/wiki/Physical "Physical") [Thorns](/wiki/Thorns "Thorns") damage |
| [Beacon of Azis](/wiki/Beacon_of_Azis "Beacon of Azis") | 30 | +(10-15) to [Spirit](/wiki/Spirit "Spirit")+(60-100) to maximum Mana +30 to [Spirit](/wiki/Spirit "Spirit") 30% increased [Light Radius](/wiki/Light_Radius "Light Radius") [Critical Hits](/wiki/Critical_Hit "Critical Hit") ignore Enemy Monster [Elemental Resistances](/wiki/Elemental_Resistance/edit?redlink=1 "Elemental Resistance (page does not exist)") |
| [The Black Insignia](/wiki/The_Black_Insignia "The Black Insignia") | 45 | (70-100)% increased [Evasion](/wiki/Evasion "Evasion") Rating (10-20)% increased [Rarity of Items](/wiki/Rarity "Rarity") found +(15-25)% to [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance") Gain [Tailwind](/wiki/Tailwind "Tailwind") on [Critical Hit](/wiki/Critical_Hit "Critical Hit"), no more than once per second Lose all [Tailwind](/wiki/Tailwind "Tailwind") when [Hit](/wiki/Hit "Hit") |
| [Nebuloch](/wiki/Nebuloch "Nebuloch") | 55 | Adds (39-48) to (69-79) [Physical](/wiki/Physical "Physical") Damage +(20-30)% to [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus") Adds (25-36) to (44-55) [Chaos](/wiki/Chaos "Chaos") damage [Attacks](/wiki/Attack "Attack") consume an [Endurance Charge](/wiki/Endurance_Charge "Endurance Charge") to [Critically Hit](/wiki/Critically_Hit "Critically Hit") Take 100 [Chaos](/wiki/Chaos "Chaos") damage per second per [Endurance Charge](/wiki/Endurance_Charge "Endurance Charge") |
| [The Brass Dome](/wiki/The_Brass_Dome "The Brass Dome") | 58 | (700-800)% increased [Armour](/wiki/Armour "Armour") -(5-1)% to all [Maximum Elemental Resistances](/wiki/Maximum_Resistance "Maximum Resistance") +(200-300) to [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") Take no Extra Damage from [Critical Hits](/wiki/Critical_Hit "Critical Hit") |
| [Voll's Protector](/wiki/Voll%27s_Protector "Voll's Protector") | 59 | (150-200)% increased [Armour](/wiki/Armour "Armour") and [Energy Shield](/wiki/Energy_Shield "Energy Shield") 25% reduced maximum Mana +(13-17)% to [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance") 25% chance to gain a [Power Charge](/wiki/Power_Charge "Power Charge") on [Critical Hit](/wiki/Critical_Hit "Critical Hit") |
| [Cadiro's Gambit](/wiki/Cadiro%27s_Gambit "Cadiro's Gambit") | 66 | (7-10)% increased [Attack](/wiki/Attack "Attack") SpeedEach Arrow fired is a [Crescendo](/wiki/Crescendo_Arrows/edit?redlink=1 "Crescendo Arrows (page does not exist)"), [Splinter](/wiki/Splinter_Arrows/edit?redlink=1 "Splinter Arrows (page does not exist)"), [Reversing](/wiki/Reversing_Arrows/edit?redlink=1 "Reversing Arrows (page does not exist)"), [Diamond](/wiki/Diamond_Arrows/edit?redlink=1 "Diamond Arrows (page does not exist)"), [Covetous](/wiki/Covetous_Arrows/edit?redlink=1 "Covetous Arrows (page does not exist)"), or [Blunt](/wiki/Blunt_Arrows/edit?redlink=1 "Blunt Arrows (page does not exist)") Arrow |
| [Choir of the Storm](/wiki/Choir_of_the_Storm "Choir of the Storm") | 72 | +(10-15) to [Dexterity](/wiki/Dexterity "Dexterity")+(50-100)% to [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance") [Critical Hits](/wiki/Critical_Hit "Critical Hit") [Ignore](/wiki/Ignoring_Resistances "Ignoring Resistances") Enemy Monster [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance") [Trigger](/wiki/Trigger "Trigger") Lightning Bolt Skill on [Critical Hit](/wiki/Critical_Hit "Critical Hit") |
