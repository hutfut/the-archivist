# Ailment

Ailments

Tooltip

Ailments are a family of common [Debuffs](/wiki/Debuff "Debuff") associated with specific damage types. The list of Ailments is: [Bleeding](/wiki/Bleeding "Bleeding"), [Ignite](/wiki/Ignite "Ignite"), [Chill](/wiki/Chill "Chill"), [Freeze](/wiki/Freeze "Freeze"), [Shock](/wiki/Shock "Shock"), [Electrocute](/wiki/Electrocute "Electrocute"), and [Poison](/wiki/Poison "Poison").

Damage Contributing to Ailments

Tooltip

By default, specific Ailments are calculated based on only specific [damage types](/wiki/Damage_type "Damage type"), such as only the [Fire](/wiki/Fire_Damage "Fire Damage") damage of a [Hit](/wiki/Hit "Hit") mattering when inflicting [Ignite](/wiki/Ignite "Ignite").

Allowing another damage type to contribute to an Ailment means that all damage of the relevant types is summed when performing calculations for that Ailment.

For Ailments that use [Hit](/wiki/Hit "Hit") damage to determine Ailment chance or buildup, this means that the damage type becomes capable of inflicting that Ailment. For Ailments that only use [Hit](/wiki/Hit "Hit") damage to determine Ailment [Magnitude](/wiki/Magnitude "Magnitude") (i.e. [Bleeding](/wiki/Bleeding "Bleeding") and [Poison](/wiki/Poison "Poison")), you still need a way to apply those Ailments (e.g. a source of [Bleeding](/wiki/Bleeding "Bleeding") or [Poison](/wiki/Poison "Poison") chance).

**Ailments** are a type of [debuff](/wiki/Debuff "Debuff") associated with specific damage types. Damaging ailments [damage over time](/wiki/Damage_over_time "Damage over time").

Damaging ailments: [bleeding](/wiki/Bleeding "Bleeding"), [poison](/wiki/Poison "Poison"), and [ignite](/wiki/Ignite "Ignite").

Non-damaging ailments: [chill](/wiki/Chill "Chill"), [freeze](/wiki/Freeze "Freeze"), [shock](/wiki/Shock "Shock") and [electrocute](/wiki/Electrocute "Electrocute").

## Mechanics

The chance for most ailments to be applied generally depends on the amount of damage dealt before [mitigation](/wiki/Mitigation "Mitigation") compared to the defender's ailment threshold value. A player's base ailment threshold is based on half of their maximum [life](/wiki/Life "Life"). This scaling is different for monsters; unique monsters with extremely large life pools may have a reduced relative ailment threshold.

[Chill](/wiki/Chill "Chill") will always be applied as long as the damage meets the minimum ailment threshold to not be discarded, though its [slow](/wiki/Slow "Slow") magnitude scales with the ailment threshold formula.

The chance to inflict [poison](/wiki/Poison "Poison") or [bleeding](/wiki/Bleeding "Bleeding") is based on a static numerical chance instead rather than being calculated via the ailment threshold formula.

The chance to inflict an ailment is multiplicative against the chance to avoid an ailment. If the defender has 100% chance to avoid an ailment, they cannot be inflicted with that ailment, even by constant [ground effects](/wiki/Ground_effect "Ground effect") that usually bypass ailment avoidance chance.

## Elemental ailments

Elemental Ailments

Tooltip

Elemental Ailments are [Ignite](/wiki/Ignite "Ignite"), [Chill](/wiki/Chill "Chill"), [Freeze](/wiki/Freeze "Freeze"), [Shock](/wiki/Shock "Shock"), and [Electrocute](/wiki/Electrocute "Electrocute").

Elemental Ailment Threshold

Tooltip

A higher Elemental Ailment Threshold makes it less likely that being [Hit](/wiki/Hit "Hit") by [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") will apply the relevant Ailment, as well as lowering the amount of [Freeze](/wiki/Freeze "Freeze") and [Electrocute](/wiki/Electrocute "Electrocute") buildup recieved. A lower Elemental Ailment Threshold makes it more likely, and increases buildup of [Freeze](/wiki/Freeze "Freeze") and [Electrocute](/wiki/Electrocute "Electrocute") recieved. By default a player's Ailment Threshold is equal to half their Life.

Elemental ailments refers to ailments associated with one of the elements, [Fire](/wiki/Fire "Fire"), [Cold](/wiki/Cold "Cold") or [Lightning](/wiki/Lightning "Lightning"). Some [support gems](/wiki/Support_gem "Support gem") or [passives](/wiki/Passive "Passive") may use this term to collectively refer to all of these ailments, but exclude ailments associated with [Physical](/wiki/Physical "Physical") or [Chaos](/wiki/Chaos "Chaos") damage.

* [Ignite](/wiki/Ignite "Ignite") (fire)
* [Chill](/wiki/Chill "Chill") (cold)
* [Freeze](/wiki/Freeze "Freeze") (cold)
* [Electrocute](/wiki/Electrocute "Electrocute") (lightning)
* [Shock](/wiki/Shock "Shock") (lightning)

## Spreading ailments

Spreading Ailments

Tooltip

Spreading an ailment inflicts a new, matching ailment on another target, from the same source. The new ailment can potentially spread further, but never back to the same target twice.

Some effects may cause an ailment to spread to other nearby targets. Spreading an ailment inflicts a new, matching ailment on another target, from the same source. The new ailment can potentially spread further, but never back to the same target twice.

## Damaging ailments

Damaging Ailments

Tooltip

Ailments that deal damage are [Bleeding](/wiki/Bleeding "Bleeding"), [Ignite](/wiki/Ignite "Ignite"), and [Poison](/wiki/Poison "Poison").

This only includes ailments which directly deal damage themselves, not those which amplify damage from other sources. Some [support gems](/wiki/Support_gem "Support gem") or [passives](/wiki/Passive "Passive") may use this term to collectively refer to all of these ailments.

* [Bleeding](/wiki/Bleeding "Bleeding")
* [Poison](/wiki/Poison "Poison")
* [Ignite](/wiki/Ignite "Ignite")

## List of ailments

[Ignite](/wiki/Ignite "Ignite"), [chill](/wiki/Chill "Chill"), [freeze](/wiki/Freeze "Freeze"), [shock](/wiki/Shock "Shock") and [electrocute](/wiki/Electrocute "Electrocute") are elemental ailments. [Bleeding](/wiki/Bleeding "Bleeding") and [poison](/wiki/Poison "Poison") are non-elemental ailments.

| Ailment | Associated damage type | Effect | Elemental | Damaging |
| --- | --- | --- | --- | --- |
| [Bleeding](/wiki/Bleeding "Bleeding") | Physical | [Bleeding](/wiki/Bleeding "Bleeding") enemies take physical damage over time, at 15% of the physical damage of the hit that inflicted bleeding per second. Bleeding deals an additional 100% damage per second if the enemy is moving or the bleeding has been Aggravated. The base duration is 5 seconds. |  |  |
| [Poison](/wiki/Poison "Poison") | Physical and chaos | [Poison](/wiki/Poison "Poison") causes the affected target to take chaos damage over time, at 20% of the combined [physical](/wiki/Physical "Physical") and [chaos damage](/wiki/Chaos_damage "Chaos damage") of the hit that applied it per second, with an explicit source of poison chance. The base duration is 2 seconds. |  |  |
| [Ignite](/wiki/Ignite "Ignite") | Fire | [Ignite](/wiki/Ignite "Ignite") causes the affected target to [burn](/wiki/Burn "Burn") for 20% of the [fire damage](/wiki/Fire_damage "Fire damage") of the final hit that applied it, per second. The base duration is 4 seconds. |  |  |
| [Chill](/wiki/Chill "Chill") | Cold | [Cold damage](/wiki/Cold_damage "Cold damage") always inflicts [chill](/wiki/Chill "Chill"). Chill slows all actions of the affected target up to 50%, based on the cold damage of the hit. The base duration is 2 seconds. |  |  |
| [Freeze](/wiki/Freeze "Freeze") | Cold | [Freeze](/wiki/Freeze "Freeze") [immobilises](/wiki/Immobilise "Immobilise") the target, reducing its [action speed](/wiki/Action_speed "Action speed") to 0% and preventing it from moving or acting for a duration. The base duration is 4 seconds. |  |  |
| [Shock](/wiki/Shock "Shock") | Lightning | [Shock](/wiki/Shock "Shock") causes the affected target to take 20% increased damage from all sources, based on the lightning damage of the hit. The base duration is 4 seconds. |  |  |
| [Electrocute](/wiki/Electrocute "Electrocute") | Lightning | [Electrocute](/wiki/Electrocute "Electrocute") [immobilises](/wiki/Immobilise "Immobilise") the target, preventing it from moving or acting for a duration. The base duration is 5 seconds. |  |  |

## Related skills

The following skills are related to multiple ailments or ailments in general:

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Inevitable Agony](/wiki/Inevitable_Agony "Inevitable Agony") | *0* |  |  |  |
| [Pinnacle of Power](/wiki/Pinnacle_of_Power "Pinnacle of Power") | *0* |  |  |  |
| [Unbound Avatar](/wiki/Unbound_Avatar "Unbound Avatar") | *0* |  |  |  |
| [Living Bomb](/wiki/Living_Bomb "Living Bomb") | *3* |  |  |  |
| [Tempest Bell](/wiki/Tempest_Bell "Tempest Bell") | *3* |  |  |  |
| [Snap](/wiki/Snap "Snap") | *5* |  |  |  |
| [Elemental Sundering](/wiki/Elemental_Sundering "Elemental Sundering") | *11* |  |  |  |
| [Shockchain Arrow](/wiki/Shockchain_Arrow "Shockchain Arrow") | *11* |  |  |  |
| [Shockburst Rounds](/wiki/Shockburst_Rounds "Shockburst Rounds") | *11* |  |  |  |

### Persistent skills

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Fire Spell on Hit](/wiki/Fire_Spell_on_Hit "Fire Spell on Hit") | *0* |  |  |  |
| [Thundergod's Wrath](/wiki/Thundergod%27s_Wrath "Thundergod's Wrath") | *0* |  |  |  |
| [Mana Remnants](/wiki/Mana_Remnants "Mana Remnants") | *4* |  |  |  |
| [Elemental Invocation](/wiki/Elemental_Invocation "Elemental Invocation") | *8* |  |  |  |
| [Overwhelming Presence](/wiki/Overwhelming_Presence "Overwhelming Presence") | *8* |  |  |  |
| [Time of Need](/wiki/Time_of_Need "Time of Need") | *8* |  |  |  |
| [Cast on Critical](/wiki/Cast_on_Critical "Cast on Critical") | *14* |  |  |  |
| [Cast on Elemental Ailment](/wiki/Cast_on_Elemental_Ailment "Cast on Elemental Ailment") | *14* |  |  |  |
| [Dread Banner](/wiki/Dread_Banner "Dread Banner") | *14* |  |  |  |

## Related support gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Tul's Stillness](/wiki/Tul%27s_Stillness "Tul's Stillness") | *0* |  |  |  |
| [Esh's Radiance](/wiki/Esh%27s_Radiance "Esh's Radiance") | *0* |  |  |  |
| [Xoph's Pyre](/wiki/Xoph%27s_Pyre "Xoph's Pyre") | *0* |  |  |  |
| [Withering Touch](/wiki/Withering_Touch "Withering Touch") | *1* |  |  |  |
| [Commiserate](/wiki/Commiserate "Commiserate") | *2* |  |  |  |
| [Deathmarch](/wiki/Deathmarch "Deathmarch") | *2* |  |  |  |
| [Drain Ailments](/wiki/Drain_Ailments "Drain Ailments") | *3* |  |  |  |
| [Elemental Discharge](/wiki/Elemental_Discharge "Elemental Discharge") | *3* |  |  |  |
| [Elemental Focus](/wiki/Elemental_Focus "Elemental Focus") | *3* |  |  |  |
| [Execrate](/wiki/Execrate "Execrate") | *3* |  |  |  |
| [Steadfast II](/wiki/Steadfast_II "Steadfast II") | *3* |  |  |  |
| [Elemental Armament III](/wiki/Elemental_Armament_III "Elemental Armament III") | *5* |  |  |  |

## Related passive skills

The following [passive skills](/wiki/Passive_skill "Passive skill") are related to ailments:

### Chance to inflict ailments

| Name | Stats |
| --- | --- |
| [Ailment Chance](/wiki/Ailment_Chance/edit?redlink=1 "Ailment Chance (page does not exist)") | 10% increased chance to inflict [Ailments](/wiki/Ailments "Ailments") [[1]](/wiki/Passive_Skill:Ailments1 "Passive Skill:Ailments1") [[2]](/wiki/Passive_Skill:Ailments2 "Passive Skill:Ailments2") [[3]](/wiki/Passive_Skill:Ailments3 "Passive Skill:Ailments3") [[4]](/wiki/Passive_Skill:Ailments41~ "Passive Skill:Ailments41~") [[5]](/wiki/Passive_Skill:Ailments42 "Passive Skill:Ailments42") [[6]](/wiki/Passive_Skill:Exploiting~elemental~ailments6 "Passive Skill:Exploiting~elemental~ailments6") [[7]](/wiki/Passive_Skill:Exploiting~elemental~ailments7 "Passive Skill:Exploiting~elemental~ailments7") [[8]](/wiki/Passive_Skill:Exploiting~elemental~ailments8 "Passive Skill:Exploiting~elemental~ailments8") [[9]](/wiki/Passive_Skill:Exploiting~elemental~ailments9~ "Passive Skill:Exploiting~elemental~ailments9~") |
| [Ailment Chance and Duration](/wiki/Ailment_Chance_and_Duration/edit?redlink=1 "Ailment Chance and Duration (page does not exist)") | 6% increased chance to inflict [Ailments](/wiki/Ailments "Ailments") 6% increased Duration of [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") on Enemies [[1]](/wiki/Passive_Skill:Ailments44 "Passive Skill:Ailments44") [[2]](/wiki/Passive_Skill:Ailments45 "Passive Skill:Ailments45") |
| [Ailment Chance and Effect](/wiki/Ailment_Chance_and_Effect/edit?redlink=1 "Ailment Chance and Effect (page does not exist)") | 6% increased chance to inflict [Ailments](/wiki/Ailments "Ailments") 6% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") you inflict [[1]](/wiki/Passive_Skill:Ailments14 "Passive Skill:Ailments14") [[2]](/wiki/Passive_Skill:Ailments15 "Passive Skill:Ailments15") [[3]](/wiki/Passive_Skill:Ailments16 "Passive Skill:Ailments16") |
| [Ailment Chance and Elemental Damage](/wiki/Ailment_Chance_and_Elemental_Damage/edit?redlink=1 "Ailment Chance and Elemental Damage (page does not exist)") | 6% increased chance to inflict [Ailments](/wiki/Ailments "Ailments") 10% increased [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") [[1]](/wiki/Passive_Skill:Ailments46 "Passive Skill:Ailments46") [[2]](/wiki/Passive_Skill:Ailments47 "Passive Skill:Ailments47") |
| [One Handed Ailment Chance](/wiki/One_Handed_Ailment_Chance/edit?redlink=1 "One Handed Ailment Chance (page does not exist)") | [Attacks](/wiki/Attack "Attack") with [One-Handed](/wiki/One-Handed "One-Handed") [Weapons](/wiki/Martial_Weapons "Martial Weapons") have 15% increased Chance to inflict [Ailments](/wiki/Ailments "Ailments") [[1]](/wiki/Passive_Skill:One~handed24 "Passive Skill:One~handed24") [[2]](/wiki/Passive_Skill:One~handed25~ "Passive Skill:One~handed25~") |
| [Physical Damage and Ailment Chance](/wiki/Physical_Damage_and_Ailment_Chance/edit?redlink=1 "Physical Damage and Ailment Chance (page does not exist)") | 8% increased [Physical](/wiki/Physical "Physical") Damage 8% increased chance to inflict [Ailments](/wiki/Ailments "Ailments") [[1]](/wiki/Passive_Skill:Projectiles49 "Passive Skill:Projectiles49") |
| [Projectile Ailment Chance](/wiki/Projectile_Ailment_Chance/edit?redlink=1 "Projectile Ailment Chance (page does not exist)") | 20% increased chance to inflict [Ailments](/wiki/Ailments "Ailments") with [Projectiles](/wiki/Projectile "Projectile") [[1]](/wiki/Passive_Skill:Quivers1~ "Passive Skill:Quivers1~") |
| [Shapeshifting Elemental Ailment Chance](/wiki/Shapeshifting_Elemental_Ailment_Chance/edit?redlink=1 "Shapeshifting Elemental Ailment Chance (page does not exist)") | 20% increased chance to inflict [Elemental Ailments](/wiki/Elemental_Ailment "Elemental Ailment") if you have [Shapeshifted](/wiki/Shapeshifting "Shapeshifting") to an Animal form [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Shapeshifting30 "Passive Skill:Shapeshifting30") |
| [Advanced Munitions](/wiki/Advanced_Munitions/edit?redlink=1 "Advanced Munitions (page does not exist)") | 25% increased chance to inflict [Ailments](/wiki/Ailments "Ailments") with [Projectiles](/wiki/Projectile "Projectile") [[1]](/wiki/Passive_Skill:Ranged40 "Passive Skill:Ranged40") |
| [Coated Arms](/wiki/Coated_Arms/edit?redlink=1 "Coated Arms (page does not exist)") | 25% increased Damage with One Handed Weapons [Attacks](/wiki/Attack "Attack") with [One-Handed](/wiki/One-Handed "One-Handed") [Weapons](/wiki/Martial_Weapons "Martial Weapons") have 20% increased Chance to inflict [Ailments](/wiki/Ailments "Ailments") [[1]](/wiki/Passive_Skill:One~handed26 "Passive Skill:One~handed26") |
| [Exploit the Elements](/wiki/Exploit_the_Elements/edit?redlink=1 "Exploit the Elements (page does not exist)") | 24% increased Damage with [Hits](/wiki/Hit "Hit") against Enemies affected by [Elemental Ailments](/wiki/Elemental_Ailment "Elemental Ailment") 30% increased chance to inflict [Ailments](/wiki/Ailments "Ailments") against [Rare or Unique](/wiki/Rarity "Rarity") Enemies [[1]](/wiki/Passive_Skill:Exploiting~elemental~ailments16 "Passive Skill:Exploiting~elemental~ailments16") |
| [Exposed to the Cosmos](/wiki/Exposed_to_the_Cosmos/edit?redlink=1 "Exposed to the Cosmos (page does not exist)") | Damage [Penetrates](/wiki/Resistance_Penetration "Resistance Penetration") 18% [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance") 20% increased chance to inflict [Ailments](/wiki/Ailments "Ailments") against Enemies with [Exposure](/wiki/Exposure "Exposure") [[1]](/wiki/Passive_Skill:Cold~penetration23 "Passive Skill:Cold~penetration23") |
| [Exposed Wounds](/wiki/Exposed_Wounds/edit?redlink=1 "Exposed Wounds (page does not exist)") | 15% increased chance to inflict [Ailments](/wiki/Ailments "Ailments") [Hits](/wiki/Hit "Hit") [Break](/wiki/Break "Break") 30% increased [Armour](/wiki/Armour "Armour") on targets with [Ailments](/wiki/Ailments "Ailments") [[1]](/wiki/Passive_Skill:Ailments20 "Passive Skill:Ailments20") |
| [Giantslayer](/wiki/Giantslayer/edit?redlink=1 "Giantslayer (page does not exist)") | 25% increased Damage with [Hits](/wiki/Hit "Hit") against [Rare and Unique](/wiki/Rarity "Rarity") Enemies 20% increased [Accuracy](/wiki/Accuracy "Accuracy") Rating against [Rare or Unique](/wiki/Rarity "Rarity") Enemies 20% increased chance to inflict [Ailments](/wiki/Ailments "Ailments") against [Rare or Unique](/wiki/Rarity "Rarity") Enemies [[1]](/wiki/Passive_Skill:Boss~slaying10 "Passive Skill:Boss~slaying10") |
| [Hidden Barb](/wiki/Hidden_Barb/edit?redlink=1 "Hidden Barb (page does not exist)") | 20% increased [Physical](/wiki/Physical "Physical") Damage 20% increased chance to inflict [Ailments](/wiki/Ailments "Ailments") [[1]](/wiki/Passive_Skill:Projectiles50 "Passive Skill:Projectiles50") |
| [Intense Dose](/wiki/Intense_Dose/edit?redlink=1 "Intense Dose (page does not exist)") | 20% increased chance to inflict [Ailments](/wiki/Ailments "Ailments") 15% increased Duration of [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") on Enemies [[1]](/wiki/Passive_Skill:Ailments43 "Passive Skill:Ailments43") |
| [Manifold Method](/wiki/Manifold_Method/edit?redlink=1 "Manifold Method (page does not exist)") | 50% increased amount of Mana [Leeched](/wiki/Leech "Leech") 25% increased chance to inflict [Ailments](/wiki/Ailments "Ailments") against [Rare or Unique](/wiki/Rarity "Rarity") Enemies [[1]](/wiki/Passive_Skill:Mana~leech19 "Passive Skill:Mana~leech19") |
| [Nature's Bite](/wiki/Nature%27s_Bite/edit?redlink=1 "Nature's Bite (page does not exist)") | 15% increased chance to inflict [Ailments](/wiki/Ailments "Ailments") 20% increased [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") [[1]](/wiki/Passive_Skill:Ailments48 "Passive Skill:Ailments48") |
| [Sling Shots](/wiki/Sling_Shots/edit?redlink=1 "Sling Shots (page does not exist)") | 20% increased [Projectile](/wiki/Projectile "Projectile") Damage 20% increased chance to inflict [Ailments](/wiki/Ailments "Ailments") with [Projectiles](/wiki/Projectile "Projectile") [[1]](/wiki/Passive_Skill:Projectiles39 "Passive Skill:Projectiles39") |
| [Wyvern's Breath](/wiki/Wyvern%27s_Breath/edit?redlink=1 "Wyvern's Breath (page does not exist)") | 40% increased chance to inflict [Elemental Ailments](/wiki/Elemental_Ailment "Elemental Ailment") if you have [Shapeshifted](/wiki/Shapeshifting "Shapeshifting") to an Animal form [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Shapeshifting28 "Passive Skill:Shapeshifting28") |

### Ailment magnitude

| Name | Stats |
| --- | --- |
| [Ailment Chance and Effect](/wiki/Ailment_Chance_and_Effect/edit?redlink=1 "Ailment Chance and Effect (page does not exist)") | 6% increased chance to inflict [Ailments](/wiki/Ailments "Ailments") 6% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") you inflict [[1]](/wiki/Passive_Skill:Ailments14 "Passive Skill:Ailments14") [[2]](/wiki/Passive_Skill:Ailments15 "Passive Skill:Ailments15") [[3]](/wiki/Passive_Skill:Ailments16 "Passive Skill:Ailments16") |
| [Ailment Effect](/wiki/Ailment_Effect/edit?redlink=1 "Ailment Effect (page does not exist)") | 10% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Ailments](/wiki/Ailments "Ailments") you inflict [[1]](/wiki/Passive_Skill:Ailments23 "Passive Skill:Ailments23")  ---  12% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Ailments](/wiki/Ailments "Ailments") you inflict [[3]](/wiki/Passive_Skill:Slow~attacks4 "Passive Skill:Slow~attacks4") [[4]](/wiki/Passive_Skill:Slow~attacks6~ "Passive Skill:Slow~attacks6~") |
| [Ailment Effect and Duration](/wiki/Ailment_Effect_and_Duration/edit?redlink=1 "Ailment Effect and Duration (page does not exist)") | 5% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Ailments](/wiki/Ailments "Ailments") you inflict 5% increased Duration of [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") on Enemies [[1]](/wiki/Passive_Skill:Ailments35 "Passive Skill:Ailments35") [[2]](/wiki/Passive_Skill:Ailments36 "Passive Skill:Ailments36") |
| [Ailment Magnitude](/wiki/Ailment_Magnitude/edit?redlink=1 "Ailment Magnitude (page does not exist)") | 10% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Ailments](/wiki/Ailments "Ailments") you inflict [[1]](/wiki/Passive_Skill:Azmerianimals43 "Passive Skill:Azmerianimals43") [[2]](/wiki/Passive_Skill:Azmerianimals44 "Passive Skill:Azmerianimals44") |
| [Non-Damaging Ailment Magnitude](/wiki/Non-Damaging_Ailment_Magnitude/edit?redlink=1 "Non-Damaging Ailment Magnitude (page does not exist)") | 10% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Non-Damaging Ailments](/wiki/Non-Damaging_Ailment "Non-Damaging Ailment") you inflict [[1]](/wiki/Passive_Skill:Monkchakra22 "Passive Skill:Monkchakra22") [[2]](/wiki/Passive_Skill:Monkchakra23 "Passive Skill:Monkchakra23") |
| [Spell Critical Chance and Critical Ailment Effect](/wiki/Spell_Critical_Chance_and_Critical_Ailment_Effect/edit?redlink=1 "Spell Critical Chance and Critical Ailment Effect (page does not exist)") | 10% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for [Spells](/wiki/Spell "Spell") 15% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") you inflict with [Critical Hits](/wiki/Critical_Hit "Critical Hit") [[1]](/wiki/Passive_Skill:Physical17 "Passive Skill:Physical17") |
| [Breaking Point](/wiki/Breaking_Point/edit?redlink=1 "Breaking Point (page does not exist)") | 30% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Non-Damaging Ailments](/wiki/Non-Damaging_Ailment "Non-Damaging Ailment") you inflict 10% increased Duration of Elemental [Ailments](/wiki/Ailments "Ailments") on Enemies [[1]](/wiki/Passive_Skill:Elemental37~ "Passive Skill:Elemental37~") |
| [Cruel Fate](/wiki/Cruel_Fate/edit?redlink=1 "Cruel Fate (page does not exist)") | 20% increased [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus") 20% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Non-Damaging Ailments](/wiki/Non-Damaging_Ailment "Non-Damaging Ailment") you inflict with [Critical Hits](/wiki/Critical_Hit "Critical Hit") [[1]](/wiki/Passive_Skill:Criticals25~ "Passive Skill:Criticals25~") |
| [Deterioration](/wiki/Deterioration/edit?redlink=1 "Deterioration (page does not exist)") | 20% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") you inflict [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") Cannot Be inflicted on you while you already have one [[1]](/wiki/Passive_Skill:Ailments17 "Passive Skill:Ailments17") |
| [Lasting Trauma](/wiki/Lasting_Trauma/edit?redlink=1 "Lasting Trauma (page does not exist)") | 30% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Ailments](/wiki/Ailments "Ailments") you inflict 20% increased Duration of [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") on Enemies 5% reduced [Attack](/wiki/Attack "Attack") Speed [[1]](/wiki/Passive_Skill:Slow~attacks11 "Passive Skill:Slow~attacks11") |
| [Shredding Force](/wiki/Shredding_Force/edit?redlink=1 "Shredding Force (page does not exist)") | 15% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for [Spells](/wiki/Spell "Spell") 15% increased [Critical Spell Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus") 15% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") you inflict with [Critical Hits](/wiki/Critical_Hit "Critical Hit") [[1]](/wiki/Passive_Skill:Physical34 "Passive Skill:Physical34") |
| [Tainted Strike](/wiki/Tainted_Strike/edit?redlink=1 "Tainted Strike (page does not exist)") | 30% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Non-Damaging Ailments](/wiki/Non-Damaging_Ailment "Non-Damaging Ailment") you inflict with [Critical Hits](/wiki/Critical_Hit "Critical Hit") 20% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for [Attacks](/wiki/Attack "Attack") [[1]](/wiki/Passive_Skill:Criticals79 "Passive Skill:Criticals79") |

### Ailment duration

| Name | Stats |
| --- | --- |
| [Ailment Chance and Duration](/wiki/Ailment_Chance_and_Duration/edit?redlink=1 "Ailment Chance and Duration (page does not exist)") | 6% increased chance to inflict [Ailments](/wiki/Ailments "Ailments") 6% increased Duration of [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") on Enemies [[1]](/wiki/Passive_Skill:Ailments44 "Passive Skill:Ailments44") [[2]](/wiki/Passive_Skill:Ailments45 "Passive Skill:Ailments45") |
| [Ailment Duration](/wiki/Ailment_Duration/edit?redlink=1 "Ailment Duration (page does not exist)") | 10% increased Duration of [Ailments](/wiki/Ailments "Ailments") on Beasts [[1]](/wiki/Passive_Skill:Mercenary2 "Passive Skill:Mercenary2") |
| [Ailment Effect and Duration](/wiki/Ailment_Effect_and_Duration/edit?redlink=1 "Ailment Effect and Duration (page does not exist)") | 5% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Ailments](/wiki/Ailments "Ailments") you inflict 5% increased Duration of [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") on Enemies [[1]](/wiki/Passive_Skill:Ailments35 "Passive Skill:Ailments35") [[2]](/wiki/Passive_Skill:Ailments36 "Passive Skill:Ailments36") |
| [Breaking Point](/wiki/Breaking_Point/edit?redlink=1 "Breaking Point (page does not exist)") | 30% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Non-Damaging Ailments](/wiki/Non-Damaging_Ailment "Non-Damaging Ailment") you inflict 10% increased Duration of Elemental [Ailments](/wiki/Ailments "Ailments") on Enemies [[1]](/wiki/Passive_Skill:Elemental37~ "Passive Skill:Elemental37~") |
| [Decrepifying Curse](/wiki/Decrepifying_Curse/edit?redlink=1 "Decrepifying Curse (page does not exist)") | 20% increased duration of [Ailments](/wiki/Ailments "Ailments") you inflict against [Cursed](/wiki/Curse "Curse") Enemies [[1]](/wiki/Passive_Skill:Curses25 "Passive Skill:Curses25") |
| [Exposed to the Inferno](/wiki/Exposed_to_the_Inferno/edit?redlink=1 "Exposed to the Inferno (page does not exist)") | Damage [Penetrates](/wiki/Resistance_Penetration "Resistance Penetration") 18% [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") 15% increased Duration of [Ailments](/wiki/Ailments "Ailments") against Enemies with [Exposure](/wiki/Exposure "Exposure") [[1]](/wiki/Passive_Skill:Fire~penetration22 "Passive Skill:Fire~penetration22") |
| [Hunter](/wiki/Hunter/edit?redlink=1 "Hunter (page does not exist)") | 50% increased Damage against Demons 50% increased [Immobilisation](/wiki/Immobilised "Immobilised") buildup against Constructs 50% increased Duration of [Ailments](/wiki/Ailments "Ailments") on Beasts 50% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") against Humanoids [[1]](/wiki/Passive_Skill:Mercenary5 "Passive Skill:Mercenary5") |
| [Intense Dose](/wiki/Intense_Dose/edit?redlink=1 "Intense Dose (page does not exist)") | 20% increased chance to inflict [Ailments](/wiki/Ailments "Ailments") 15% increased Duration of [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") on Enemies [[1]](/wiki/Passive_Skill:Ailments43 "Passive Skill:Ailments43") |
| [Lasting Trauma](/wiki/Lasting_Trauma/edit?redlink=1 "Lasting Trauma (page does not exist)") | 30% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Ailments](/wiki/Ailments "Ailments") you inflict 20% increased Duration of [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") on Enemies 5% reduced [Attack](/wiki/Attack "Attack") Speed [[1]](/wiki/Passive_Skill:Slow~attacks11 "Passive Skill:Slow~attacks11") |
| [Protraction](/wiki/Protraction/edit?redlink=1 "Protraction (page does not exist)") | 20% increased Skill Effect Duration 15% increased Duration of [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") on Enemies [[1]](/wiki/Passive_Skill:Duration5 "Passive Skill:Duration5") |
| [Shedding Skin](/wiki/Shedding_Skin/edit?redlink=1 "Shedding Skin (page does not exist)") | 40% increased Elemental Ailment Threshold 10% reduced Duration of [Ailments](/wiki/Ailments "Ailments") on You [[1]](/wiki/Passive_Skill:Spell~suppression32 "Passive Skill:Spell~suppression32") |
| [Shimmering Mirage](/wiki/Shimmering_Mirage "Shimmering Mirage") | Gain additional [Ailment Threshold](/wiki/Ailment_Threshold "Ailment Threshold") equal to 30% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") 10% reduced Duration of [Ailments](/wiki/Ailments "Ailments") on You [[1]](/wiki/Passive_Skill:Stun~threshold~from~energy~shield21 "Passive Skill:Stun~threshold~from~energy~shield21") |
| [Smoke Inhalation](/wiki/Smoke_Inhalation/edit?redlink=1 "Smoke Inhalation (page does not exist)") | Damage [Penetrates](/wiki/Resistance_Penetration "Resistance Penetration") 15% [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") 15% increased Duration of [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") on Enemies [[1]](/wiki/Passive_Skill:Fire~penetration25 "Passive Skill:Fire~penetration25") |
| [The Raging Ox](/wiki/The_Raging_Ox/edit?redlink=1 "The Raging Ox (page does not exist)") | 15% reduced Duration of [Ailments](/wiki/Ailments "Ailments") on You Hits against you have 30% reduced [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus") +10 to [Strength](/wiki/Strength "Strength") [[1]](/wiki/Passive_Skill:Azmerianimals36 "Passive Skill:Azmerianimals36") |
| [Wasting](/wiki/Wasting/edit?redlink=1 "Wasting (page does not exist)") | 15% increased Duration of [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") on Enemies 30% increased Damage with [Hits](/wiki/Hit "Hit") against Enemies affected by [Ailments](/wiki/Ailments "Ailments") [[1]](/wiki/Passive_Skill:Ailments39~ "Passive Skill:Ailments39~") |

### Ailment threshold

| Name | Stats |
| --- | --- |
| [Ailment Threshold](/wiki/Ailment_Threshold "Ailment Threshold") | 15% increased Elemental Ailment Threshold [[1]](/wiki/Passive_Skill:Spell~suppression26~ "Passive Skill:Spell~suppression26~") [[2]](/wiki/Passive_Skill:Spell~suppression27 "Passive Skill:Spell~suppression27") [[3]](/wiki/Passive_Skill:Spell~suppression28~ "Passive Skill:Spell~suppression28~") [[4]](/wiki/Passive_Skill:Spell~suppression30 "Passive Skill:Spell~suppression30") [[5]](/wiki/Passive_Skill:Spell~suppression31 "Passive Skill:Spell~suppression31") [[6]](/wiki/Passive_Skill:Spell~suppression8 "Passive Skill:Spell~suppression8") [[7]](/wiki/Passive_Skill:Spell~suppression9 "Passive Skill:Spell~suppression9")  ---  25% increased Elemental Ailment Threshold [[2]](/wiki/Passive_Skill:Spell~suppression29 "Passive Skill:Spell~suppression29") |
| [Ailment Threshold and Companion Resistance](/wiki/Ailment_Threshold_and_Companion_Resistance/edit?redlink=1 "Ailment Threshold and Companion Resistance (page does not exist)") | 8% increased Elemental Ailment Threshold [Companions](/wiki/Companion "Companion") have +12% to all Elemental [Resistances](/wiki/Resistances "Resistances") [[1]](/wiki/Passive_Skill:Companions25 "Passive Skill:Companions25") [[2]](/wiki/Passive_Skill:Companions33 "Passive Skill:Companions33") [[3]](/wiki/Passive_Skill:Companions34 "Passive Skill:Companions34") |
| [Ailment Threshold and Slow Effect on You](/wiki/Ailment_Threshold_and_Slow_Effect_on_You/edit?redlink=1 "Ailment Threshold and Slow Effect on You (page does not exist)") | 10% increased Elemental Ailment Threshold 5% reduced [Slowing](/wiki/Slow "Slow") Potency of [Debuffs](/wiki/Debuff "Debuff") on You [[1]](/wiki/Passive_Skill:Slow~mitigation17 "Passive Skill:Slow~mitigation17") [[2]](/wiki/Passive_Skill:Slow~mitigation18 "Passive Skill:Slow~mitigation18") |
| [Ailment Threshold from Energy Shield](/wiki/Ailment_Threshold_from_Energy_Shield/edit?redlink=1 "Ailment Threshold from Energy Shield (page does not exist)") | Gain additional [Ailment Threshold](/wiki/Ailment_Threshold "Ailment Threshold") equal to 12% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") [[1]](/wiki/Passive_Skill:Stun~threshold~from~energy~shield20 "Passive Skill:Stun~threshold~from~energy~shield20") |
| [Stun and Ailment Threshold from Energy Shield](/wiki/Stun_and_Ailment_Threshold_from_Energy_Shield "Stun and Ailment Threshold from Energy Shield") | Gain additional [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") equal to 8% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") Gain additional [Ailment Threshold](/wiki/Ailment_Threshold "Ailment Threshold") equal to 8% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") [[1]](/wiki/Passive_Skill:Energy~shield3 "Passive Skill:Energy~shield3") [[2]](/wiki/Passive_Skill:Stun~threshold~from~energy~shield8 "Passive Skill:Stun~threshold~from~energy~shield8") [[3]](/wiki/Passive_Skill:Stun~threshold~from~energy~shield7 "Passive Skill:Stun~threshold~from~energy~shield7") [[4]](/wiki/Passive_Skill:Stun~threshold~from~energy~shield2 "Passive Skill:Stun~threshold~from~energy~shield2") [[5]](/wiki/Passive_Skill:Stun~threshold~from~energy~shield1~ "Passive Skill:Stun~threshold~from~energy~shield1~") [[6]](/wiki/Passive_Skill:Stun~threshold~from~energy~shield17 "Passive Skill:Stun~threshold~from~energy~shield17") [[7]](/wiki/Passive_Skill:Stun~threshold~from~energy~shield16 "Passive Skill:Stun~threshold~from~energy~shield16") [[8]](/wiki/Passive_Skill:Stun~threshold~from~energy~shield15 "Passive Skill:Stun~threshold~from~energy~shield15") [[9]](/wiki/Passive_Skill:Stun~threshold~from~energy~shield14 "Passive Skill:Stun~threshold~from~energy~shield14") [[10]](/wiki/Passive_Skill:Stun~threshold~from~energy~shield13 "Passive Skill:Stun~threshold~from~energy~shield13") |
| [Against the Elements](/wiki/Against_the_Elements/edit?redlink=1 "Against the Elements (page does not exist)") | 30% increased Elemental Ailment Threshold 15% reduced [Slowing](/wiki/Slow "Slow") Potency of [Debuffs](/wiki/Debuff "Debuff") on You [[1]](/wiki/Passive_Skill:Slow~mitigation19~ "Passive Skill:Slow~mitigation19~") |
| [Austerity Measures](/wiki/Austerity_Measures "Austerity Measures") | Gain additional [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") equal to 16% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") Gain additional [Ailment Threshold](/wiki/Ailment_Threshold "Ailment Threshold") equal to 16% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") +5 to all [Attributes](/wiki/Attributes "Attributes") [[1]](/wiki/Passive_Skill:Stun~threshold~from~energy~shield9 "Passive Skill:Stun~threshold~from~energy~shield9") |
| [Dampening Shield](/wiki/Dampening_Shield "Dampening Shield") | 28% increased maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") Gain additional [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") equal to 12% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") Gain additional [Ailment Threshold](/wiki/Ailment_Threshold "Ailment Threshold") equal to 12% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") [[1]](/wiki/Passive_Skill:Energy~shield37 "Passive Skill:Energy~shield37") |
| [Eldritch Will](/wiki/Eldritch_Will "Eldritch Will") | Gain additional [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") equal to 15% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") Gain additional [Ailment Threshold](/wiki/Ailment_Threshold "Ailment Threshold") equal to 15% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") 3% increased maximum Life, Mana and [Energy Shield](/wiki/Energy_Shield "Energy Shield") [[1]](/wiki/Passive_Skill:Stun~threshold~from~energy~shield22 "Passive Skill:Stun~threshold~from~energy~shield22") |
| [Fan the Flames](/wiki/Fan_the_Flames/edit?redlink=1 "Fan the Flames (page does not exist)") | 40% increased Elemental Ailment Threshold 25% reduced [Ignite](/wiki/Ignite "Ignite") Duration on you [[1]](/wiki/Passive_Skill:Spell~suppression23 "Passive Skill:Spell~suppression23") |
| [Favourable Odds](/wiki/Favourable_Odds/edit?redlink=1 "Favourable Odds (page does not exist)") | 30% increased [Block](/wiki/Block "Block") chance while [Surrounded](/wiki/Surrounded "Surrounded") 10% increased [Deflection Rating](/wiki/Deflect "Deflect") while [Surrounded](/wiki/Surrounded "Surrounded") 40% increased Ailment and [Stun](/wiki/Stun_Threshold "Stun Threshold") Threshold while [Surrounded](/wiki/Surrounded "Surrounded") [[1]](/wiki/Passive_Skill:Being~surrounded23 "Passive Skill:Being~surrounded23") |
| [Feel the Earth](/wiki/Feel_the_Earth/edit?redlink=1 "Feel the Earth (page does not exist)") | 40% increased Elemental Ailment Threshold 25% reduced [Shock](/wiki/Shock "Shock") duration on you [[1]](/wiki/Passive_Skill:Spell~suppression25~ "Passive Skill:Spell~suppression25~") |
| [Hallowed](/wiki/Hallowed "Hallowed") | Gain additional [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") equal to 20% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") Gain additional [Ailment Threshold](/wiki/Ailment_Threshold "Ailment Threshold") equal to 20% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") [[1]](/wiki/Passive_Skill:Stun~threshold~from~energy~shield12 "Passive Skill:Stun~threshold~from~energy~shield12") |
| [Insulated Treads](/wiki/Insulated_Treads/edit?redlink=1 "Insulated Treads (page does not exist)") | Gain [Ailment Threshold](/wiki/Ailment_Threshold "Ailment Threshold") equal to the lowest of [Evasion](/wiki/Evasion "Evasion") and [Armour](/wiki/Armour "Armour") on your Boots [[1]](/wiki/Passive_Skill:Armour~and~evasion14~~ "Passive Skill:Armour~and~evasion14~~") |
| [Natural Immunity](/wiki/Natural_Immunity/edit?redlink=1 "Natural Immunity (page does not exist)") | +4 to [Ailment Threshold](/wiki/Ailment_Threshold "Ailment Threshold") per [Dexterity](/wiki/Dexterity "Dexterity") [[1]](/wiki/Passive_Skill:Spell~suppression14 "Passive Skill:Spell~suppression14") |
| [Shedding Skin](/wiki/Shedding_Skin/edit?redlink=1 "Shedding Skin (page does not exist)") | 40% increased Elemental Ailment Threshold 10% reduced Duration of [Ailments](/wiki/Ailments "Ailments") on You [[1]](/wiki/Passive_Skill:Spell~suppression32 "Passive Skill:Spell~suppression32") |
| [Shimmering Mirage](/wiki/Shimmering_Mirage "Shimmering Mirage") | Gain additional [Ailment Threshold](/wiki/Ailment_Threshold "Ailment Threshold") equal to 30% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") 10% reduced Duration of [Ailments](/wiki/Ailments "Ailments") on You [[1]](/wiki/Passive_Skill:Stun~threshold~from~energy~shield21 "Passive Skill:Stun~threshold~from~energy~shield21") |
| [Silent Guardian](/wiki/Silent_Guardian/edit?redlink=1 "Silent Guardian (page does not exist)") | [Minions](/wiki/Minion "Minion") have +20% to all Elemental [Resistances](/wiki/Resistances "Resistances") 20% increased Elemental Ailment Threshold [[1]](/wiki/Passive_Skill:Sentinels9 "Passive Skill:Sentinels9") |
| [Unbreaking](/wiki/Unbreaking/edit?redlink=1 "Unbreaking (page does not exist)") | 30% increased [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") 30% increased Elemental Ailment Threshold [[1]](/wiki/Passive_Skill:Stun~threshold12 "Passive Skill:Stun~threshold12") |

### Miscellany

| Name | Stats |
| --- | --- |
| [Damage against Ailments](/wiki/Damage_against_Ailments/edit?redlink=1 "Damage against Ailments (page does not exist)") | 12% increased Damage with [Hits](/wiki/Hit "Hit") against Enemies affected by [Elemental Ailments](/wiki/Elemental_Ailment "Elemental Ailment") [[1]](/wiki/Passive_Skill:Exploiting~elemental~ailments1 "Passive Skill:Exploiting~elemental~ailments1") [[2]](/wiki/Passive_Skill:Exploiting~elemental~ailments2 "Passive Skill:Exploiting~elemental~ailments2") [[3]](/wiki/Passive_Skill:Exploiting~elemental~ailments3 "Passive Skill:Exploiting~elemental~ailments3") [[4]](/wiki/Passive_Skill:Exploiting~elemental~ailments4 "Passive Skill:Exploiting~elemental~ailments4") [[5]](/wiki/Passive_Skill:Exploiting~elemental~ailments5 "Passive Skill:Exploiting~elemental~ailments5") |
| [Faster Ailments](/wiki/Faster_Ailments/edit?redlink=1 "Faster Ailments (page does not exist)") | [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") deal damage 5% faster [[1]](/wiki/Passive_Skill:Ailments22 "Passive Skill:Ailments22") [[2]](/wiki/Passive_Skill:Ailments25 "Passive Skill:Ailments25") |
| [Deterioration](/wiki/Deterioration/edit?redlink=1 "Deterioration (page does not exist)") | 20% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") you inflict [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") Cannot Be inflicted on you while you already have one [[1]](/wiki/Passive_Skill:Ailments17 "Passive Skill:Ailments17") |
| [Direct Approach](/wiki/Direct_Approach/edit?redlink=1 "Direct Approach (page does not exist)") | 35% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") against Enemies that are affected by no Elemental [Ailments](/wiki/Ailments "Ailments") [[1]](/wiki/Passive_Skill:Criticals27 "Passive Skill:Criticals27") |
| [Exploit](/wiki/Exploit/edit?redlink=1 "Exploit (page does not exist)") | 25% increased Damage with [Hits](/wiki/Hit "Hit") against Enemies affected by [Elemental Ailments](/wiki/Elemental_Ailment "Elemental Ailment") 15% increased Duration of [Ignite](/wiki/Ignite "Ignite"), [Shock](/wiki/Shock "Shock") and [Chill](/wiki/Chill "Chill") on Enemies [[1]](/wiki/Passive_Skill:Exploiting~elemental~ailments15 "Passive Skill:Exploiting~elemental~ailments15") |
| [Exploit the Elements](/wiki/Exploit_the_Elements/edit?redlink=1 "Exploit the Elements (page does not exist)") | 24% increased Damage with [Hits](/wiki/Hit "Hit") against Enemies affected by [Elemental Ailments](/wiki/Elemental_Ailment "Elemental Ailment") 30% increased chance to inflict [Ailments](/wiki/Ailments "Ailments") against [Rare or Unique](/wiki/Rarity "Rarity") Enemies [[1]](/wiki/Passive_Skill:Exploiting~elemental~ailments16 "Passive Skill:Exploiting~elemental~ailments16") |
| [Exposed Wounds](/wiki/Exposed_Wounds/edit?redlink=1 "Exposed Wounds (page does not exist)") | 15% increased chance to inflict [Ailments](/wiki/Ailments "Ailments") [Hits](/wiki/Hit "Hit") [Break](/wiki/Break "Break") 30% increased [Armour](/wiki/Armour "Armour") on targets with [Ailments](/wiki/Ailments "Ailments") [[1]](/wiki/Passive_Skill:Ailments20 "Passive Skill:Ailments20") |
| [Fast Acting Toxins](/wiki/Fast_Acting_Toxins/edit?redlink=1 "Fast Acting Toxins (page does not exist)") | [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") deal damage 12% faster [[1]](/wiki/Passive_Skill:Ailments38 "Passive Skill:Ailments38") |
| [Harness the Elements](/wiki/Harness_the_Elements/edit?redlink=1 "Harness the Elements (page does not exist)") | 20% increased Damage for each type of [Elemental Ailment](/wiki/Elemental_Ailment "Elemental Ailment") on Enemy [[1]](/wiki/Passive_Skill:Elemental32 "Passive Skill:Elemental32") |
| [Splinters](/wiki/Splinters "Splinters") | [Hits](/wiki/Hit "Hit") [Break](/wiki/Break "Break") 50% increased [Armour](/wiki/Armour "Armour") on targets with [Ailments](/wiki/Ailments "Ailments") 30% increased [Stun](/wiki/Stun "Stun") Buildup [[1]](/wiki/Passive_Skill:Physical39 "Passive Skill:Physical39") |
| [Stand Ground](/wiki/Stand_Ground/edit?redlink=1 "Stand Ground (page does not exist)") | Regenerate 1% of maximum Life per second while stationary Regenerate 1% of maximum Life per second while affected by any [Damaging Ailment](/wiki/Damaging_Ailment "Damaging Ailment") [[1]](/wiki/Passive_Skill:Life~regeneration38 "Passive Skill:Life~regeneration38") |
| [Stormbreaker](/wiki/Stormbreaker/edit?redlink=1 "Stormbreaker (page does not exist)") | 20% increased Damage for each type of [Elemental Ailment](/wiki/Elemental_Ailment "Elemental Ailment") on Enemy [[1]](/wiki/Passive_Skill:Elemental40 "Passive Skill:Elemental40") |
| [Stylebender](/wiki/Stylebender/edit?redlink=1 "Stylebender (page does not exist)") | [Hits](/wiki/Hit "Hit") [Break](/wiki/Break "Break") 30% increased [Armour](/wiki/Armour "Armour") on targets with [Ailments](/wiki/Ailments "Ailments") 25% increased [Physical](/wiki/Physical "Physical") Damage +10 to [Strength](/wiki/Strength "Strength") [[1]](/wiki/Passive_Skill:Chaos35 "Passive Skill:Chaos35") |
| [The Noble Wolf](/wiki/The_Noble_Wolf/edit?redlink=1 "The Noble Wolf (page does not exist)") | 25% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Ailments](/wiki/Ailments "Ailments") you inflict against [Marked](/wiki/Mark "Mark") Enemies 20% increased [Critical](/wiki/Critical "Critical") Hit Chance against [Marked](/wiki/Mark "Mark") Enemies +10 to [Dexterity](/wiki/Dexterity "Dexterity") [[1]](/wiki/Passive_Skill:Azmerianimals48 "Passive Skill:Azmerianimals48") |
| [Vile Wounds](/wiki/Vile_Wounds/edit?redlink=1 "Vile Wounds (page does not exist)") | 33% increased Damage with [Hits](/wiki/Hit "Hit") against Enemies affected by [Ailments](/wiki/Ailments "Ailments") [[1]](/wiki/Passive_Skill:Exploiting~elemental~ailments10 "Passive Skill:Exploiting~elemental~ailments10") |
| [Wasting](/wiki/Wasting/edit?redlink=1 "Wasting (page does not exist)") | 15% increased Duration of [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") on Enemies 30% increased Damage with [Hits](/wiki/Hit "Hit") against Enemies affected by [Ailments](/wiki/Ailments "Ailments") [[1]](/wiki/Passive_Skill:Ailments39~ "Passive Skill:Ailments39~") |

### Paths Not Taken passive skills

The following passive skills are exclusive the [Oracle](/wiki/Oracle "Oracle") with [The Unseen Path](/wiki/The_Unseen_Path "The Unseen Path") allocated:

| Name | Stats |
| --- | --- |
| [Elemental Threshold](/wiki/Elemental_Threshold/edit?redlink=1 "Elemental Threshold (page does not exist)") | 17% increased Elemental Ailment Threshold [[1]](/wiki/Passive_Skill:Oracle~beast~corruption5 "Passive Skill:Oracle~beast~corruption5") [[2]](/wiki/Passive_Skill:Oracle~beast~corruption6 "Passive Skill:Oracle~beast~corruption6") |
| [Stun and Elemental Threshold](/wiki/Stun_and_Elemental_Threshold/edit?redlink=1 "Stun and Elemental Threshold (page does not exist)") | 11% increased [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") 11% increased Elemental Ailment Threshold [[1]](/wiki/Passive_Skill:Oracle~beast~corruption1 "Passive Skill:Oracle~beast~corruption1") |
| [Flesh Withstands](/wiki/Flesh_Withstands "Flesh Withstands") | 21% increased [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") 21% increased Elemental Ailment Threshold 30% increased Life Regeneration rate while [Ignited](/wiki/Ignite "Ignite") +500 to [Armour](/wiki/Armour "Armour") while Frozen 30% increased Mana Regeneration Rate while [Shocked](/wiki/Shock "Shock") [[1]](/wiki/Passive_Skill:Oracle~beast~corruption7 "Passive Skill:Oracle~beast~corruption7") |

### Ascendancy passive skills

The following [Ascendancy passive skills](/wiki/Ascendancy_passive_skill "Ascendancy passive skill") are related to ailments:

| Ascendancy Class | Name | Stats |
| --- | --- | --- |
| [Acolyte of Chayula](/wiki/Acolyte_of_Chayula "Acolyte of Chayula") | [Inner Turmoil](/wiki/Inner_Turmoil "Inner Turmoil") | Gain 1 [Volatility](/wiki/Volatility "Volatility") on inflicting an [Elemental Ailment](/wiki/Elemental_Ailment "Elemental Ailment") Take no Damage from [Volatility](/wiki/Volatility "Volatility") [[1]](/wiki/Passive_Skill:AscendancyMonk3Notable1 "Passive Skill:AscendancyMonk3Notable1") |
| [Invoker](/wiki/Invoker "Invoker") | [...and I Shall Rage](/wiki/...and_I_Shall_Rage "...and I Shall Rage") | Grants Skill: [Unbound Avatar](/wiki/Unbound_Avatar "Unbound Avatar") [[1]](/wiki/Passive_Skill:AscendancyMonk2Notable5 "Passive Skill:AscendancyMonk2Notable5") |
| [Smith of Kitava](/wiki/Smith_of_Kitava "Smith of Kitava") | [Heatproofing](/wiki/Heatproofing "Heatproofing") | Body Armour grants [Unaffected](/wiki/Unaffected "Unaffected") by [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") [[1]](/wiki/Passive_Skill:AscendancyWarrior3Notable6~12~ "Passive Skill:AscendancyWarrior3Notable6~12~") |
| [Tactician](/wiki/Tactician "Tactician") | [Polish That Gear](/wiki/Polish_That_Gear "Polish That Gear") | Gain [Deflection Rating](/wiki/Deflect "Deflect") equal to 20% of [Armour](/wiki/Armour "Armour") [Gain](/wiki/Gain "Gain") 100% of [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") as extra [Ailment Threshold](/wiki/Ailment_Threshold "Ailment Threshold") [[1]](/wiki/Passive_Skill:AscendancyMercenary1Notable6 "Passive Skill:AscendancyMercenary1Notable6") |
