# Equipment

Equipment

Tooltip

Equipment are items that can be [Equipped](/wiki/Equipped/edit?redlink=1 "Equipped (page does not exist)")

An example of the player's inventory screen with various equipment equipped.

**Equipment** refers to [items](/wiki/Item "Item") that can be placed directly into equipment slots on the [character](/wiki/Character "Character")'s inventory screen. These include [weapons](/wiki/Weapon "Weapon"), [off-hands](/wiki/Off-hand "Off-hand"), [armour](/wiki/Armour_(equipment) "Armour (equipment)"), and [jewellery](/wiki/Jewellery "Jewellery").

## Equipping items

Equipped

Tooltip

Weapon, Armour, Belt, and [Jewellery](/wiki/Jewellery "Jewellery") Items are Equipped to the character in the Inventory Panel. Flasks, Skill Gems, and Jewels are never considered to be Equipped.

An item is equipped when placed into a compatible equipment slot on the [character](/wiki/Character "Character")'s inventory screen and the item or slot is not disabled. To equip an item, the character must meet or exceed the level and/or [attribute](/wiki/Attribute "Attribute") requirements present on that item. If the character's level or attributes fall below the requirement at any point, the item will become disabled, causing the equipment slot to turn red, until the requirements are met again. Disabled items are no longer considered equipped, and any bonuses and effects granted by them (including from [runes](/wiki/Runes "Runes") and [Soul cores](/wiki/Soul_cores "Soul cores")) are also disabled. Certain items can also disable specific item slots instead, causing any item placed within them to be disabled.

If a character's weapon is empty or disabled (or both weapons if [dual wielding](/wiki/Dual_wielding "Dual wielding")), they are considered [unarmed](/wiki/Unarmed "Unarmed").

The term *equipped item* specifically only include weapons, off-hands, armour, and jewellery. Items like [flasks](/wiki/Flask "Flask") and [charms](/wiki/Charm "Charm") also have dedicated slots on the inventory screen, but are not technically considered equipped items. Socketable items are also not considered equipment.

### Restrictions

Equipment cannot be changed around while in a fight against a [boss](/wiki/Boss "Boss").

## Categories of equipment

### Weapons

Main article: [Weapon](/wiki/Weapon "Weapon")

**Weapons** are equipment used to perform [attacks](/wiki/Attack "Attack") or enhance [spells](/wiki/Spell "Spell"). Each weapon has a base damage value range, attacks per second, and base [critical hit](/wiki/Critical_hit "Critical hit") chance. [Quality](/wiki/Quality "Quality") improves a weapon's physical damage values or the skill the weapon grants.

Types of weapons:

* [Axes](/wiki/Axe "Axe")
* [Bows](/wiki/Bow "Bow")
* [Crossbows](/wiki/Crossbow "Crossbow")
* [Daggers](/wiki/Dagger "Dagger")
* [Flails](/wiki/Flail "Flail")
* [Maces](/wiki/Mace "Mace")
* [Quarterstaves](/wiki/Quarterstaff "Quarterstaff")
* [Sceptres](/wiki/Sceptre "Sceptre")
* [Spears](/wiki/Spear "Spear")
* [Staves](/wiki/Staff "Staff")
* [Swords](/wiki/Sword "Sword")
* [Talismans](/wiki/Talisman "Talisman")
* [Traps](/wiki/Trap "Trap")
* [Wands](/wiki/Wand "Wand")

### Off-hand equipment

Main article: [Off hand](/wiki/Off_hand "Off hand")

**Off-hand equipment** is a sub-category of equipment that is equipped in the off-hand slot (right weapon slot), typically alongside other one-handed weapons, to provide offensive or defensive benefits through [modifiers](/wiki/Modifiers "Modifiers").

* [Bucklers](/wiki/Buckler "Buckler")
* [Foci](/wiki/Focus "Focus")
* [Quivers](/wiki/Quiver "Quiver")
* [Shields](/wiki/Shield "Shield")

### Armour

Main article: [Armour (equipment)](/wiki/Armour_(equipment) "Armour (equipment)")

**Armour** is a category of equipment worn on different parts of the body to provide protection through their [defence](/wiki/Defence "Defence") values and bonuses from modifiers.

* [Body armours](/wiki/Body_armour "Body armour")
* [Boots](/wiki/Boots "Boots")
* [Gloves](/wiki/Gloves "Gloves")
* [Helmets](/wiki/Helmet "Helmet")

Shields and foci are considered both off-hands and armour.

* [Bucklers](/wiki/Buckler "Buckler")
* [Foci](/wiki/Focus "Focus")
* [Shields](/wiki/Shield "Shield")

### Jewellery

Main article: [Jewellery](/wiki/Jewellery "Jewellery")

Jewellery grant a variety of different bonuses from modifiers. All jewellery also have implicit modifiers that provide baseline bonuses. [Jewels](/wiki/Jewel "Jewel") are not considered jewellery as they are socketed, not equipped.

* [Amulets](/wiki/Amulet "Amulet")
* [Belts](/wiki/Belt "Belt")
* [Rings](/wiki/Ring "Ring")
