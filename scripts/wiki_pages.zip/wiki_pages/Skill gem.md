# Skill gem

Redirect to:

* [Gem#Skill gems](/wiki/Gem#Skill_gems "Gem")
