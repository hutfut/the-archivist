# Hideout

[File:Hideout example.jpg](/index.php?title=Special:Upload&wpDestFile=Hideout_example.jpg "File:Hideout example.jpg")

An example of a hideout.

**Hideouts** are special [town](/wiki/Town "Town")-like areas that act as a player's personal hub in the [Endgame](/wiki/Endgame "Endgame"). [NPCs](/wiki/NPC "NPC") can be invited to your hideout to perform the same functions they do in towns. Hideouts also contain a [Map Device](/wiki/Map_Device "Map Device") which becomes usable once the player reaches Endgame for the first time in a [league](/wiki/League "League"). Hideouts can be first unlocked in [Act 4](/wiki/Act_4 "Act 4") after completing [Singing Caverns](/wiki/Singing_Caverns "Singing Caverns").

Speaking to [Alva](/wiki/Alva "Alva") in the [Ziggurat Refuge](/wiki/Ziggurat_Refuge "Ziggurat Refuge") or in your hideout allows you to swap to a different hideout if you have more than one unlocked.

## Mechanics

[Monsters](/wiki/Monster "Monster") cannot appear in claimed hideouts. Unlike in [towns](/wiki/Town "Town"), it is possible to use your [skills](/wiki/Skill "Skill"). It is possible to visit other player's hideouts to play in a [party](/wiki/Party "Party") or to [trade](/wiki/Trade "Trade").

[Shoreline Hideout](/wiki/Shoreline_Hideout "Shoreline Hideout") can be unlocked by completing the [quest](/wiki/Quest "Quest") [Hostile Takeover](/wiki/Hostile_Takeover "Hostile Takeover") in [Act 4](/wiki/Act_4 "Act 4").

Map hideouts can be unlocked by completing the corresponding [map](/wiki/Map "Map") on the [Atlas](/wiki/Atlas "Atlas"). Microtransaction hideouts can be accessed earlier, but require a purchase from the [microtransaction](/wiki/Microtransaction "Microtransaction") store. Once any hideout is unlocked, it can be accessed by any of your [characters](/wiki/Character "Character") in that [league](/wiki/League "League") after first reaching [Clearfell Encampment](/wiki/Clearfell_Encampment "Clearfell Encampment") in [Act 1](/wiki/Act_1 "Act 1").

`/hideout` can be entered as a chat message to automatically teleport to your hideout while in any [town](/wiki/Town "Town") area.

## List of hideouts

### Story hideouts

* [Shoreline Hideout](/wiki/Shoreline_Hideout "Shoreline Hideout")

### Map hideouts

* [Canal Hideout](/wiki/Canal_Hideout "Canal Hideout")
* [Felled Hideout](/wiki/Felled_Hideout "Felled Hideout")
* [Limestone Hideout](/wiki/Limestone_Hideout "Limestone Hideout")
* [Shrine Hideout](/wiki/Shrine_Hideout "Shrine Hideout")

### Microtransaction hideouts

* [Beacon of Salvation Hideout](/wiki/Beacon_of_Salvation_Hideout/edit?redlink=1 "Beacon of Salvation Hideout (page does not exist)")
* [Monolith Hideout](/wiki/Monolith_Hideout/edit?redlink=1 "Monolith Hideout (page does not exist)")
* [Plateau of the Gods Hideout](/wiki/Plateau_of_the_Gods_Hideout/edit?redlink=1 "Plateau of the Gods Hideout (page does not exist)")
* [The Dreadnought Hideout](/wiki/The_Dreadnought_Hideout "The Dreadnought Hideout")
* [Twisted Hideout](/wiki/Twisted_Hideout "Twisted Hideout")
* [Vastiri Racecourse Hideout](/wiki/Vastiri_Racecourse_Hideout/edit?redlink=1 "Vastiri Racecourse Hideout (page does not exist)")
