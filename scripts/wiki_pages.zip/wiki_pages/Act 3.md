# Act 3

Example overworld map of Act 3 (present)

Example overworld map of Act 3 (present, lake drained)

Example overworld map of Act 3 (past)

Example underground map of Act 3

**Act Three** is [Path of Exile 2](/wiki/Path_of_Exile_2 "Path of Exile 2")'s third storyline [act](/wiki/Act "Act"), taking place in the present and past of Utzaal, the drowned [Vaal](/wiki/Vaal/edit?redlink=1 "Vaal (page does not exist)") city. The player must search for someone with knowledge of [the Beast](/wiki/The_Beast "The Beast") and how to stop it.

## Quests

* [Legacy of the Vaal](/wiki/Legacy_of_the_Vaal "Legacy of the Vaal")
* [Treasures of Utzaal](/wiki/Treasures_of_Utzaal "Treasures of Utzaal") (optional)
* [The Slithering Dead](/wiki/The_Slithering_Dead "The Slithering Dead") (optional)
* [Tribal Vengeance](/wiki/Tribal_Vengeance "Tribal Vengeance") (optional)
* [The Trials of Chaos](/wiki/The_Trials_of_Chaos "The Trials of Chaos") (optional)

## Progression

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  |  |  | ↓ |
|  |  |  |  | [Sandswept Marsh](/wiki/Sandswept_Marsh "Sandswept Marsh")   33  Boss: [Rootdredge](/wiki/Rootdredge "Rootdredge") |
|  |  |  |  | ↕ |  |
| [The Venom Crypts](/wiki/The_Venom_Crypts "The Venom Crypts")   34 | ↔ | [Jungle Ruins](/wiki/Jungle_Ruins "Jungle Ruins")   34  Boss: [Mighty Silverfist](/wiki/Mighty_Silverfist "Mighty Silverfist") | ↔ | [Ziggurat Encampment](/wiki/Ziggurat_Encampment "Ziggurat Encampment") | ↔ | [The Drowned City](/wiki/The_Drowned_City "The Drowned City")   40 | ↔ | [Apex of Filth](/wiki/Apex_of_Filth "Apex of Filth")   41  Boss: [The Queen of Filth](/wiki/The_Queen_of_Filth "The Queen of Filth") |
|  |  | ↕ |  | ↕ | ⤡ |  | ⤡ |
| [The Azak Bog](/wiki/The_Azak_Bog "The Azak Bog")   36  Boss: [Ignagduk, the Bog Witch](/wiki/Ignagduk,_the_Bog_Witch "Ignagduk, the Bog Witch") | ↔ | [Infested Barrens](/wiki/Infested_Barrens "Infested Barrens")   35 |  | [Ziggurat Encampment (Past)](/wiki/Ziggurat_Encampment_(Past) "Ziggurat Encampment (Past)") |  | [Temple of Kopec](/wiki/Temple_of_Kopec "Temple of Kopec")   42  Boss: [Ketzuli, High Priest of the Sun](/wiki/Ketzuli,_High_Priest_of_the_Sun "Ketzuli, High Priest of the Sun") |  | [The Molten Vault](/wiki/The_Molten_Vault "The Molten Vault")   41  Boss: [Mektul, the Forgemaster](/wiki/Mektul,_the_Forgemaster "Mektul, the Forgemaster") |
|  | ⤢ | ↕ |  | ↕ |  |
| [The Matlan Waterways](/wiki/The_Matlan_Waterways "The Matlan Waterways")   39 |  | [Chimeral Wetlands](/wiki/Chimeral_Wetlands "Chimeral Wetlands")   36  Boss: [Xyclucian, the Chimeral](/wiki/Xyclucian,_the_Chimeral "Xyclucian, the Chimeral") |  | [Utzaal](/wiki/Utzaal "Utzaal")   43  Boss: [Viper Napuatzi](/wiki/Viper_Napuatzi "Viper Napuatzi") |
|  | ⤢ | ↓ |  | ↕ |
| [The Temple of Chaos](/wiki/The_Temple_of_Chaos "The Temple of Chaos") [The Trial of Chaos](/wiki/The_Trial_of_Chaos "The Trial of Chaos") |  | [Jiquani's Machinarium](/wiki/Jiquani%27s_Machinarium "Jiquani's Machinarium")   37  Boss: [Blackjaw, the Remnant](/wiki/Blackjaw,_the_Remnant "Blackjaw, the Remnant") |  | [Aggorat](/wiki/Aggorat "Aggorat")   44 |  |
|  |  | ↕ |  | ↕ |
|  |  | [Jiquani's Sanctum](/wiki/Jiquani%27s_Sanctum "Jiquani's Sanctum")   38  Boss: [Zicoatl, Warden of the Core](/wiki/Zicoatl,_Warden_of_the_Core "Zicoatl, Warden of the Core") |  | [The Black Chambers](/wiki/The_Black_Chambers "The Black Chambers")   45  Act Boss: [Doryani, Royal Thaumaturge](/wiki/Doryani,_Royal_Thaumaturge "Doryani, Royal Thaumaturge") |
