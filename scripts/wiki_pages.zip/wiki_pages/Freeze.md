# Freeze

Freeze

Tooltip

Freeze is an [Ailment](/wiki/Ailment "Ailment") that causes targets to be unable to move or act, and lasts 4 seconds by default.

[Cold](/wiki/Cold_Damage "Cold Damage") damage from [Hits](/wiki/Hit "Hit") [Contributes](/wiki/Damage_Contributing_to_Ailments "Damage Contributing to Ailments") to Freeze Buildup on enemies until they become [Frozen](/wiki/Frozen "Frozen").

Frozen

Tooltip

A Frozen target cannot move or act. Targets become Frozen when they reach 100% Freeze buildup.

**Freeze** or **frozen** is a non-damaging [cold](/wiki/Cold "Cold") [ailment](/wiki/Ailment "Ailment") that causes targets to be unable to act by fully slowing their action speed and [immobilising](/wiki/Immobilise "Immobilise") them. Monsters killed while frozen will [shatter](/wiki/Shatter "Shatter"), leaving behind no corpse.

## Mechanics

Freeze reduces [action speed](/wiki/Action_speed "Action speed") to 0, preventing movement and usage of skills. The duration of freeze depends on the damage taken by the enemy after mitigation relative to the enemy's ailment threshold.

If a hit that can freeze fails to do so due to not reaching the minimum ailment threshold, it will instead add to a counter called **Freeze Buildup**. When freeze buildup reaches or exceeds 100%, it will apply a fixed duration freeze to the target, then reset the counter to 0%.

Each time a boss monster is frozen either directly or by accumulating freeze buildup, its ailment threshold against freeze increases. This value decreases over time to its base value.

Blocking a hit does not prevent it from applying freeze buildup.

## Related Skill gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Freezing Shards](/wiki/Freezing_Shards "Freezing Shards") | *0* |  |  |  |
| [Icestorm](/wiki/Icestorm "Icestorm") | *0* |  |  |  |
| [Moment of Vulnerability](/wiki/Moment_of_Vulnerability "Moment of Vulnerability") | *0* |  |  |  |
| [Pinnacle of Power](/wiki/Pinnacle_of_Power "Pinnacle of Power") | *0* |  |  |  |
| [Shattering Concoction](/wiki/Shattering_Concoction "Shattering Concoction") | *0* |  |  |  |
| [Time Freeze](/wiki/Time_Freeze "Time Freeze") | *0* |  |  |  |
| [Escape Shot](/wiki/Escape_Shot "Escape Shot") | *1* |  |  |  |
| [Ice Nova](/wiki/Ice_Nova "Ice Nova") | *1* |  |  |  |
| [Fragmentation Rounds](/wiki/Fragmentation_Rounds "Fragmentation Rounds") | *1* |  |  |  |
| [Glacial Cascade](/wiki/Glacial_Cascade "Glacial Cascade") | *1* |  |  |  |
| [Lunar Assault](/wiki/Lunar_Assault "Lunar Assault") | *1* |  |  |  |
| [Permafrost Bolts](/wiki/Permafrost_Bolts "Permafrost Bolts") | *1* |  |  |  |
| [Fangs of Frost](/wiki/Fangs_of_Frost "Fangs of Frost") | *3* |  |  |  |
| [Freezing Salvo](/wiki/Freezing_Salvo "Freezing Salvo") | *3* |  |  |  |
| [Snipe](/wiki/Snipe "Snipe") | *3* |  |  |  |
| [Frost Darts](/wiki/Frost_Darts "Frost Darts") | *3* |  |  |  |
| [Skeletal Frost Mage](/wiki/Skeletal_Frost_Mage "Skeletal Frost Mage") | *5* |  |  |  |
| [Arctic Howl](/wiki/Arctic_Howl "Arctic Howl") | *5* |  |  |  |
| [Thunderstorm](/wiki/Thunderstorm "Thunderstorm") | *5* |  |  |  |
| [Glacial Lance](/wiki/Glacial_Lance "Glacial Lance") | *7* |  |  |  |
| [Freezing Mark](/wiki/Freezing_Mark "Freezing Mark") | *7* |  |  |  |
| [Wave of Frost](/wiki/Wave_of_Frost "Wave of Frost") | *7* |  |  |  |
| [Ice Shot](/wiki/Ice_Shot "Ice Shot") | *9* |  |  |  |
| [Frost Wall](/wiki/Frost_Wall "Frost Wall") | *9* |  |  |  |
| [Elemental Sundering](/wiki/Elemental_Sundering "Elemental Sundering") | *11* |  |  |  |
| [Spear of Solaris](/wiki/Spear_of_Solaris "Spear of Solaris") | *13* |  |  |  |
| [Skeletal Brute](/wiki/Skeletal_Brute "Skeletal Brute") | *13* |  |  |  |

### Related Spirit and Meta Gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Arctic Armour](/wiki/Arctic_Armour "Arctic Armour") | *4* |  |  |  |
| [Combat Frenzy](/wiki/Combat_Frenzy "Combat Frenzy") | *8* |  |  |  |
| [Siphon Elements](/wiki/Siphon_Elements "Siphon Elements") | *8* |  |  |  |
| [Elemental Invocation](/wiki/Elemental_Invocation "Elemental Invocation") | *8* |  |  |  |
| [Shard Scavenger](/wiki/Shard_Scavenger "Shard Scavenger") | *8* |  |  |  |
| [Cast on Elemental Ailment](/wiki/Cast_on_Elemental_Ailment "Cast on Elemental Ailment") | *14* |  |  |  |

## Related Support Gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Tul's Stillness](/wiki/Tul%27s_Stillness "Tul's Stillness") | *0* |  |  |  |
| [Bhatair's Vengeance](/wiki/Bhatair%27s_Vengeance "Bhatair's Vengeance") | *0* |  |  |  |
| [Deep Freeze](/wiki/Deep_Freeze "Deep Freeze") | *1* |  |  |  |
| [Ice Bite I](/wiki/Ice_Bite_I "Ice Bite I") | *1* |  |  |  |
| [Freeze](/wiki/Freeze_(support_gem) "Freeze (support gem)") | *2* |  |  |  |
| [Frost Nexus](/wiki/Frost_Nexus "Frost Nexus") | *2* |  |  |  |
| [Warm Blooded](/wiki/Warm_Blooded "Warm Blooded") | *3* |  |  |  |
| [Biting Frost I](/wiki/Biting_Frost_I "Biting Frost I") | *3* |  |  |  |
| [Brittle Armour](/wiki/Brittle_Armour "Brittle Armour") | *3* |  |  |  |
| [Chaotic Freeze](/wiki/Chaotic_Freeze "Chaotic Freeze") | *3* |  |  |  |
| [Elemental Discharge](/wiki/Elemental_Discharge "Elemental Discharge") | *3* |  |  |  |
| [Frostfire](/wiki/Frostfire "Frostfire") | *3* |  |  |  |
| [Ice Bite II](/wiki/Ice_Bite_II "Ice Bite II") | *3* |  |  |  |
| [Biting Frost II](/wiki/Biting_Frost_II "Biting Frost II") | *5* |  |  |  |

## Related base items

| Item | Base item | Item class |  | Stats |
| --- | --- | --- | --- | --- |
| [Thawing Charm](/wiki/Thawing_Charm "Thawing Charm") | — | *[Charm](/wiki/Charm "Charm")* | 12 | Used when you become [Frozen](/wiki/Frozen "Frozen") |

## Unique Items

| Item | Base item | Item class |  | Stats |
| --- | --- | --- | --- | --- |
| [Against the Darkness](/wiki/Against_the_Darkness "Against the Darkness") | [Time-Lost Diamond](/wiki/Time-Lost_Diamond "Time-Lost Diamond") | *[Jewel](/wiki/Jewel "Jewel")* | 1 | | <2 random jewel modifiers> | | --- | | +(2-3)% to [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance")  ---  +(2-4)% to [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance")  ---  [Gain](/wiki/Gain "Gain") (2-4)% of Damage as Extra [Chaos](/wiki/Chaos "Chaos") Damage  ---  [Gain](/wiki/Gain "Gain") (2-4)% of Damage as Extra [Cold](/wiki/Cold "Cold") Damage  ---  [Gain](/wiki/Gain "Gain") (2-4)% of Damage as Extra [Fire](/wiki/Fire "Fire") Damage  ---  [Gain](/wiki/Gain "Gain") (2-4)% of Damage as Extra [Lightning](/wiki/Lightning "Lightning") Damage  ---  +(2-4)% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance")  ---  (4-6)% reduced Freeze Duration on you  ---  (4-6)% reduced [Ignite](/wiki/Ignite "Ignite") Duration on you  ---  +8 to maximum Life  ---  +8 to maximum Mana  ---  +(2-4)% to [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance")  ---  +1% to [Maximum Chaos Resistance](/wiki/Maximum_Chaos_Resistance/edit?redlink=1 "Maximum Chaos Resistance (page does not exist)")  ---  +1% to [Maximum Cold Resistance](/wiki/Maximum_Cold_Resistance "Maximum Cold Resistance")  ---  +1% to [Maximum Fire Resistance](/wiki/Maximum_Fire_Resistance "Maximum Fire Resistance")  ---  +1% to [Maximum Lightning Resistance](/wiki/Maximum_Lightning_Resistance "Maximum Lightning Resistance")  ---  (2-3)% increased [Dexterity](/wiki/Dexterity "Dexterity")  ---  (2-3)% increased [Intelligence](/wiki/Intelligence "Intelligence")  ---  (2-3)% increased [Strength](/wiki/Strength "Strength")  ---  (4-6)% reduced [Shock](/wiki/Shock "Shock") duration on you  ---  +(8-12) to [Spirit](/wiki/Spirit "Spirit") | |
| [Mist Whisper](/wiki/Mist_Whisper "Mist Whisper") | [Makeshift Crossbow](/wiki/Makeshift_Crossbow "Makeshift Crossbow") | *[Crossbow](/wiki/Crossbow "Crossbow")* | 1 | Adds (8-10) to (13-15) [Cold](/wiki/Cold "Cold") Damage Gain 5 Mana per enemy killed (30-50)% increased Freeze Buildup 30% increased [Chill](/wiki/Chill "Chill") Duration on Enemies [Attacks](/wiki/Attack "Attack") [Chain](/wiki/Chain "Chain") 2 additional times |
| [Winter's Bite](/wiki/Winter%27s_Bite "Winter's Bite") | [Glass Shank](/wiki/Glass_Shank "Glass Shank") | *[Dagger](/wiki/Dagger "Dagger")* | 1 | No [Physical](/wiki/Physical "Physical") Damage Adds (8-10) to (15-18) [Cold](/wiki/Cold "Cold") Damage Freezes Enemies that are on Full Life |
| [Taryn's Shiver](/wiki/Taryn%27s_Shiver "Taryn's Shiver") | [Gelid Staff](/wiki/Gelid_Staff "Gelid Staff") | *[Staff](/wiki/Staff "Staff")* | 2 | (80-120)% increased [Spell](/wiki/Spell "Spell") Damage (10-20)% increased Cast Speed 30% increased Freeze Buildup Enemies [Frozen](/wiki/Frozen "Frozen") by you take 100% increased Damage |
| [Frostbreath](/wiki/Frostbreath "Frostbreath") | [Slim Mace](/wiki/Slim_Mace "Slim Mace") | *[One Hand Mace](/wiki/One_Hand_Mace "One Hand Mace")* | 10 | Adds (8-12) to (16-20) [Physical](/wiki/Physical "Physical") Damage Adds (8-12) to (16-20) [Cold](/wiki/Cold "Cold") Damage +5% to [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance [All Damage](/wiki/Damage_type "Damage type") from [Hits](/wiki/Hit "Hit") with this Weapon [Contributes](/wiki/Contributes "Contributes") to Freeze Buildup [Culling Strike](/wiki/Culling_Strike "Culling Strike") against [Frozen](/wiki/Frozen "Frozen") Enemies |
| [Grip of Winter](/wiki/Grip_of_Winter "Grip of Winter") | [Firm Bracers](/wiki/Firm_Bracers "Firm Bracers") | *[Gloves](/wiki/Gloves "Gloves")* | 11 | (30-50)% increased [Evasion](/wiki/Evasion "Evasion") Rating Adds (3-5) to (6-8) [Cold](/wiki/Cold "Cold") damage to [Attacks](/wiki/Attack "Attack") +(20-30)% to [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance") (40-50)% increased Freeze Buildup (20-30)% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Chill](/wiki/Chill "Chill") you inflict |
| [Dream Fragments](/wiki/Dream_Fragments "Dream Fragments") | [Sapphire Ring](/wiki/Sapphire_Ring "Sapphire Ring") | *[Ring](/wiki/Ring "Ring")* | 12 | +(20-30)% to [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance")(10-15)% increased maximum Mana (30-50)% increased Mana Regeneration Rate You cannot be [Chilled](/wiki/Chill "Chill") or [Frozen](/wiki/Frozen "Frozen") |
| [Nascent Hope](/wiki/Nascent_Hope "Nascent Hope") | [Thawing Charm](/wiki/Thawing_Charm "Thawing Charm") | *[Charm](/wiki/Charm "Charm")* | 12 | Used when you become [Frozen](/wiki/Frozen "Frozen")(20-25)% Chance to gain a [Charge](/wiki/Charge "Charge") when you kill an enemy [Energy Shield Recharge](/wiki/Energy_Shield_Recharge "Energy Shield Recharge") starts on use |
| [Polcirkeln](/wiki/Polcirkeln "Polcirkeln") | [Sapphire Ring](/wiki/Sapphire_Ring "Sapphire Ring") | *[Ring](/wiki/Ring "Ring")* | 12 | +(20-30)% to [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance")(20-30)% increased [Cold](/wiki/Cold "Cold") Damage +(40-60) to maximum Mana +(10-15) to [Strength](/wiki/Strength "Strength") Enemies [Chilled](/wiki/Chill "Chill") by your [Hits](/wiki/Hit "Hit") can be [Shattered](/wiki/Shatter "Shatter") as though [Frozen](/wiki/Frozen "Frozen") |
| [Shackles of the Wretched](/wiki/Shackles_of_the_Wretched "Shackles of the Wretched") | [Aged Cuffs](/wiki/Aged_Cuffs "Aged Cuffs") | *[Gloves](/wiki/Gloves "Gloves")* | 16 | (30-50)% increased [Armour](/wiki/Armour "Armour") and [Energy Shield](/wiki/Energy_Shield "Energy Shield") You cannot be [Chilled](/wiki/Chill "Chill") for 6 seconds after being [Chilled](/wiki/Chill "Chill") You cannot be [Frozen](/wiki/Frozen "Frozen") for 6 seconds after being [Frozen](/wiki/Frozen "Frozen") You cannot be [Ignited](/wiki/Ignite "Ignite") for 6 seconds after being [Ignited](/wiki/Ignite "Ignite") You cannot be [Shocked](/wiki/Shock "Shock") for 6 seconds after being [Shocked](/wiki/Shock "Shock") [Curses](/wiki/Curse "Curse") you inflict are reflected back to you |
| [Kaltenhalt](/wiki/Kaltenhalt "Kaltenhalt") | [Ridged Buckler](/wiki/Ridged_Buckler "Ridged Buckler") | *[Buckler](/wiki/Buckler "Buckler")* | 22 | (80-120)% increased [Evasion](/wiki/Evasion "Evasion") Rating +5% to [Maximum Cold Resistance](/wiki/Maximum_Cold_Resistance "Maximum Cold Resistance") +(-40-40)% to [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance") Modifiers to [Stun](/wiki/Stun "Stun") Buildup apply to Freeze Buildup instead for Parry 100% of Parry [Physical](/wiki/Physical "Physical") Damage Converted to [Cold](/wiki/Cold "Cold") Damage 25 to 35 [Cold](/wiki/Cold "Cold") [Thorns](/wiki/Thorns "Thorns") damage |
| [Call of the Brotherhood](/wiki/Call_of_the_Brotherhood "Call of the Brotherhood") | [Topaz Ring](/wiki/Topaz_Ring "Topaz Ring") | *[Ring](/wiki/Ring "Ring")* | 32 | +(20-30)% to [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance")+(10-20) to [Intelligence](/wiki/Intelligence "Intelligence") (25-35)% increased Mana Regeneration Rate (20-30)% increased Freeze Buildup 100% of [Lightning](/wiki/Lightning "Lightning") Damage [Converted](/wiki/Damage_conversion "Damage conversion") to [Cold](/wiki/Cold "Cold") Damage |
| [Obern's Bastion](/wiki/Obern%27s_Bastion "Obern's Bastion") | [Stacked Sabatons](/wiki/Stacked_Sabatons "Stacked Sabatons") | *[Boots](/wiki/Boots "Boots")* | 33 | (150-200)% increased [Armour](/wiki/Armour "Armour") and [Evasion](/wiki/Evasion "Evasion") (20-25) Life Regeneration per second 200% increased [Stun Recovery](/wiki/Stun_Recovery/edit?redlink=1 "Stun Recovery (page does not exist)") (30-50)% reduced [Chill](/wiki/Chill "Chill") Duration on you (30-50)% reduced Freeze Duration on you (30-50)% reduced [Shock](/wiki/Shock "Shock") duration on you |
| [The Three Dragons](/wiki/The_Three_Dragons "The Three Dragons") | [Solid Mask](/wiki/Solid_Mask "Solid Mask") | *[Helmet](/wiki/Helmet "Helmet")* | 45 | (40-60)% increased [Evasion](/wiki/Evasion "Evasion") and [Energy Shield](/wiki/Energy_Shield "Energy Shield") +(10-20)% to all [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") [Fire](/wiki/Fire "Fire") Damage from [Hits](/wiki/Hit "Hit") [Contributes](/wiki/Contributes "Contributes") to [Shock](/wiki/Shock "Shock") Chance instead of [Flammability](/wiki/Flammability "Flammability") and [Ignite](/wiki/Ignite "Ignite") [Magnitudes](/wiki/Magnitude "Magnitude") [Cold](/wiki/Cold "Cold") Damage from [Hits](/wiki/Hit "Hit") [Contributes](/wiki/Contributes "Contributes") to [Flammability](/wiki/Flammability "Flammability") and [Ignite](/wiki/Ignite "Ignite") [Magnitudes](/wiki/Magnitude "Magnitude") instead of [Chill](/wiki/Chill "Chill") Magnitude or Freeze Buildup [Lightning](/wiki/Lightning "Lightning") Damage from [Hits](/wiki/Hit "Hit") [Contributes](/wiki/Contributes "Contributes") to Freeze Buildup instead of [Shock](/wiki/Shock "Shock") Chance |
| [Beyond Reach](/wiki/Beyond_Reach "Beyond Reach") | [Visceral Quiver](/wiki/Visceral_Quiver "Visceral Quiver") | *[Quiver](/wiki/Quiver "Quiver")* | 65 | (20-30)% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for [Attacks](/wiki/Attack "Attack")(15-10)% reduced [Attack](/wiki/Attack "Attack") Speed [Chaos](/wiki/Chaos "Chaos") Damage from [Hits](/wiki/Hit "Hit") also [Contributes](/wiki/Contributes "Contributes") to Freeze Buildup [Chaos](/wiki/Chaos "Chaos") Damage from [Hits](/wiki/Hit "Hit") also [Contributes](/wiki/Contributes "Contributes") to [Electrocute](/wiki/Electrocute "Electrocute") Buildup [Attacks](/wiki/Attack "Attack") [Gain](/wiki/Gain "Gain") (10-20)% of [Physical](/wiki/Physical "Physical") Damage as extra [Chaos](/wiki/Chaos "Chaos") Damage |
| [Guiding Palm of the Eye](/wiki/Guiding_Palm_of_the_Eye "Guiding Palm of the Eye") | [Shrine Sceptre](/wiki/Shrine_Sceptre_(Cold) "Shrine Sceptre (Cold)") | *[Sceptre](/wiki/Sceptre "Sceptre")* | 65 | [Gain](/wiki/Gain "Gain") 25% of Damage as Extra [Cold](/wiki/Cold "Cold") Damage [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") deal (15-23) to (28-35) added [Attack](/wiki/Attack "Attack") [Cold](/wiki/Cold "Cold") Damage 50% of your Base Life Regeneration is granted to [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") +(20-30) to [Intelligence](/wiki/Intelligence "Intelligence") 25% increased [Light Radius](/wiki/Light_Radius "Light Radius") Grants effect of [Guided Freezing Shrine](/wiki/Guided_Freezing_Shrine "Guided Freezing Shrine") |
| [Hyrri's Ire](/wiki/Hyrri%27s_Ire "Hyrri's Ire") | [Armoured Vest](/wiki/Armoured_Vest "Armoured Vest") | *[Body Armour](/wiki/Body_Armour "Body Armour")* | 73 | (30-40)% increased [Elemental Ailment Threshold](/wiki/Ailment "Ailment")(200-250)% increased [Evasion](/wiki/Evasion "Evasion") Rating [Gain](/wiki/Gain "Gain") (15-25)% of Damage as Extra [Cold](/wiki/Cold "Cold") Damage +(30-40) to [Dexterity](/wiki/Dexterity "Dexterity") 25% increased Freeze Duration on Enemies [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") is doubled if you have not been [Hit](/wiki/Hit "Hit") [Recently](/wiki/Recently "Recently") |
| [The Unborn Lich](/wiki/The_Unborn_Lich "The Unborn Lich") | [Ravenous Staff](/wiki/Ravenous_Staff "Ravenous Staff") | *[Staff](/wiki/Staff "Staff")* | 78 | (60-80)% increased [Desecrated Modifier](/wiki/Desecrated_modifier "Desecrated modifier") magnitudes <Custom Desecrated prefix> <Lich's Desecrated prefix> <Lich's Desecrated suffix> <Lich's Desecrated prefix or suffix>   | <List of mods> | | --- | | (86-99)% increased [Fire](/wiki/Fire "Fire") Damage (14-23)% increased [Ignite](/wiki/Ignite "Ignite") [Magnitude](/wiki/Magnitude "Magnitude")  ---  (25-40)% chance to build an additional [Combo](/wiki/Combo "Combo") on [Hit](/wiki/Hit "Hit")  ---  (86-99)% increased [Cold](/wiki/Cold "Cold") Damage (14-23)% increased Freeze Buildup  ---  Recover (4-6)% of Maximum Mana when you expend at least 10 [Combo](/wiki/Combo "Combo")  ---  (86-99)% increased [Lightning](/wiki/Lightning "Lightning") Damage (14-23)% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Shock](/wiki/Shock "Shock") you inflict  ---  Recover (6-12)% of Maximum Life when you expend at least 10 [Combo](/wiki/Combo "Combo")  ---  +(35-50) to [Spirit](/wiki/Spirit "Spirit")  ---  (148-178)% increased [Spell](/wiki/Spell "Spell") Damage with [Spells](/wiki/Spell "Spell") that cost Life  ---  (25-35)% increased [Archon](/wiki/Archon "Archon") Buff duration  ---  +(12-16)% to [Block](/wiki/Block "Block") chance  ---  (25-35)% of [Spell](/wiki/Spell "Spell") Mana Cost [Converted](/wiki/Stat_conversion "Stat conversion") to Life Cost  ---  +(1-2) to maximum number of [Elemental Infusions](/wiki/Elemental_Infusion "Elemental Infusion")  ---  (4-5)% increased [Spell](/wiki/Spell "Spell") Damage per 100 maximum Mana  ---  [Archon](/wiki/Archon "Archon") recovery period expires (25-35)% faster  ---  (26-36)% increased Cast Speed while on Full Mana  ---  (40-64)% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") you inflict  ---  (4-5)% increased [Spell](/wiki/Spell "Spell") Damage per 100 Maximum Life  ---  (30-40)% increased Cast Speed when on [Low Life](/wiki/Low_Life "Low Life")  ---  (25-35)% chance for [Spell](/wiki/Spell "Spell") Skills to fire 2 additional [Projectiles](/wiki/Projectile "Projectile")  ---  (100-160)% increased [Chaos](/wiki/Chaos "Chaos") Damage Enemies you kill have a (5-10)% chance to explode, dealing a quarter of their maximum Life as [Chaos](/wiki/Chaos "Chaos") damage  ---  (100-160)% increased [Chaos](/wiki/Chaos "Chaos") Damage Enemies you [Curse](/wiki/Curse "Curse") have -(8-5)% to Chaos [Resistance](/wiki/Resistance "Resistance")  ---  (100-160)% increased [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") (10-20)% increased Duration of Elemental [Ailments](/wiki/Ailments "Ailments") on Enemies  ---  (100-160)% increased [Spell](/wiki/Spell "Spell") [Physical](/wiki/Physical "Physical") Damage (20-30)% chance to inflict [Bleeding](/wiki/Bleeding "Bleeding") on [Hit](/wiki/Hit "Hit")  ---  +(40-60) to [Spirit](/wiki/Spirit "Spirit") (6-10)% increased [Spirit](/wiki/Spirit "Spirit") [Reservation](/wiki/Reservation "Reservation") [Efficiency](/wiki/Efficiency "Efficiency") of Skills  ---  You have [Unholy Might](/wiki/Unholy_Might "Unholy Might") (28-56)% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Unholy Might](/wiki/Unholy_Might "Unholy Might") buffs you grant | |

## Related passive skills

The following [passive skills](/wiki/Passive_skill "Passive skill") are related to freeze:

### Freeze buildup

| Name | Stats |
| --- | --- |
| [Attack Cold Damage and Freeze Buildup](/wiki/Attack_Cold_Damage_and_Freeze_Buildup/edit?redlink=1 "Attack Cold Damage and Freeze Buildup (page does not exist)") | 8% increased [Attack](/wiki/Attack "Attack") Cold Damage 8% increased Freeze Buildup [[1]](/wiki/Passive_Skill:Cold41 "Passive Skill:Cold41") [[2]](/wiki/Passive_Skill:Cold42~ "Passive Skill:Cold42~") |
| [Elemental Ailment Chance](/wiki/Elemental_Ailment_Chance/edit?redlink=1 "Elemental Ailment Chance (page does not exist)") | 12% increased chance to [Shock](/wiki/Shock "Shock") 12% increased Freeze Buildup 24% increased [Flammability](/wiki/Flammability "Flammability") [Magnitude](/wiki/Magnitude "Magnitude") [[1]](/wiki/Passive_Skill:Elemental51 "Passive Skill:Elemental51") [[2]](/wiki/Passive_Skill:Elemental52 "Passive Skill:Elemental52")  ---  10% increased chance to [Shock](/wiki/Shock "Shock") 10% increased Freeze Buildup 20% increased [Flammability](/wiki/Flammability "Flammability") [Magnitude](/wiki/Magnitude "Magnitude") [[3]](/wiki/Passive_Skill:Fire3 "Passive Skill:Fire3") [[4]](/wiki/Passive_Skill:Sorcerer~start1 "Passive Skill:Sorcerer~start1") |
| [Elemental Damage and Freeze Buildup](/wiki/Elemental_Damage_and_Freeze_Buildup/edit?redlink=1 "Elemental Damage and Freeze Buildup (page does not exist)") | 8% increased [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") 10% increased Freeze Buildup [[1]](/wiki/Passive_Skill:Elemental16 "Passive Skill:Elemental16") [[2]](/wiki/Passive_Skill:Elemental26 "Passive Skill:Elemental26") [[3]](/wiki/Passive_Skill:Elemental27 "Passive Skill:Elemental27") |
| [Empowered Attack Freeze Buildup](/wiki/Empowered_Attack_Freeze_Buildup/edit?redlink=1 "Empowered Attack Freeze Buildup (page does not exist)") | 20% increased Freeze Buildup with [Empowered](/wiki/Empowered "Empowered") [Attacks](/wiki/Attack "Attack") [[1]](/wiki/Passive_Skill:Cold49 "Passive Skill:Cold49") [[2]](/wiki/Passive_Skill:Cold50 "Passive Skill:Cold50") |
| [Freeze Buildup](/wiki/Freeze_Buildup/edit?redlink=1 "Freeze Buildup (page does not exist)") | 15% increased Freeze Buildup [[1]](/wiki/Passive_Skill:Chill~and~freeze1 "Passive Skill:Chill~and~freeze1") [[2]](/wiki/Passive_Skill:Chill~and~freeze13 "Passive Skill:Chill~and~freeze13") [[3]](/wiki/Passive_Skill:Chill~and~freeze19~ "Passive Skill:Chill~and~freeze19~") [[4]](/wiki/Passive_Skill:Chill~and~freeze2 "Passive Skill:Chill~and~freeze2") [[5]](/wiki/Passive_Skill:Chill~and~freeze20 "Passive Skill:Chill~and~freeze20") [[6]](/wiki/Passive_Skill:Chill~and~freeze23 "Passive Skill:Chill~and~freeze23") [[7]](/wiki/Passive_Skill:Chill~and~freeze27 "Passive Skill:Chill~and~freeze27") [[8]](/wiki/Passive_Skill:Chill~and~freeze28 "Passive Skill:Chill~and~freeze28") [[9]](/wiki/Passive_Skill:Chill~and~freeze3 "Passive Skill:Chill~and~freeze3") [[10]](/wiki/Passive_Skill:Chill~and~freeze5 "Passive Skill:Chill~and~freeze5") [[11]](/wiki/Passive_Skill:Chill~and~freeze6 "Passive Skill:Chill~and~freeze6") [[12]](/wiki/Passive_Skill:Chill~and~freeze7 "Passive Skill:Chill~and~freeze7") [[13]](/wiki/Passive_Skill:Cold10 "Passive Skill:Cold10") [[14]](/wiki/Passive_Skill:Cold28 "Passive Skill:Cold28") [[15]](/wiki/Passive_Skill:Cold29 "Passive Skill:Cold29") [[16]](/wiki/Passive_Skill:Cold46 "Passive Skill:Cold46") [[17]](/wiki/Passive_Skill:Cold47 "Passive Skill:Cold47")  ---  20% increased Freeze Buildup [[2]](/wiki/Passive_Skill:Chill~and~freeze17 "Passive Skill:Chill~and~freeze17") |
| [Freeze Buildup and Cold Damage](/wiki/Freeze_Buildup_and_Cold_Damage/edit?redlink=1 "Freeze Buildup and Cold Damage (page does not exist)") | 8% increased Freeze Buildup 8% increased [Cold](/wiki/Cold "Cold") Damage [[1]](/wiki/Passive_Skill:Daze~15 "Passive Skill:Daze~15") [[2]](/wiki/Passive_Skill:Daze~16 "Passive Skill:Daze~16") |
| [Freeze Buildup and Skill Effect Duration](/wiki/Freeze_Buildup_and_Skill_Effect_Duration/edit?redlink=1 "Freeze Buildup and Skill Effect Duration (page does not exist)") | 10% increased Freeze Buildup 6% increased Skill Effect Duration [[1]](/wiki/Passive_Skill:Chill~and~freeze26 "Passive Skill:Chill~and~freeze26") |
| [Quarterstaff Freeze and Daze Buildup](/wiki/Quarterstaff_Freeze_and_Daze_Buildup/edit?redlink=1 "Quarterstaff Freeze and Daze Buildup (page does not exist)") | 20% increased Freeze Buildup with [Quarterstaves](/wiki/Quarterstaves "Quarterstaves") 5% chance to [Daze](/wiki/Daze "Daze") on [Hit](/wiki/Hit "Hit") [[1]](/wiki/Passive_Skill:Quarterstaff15 "Passive Skill:Quarterstaff15") [[2]](/wiki/Passive_Skill:Quarterstaff6 "Passive Skill:Quarterstaff6") |
| [Stun and Freeze Buildup](/wiki/Stun_and_Freeze_Buildup/edit?redlink=1 "Stun and Freeze Buildup (page does not exist)") | 15% increased [Stun](/wiki/Stun "Stun") Buildup 15% increased Freeze Buildup [[1]](/wiki/Passive_Skill:Poise3 "Passive Skill:Poise3") [[2]](/wiki/Passive_Skill:Poise4 "Passive Skill:Poise4") [[3]](/wiki/Passive_Skill:Poise5 "Passive Skill:Poise5") [[4]](/wiki/Passive_Skill:Poise6 "Passive Skill:Poise6") [[5]](/wiki/Passive_Skill:Poise7 "Passive Skill:Poise7") |
| [Affliction Enforcer](/wiki/Affliction_Enforcer/edit?redlink=1 "Affliction Enforcer (page does not exist)") | 20% increased chance to [Shock](/wiki/Shock "Shock") 20% increased Freeze Buildup 40% increased [Flammability](/wiki/Flammability "Flammability") [Magnitude](/wiki/Magnitude "Magnitude") [[1]](/wiki/Passive_Skill:Fire32 "Passive Skill:Fire32") |
| [Climate Change](/wiki/Climate_Change/edit?redlink=1 "Climate Change (page does not exist)") | [Gain](/wiki/Gain "Gain") 25% of [Cold](/wiki/Cold "Cold") Damage as Extra [Fire](/wiki/Fire "Fire") Damage against Frozen Enemies 20% increased Freeze Buildup [[1]](/wiki/Passive_Skill:Cold36 "Passive Skill:Cold36") |
| [Cold Coat](/wiki/Cold_Coat/edit?redlink=1 "Cold Coat (page does not exist)") | 25% reduced Freeze Duration on you 25% increased [Freeze Threshold](/wiki/Freeze_Threshold/edit?redlink=1 "Freeze Threshold (page does not exist)") 25% increased Freeze Buildup [[1]](/wiki/Passive_Skill:Chill~and~freeze25 "Passive Skill:Chill~and~freeze25") |
| [Deep Freeze](/wiki/Deep_Freeze "Deep Freeze") | 20% increased Freeze Buildup Enemies Frozen by you have -8% to Cold Resistance [[1]](/wiki/Passive_Skill:Cold48 "Passive Skill:Cold48") |
| [Emboldened Avatar](/wiki/Emboldened_Avatar/edit?redlink=1 "Emboldened Avatar (page does not exist)") | 25% increased chance to [Shock](/wiki/Shock "Shock") 50% increased [Flammability](/wiki/Flammability "Flammability") [Magnitude](/wiki/Magnitude "Magnitude") 25% increased Freeze Buildup 25% increased [Electrocute Buildup](/wiki/Electrocute "Electrocute") [[1]](/wiki/Passive_Skill:Elemental~attacks11 "Passive Skill:Elemental~attacks11") |
| [Essence of the Mountain](/wiki/Essence_of_the_Mountain/edit?redlink=1 "Essence of the Mountain (page does not exist)") | [Gain](/wiki/Gain "Gain") 5% of Damage as Extra [Cold](/wiki/Cold "Cold") Damage 20% increased Freeze Buildup [[1]](/wiki/Passive_Skill:Cold39~~ "Passive Skill:Cold39~~") |
| [Heavy Frost](/wiki/Heavy_Frost "Heavy Frost") | [Hits](/wiki/Hit "Hit") ignore non-negative [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") of [Frozen](/wiki/Frozen "Frozen") Enemies 20% increased Freeze Buildup [[1]](/wiki/Passive_Skill:Cold33 "Passive Skill:Cold33") |
| [Inescapable Cold](/wiki/Inescapable_Cold/edit?redlink=1 "Inescapable Cold (page does not exist)") | 40% increased Freeze Buildup 20% increased Freeze Duration on Enemies [[1]](/wiki/Passive_Skill:Chill~and~freeze4 "Passive Skill:Chill~and~freeze4") |
| [One with the River](/wiki/One_with_the_River/edit?redlink=1 "One with the River (page does not exist)") | 30% increased [Defences](/wiki/Defences "Defences") while wielding a [Quarterstaff](/wiki/Quarterstaff "Quarterstaff") 30% increased [Stun](/wiki/Stun "Stun") Buildup with [Quarterstaves](/wiki/Quarterstaves "Quarterstaves") 30% increased Freeze Buildup with [Quarterstaves](/wiki/Quarterstaves "Quarterstaves") 10% chance to [Daze](/wiki/Daze "Daze") on [Hit](/wiki/Hit "Hit") [[1]](/wiki/Passive_Skill:Quarterstaff4 "Passive Skill:Quarterstaff4") |
| [Perpetual Freeze](/wiki/Perpetual_Freeze/edit?redlink=1 "Perpetual Freeze (page does not exist)") | 15% increased [Chill](/wiki/Chill "Chill") and Freeze Duration on Enemies 20% increased Freeze Buildup 15% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Chill](/wiki/Chill "Chill") you inflict [[1]](/wiki/Passive_Skill:Chill~and~freeze18 "Passive Skill:Chill~and~freeze18") |
| [Pressure Points](/wiki/Pressure_Points/edit?redlink=1 "Pressure Points (page does not exist)") | 35% increased [Stun](/wiki/Stun "Stun") Buildup 35% increased Freeze Buildup [[1]](/wiki/Passive_Skill:Poise39 "Passive Skill:Poise39") |
| [Shattering](/wiki/Shattering/edit?redlink=1 "Shattering (page does not exist)") | 20% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Chill](/wiki/Chill "Chill") you inflict 20% increased [Chill](/wiki/Chill "Chill") Duration on Enemies 30% increased Freeze Buildup [[1]](/wiki/Passive_Skill:Chill~and~freeze8 "Passive Skill:Chill~and~freeze8") |
| [Thin Ice](/wiki/Thin_Ice/edit?redlink=1 "Thin Ice (page does not exist)") | 50% increased Damage with Hits against [Frozen](/wiki/Frozen "Frozen") Enemies 20% increased Freeze Buildup [[1]](/wiki/Passive_Skill:Cold32 "Passive Skill:Cold32") |

### Freeze duration

| Name | Stats |
| --- | --- |
| [Biting Frost](/wiki/Biting_Frost "Biting Frost") | 20% reduced Freeze Duration on Enemies Enemies [Frozen](/wiki/Frozen "Frozen") by you take 20% increased [Cold](/wiki/Cold "Cold") Damage [[1]](/wiki/Passive_Skill:Cold43 "Passive Skill:Cold43") |
| [Inescapable Cold](/wiki/Inescapable_Cold/edit?redlink=1 "Inescapable Cold (page does not exist)") | 40% increased Freeze Buildup 20% increased Freeze Duration on Enemies [[1]](/wiki/Passive_Skill:Chill~and~freeze4 "Passive Skill:Chill~and~freeze4") |
| [Perpetual Freeze](/wiki/Perpetual_Freeze/edit?redlink=1 "Perpetual Freeze (page does not exist)") | 15% increased [Chill](/wiki/Chill "Chill") and Freeze Duration on Enemies 20% increased Freeze Buildup 15% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Chill](/wiki/Chill "Chill") you inflict [[1]](/wiki/Passive_Skill:Chill~and~freeze18 "Passive Skill:Chill~and~freeze18") |

### Freeze mitigation

| Name | Stats |
| --- | --- |
| [Freeze and Chill Resistance](/wiki/Freeze_and_Chill_Resistance/edit?redlink=1 "Freeze and Chill Resistance (page does not exist)") | 10% increased [Freeze Threshold](/wiki/Freeze_Threshold/edit?redlink=1 "Freeze Threshold (page does not exist)") 5% reduced Effect of [Chill](/wiki/Chill "Chill") on you [[1]](/wiki/Passive_Skill:Freeze~and~chill~mitigation1 "Passive Skill:Freeze~and~chill~mitigation1") [[2]](/wiki/Passive_Skill:Freeze~and~chill~mitigation2 "Passive Skill:Freeze~and~chill~mitigation2") [[3]](/wiki/Passive_Skill:Freeze~and~chill~mitigation4 "Passive Skill:Freeze~and~chill~mitigation4") |
| [Freeze Threshold](/wiki/Freeze_Threshold/edit?redlink=1 "Freeze Threshold (page does not exist)") | 15% increased [Freeze Threshold](/wiki/Freeze_Threshold/edit?redlink=1 "Freeze Threshold (page does not exist)") [[1]](/wiki/Passive_Skill:Chill~and~freeze21 "Passive Skill:Chill~and~freeze21") [[2]](/wiki/Passive_Skill:Chill~and~freeze22 "Passive Skill:Chill~and~freeze22") |
| [Chillproof](/wiki/Chillproof/edit?redlink=1 "Chillproof (page does not exist)") | +30% of [Armour](/wiki/Armour "Armour") also applies to [Cold Damage](/wiki/Cold_Damage "Cold Damage") 30% reduced Effect of [Chill](/wiki/Chill "Chill") on you 30% increased [Freeze Threshold](/wiki/Freeze_Threshold/edit?redlink=1 "Freeze Threshold (page does not exist)") [[1]](/wiki/Passive_Skill:Armour41 "Passive Skill:Armour41") |
| [Cold Coat](/wiki/Cold_Coat/edit?redlink=1 "Cold Coat (page does not exist)") | 25% reduced Freeze Duration on you 25% increased [Freeze Threshold](/wiki/Freeze_Threshold/edit?redlink=1 "Freeze Threshold (page does not exist)") 25% increased Freeze Buildup [[1]](/wiki/Passive_Skill:Chill~and~freeze25 "Passive Skill:Chill~and~freeze25") |
| [Warm the Heart](/wiki/Warm_the_Heart/edit?redlink=1 "Warm the Heart (page does not exist)") | 60% increased [Freeze Threshold](/wiki/Freeze_Threshold/edit?redlink=1 "Freeze Threshold (page does not exist)") 25% reduced Freeze Duration on you [[1]](/wiki/Passive_Skill:Spell~suppression24 "Passive Skill:Spell~suppression24") |

### Miscellany

| Name | Stats |
| --- | --- |
| [Energy Shield as Freeze Threshold](/wiki/Energy_Shield_as_Freeze_Threshold/edit?redlink=1 "Energy Shield as Freeze Threshold (page does not exist)") | Gain 15% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") as additional [Freeze Threshold](/wiki/Freeze_Threshold/edit?redlink=1 "Freeze Threshold (page does not exist)") [[1]](/wiki/Passive_Skill:Cold23 "Passive Skill:Cold23") [[2]](/wiki/Passive_Skill:Cold24 "Passive Skill:Cold24") [[3]](/wiki/Passive_Skill:Cold25 "Passive Skill:Cold25") |
| [Biting Frost](/wiki/Biting_Frost "Biting Frost") | 20% reduced Freeze Duration on Enemies Enemies [Frozen](/wiki/Frozen "Frozen") by you take 20% increased [Cold](/wiki/Cold "Cold") Damage [[1]](/wiki/Passive_Skill:Cold43 "Passive Skill:Cold43") |
| [Deep Freeze](/wiki/Deep_Freeze "Deep Freeze") | 20% increased Freeze Buildup Enemies Frozen by you have -8% to Cold Resistance [[1]](/wiki/Passive_Skill:Cold48 "Passive Skill:Cold48") |
| [Embodiment of Frost](/wiki/Embodiment_of_Frost/edit?redlink=1 "Embodiment of Frost (page does not exist)") | Immune to Freeze and [Chill](/wiki/Chill "Chill") while affected by an [Archon](/wiki/Archon "Archon") [Buff](/wiki/Buff "Buff") [[1]](/wiki/Passive_Skill:Cold22 "Passive Skill:Cold22") |
| [Icebreaker](/wiki/Icebreaker "Icebreaker") | Gain 50% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") as additional [Freeze Threshold](/wiki/Freeze_Threshold/edit?redlink=1 "Freeze Threshold (page does not exist)") [[1]](/wiki/Passive_Skill:Freeze~and~chill~mitigation12 "Passive Skill:Freeze~and~chill~mitigation12") |

### Ascendancy passive skills

The following [Ascendancy passive skills](/wiki/Ascendancy_passive_skill "Ascendancy passive skill") are related to freeze:

| Ascendancy Class | Name | Stats |
| --- | --- | --- |
| [Invoker](/wiki/Invoker "Invoker") | [I am the Blizzard...](/wiki/I_am_the_Blizzard... "I am the Blizzard...") | On [Freezing](/wiki/Freezing "Freezing") Enemies create [Chilled Ground](/wiki/Chilled_Ground "Chilled Ground") [Gain](/wiki/Gain "Gain") 10% of Damage as Extra [Cold](/wiki/Cold "Cold") Damage [[1]](/wiki/Passive_Skill:AscendancyMonk2Notable4 "Passive Skill:AscendancyMonk2Notable4") |
