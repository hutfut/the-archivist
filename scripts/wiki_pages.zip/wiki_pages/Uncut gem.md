# Uncut gem

**Uncut Gems** are a category of [currency items](/wiki/Currency_items "Currency items") and some [quest items](/wiki/Quest_item "Quest item") that can be used to [engrave](/wiki/Engrave "Engrave") a [skill gem](/wiki/Skill_gem "Skill gem") or [support gem](/wiki/Support_gem "Support gem"), or level up a current skill gem.

At higher levels, uncut gems use an equity system such that players will find fewer lower level uncut gems as a percentage of lower level uncut gems will instead accumulate towards the drop of a higher level uncut gem. Between [item levels](/wiki/Item_level "Item level") 78-80, and even further between 81-82, this percentage increases significantly.[[1]](#cite_note-1)

## List of uncut gems

Main article: [List of uncut gems](/wiki/List_of_uncut_gems "List of uncut gems")

| Item | Description | Drop level |
| --- | --- | --- |
| [Uncut Skill Gem](/wiki/Uncut_Skill_Gem "Uncut Skill Gem") | Creates a Skill Gem or Level an existing gem to level # | *1* |
| [Uncut Skill Gem](/wiki/Uncut_Skill_Gem_(quest_item) "Uncut Skill Gem (quest item)") | Creates a Skill Gem | *1* |
| [Uncut Spirit Gem](/wiki/Uncut_Spirit_Gem "Uncut Spirit Gem") | Creates a Persistent Buff Skill Gem or Level an existing gem to Level # | *11* |
| [Uncut Support Gem](/wiki/Uncut_Support_Gem "Uncut Support Gem") | Creates a Support Gem | *1* |

## Uncut gem levels

### Drop level breakpoints

The level of the gem dropped depends on the [drop level](/wiki/Drop_level "Drop level"). Note that [Uncut Spirit Gem](/wiki/Uncut_Spirit_Gem "Uncut Spirit Gem")'s lowest level is 4 (drop level 12).

For example, if an Uncut Skill Gem drops from a normal monster in a level 40 area, it will always be a level 10 gem.

From drop level 62+, multiple tiers of uncut gems can drop based on a weighting system.

| Drop level | Uncut Skill/Spirit Gem level | Uncut Support Gem level |
| --- | --- | --- |
| 1 | 1 | — |
| 4 | 2 | 1 |
| 7 | 3 | 1 |
| 11 | 4 | 1 |
| 15 | 5 | 1 |
| 16 | 5 | 2 |
| 19 | 6 | 2 |
| 23 | 7 | 2 |
| 27 | 8 | 2 |
| 32 | 9 | 2 |
| 33 | 9 | 3 |
| 37 | 10 | 3 |
| 42 | 11 | 3 |
| 45 | 11 | 4 |
| 47 | 12 | 4 |
| 53 | 13 | 4 |
| 55 | 13 | 5 |
| 58 | 14 | 5 |
| 62 | 14-15 | 5 |
| 66 | 14-16 | 5 |
| 70 | 15-17 | 5 |
| 74 | 16-18 | 5 |
| 78 | 17-19 | 5 |
| 80 | 17-20 | 5 |
| 82 | 18-20 | 5 |
| 86 | 19-20 | 5 |
