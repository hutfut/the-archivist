# Item level

Redirect to:

* [Item#Item level](/wiki/Item#Item_level "Item")
