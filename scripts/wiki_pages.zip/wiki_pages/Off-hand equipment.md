# Off-hand equipment

Redirect to:

* [Off Hand](/wiki/Off_Hand "Off Hand")
