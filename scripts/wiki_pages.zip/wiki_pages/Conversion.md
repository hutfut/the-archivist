# Conversion

**Conversion** may refer to:

* [Damage conversion](/wiki/Damage_conversion "Damage conversion"), a mechanic that causes a portion of the base damage of one [damage type](/wiki/Damage_type "Damage type") to be converted into or gained as another before damage multipliers
* [Stat conversion](/wiki/Stat_conversion "Stat conversion"), a similar mechanic that causes a portion of one stat (e.g. [Life](/wiki/Life "Life"), [Mana](/wiki/Mana "Mana"), [Defences](/wiki/Defences "Defences")) to be converted into or gained as another before relevant multipliers

Conversion should not be confused with the [damage taken as](/wiki/Damage_taken_as "Damage taken as") stat, which affects damage taken, not damage dealt.

This [disambiguation](https://en.wikipedia.org/wiki/Help:Disambiguation "wikipedia:Help:Disambiguation") page lists articles associated with the title **Conversion**.
 If an [internal link](/wiki/Special:WhatLinksHere/Conversion "Special:WhatLinksHere/Conversion") led you here, you may wish to change the link to point directly to the intended article.
