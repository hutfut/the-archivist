# Movement speed

**Movement speed** (often referred to as **MS**) is a stat that determines the rate at which an entity can [move](/wiki/Movement "Movement"). It is used to determine the player's walk/run speed, as well as the speed of a [dodge roll](/wiki/Dodge_roll "Dodge roll"). The base movement speed modifier of a player is treated as 0% in the Miscellaneous section of the Character screen, which can be interpreted as 100% of base movement speed.

## Mechanics

### Armour movement penalties

Armour Movement Penalties

Tooltip

Depending on the type of [Armour](/wiki/Armour_(equipment) "Armour (equipment)") equipped, Players will have a less Movement Speed penalty applied depending on what [Attribute](/wiki/Attribute "Attribute") the Armour requires. These penalties only apply to equipped Body Armours and [Shields](/wiki/Shield "Shield").
For Body Armour, pure [Strength](/wiki/Strength "Strength") has a 5% penalty, hybrid [Strength](/wiki/Strength "Strength") and [Dexterity](/wiki/Dexterity "Dexterity") or [Intelligence](/wiki/Intelligence "Intelligence") has a 4% penalty and pure [Dexterity](/wiki/Dexterity "Dexterity") or [Intelligence](/wiki/Intelligence "Intelligence") has a 3% penalty.
For [Shields](/wiki/Shield "Shield"), pure [Strength](/wiki/Strength "Strength") has a 3% penalty, hybrid [Strength](/wiki/Strength "Strength") and [Dexterity](/wiki/Dexterity "Dexterity") or [Intelligence](/wiki/Intelligence "Intelligence") has a 1.5% penalty and pure [Dexterity](/wiki/Dexterity "Dexterity") or [Intelligence](/wiki/Intelligence "Intelligence") has no penalty.

To calculate movement speed, first the movement speed penalty must be considered. [Body armours](/wiki/Body_armour "Body armour") and [shields](/wiki/Shield "Shield") have an inherent movement speed penalty that applies to base movement speed (100% by default) when equipped according to the following:

Equipment inherent movement speed penalties

| Attr. | Item type | Movement speed penalty |
| --- | --- | --- |
|  | Pure armour body armour | -5% |
|  | Hybrid armour body armour | -4% |
|  | Non-armour body armour | -3% |
|  | Pure armour shield | -3% |
|  | Hybrid armour shield | -1.5% |
|  | Pure evasion shield | 0% |

Pure [evasion](/wiki/Evasion "Evasion") shields ([bucklers](/wiki/Buckler "Buckler")) and [foci](/wiki/Foci "Foci") do not have movement speed penalties.

Other modifiers to movement speed apply to the movement speed value after penalties. For example, [boots](/wiki/Boots "Boots") with 20% increased Movement Speed on a character wearing an [energy shield](/wiki/Energy_shield "Energy shield") body armour will have a movement speed of:

(
100
−
3
)
∗
1.2
\color [rgb]{0.6392156862745098,0.5529411764705883,0.42745098039215684}(100-3)\*1.2
 =

116.4
\color [rgb]{0.6392156862745098,0.5529411764705883,0.42745098039215684}116.4

So the player will have 116.4% of base movement speed, or +16.4% Movement speed modifier.

### Movement speed penalty

Certain skills (mainly ranged attacks and spells) allow movement during the skill animation, but at reduced speed. Effects which decrease movement speed penalty will allow you to move faster while using these skills.

## Related effects

### Buffs

* [Onslaught](/wiki/Onslaught "Onslaught") grants 10% increased Movement Speed.
* [Tailwind](/wiki/Tailwind "Tailwind") grants 1% increased Movement Speed per stack.

### Debuffs

[Slows](/wiki/Slow "Slow") reduce movement speed by varying amounts.

### Other

* [Sprinting](/wiki/Sprint "Sprint") increases the player character's movement speed by 50%.
* While in [Werewolf](/wiki/Werewolf "Werewolf") form, moving for 1 second makes your character run on all four legs, grants 30% increased Movement Speed except while sprinting.

## Related skills

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Whirling Slash](/wiki/Whirling_Slash "Whirling Slash") | *1* |  |  |  |
| [Shield Charge](/wiki/Shield_Charge "Shield Charge") | *3* |  |  |  |
| [Raise Zombie](/wiki/Raise_Zombie "Raise Zombie") | *5* |  |  |  |
| [Oil Barrage](/wiki/Oil_Barrage "Oil Barrage") | *9* |  |  |  |
| [Oil Grenade](/wiki/Oil_Grenade "Oil Grenade") | *9* |  |  |  |
| [Rampage](/wiki/Rampage "Rampage") | *11* |  |  |  |
| [Stampede](/wiki/Stampede "Stampede") | *11* |  |  |  |

### Persistent skills

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Defiance Banner](/wiki/Defiance_Banner "Defiance Banner") | *8* |  |  |  |
| [Rhoa Mount](/wiki/Rhoa_Mount "Rhoa Mount") | *14* |  |  |  |

## Related support gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Deliberation](/wiki/Deliberation "Deliberation") | *3* |  |  |  |
| [Mobility](/wiki/Mobility "Mobility") | *3* |  |  |  |

## Unique items

| Item | Stats |
| --- | --- |
| [Flesh Crucible](/wiki/Flesh_Crucible "Flesh Crucible") | <Keystone Passive Skill>   | <Random stat penalty> | | --- | | (20-10)% less Damage  ---  (20-10)% less [Defences](/wiki/Defences "Defences")  ---  (20-10)% less maximum Life  ---  (20-10)% less maximum Mana  ---  (20-10)% less Movement Speed  ---  (20-10)% less [Spirit](/wiki/Spirit "Spirit") |  *Corrupted* |
| [Heart of the Well](/wiki/Heart_of_the_Well "Heart of the Well") | <Custom Desecrated prefix> <Custom Desecrated prefix> <Custom Desecrated suffix> <Custom Desecrated suffix>   | <List of mods> | | --- | | (5-10)% chance to [Aggravate](/wiki/Aggravate "Aggravate") [Bleeding](/wiki/Bleeding "Bleeding") on targets you [Hit](/wiki/Hit "Hit") with [Attacks](/wiki/Attack "Attack")  ---  (5-8)% increased [Attack](/wiki/Attack "Attack") Speed while a [Rare or Unique](/wiki/Rarity "Rarity") Enemy is in your [Presence](/wiki/Presence "Presence")  ---  (40-60)% increased [Armour](/wiki/Armour "Armour") from Equipped Body Armour  ---  (30-50)% chance to [Pierce](/wiki/Pierce "Pierce") an Enemy  ---  (10-15)% chance when a [Charm](/wiki/Charm "Charm") is used to use another Charm without consuming Charges  ---  [Charms](/wiki/Charm "Charm") applied to you have (15-25)% increased Effect  ---  Recover (5-10)% of maximum Mana when a [Charm](/wiki/Charm "Charm") is used  ---  (15-25)% increased [Culling Strike](/wiki/Culling_Strike "Culling Strike") Threshold  ---  [Gain](/wiki/Gain "Gain") (9-15)% of Damage as Extra [Lightning](/wiki/Lightning "Lightning") Damage  ---  [Gain](/wiki/Gain "Gain") (7-13)% of Damage as Extra [Chaos](/wiki/Chaos "Chaos") Damage  ---  [Gain](/wiki/Gain "Gain") (9-15)% of Damage as Extra [Fire](/wiki/Fire "Fire") Damage  ---  [Gain](/wiki/Gain "Gain") (9-15)% of Damage as Extra [Cold](/wiki/Cold "Cold") Damage  ---  (15-25)% increased Damage while your [Companion](/wiki/Companion "Companion") is in your [Presence](/wiki/Presence "Presence")  ---  (15-25)% increased [Exposure](/wiki/Exposure "Exposure") Effect  ---  (40-60)% increased [Evasion](/wiki/Evasion "Evasion") Rating from Equipped Body Armour  ---  Regenerate (1-1.5)% of maximum Life per Second if you've used a Life [Flask](/wiki/Flask "Flask") in the past 10 seconds  ---  (10-18)% increased [Cooldown Recovery Rate](/wiki/Cooldown_Recovery_Rate "Cooldown Recovery Rate")  ---  (40-60)% increased [Ice Crystal](/wiki/Ice_Crystal "Ice Crystal") Life  ---  (4-8)% increased [Skill Speed](/wiki/Skill_Speed "Skill Speed")  ---  (15-25)% chance for [Lightning](/wiki/Lightning "Lightning") Damage with [Hits](/wiki/Hit "Hit") to be [Lucky](/wiki/Lucky "Lucky")  ---  (8-16)% increased Mana Cost [Efficiency](/wiki/Efficiency "Efficiency")  ---  (20-30)% increased Mana Regeneration Rate while moving  ---  +1% to all [Maximum Elemental Resistances](/wiki/Maximum_Resistance "Maximum Resistance")  ---  (40-60)% increased [Energy Shield](/wiki/Energy_Shield "Energy Shield") from Equipped Body Armour  ---  [Minions](/wiki/Minion "Minion") gain (10-15)% of their maximum Life as Extra maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield")  ---  [Minions](/wiki/Minion "Minion") Regenerate (1-3)% of maximum Life per second  ---  [Minions](/wiki/Minion "Minion") [Revive](/wiki/Reviving_Minions "Reviving Minions") (5-10)% faster  ---  (8-15)% of Leech is Instant  ---  (5-10)% of Physical Damage prevented [Recouped](/wiki/Recoup "Recoup") as Life  ---  (8-14)% increased speed of [Recoup](/wiki/Recoup "Recoup") Effects  ---  Recover (2-4)% of maximum Life on Killing a [Poisoned](/wiki/Poison "Poison") Enemy  ---  (10-15)% increased Skill Effect Duration  ---  +(2-4)% to Thorns [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance  ---  Gain [Physical](/wiki/Physical "Physical") [Thorns](/wiki/Thorns "Thorns") damage equal to (4-6)% of [Item Armour](/wiki/Defences "Defences") on [Equipped](/wiki/Equipped/edit?redlink=1 "Equipped (page does not exist)") Body Armour  ---  (6-12)% chance for [Trigger](/wiki/Trigger "Trigger") skills to refund half of [Energy](/wiki/Energy "Energy") Spent  ---  (4-8)% increased chance to inflict [Ailments](/wiki/Ailments "Ailments")  ---  Gain additional [Ailment Threshold](/wiki/Ailment_Threshold "Ailment Threshold") equal to (4-10)% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield")  ---  (5-10)% chance to inflict [Bleeding](/wiki/Bleeding "Bleeding") on [Hit](/wiki/Hit "Hit")  ---  (5-10)% chance to [Poison](/wiki/Poison "Poison") on [Hit](/wiki/Hit "Hit")  ---  (4-8)% increased [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance  ---  (6-12)% increased [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus")  ---  (2-3)% of Damage is taken from Mana before Life  ---  [Debuffs](/wiki/Debuff "Debuff") on you expire (4-8)% faster  ---  [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") deal damage (2-4)% faster  ---  (4-8)% increased [Flask](/wiki/Flask "Flask") Effect Duration  ---  Gain (1-2) [Rage](/wiki/Rage "Rage") when [Hit](/wiki/Hit "Hit") by an Enemy  ---  (2-3)% increased [Cooldown Recovery Rate](/wiki/Cooldown_Recovery_Rate "Cooldown Recovery Rate")  ---  (6-12)% increased [Elemental Ailment Threshold](/wiki/Ailment "Ailment")  ---  (2-3)% increased [Attack](/wiki/Attack "Attack") Speed  ---  (2-3)% increased Cast Speed  ---  (4-8)% increased [Flask](/wiki/Flask "Flask") Charges gained  ---  (5-10)% increased [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold")  ---  (2-3)% of Skill Mana Costs [Converted](/wiki/Stat_conversion "Stat conversion") to Life Costs  ---  (2-3)% of Damage taken [Recouped](/wiki/Recoup "Recoup") as Life  ---  (6-12)% increased Life Regeneration rate  ---  Recover (1-2)% of maximum Mana on Kill  ---  (4-8)% increased Mana Regeneration Rate  ---  +1% to [Maximum Cold Resistance](/wiki/Maximum_Cold_Resistance "Maximum Cold Resistance")  ---  +1% to [Maximum Fire Resistance](/wiki/Maximum_Fire_Resistance "Maximum Fire Resistance")  ---  Recover (1-2)% of maximum Life on Kill  ---  +1% to [Maximum Lightning Resistance](/wiki/Maximum_Lightning_Resistance "Maximum Lightning Resistance")  ---  [Minions](/wiki/Minion "Minion") have (2-3)% increased [Attack](/wiki/Attack "Attack") and Cast Speed  ---  [Minions](/wiki/Minion "Minion") have (6-12)% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance")  ---  [Minions](/wiki/Minion "Minion") have +(3-4)% to all Elemental [Resistances](/wiki/Resistances "Resistances")  ---  [Minions](/wiki/Minion "Minion") have (3-12)% additional [Physical](/wiki/Physical "Physical") Damage Reduction  ---  (1-2)% increased Movement Speed  ---  Gain 1 [Rage](/wiki/Rage "Rage") on [Melee](/wiki/Melee "Melee") [Hit](/wiki/Hit "Hit")  ---  (3-8)% increased Skill Effect Duration  ---  (10-5)% reduced [Slowing](/wiki/Slow "Slow") Potency of [Debuffs](/wiki/Debuff "Debuff") on You  ---  (4-8)% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for [Spells](/wiki/Spell "Spell")  ---  (6-12)% increased [Critical Spell Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus")  ---  (6-12)% increased [Stun](/wiki/Stun "Stun") Buildup  ---  Gain additional [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") equal to (4-10)% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") | |
| [Foxshade](/wiki/Foxshade "Foxshade") | +(50-70) to [Evasion](/wiki/Evasion "Evasion") Rating +(20-30) to [Dexterity](/wiki/Dexterity "Dexterity") 10% increased Movement Speed when on Full Life 100% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") when on Full Life |
| [Bronzebeard](/wiki/Bronzebeard "Bronzebeard") | 10% reduced Movement Speed (50-100)% increased [Armour](/wiki/Armour "Armour") and [Energy Shield](/wiki/Energy_Shield "Energy Shield") +100 to maximum Life (50-35)% reduced Effect of [Chill](/wiki/Chill "Chill") on you (50-35)% reduced [Magnitude](/wiki/Magnitude "Magnitude") of [Ignite](/wiki/Ignite "Ignite") on you (50-35)% reduced [effect](/wiki/Buff "Buff") of [Shock](/wiki/Shock "Shock") on you |
| [Hysseg's Claw](/wiki/Hysseg%27s_Claw "Hysseg's Claw") | [Minions](/wiki/Minion "Minion") deal (30-50)% increased Damage(70-100)% increased [Physical](/wiki/Physical "Physical") Damage 5% increased Movement Speed +(8-15) to [Strength](/wiki/Strength "Strength") +(8-15) to [Intelligence](/wiki/Intelligence "Intelligence") (5-8)% increased Damage per [Minion](/wiki/Minion "Minion") |
| [The Anvil](/wiki/The_Anvil "The Anvil") | +(30-40) to maximum Life10% reduced Movement Speed 10% reduced [Skill Speed](/wiki/Skill_Speed "Skill Speed") (25-50)% increased [Armour](/wiki/Armour "Armour") 25% increased [Block](/wiki/Block "Block") chance +(5-10)% to maximum [Block](/wiki/Block "Block") chance |
| [Feathered Fortress](/wiki/Feathered_Fortress "Feathered Fortress") | +(20-30) to [Strength](/wiki/Strength "Strength") +(20-30) to [Dexterity](/wiki/Dexterity "Dexterity") +(20-30)% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") +(20-30)% to [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance") No Movement Speed Penalty while Shield is Raised |
| [Greed's Embrace](/wiki/Greed%27s_Embrace "Greed's Embrace") | 50% increased [Strength](/wiki/Strength "Strength") Requirement 20% reduced Movement Speed (100-150)% increased [Armour](/wiki/Armour "Armour") (30-50)% increased [Rarity of Items](/wiki/Rarity "Rarity") found +(20-30)% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") |
| [Queen of the Forest](/wiki/Queen_of_the_Forest "Queen of the Forest") | (250-300)% increased [Evasion](/wiki/Evasion "Evasion") Rating -(15-10)% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") +(25-30)% to [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance") +(10-15)% to [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance") Increases Movement Speed by 25%, plus 1% per 600 [Evasion](/wiki/Evasion "Evasion") Rating, up to [a maximum of 75](/wiki/Maximim/edit?redlink=1 "Maximim (page does not exist)")% Other Modifiers to Movement Speed except for Sprinting do not apply |

## Related passive skills

The following [passive skills](/wiki/Passive_skill "Passive skill") are related to movement speed:

### Movement speed

| Name | Stats |
| --- | --- |
| [Attack Damage and Movement Speed](/wiki/Attack_Damage_and_Movement_Speed/edit?redlink=1 "Attack Damage and Movement Speed (page does not exist)") | 8% increased [Attack](/wiki/Attack "Attack") Damage 2% increased Movement Speed [[1]](/wiki/Passive_Skill:Attack2 "Passive Skill:Attack2") |
| [Evasion and Movement Speed](/wiki/Evasion_and_Movement_Speed/edit?redlink=1 "Evasion and Movement Speed (page does not exist)") | 8% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") 1% increased Movement Speed [[1]](/wiki/Passive_Skill:Azmerianimals7 "Passive Skill:Azmerianimals7") |
| [Evasion and Movement Speed while Sprinting](/wiki/Evasion_and_Movement_Speed_while_Sprinting/edit?redlink=1 "Evasion and Movement Speed while Sprinting (page does not exist)") | 15% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") while Sprinting 2% increased Movement Speed while Sprinting [[1]](/wiki/Passive_Skill:Sprint7 "Passive Skill:Sprint7") |
| [Movement Speed](/wiki/Movement_Speed "Movement Speed") | 2% increased Movement Speed [[1]](/wiki/Passive_Skill:Azmerianimals10 "Passive Skill:Azmerianimals10") [[2]](/wiki/Passive_Skill:Azmerianimals11 "Passive Skill:Azmerianimals11") [[3]](/wiki/Passive_Skill:Movement~speed1 "Passive Skill:Movement~speed1") [[4]](/wiki/Passive_Skill:Movement~speed3 "Passive Skill:Movement~speed3") [[5]](/wiki/Passive_Skill:Slow~mitigation3 "Passive Skill:Slow~mitigation3") [[6]](/wiki/Passive_Skill:Slow~mitigation4~ "Passive Skill:Slow~mitigation4~")  ---  3% increased Movement Speed if you've Killed [Recently](/wiki/Recently "Recently") [[3]](/wiki/Passive_Skill:Movement~speed6 "Passive Skill:Movement~speed6") [[4]](/wiki/Passive_Skill:Movement~speed8~ "Passive Skill:Movement~speed8~") |
| [Movement Speed and Slow Effect on You](/wiki/Movement_Speed_and_Slow_Effect_on_You/edit?redlink=1 "Movement Speed and Slow Effect on You (page does not exist)") | 1% increased Movement Speed 4% reduced [Slowing](/wiki/Slow "Slow") Potency of [Debuffs](/wiki/Debuff "Debuff") on You [[1]](/wiki/Passive_Skill:Slow~mitigation5 "Passive Skill:Slow~mitigation5") |
| [Sprint Movement Speed](/wiki/Sprint_Movement_Speed/edit?redlink=1 "Sprint Movement Speed (page does not exist)") | 3% increased Movement Speed while Sprinting [[1]](/wiki/Passive_Skill:Sprint3 "Passive Skill:Sprint3") [[2]](/wiki/Passive_Skill:Sprint4 "Passive Skill:Sprint4") |
| [Acceleration](/wiki/Acceleration "Acceleration") | 10% increased [Skill Speed](/wiki/Skill_Speed "Skill Speed") 3% increased Movement Speed [[1]](/wiki/Passive_Skill:Movement~speed9 "Passive Skill:Movement~speed9") |
| [Adrenaline Rush](/wiki/Adrenaline_Rush/edit?redlink=1 "Adrenaline Rush (page does not exist)") | 4% increased Movement Speed if you've Killed [Recently](/wiki/Recently "Recently") 8% increased [Attack](/wiki/Attack "Attack") Speed if you've killed [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Movement~speed11 "Passive Skill:Movement~speed11") |
| [Among the Hordes](/wiki/Among_the_Hordes/edit?redlink=1 "Among the Hordes (page does not exist)") | [Minions](/wiki/Minion "Minion") have 10% increased Movement Speed 15% increased [Attack](/wiki/Attack "Attack") Damage 3% increased Movement Speed [[1]](/wiki/Passive_Skill:Minion~offence59 "Passive Skill:Minion~offence59") |
| [Blur](/wiki/Blur/edit?redlink=1 "Blur (page does not exist)") | 20% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") 4% increased Movement Speed +10 to [Dexterity](/wiki/Dexterity "Dexterity") [[1]](/wiki/Passive_Skill:Ranger~huntress~notable1 "Passive Skill:Ranger~huntress~notable1") |
| [Cross Strike](/wiki/Cross_Strike/edit?redlink=1 "Cross Strike (page does not exist)") | 20% increased Accuracy Rating while [Dual Wielding](/wiki/Dual_Wielding "Dual Wielding") 3% increased Movement Speed while [Dual Wielding](/wiki/Dual_Wielding "Dual Wielding") [[1]](/wiki/Passive_Skill:Dual~wielding4 "Passive Skill:Dual~wielding4") |
| [Escape Velocity](/wiki/Escape_Velocity/edit?redlink=1 "Escape Velocity (page does not exist)") | 30% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") 3% increased Movement Speed [[1]](/wiki/Passive_Skill:Evasion31 "Passive Skill:Evasion31") |
| [Gem Enthusiast](/wiki/Gem_Enthusiast/edit?redlink=1 "Gem Enthusiast (page does not exist)") | 5% increased Maximum Life if you have at least 10 Red [Support Gems](/wiki/Support_Gem "Support Gem") Socketed 5% increased Movement Speed if you have at least 10 Green [Support Gems](/wiki/Support_Gem "Support Gem") Socketed 5% increased Maximum Mana if you have at least 10 Blue [Support Gems](/wiki/Support_Gem "Support Gem") Socketed [[1]](/wiki/Passive_Skill:Attributes100~ "Passive Skill:Attributes100~") |
| [Invigorating Archon](/wiki/Invigorating_Archon/edit?redlink=1 "Invigorating Archon (page does not exist)") | [Archon](/wiki/Archon "Archon") Buffs also grant 10% increased Movement Speed [Archon](/wiki/Archon "Archon") Buffs also grant +20% to all [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") [[1]](/wiki/Passive_Skill:Archon11 "Passive Skill:Archon11") |
| [Kite Runner](/wiki/Kite_Runner/edit?redlink=1 "Kite Runner (page does not exist)") | 15% increased [Projectile](/wiki/Projectile "Projectile") Speed 15% increased [Projectile](/wiki/Projectile "Projectile") Damage 3% increased Movement Speed [[1]](/wiki/Passive_Skill:Ranged30~ "Passive Skill:Ranged30~") |
| [Light on your Feet](/wiki/Light_on_your_Feet/edit?redlink=1 "Light on your Feet (page does not exist)") | Immune to [Maim](/wiki/Maim "Maim") Immune to [Hinder](/wiki/Hinder "Hinder") 3% increased Movement Speed [[1]](/wiki/Passive_Skill:Slow~mitigation8 "Passive Skill:Slow~mitigation8") |
| [Lucky Rabbit Foot](/wiki/Lucky_Rabbit_Foot/edit?redlink=1 "Lucky Rabbit Foot (page does not exist)") | 30% increased Damage while you have an active [Charm](/wiki/Charm "Charm") 6% increased Movement Speed while you have an active [Charm](/wiki/Charm "Charm") [[1]](/wiki/Passive_Skill:Charms6 "Passive Skill:Charms6") |
| [Marathon Runner](/wiki/Marathon_Runner/edit?redlink=1 "Marathon Runner (page does not exist)") | 12% increased Movement Speed while Sprinting [[1]](/wiki/Passive_Skill:Sprint9~ "Passive Skill:Sprint9~") |
| [Marked Agility](/wiki/Marked_Agility/edit?redlink=1 "Marked Agility (page does not exist)") | 60% increased Mana Cost [Efficiency](/wiki/Efficiency "Efficiency") of [Marks](/wiki/Mark "Mark") 4% increased Movement Speed if you've used a [Mark](/wiki/Mark "Mark") [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Marks17 "Passive Skill:Marks17") |
| [Pin and Run](/wiki/Pin_and_Run/edit?redlink=1 "Pin and Run (page does not exist)") | 30% increased [Pin](/wiki/Pinned "Pinned") Buildup 5% increased Movement Speed if you've [Pinned](/wiki/Pinned "Pinned") an Enemy [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Pin10 "Passive Skill:Pin10") |
| [Relentless Fallen](/wiki/Relentless_Fallen/edit?redlink=1 "Relentless Fallen (page does not exist)") | [Minions](/wiki/Minion "Minion") have 8% increased [Attack](/wiki/Attack "Attack") and Cast Speed [Minions](/wiki/Minion "Minion") have 20% increased Movement Speed 3% increased Movement Speed [[1]](/wiki/Passive_Skill:Minion~offence21~ "Passive Skill:Minion~offence21~") |
| [Shimmering](/wiki/Shimmering/edit?redlink=1 "Shimmering (page does not exist)") | 20% increased [Energy Shield](/wiki/Energy_Shield "Energy Shield") Recovery Rate if you haven't been [Hit](/wiki/Hit "Hit") [Recently](/wiki/Recently "Recently") 3% increased Movement Speed while you have [Energy Shield](/wiki/Energy_Shield "Energy Shield") [[1]](/wiki/Passive_Skill:Evasion~and~energy~shield15 "Passive Skill:Evasion~and~energy~shield15") |
| [Spaghettification](/wiki/Spaghettification "Spaghettification") | +13 to all [Attributes](/wiki/Attributes "Attributes") 29% increased [Chaos](/wiki/Chaos "Chaos") Damage -7% to [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance") 23% reduced [Light Radius](/wiki/Light_Radius "Light Radius") 3% increased Movement Speed [[1]](/wiki/Passive_Skill:Chaos32 "Passive Skill:Chaos32") |
| [Spiral into Depression](/wiki/Spiral_into_Depression/edit?redlink=1 "Spiral into Depression (page does not exist)") | 25% increased [Armour](/wiki/Armour "Armour") 25% increased maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") 3% increased Movement Speed [[1]](/wiki/Passive_Skill:Energy~shield~and~armour14 "Passive Skill:Energy~shield~and~armour14") |
| [Step Like Mist](/wiki/Step_Like_Mist/edit?redlink=1 "Step Like Mist (page does not exist)") | 15% increased Mana Regeneration Rate 4% increased Movement Speed +5 to [Dexterity](/wiki/Dexterity "Dexterity") and [Intelligence](/wiki/Intelligence "Intelligence") [[1]](/wiki/Passive_Skill:Shadow~monk~notable2 "Passive Skill:Shadow~monk~notable2") |
| [Swift Blocking](/wiki/Swift_Blocking/edit?redlink=1 "Swift Blocking (page does not exist)") | 12% increased [Block](/wiki/Block "Block") chance 1% increased Movement Speed for each time you've Blocked in the past 10 seconds [[1]](/wiki/Passive_Skill:Block16 "Passive Skill:Block16") |
| [Swift Interruption](/wiki/Swift_Interruption/edit?redlink=1 "Swift Interruption (page does not exist)") | 6% increased Movement Speed if you've successfully [Parried](/wiki/Parry "Parry") [Recently](/wiki/Recently "Recently") 12% increased [Attack](/wiki/Attack "Attack") Speed if you've successfully [Parried](/wiki/Parry "Parry") [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Deflect9 "Passive Skill:Deflect9") |
| [Tactical Retreat](/wiki/Tactical_Retreat/edit?redlink=1 "Tactical Retreat (page does not exist)") | 10% increased Movement Speed while [Surrounded](/wiki/Surrounded "Surrounded") +0.5 metres to Dodge Roll distance while [Surrounded](/wiki/Surrounded "Surrounded") [[1]](/wiki/Passive_Skill:Being~surrounded21 "Passive Skill:Being~surrounded21") |

### Movement speed penalty

| Name | Stats |
| --- | --- |
| [Block and Movement Penalty with Raised Shield](/wiki/Block_and_Movement_Penalty_with_Raised_Shield/edit?redlink=1 "Block and Movement Penalty with Raised Shield (page does not exist)") | 4% increased [Block](/wiki/Block "Block") chance 5% reduced Movement Speed Penalty while Actively [Blocking](/wiki/Block "Block") [[1]](/wiki/Passive_Skill:Shield29 "Passive Skill:Shield29") |
| [Evasion and Reduced Movement Penalty](/wiki/Evasion_and_Reduced_Movement_Penalty/edit?redlink=1 "Evasion and Reduced Movement Penalty (page does not exist)") | 10% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") 2% reduced Movement Speed Penalty from using Skills while moving [[1]](/wiki/Passive_Skill:Evasion23~ "Passive Skill:Evasion23~") [[2]](/wiki/Passive_Skill:Evasion4 "Passive Skill:Evasion4") [[3]](/wiki/Passive_Skill:Evasion9 "Passive Skill:Evasion9") |
| [Movement Penalty with Raised Shield](/wiki/Movement_Penalty_with_Raised_Shield/edit?redlink=1 "Movement Penalty with Raised Shield (page does not exist)") | 10% reduced Movement Speed Penalty while Actively [Blocking](/wiki/Block "Block") [[1]](/wiki/Passive_Skill:Shield30 "Passive Skill:Shield30") [[2]](/wiki/Passive_Skill:Shield32 "Passive Skill:Shield32") |
| [Reduced Movement Penalty](/wiki/Reduced_Movement_Penalty/edit?redlink=1 "Reduced Movement Penalty (page does not exist)") | 3% reduced Movement Speed Penalty from using Skills while moving [[1]](/wiki/Passive_Skill:Spell~suppression36 "Passive Skill:Spell~suppression36") [[2]](/wiki/Passive_Skill:Spell~suppression6 "Passive Skill:Spell~suppression6") |
| [Reduced Movement Penalty and Attack Damage while Moving](/wiki/Reduced_Movement_Penalty_and_Attack_Damage_while_Moving/edit?redlink=1 "Reduced Movement Penalty and Attack Damage while Moving (page does not exist)") | 2% reduced Movement Speed Penalty from using Skills while moving 8% increased [Attack](/wiki/Attack "Attack") Damage while moving [[1]](/wiki/Passive_Skill:Slow~mitigation11 "Passive Skill:Slow~mitigation11") [[2]](/wiki/Passive_Skill:Slow~mitigation13 "Passive Skill:Slow~mitigation13") |
| [Afterimage](/wiki/Afterimage/edit?redlink=1 "Afterimage (page does not exist)") | 60% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") if you have Hit an Enemy [Recently](/wiki/Recently "Recently") 5% reduced Movement Speed Penalty from using Skills while moving [[1]](/wiki/Passive_Skill:Evasion35 "Passive Skill:Evasion35") |
| [Catlike Agility](/wiki/Catlike_Agility "Catlike Agility") | 25% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") 40% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") if you've Dodge Rolled [Recently](/wiki/Recently "Recently") 3% reduced Movement Speed Penalty from using Skills while moving [[1]](/wiki/Passive_Skill:Evasion39 "Passive Skill:Evasion39") |
| [Ether Flow](/wiki/Ether_Flow/edit?redlink=1 "Ether Flow (page does not exist)") | 25% reduced Mana Regeneration Rate while stationary 50% increased Mana Regeneration Rate while moving 5% reduced Movement Speed Penalty from using Skills while moving [[1]](/wiki/Passive_Skill:Mana~regeneration40 "Passive Skill:Mana~regeneration40") |
| [Freedom of Movement](/wiki/Freedom_of_Movement "Freedom of Movement") | 20% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") 5% reduced Movement Speed Penalty from using Skills while moving 10% reduced [Slowing](/wiki/Slow "Slow") Potency of [Debuffs](/wiki/Debuff "Debuff") on You [[1]](/wiki/Passive_Skill:Evasion30 "Passive Skill:Evasion30") |
| [Momentum](/wiki/Momentum "Momentum") | Ignore all [Movement Penalties](/wiki/Armour_Movement_Penalties/edit?redlink=1 "Armour Movement Penalties (page does not exist)") from [Armour](/wiki/Armour_(equipment) "Armour (equipment)") 5% reduced [Slowing](/wiki/Slow "Slow") Potency of [Debuffs](/wiki/Debuff "Debuff") on You [[1]](/wiki/Passive_Skill:Slow~mitigation7~ "Passive Skill:Slow~mitigation7~") |
| [Run and Gun](/wiki/Run_and_Gun/edit?redlink=1 "Run and Gun (page does not exist)") | [Projectile](/wiki/Projectile "Projectile") [Attacks](/wiki/Attack "Attack") have a 12% chance to fire two additional [Projectiles](/wiki/Projectile "Projectile") while moving 5% reduced Movement Speed Penalty from using Skills while moving [[1]](/wiki/Passive_Skill:Slow~mitigation16 "Passive Skill:Slow~mitigation16") |
| [Spray and Pray](/wiki/Spray_and_Pray/edit?redlink=1 "Spray and Pray (page does not exist)") | 50% increased [Attack](/wiki/Attack "Attack") Damage while moving 20% reduced [Accuracy](/wiki/Accuracy "Accuracy") Rating while moving 5% reduced Movement Speed Penalty from using Skills while moving [[1]](/wiki/Passive_Skill:Slow~mitigation15 "Passive Skill:Slow~mitigation15") |
| [Unhindered](/wiki/Unhindered "Unhindered") | 20% reduced [Slowing](/wiki/Slow "Slow") Potency of [Debuffs](/wiki/Debuff "Debuff") on You 6% reduced Movement Speed Penalty from using Skills while moving [[1]](/wiki/Passive_Skill:Spell~suppression12 "Passive Skill:Spell~suppression12") |

### Paths Not Taken passive skills

The following passive skills are exclusive the [Oracle](/wiki/Oracle "Oracle") with [The Unseen Path](/wiki/The_Unseen_Path "The Unseen Path") allocated:

| Name | Stats |
| --- | --- |
| [Movement Speed](/wiki/Movement_Speed "Movement Speed") | 3% increased Movement Speed [[1]](/wiki/Passive_Skill:Oracle~movement~cooldown1 "Passive Skill:Oracle~movement~cooldown1") [[2]](/wiki/Passive_Skill:Oracle~movement~cooldown3~ "Passive Skill:Oracle~movement~cooldown3~") |
| [Reduced Movement Penalty](/wiki/Reduced_Movement_Penalty/edit?redlink=1 "Reduced Movement Penalty (page does not exist)") | 6% reduced Movement Speed Penalty from using Skills while moving [[1]](/wiki/Passive_Skill:Oracle~bow~movement4~ "Passive Skill:Oracle~bow~movement4~") [[2]](/wiki/Passive_Skill:Oracle~bow~movement5 "Passive Skill:Oracle~bow~movement5") |
| [Limitless Pursuit](/wiki/Limitless_Pursuit "Limitless Pursuit") | 4% increased Movement Speed 14% increased [Cooldown Recovery Rate](/wiki/Cooldown_Recovery_Rate "Cooldown Recovery Rate") [[1]](/wiki/Passive_Skill:Oracle~movement~cooldown5~ "Passive Skill:Oracle~movement~cooldown5~") |
| [Scent of Blood](/wiki/Scent_of_Blood "Scent of Blood") | 20% increased Bleeding Duration 40% chance for [Attack](/wiki/Attack "Attack") [Hits](/wiki/Hit "Hit") to apply [Incision](/wiki/Incision "Incision") 3% increased Movement Speed [[1]](/wiki/Passive_Skill:Oracle~bleed3 "Passive Skill:Oracle~bleed3") |

### Ascendancy passive skills

The following [Ascendancy passive skills](/wiki/Ascendancy_passive_skill "Ascendancy passive skill") are related to movement speed:

| Ascendancy Class | Name | Stats |
| --- | --- | --- |
| [Amazon](/wiki/Amazon "Amazon") | [In for the Kill](/wiki/In_for_the_Kill "In for the Kill") | 20% increased Movement Speed while an enemy with an [Open Weakness](/wiki/Revealing_Weaknesses/edit?redlink=1 "Revealing Weaknesses (page does not exist)") is in your [Presence](/wiki/Presence "Presence") 40% increased [Skill Speed](/wiki/Skill_Speed "Skill Speed") while an enemy with an [Open Weakness](/wiki/Revealing_Weaknesses/edit?redlink=1 "Revealing Weaknesses (page does not exist)") is in your [Presence](/wiki/Presence "Presence") [[1]](/wiki/Passive_Skill:AscendancyHuntress1Notable4 "Passive Skill:AscendancyHuntress1Notable4") |
| [Gemling Legionnaire](/wiki/Gemling_Legionnaire "Gemling Legionnaire") | [Gem Studded](/wiki/Gem_Studded "Gem Studded") | For each colour of Socketed Support Gem that is most numerous, gain: •Red: [Hits](/wiki/Hit "Hit") against you have no [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus") •Blue: Skills have 30% less cost •Green: 40% less Movement Speed Penalty from using Skills while Moving [[1]](/wiki/Passive_Skill:AscendancyMercenary3Notable3 "Passive Skill:AscendancyMercenary3Notable3") |
| [Pathfinder](/wiki/Pathfinder "Pathfinder") | [Running Assault](/wiki/Running_Assault "Running Assault") | 50% less Movement Speed Penalty from using Skills while moving Cannot be [Heavy Stunned](/wiki/Heavy_Stun "Heavy Stun") while Sprinting [[1]](/wiki/Passive_Skill:AscendancyRanger3Notable1~ "Passive Skill:AscendancyRanger3Notable1~") |
| [Ritualist](/wiki/Ritualist "Ritualist") | [Movement Speed](/wiki/Movement_Speed "Movement Speed") | 3% increased Movement Speed [[1]](/wiki/Passive_Skill:AscendancyHuntress3Small7 "Passive Skill:AscendancyHuntress3Small7") [[2]](/wiki/Passive_Skill:AscendancyHuntress3Small8 "Passive Skill:AscendancyHuntress3Small8") |
