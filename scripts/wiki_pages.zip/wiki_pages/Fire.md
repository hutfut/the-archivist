# Fire

Fire Damage

Tooltip

Fire damage is one of the five [Damage Types](/wiki/Damage_type "Damage type"). It is reduced by [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance"). Fire [Hits](/wiki/Hit "Hit") inflict [Flammability](/wiki/Flammability "Flammability") based on how much Fire damage is dealt, which provides a chance to [Ignite](/wiki/Ignite "Ignite").

**Fire** [damage](/wiki/Damage "Damage") is one of the five [damage types](/wiki/Damage_type "Damage type"), and one of the three types of [elemental damage](/wiki/Elemental_damage "Elemental damage"). It can be mitigated by fire [resistance](/wiki/Resistance "Resistance").

Fire [damage over time](/wiki/Damage_over_time "Damage over time") is usually inflicted by [ignite](/wiki/Ignite "Ignite"), and fire damage applies [Flammability](/wiki/Flammability_(debuff) "Flammability (debuff)") based on the amount of fire damage dealt, which affects the chance for fire damage to apply ignite, based on its total magnitude.

## Mechanics

Fire damage modifiers usually deal the highest average damage compared to [cold](/wiki/Cold "Cold") or [lightning](/wiki/Lightning "Lightning") damage. It is also only one of the three elemental damage types to have an inherent damaging [ailment](/wiki/Ailment "Ailment"). However, it also lacks any inherent crowd control effects.

Several fire skills are also [Detonator](/wiki/Detonator "Detonator") skills, which can ignite [Oil](/wiki/Oil "Oil") and cause flammable gas to explode, dealing fire damage.

## Gems

A list of [gems](/wiki/Gem "Gem") with the [gem tag](/wiki/Gem_tag "Gem tag"): [Category:Fire (gem tag)](/wiki/Category:Fire_(gem_tag) "Category:Fire (gem tag)")

### Skill gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Explosive Spear](/wiki/Explosive_Spear "Explosive Spear") | *1* |  |  |  |
| [Flame Wall](/wiki/Flame_Wall "Flame Wall") | *1* |  |  |  |
| [Skeletal Sniper](/wiki/Skeletal_Sniper "Skeletal Sniper") | *1* |  |  |  |
| [Explosive Grenade](/wiki/Explosive_Grenade "Explosive Grenade") | *1* |  |  |  |
| [Volcano](/wiki/Volcano "Volcano") | *1* |  |  |  |
| [Fireball](/wiki/Fireball "Fireball") | *3* |  |  |  |
| [Living Bomb](/wiki/Living_Bomb "Living Bomb") | *3* |  |  |  |
| [Skeletal Arsonist](/wiki/Skeletal_Arsonist "Skeletal Arsonist") | *3* |  |  |  |
| [Incendiary Shot](/wiki/Incendiary_Shot "Incendiary Shot") | *3* |  |  |  |
| [Rolling Magma](/wiki/Rolling_Magma "Rolling Magma") | *3* |  |  |  |
| [Infernal Cry](/wiki/Infernal_Cry "Infernal Cry") | *3* |  |  |  |
| [Ember Fusillade](/wiki/Ember_Fusillade "Ember Fusillade") | *5* |  |  |  |
| [Snap](/wiki/Snap "Snap") | *5* |  |  |  |
| [Gas Grenade](/wiki/Gas_Grenade "Gas Grenade") | *5* |  |  |  |
| [Rapid Shot](/wiki/Rapid_Shot "Rapid Shot") | *5* |  |  |  |
| [Molten Blast](/wiki/Molten_Blast "Molten Blast") | *5* |  |  |  |
| [Perfect Strike](/wiki/Perfect_Strike "Perfect Strike") | *5* |  |  |  |
| [Gas Arrow](/wiki/Gas_Arrow "Gas Arrow") | *7* |  |  |  |
| [Detonate Dead](/wiki/Detonate_Dead "Detonate Dead") | *7* |  |  |  |
| [Elemental Weakness](/wiki/Elemental_Weakness "Elemental Weakness") | *7* |  |  |  |
| [Explosive Shot](/wiki/Explosive_Shot "Explosive Shot") | *7* |  |  |  |
| [Volcanic Fissure](/wiki/Volcanic_Fissure "Volcanic Fissure") | *7* |  |  |  |
| [Detonating Arrow](/wiki/Detonating_Arrow "Detonating Arrow") | *9* |  |  |  |
| [Incinerate](/wiki/Incinerate "Incinerate") | *9* |  |  |  |
| [Oil Grenade](/wiki/Oil_Grenade "Oil Grenade") | *9* |  |  |  |
| [Siege Ballista](/wiki/Siege_Ballista "Siege Ballista") | *9* |  |  |  |
| [Forge Hammer](/wiki/Forge_Hammer "Forge Hammer") | *9* |  |  |  |
| [Elemental Sundering](/wiki/Elemental_Sundering "Elemental Sundering") | *11* |  |  |  |
| [Firestorm](/wiki/Firestorm "Firestorm") | *11* |  |  |  |
| [Spear of Solaris](/wiki/Spear_of_Solaris "Spear of Solaris") | *13* |  |  |  |
| [Flameblast](/wiki/Flameblast "Flameblast") | *13* |  |  |  |
| [Cluster Grenade](/wiki/Cluster_Grenade "Cluster Grenade") | *13* |  |  |  |
| [Flame Breath](/wiki/Flame_Breath "Flame Breath") | *13* |  |  |  |
| [Walking Calamity](/wiki/Walking_Calamity "Walking Calamity") | *13* |  |  |  |
| [Ancestral Cry](/wiki/Ancestral_Cry "Ancestral Cry") | *13* |  |  |  |

### Spirit gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Raging Spirits](/wiki/Raging_Spirits "Raging Spirits") | *4* |  |  |  |
| [Herald of Ash](/wiki/Herald_of_Ash "Herald of Ash") | *4* |  |  |  |
| [Magma Barrier](/wiki/Magma_Barrier "Magma Barrier") | *4* |  |  |  |
| [Siphon Elements](/wiki/Siphon_Elements "Siphon Elements") | *8* |  |  |  |
| [Elemental Invocation](/wiki/Elemental_Invocation "Elemental Invocation") | *8* |  |  |  |
| [Shard Scavenger](/wiki/Shard_Scavenger "Shard Scavenger") | *8* |  |  |  |
| [Cast on Elemental Ailment](/wiki/Cast_on_Elemental_Ailment "Cast on Elemental Ailment") | *14* |  |  |  |
| [Elemental Conflux](/wiki/Elemental_Conflux "Elemental Conflux") | *14* |  |  |  |
| [Trinity](/wiki/Trinity "Trinity") | *14* |  |  |  |

### Support gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Arbiter's Ignition](/wiki/Arbiter%27s_Ignition "Arbiter's Ignition") | *0* |  |  |  |
| [Hayoxi's Fulmination](/wiki/Hayoxi%27s_Fulmination "Hayoxi's Fulmination") | *0* |  |  |  |
| [Xibaqua's Rending](/wiki/Xibaqua%27s_Rending "Xibaqua's Rending") | *0* |  |  |  |
| [Xoph's Pyre](/wiki/Xoph%27s_Pyre "Xoph's Pyre") | *0* |  |  |  |
| [Armour Explosion](/wiki/Armour_Explosion "Armour Explosion") | *1* |  |  |  |
| [Eternal Flame I](/wiki/Eternal_Flame_I "Eternal Flame I") | *1* |  |  |  |
| [Fire Attunement](/wiki/Fire_Attunement "Fire Attunement") | *1* |  |  |  |
| [Ignite I](/wiki/Ignite_I "Ignite I") | *1* |  |  |  |
| [Fiery Death](/wiki/Fiery_Death "Fiery Death") | *2* |  |  |  |
| [Mana Flare](/wiki/Mana_Flare "Mana Flare") | *2* |  |  |  |
| [Minion Instability](/wiki/Minion_Instability "Minion Instability") | *2* |  |  |  |
| [Wildfire](/wiki/Wildfire "Wildfire") | *2* |  |  |  |
| [Crater](/wiki/Crater "Crater") | *2* |  |  |  |
| [Fan The Flames I](/wiki/Fan_The_Flames_I "Fan The Flames I") | *2* |  |  |  |
| [Fire Penetration I](/wiki/Fire_Penetration_I "Fire Penetration I") | *2* |  |  |  |
| [Infernal Legion I](/wiki/Infernal_Legion_I "Infernal Legion I") | *2* |  |  |  |
| [Volcanic Eruption](/wiki/Volcanic_Eruption "Volcanic Eruption") | *2* |  |  |  |
| [Elemental Discharge](/wiki/Elemental_Discharge "Elemental Discharge") | *3* |  |  |  |
| [Frostfire](/wiki/Frostfire "Frostfire") | *3* |  |  |  |
| [Stormfire](/wiki/Stormfire "Stormfire") | *3* |  |  |  |
| [Eternal Flame II](/wiki/Eternal_Flame_II "Eternal Flame II") | *3* |  |  |  |
| [Ignite II](/wiki/Ignite_II "Ignite II") | *3* |  |  |  |
| [Immolate](/wiki/Immolate "Immolate") | *3* |  |  |  |
| [Searing Flame I](/wiki/Searing_Flame_I "Searing Flame I") | *3* |  |  |  |
| [Blazing Critical](/wiki/Blazing_Critical "Blazing Critical") | *4* |  |  |  |
| [Burning Inscription](/wiki/Burning_Inscription "Burning Inscription") | *4* |  |  |  |
| [Eternal Flame III](/wiki/Eternal_Flame_III "Eternal Flame III") | *4* |  |  |  |
| [Fan The Flames II](/wiki/Fan_The_Flames_II "Fan The Flames II") | *4* |  |  |  |
| [Fire Exposure](/wiki/Fire_Exposure "Fire Exposure") | *4* |  |  |  |
| [Infernal Legion II](/wiki/Infernal_Legion_II "Infernal Legion II") | *4* |  |  |  |
| [Searing Flame II](/wiki/Searing_Flame_II "Searing Flame II") | *4* |  |  |  |
| [Syzygy](/wiki/Syzygy "Syzygy") | *4* |  |  |  |
| [Catalysing Elements](/wiki/Catalysing_Elements "Catalysing Elements") | *5* |  |  |  |
| [Fire Mastery](/wiki/Fire_Mastery "Fire Mastery") | *5* |  |  |  |
| [Fire Penetration II](/wiki/Fire_Penetration_II "Fire Penetration II") | *5* |  |  |  |
| [Ignite III](/wiki/Ignite_III "Ignite III") | *5* |  |  |  |
| [Infernal Legion III](/wiki/Infernal_Legion_III "Infernal Legion III") | *5* |  |  |  |

## Base items

The following base items are related to fire damage:

| Item |  | Stats |
| --- | --- | --- |
| [Smithing Hammer](/wiki/Smithing_Hammer "Smithing Hammer") | 4 | 50% of this Weapon's base Physical Damage Converted to Fire Damage (Hidden) |
| [Cinderbark Talisman](/wiki/Cinderbark_Talisman "Cinderbark Talisman") | 10 | (50-80)% increased [Flammability](/wiki/Flammability "Flammability") [Magnitude](/wiki/Magnitude "Magnitude") 30% of this Weapon's base Physical Damage Converted to Fire Damage (Hidden) |
| [Ember Greataxe](/wiki/Ember_Greataxe "Ember Greataxe")[File:Ember Greataxe inventory icon.png](/index.php?title=Special:Upload&wpDestFile=Ember_Greataxe_inventory_icon.png "File:Ember Greataxe inventory icon.png") | 50 | 100% of this Weapon's base Physical Damage Converted to Fire Damage (Hidden) |
| [Ashbark Talisman](/wiki/Ashbark_Talisman "Ashbark Talisman") | 72 | (50-80)% increased [Flammability](/wiki/Flammability "Flammability") [Magnitude](/wiki/Magnitude "Magnitude") 30% of this Weapon's base Physical Damage Converted to Fire Damage (Hidden) |
| [Molten Hammer](/wiki/Molten_Hammer "Molten Hammer") | 77 | 50% of this Weapon's base Physical Damage Converted to Fire Damage (Hidden) |

## Unique items

The following unique items are related to fire damage:

| Item | Stats |
| --- | --- |
| [Fury of the King](/wiki/Fury_of_the_King "Fury of the King") | (50-80)% increased [Flammability](/wiki/Flammability "Flammability") [Magnitude](/wiki/Magnitude "Magnitude") 30% of this Weapon's base Physical Damage Converted to Fire Damage (Hidden)Adds (503-589) to (647-713) Fire Damage (20-15)% reduced [Attack](/wiki/Attack "Attack") Speed +(30-40) to [Strength](/wiki/Strength "Strength") [Bear](/wiki/Bear "Bear") Skills [Convert](/wiki/Damage_conversion "Damage conversion") 80% of [Physical](/wiki/Physical "Physical") Damage to Fire Damage Skills which require [Glory](/wiki/Glory "Glory") generate (2-5) [Glory](/wiki/Glory "Glory") every 2 seconds Enemies in your [Presence](/wiki/Presence "Presence") have [Exposure](/wiki/Exposure "Exposure") |
| [Sacred Flame](/wiki/Sacred_Flame "Sacred Flame") | [Gain](/wiki/Gain "Gain") (40-60)% of Damage as Extra Fire Damage [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") [Gain](/wiki/Gain "Gain") (20-30)% of Damage as Extra Fire Damage [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") Regenerate (2-3)% of their Maximum Life per second Enemies in your [Presence](/wiki/Presence "Presence") Resist [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") based on their Lowest [Resistance](/wiki/Resistance "Resistance") |

## Passive skills

### Base passive skills

The following [passive skills](/wiki/Passive_skill "Passive skill") are related to fire damage:
No results found for the given query.

### Keystone passive skills

The following [keystone](/wiki/Keystone "Keystone") passive skills are related to fire damage:

| Name | Stats |
| --- | --- |
| [Avatar of Fire](/wiki/Avatar_of_Fire "Avatar of Fire") | 75% of Damage Converted to Fire Damage Deal no Non-Fire Damage [[1]](/wiki/Passive_Skill:Passive~keystone~avatar~of~fire "Passive Skill:Passive~keystone~avatar~of~fire") |
| [Blackflame Covenant](/wiki/Blackflame_Covenant "Blackflame Covenant") | Fire [Spells](/wiki/Spell "Spell") [Convert](/wiki/Damage_conversion "Damage conversion") 100% of Fire Damage to [Chaos Damage](/wiki/Chaos_Damage "Chaos Damage") [Chaos Damage](/wiki/Chaos_Damage "Chaos Damage") from Fire [Spells](/wiki/Spell "Spell") [Contributes](/wiki/Contributes "Contributes") to [Flammability](/wiki/Flammability "Flammability") and [Ignite](/wiki/Ignite "Ignite") [Magnitudes](/wiki/Magnitude "Magnitude") [Ignite](/wiki/Ignite "Ignite") inflicted with Fire [Spells](/wiki/Spell "Spell") deals [Chaos Damage](/wiki/Chaos_Damage "Chaos Damage") instead of Fire Damage [[1]](/wiki/Passive_Skill:Passive~keystone~fire~spells~to~chaos "Passive Skill:Passive~keystone~fire~spells~to~chaos") |

### Ascendancy passive skills

The following [Ascendancy passive skills](/wiki/Ascendancy_passive_skill "Ascendancy passive skill") are related to fire damage:
No results found for the given query.
