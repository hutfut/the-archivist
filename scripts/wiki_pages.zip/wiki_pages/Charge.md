# Charge

Charges

Tooltip

Charges can be gained from a number of Skills, passives, and other effects. They do not grant any inherent benefits, but can be consumed to fuel many skills and other effects. Charges last for 15 seconds by default, refreshing whenever you gain another charge of the same type.

There are three types of Charges — Endurance, Frenzy and Power. By default players can have up to 3 of each type of Charge at once.

**Charges** are counters that are represented as glowing orbs around an entity. They are not [buffs](/wiki/Buff "Buff").

## Charge types

The three basic charges can be seen in the character menu's by default. Each charge corresponds to a different core [attribute](/wiki/Attribute "Attribute"):

* [Endurance charges](/wiki/Endurance_charge "Endurance charge") are associated with [strength](/wiki/Strength "Strength").
* [Frenzy charges](/wiki/Frenzy_charge "Frenzy charge") are associated with [dexterity](/wiki/Dexterity "Dexterity").
* [Power charges](/wiki/Power_charge "Power charge") are associated with [intelligence](/wiki/Intelligence "Intelligence").

## Mechanics

Charges do not grant stats like buffs do. All charges have a base duration of 15 seconds that refreshes when a new charge of that type is added, and a visual effect that orbits the character.

### Maximum charges

Characters have a default maximum of three Endurance, Frenzy, and Power charges. This limit can be raised with certain passive skills and equipment. If the character would gain a charge while already at the limit for that type of charge, no additional charge will be gained. However, the duration of all charges of that type will still be reset.

### Consumption

Some [skills](/wiki/Skill "Skill") can [consume](/wiki/Effect_consumption "Effect consumption") a certain type of charge to enhance or alter the skill's effects. While using these skills, charge duration timers are paused.

## Skill gems

Skill Gems that are related to non-specific charges:

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Chaotic Surge](/wiki/Chaotic_Surge "Chaotic Surge") | *0* |  |  |  |
| [Elemental Surge](/wiki/Elemental_Surge "Elemental Surge") | *0* |  |  |  |
| [Gemini Surge](/wiki/Gemini_Surge "Gemini Surge") | *0* |  |  |  |

### Persistent skills

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Charge Regulation](/wiki/Charge_Regulation "Charge Regulation") | *14* |  |  |  |

## Related support gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Charge Profusion I](/wiki/Charge_Profusion_I "Charge Profusion I") | *1* |  |  |  |
| [Perpetual Charge](/wiki/Perpetual_Charge "Perpetual Charge") | *1* |  |  |  |
| [Heightened Charges](/wiki/Heightened_Charges "Heightened Charges") | *2* |  |  |  |
| [Inhibitor](/wiki/Inhibitor "Inhibitor") | *2* |  |  |  |
| [Charge Profusion II](/wiki/Charge_Profusion_II "Charge Profusion II") | *5* |  |  |  |

## Related unique items

| Item | Base item | Item class |  | Stats |
| --- | --- | --- | --- | --- |
| [Serpent's Egg](/wiki/Serpent%27s_Egg "Serpent's Egg") | [Gold Amulet](/wiki/Gold_Amulet "Gold Amulet") | *[Amulet](/wiki/Amulet "Amulet")* | 35 | (12-20)% increased [Rarity of Items](/wiki/Rarity "Rarity") found+(10-20) to all [Attributes](/wiki/Attributes "Attributes") +(17-23)% to [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance") (20-30)% increased Mana Regeneration Rate Gain an additional Charge when you gain a Charge |
| [Hateforge](/wiki/Hateforge "Hateforge") | [Moulded Mitts](/wiki/Moulded_Mitts "Moulded Mitts") | *[Gloves](/wiki/Gloves "Gloves")* | 60 | (300-400)% increased [Armour](/wiki/Armour "Armour") Gain a random Charge on reaching Maximum [Rage](/wiki/Rage "Rage"), no more than once every (3-6) seconds Lose all [Rage](/wiki/Rage "Rage") on reaching Maximum [Rage](/wiki/Rage "Rage") +(-10-10) to Maximum [Rage](/wiki/Rage "Rage") Gain (3-6) [Rage](/wiki/Rage "Rage") on [Hit](/wiki/Hit "Hit") |
| [Spire of Ire](/wiki/Spire_of_Ire "Spire of Ire") | [Helix Spear](/wiki/Helix_Spear "Helix Spear") | *[Spear](/wiki/Spear "Spear")* | 65 | (15-20)% increased [Attack](/wiki/Attack "Attack") Speed [Leeches](/wiki/Leech "Leech") (10-20)% of [Physical](/wiki/Physical "Physical") Damage as Life Adds (167-201) to (267-333) [Chaos](/wiki/Chaos "Chaos") damage When you Consume a Charge [Trigger](/wiki/Trigger "Trigger") Chaotic Surge to gain 2 [Chaos Surges](/wiki/Elemental_Surges "Elemental Surges") [Life Leech](/wiki/Life_Leech "Life Leech") recovers based on your [Chaos](/wiki/Chaos "Chaos") damage instead of [Physical](/wiki/Physical "Physical") damage |

## Related passive skills

The following [passive skills](/wiki/Passive_skill "Passive skill") are related to generic charges:

| Name | Stats |
| --- | --- |
| [Charge Duration](/wiki/Charge_Duration/edit?redlink=1 "Charge Duration (page does not exist)") | 15% increased Endurance, Frenzy and Power Charge Duration [[1]](/wiki/Passive_Skill:Azmerianimals13 "Passive Skill:Azmerianimals13") [[2]](/wiki/Passive_Skill:Azmerianimals14 "Passive Skill:Azmerianimals14") |
| [Charge Duration and Dexterity](/wiki/Charge_Duration_and_Dexterity/edit?redlink=1 "Charge Duration and Dexterity (page does not exist)") | 10% increased Endurance, Frenzy and Power Charge Duration +5 to [Dexterity](/wiki/Dexterity "Dexterity") [[1]](/wiki/Passive_Skill:Azmerianimals15 "Passive Skill:Azmerianimals15") |
| [The Fabled Stag](/wiki/The_Fabled_Stag/edit?redlink=1 "The Fabled Stag (page does not exist)") | Skills have 10% chance to not remove [Charges](/wiki/Charges "Charges") but still count as consuming them 40% increased Endurance, Frenzy and Power Charge Duration +10 to [Dexterity](/wiki/Dexterity "Dexterity") [[1]](/wiki/Passive_Skill:Azmerianimals18 "Passive Skill:Azmerianimals18") |

### Ascendancy passive skills

The following [Ascendancy passive skills](/wiki/Ascendancy_passive_skill "Ascendancy passive skill") are related to generic charges:

| Ascendancy Class | Name | Stats |
| --- | --- | --- |
| [Amazon](/wiki/Amazon "Amazon") | [Elemental Surge](/wiki/Elemental_Surge_(passive) "Elemental Surge (passive)") | Grants Skill: [Elemental Surge](/wiki/Elemental_Surge "Elemental Surge") When you Consume a Charge, [Trigger](/wiki/Trigger "Trigger") Elemental Surge to gain 3 [Lightning Surges](/wiki/Elemental_Surges "Elemental Surges") [[1]](/wiki/Passive_Skill:AscendancyHuntress1Notable6 "Passive Skill:AscendancyHuntress1Notable6") |
| [Amazon](/wiki/Amazon "Amazon") | [Surging Avatar](/wiki/Surging_Avatar "Surging Avatar") | When you Consume a Charge, [Trigger](/wiki/Trigger "Trigger") Elemental Surge to gain 2 [Cold Surges](/wiki/Elemental_Surges "Elemental Surges") When you Consume a Charge, [Trigger](/wiki/Trigger "Trigger") Elemental Surge to gain 2 [Fire Surges](/wiki/Elemental_Surges "Elemental Surges") Gain 1 fewer [Lightning Surge](/wiki/Elemental_Surges "Elemental Surges") from [Triggering](/wiki/Trigger "Trigger") Elemental Surge [[1]](/wiki/Passive_Skill:AscendancyHuntress1Notable5 "Passive Skill:AscendancyHuntress1Notable5") |
| [Gemling Legionnaire](/wiki/Gemling_Legionnaire "Gemling Legionnaire") | [Advanced Thaumaturgy](/wiki/Advanced_Thaumaturgy "Advanced Thaumaturgy") | Grants [Thaumaturgical Dynamism](/wiki/Thaumaturgical_Dynamism "Thaumaturgical Dynamism") [[1]](/wiki/Passive_Skill:AscendancyMercenary3Notable4 "Passive Skill:AscendancyMercenary3Notable4") |

### Keystones

The following [Keystones](/wiki/Keystone "Keystone") are related to generic charges:

| Name | Stats |
| --- | --- |
| [Conduit](/wiki/Conduit "Conduit") | If you would gain a Charge, [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") gain that Charge instead [[1]](/wiki/Passive_Skill:Passive~keystone~conduit "Passive Skill:Passive~keystone~conduit") |
| [Resonance](/wiki/Resonance "Resonance") | Gain [Power Charges](/wiki/Power_Charge "Power Charge") instead of [Frenzy Charges](/wiki/Frenzy_Charge "Frenzy Charge") Gain [Frenzy Charges](/wiki/Frenzy_Charge "Frenzy Charge") instead of [Endurance Charges](/wiki/Endurance_Charge "Endurance Charge") Gain [Endurance Charges](/wiki/Endurance_Charge "Endurance Charge") instead of [Power Charges](/wiki/Power_Charge "Power Charge") [[1]](/wiki/Passive_Skill:Passive~keystone~resonance "Passive Skill:Passive~keystone~resonance") |
