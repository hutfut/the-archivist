# Poison

This article is about debuff. For support gem, see [Poison (support gem)](/wiki/Poison_(support_gem) "Poison (support gem)").

Poison

Tooltip

Poison is an [Ailment](/wiki/Ailment "Ailment") that deals [Chaos](/wiki/Chaos_Damage "Chaos Damage") damage over time, and lasts 2 seconds by default. Damage from Poison bypasses [Energy Shield](/wiki/Energy_Shield "Energy Shield").

[Physical](/wiki/Physical "Physical") and [Chaos](/wiki/Chaos_Damage "Chaos Damage") damage from [Hits](/wiki/Hit "Hit") [Contribute](/wiki/Damage_Contributing_to_Ailments "Damage Contributing to Ailments") to Poison [Magnitude](/wiki/Magnitude "Magnitude").

Damage does not [Contribute](/wiki/Damage_Contributing_to_Ailments "Damage Contributing to Ailments") to Poison chance, so it cannot be inflicted without an explicit source of Poison chance.

The base [Magnitude](/wiki/Magnitude "Magnitude") of Poison is [Chaos](/wiki/Chaos_Damage "Chaos Damage") damage per second equal to 20% of the [Pre-mitigation](/wiki/Pre-mitigation_Damage "Pre-mitigation Damage") [Physical](/wiki/Physical "Physical") and [Chaos](/wiki/Chaos_Damage "Chaos Damage") damage of the [Hit](/wiki/Hit "Hit") that inflicted it. This magnitude is not further affected by any modifiers to the damage you deal.

Modifiers and [Debuffs](/wiki/Debuff "Debuff") that affect the enemy's ability to mitigate damage (such as [Shock](/wiki/Shock "Shock")) can affect the damage the enemy takes from Poison, but any such modifiers that specifically apply to [Hit](/wiki/Hit "Hit") damage (such as [Penetration](/wiki/Resistance_Penetration "Resistance Penetration")) do not affect Poison damage.

**Poison** is a damaging [ailment](/wiki/Ailment "Ailment") that deals [chaos](/wiki/Chaos "Chaos") [damage over time](/wiki/Damage_over_time "Damage over time").

## Mechanics

Poison deals 40% of a [hit](/wiki/Hit "Hit")'s combined [physical](/wiki/Physical "Physical") and chaos damage dealt (before mitigation and [damage taken](/wiki/Damage_taken "Damage taken") modifiers) as chaos damage over time over 2 seconds. This percentage is affected multiplicatively by ailment effect/magnitude. Ailment damage cannot be scaled directly; however, it can be indirectly scaled by modifying the hit damage.

Poison can stack and has a default stack limit of 1; this can be increased through various stats or modifiers. Each instance of poison has an independent duration and only the highest damage instance(s) of poisons up to your stack limit will deal damage.

The [character](/wiki/Character "Character")'s poison stack limit also applies to external poison sources such as [Minions](/wiki/Minion "Minion") or [Poison Clouds](/wiki/Poison_Cloud "Poison Cloud").

Poison chance depends on an explicit chance to poison.

The damage over time from poison bypasses [energy shield](/wiki/Energy_shield "Energy shield") and damages life directly.

## Related skills

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Decompose](/wiki/Decompose "Decompose") | *0* |  |  |  |
| [Acidic Concoction](/wiki/Acidic_Concoction "Acidic Concoction") | *0* |  |  |  |
| [Bursting Fen Toad](/wiki/Bursting_Fen_Toad "Bursting Fen Toad") | *0* |  |  |  |
| [Poisonburst Arrow](/wiki/Poisonburst_Arrow "Poisonburst Arrow") | *1* |  |  |  |
| [Vine Arrow](/wiki/Vine_Arrow "Vine Arrow") | *3* |  |  |  |
| [Toxic Growth](/wiki/Toxic_Growth "Toxic Growth") | *5* |  |  |  |
| [Gas Grenade](/wiki/Gas_Grenade "Gas Grenade") | *5* |  |  |  |
| [Gas Arrow](/wiki/Gas_Arrow "Gas Arrow") | *7* |  |  |  |
| [Toxic Domain](/wiki/Toxic_Domain "Toxic Domain") | *13* |  |  |  |

### Persistent skills

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Plague Bearer](/wiki/Plague_Bearer "Plague Bearer") | *4* |  |  |  |
| [Ravenous Swarm](/wiki/Ravenous_Swarm "Ravenous Swarm") | *4* |  |  |  |
| [Herald of Plague](/wiki/Herald_of_Plague "Herald of Plague") | *8* |  |  |  |

## Related support gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Arakaali's Lust](/wiki/Arakaali%27s_Lust "Arakaali's Lust") | *0* |  |  |  |
| [Tacati's Ire](/wiki/Tacati%27s_Ire "Tacati's Ire") | *0* |  |  |  |
| [Corrosion](/wiki/Corrosion "Corrosion") | *1* |  |  |  |
| [Escalating Poison](/wiki/Escalating_Poison "Escalating Poison") | *1* |  |  |  |
| [Poison I](/wiki/Poison_I "Poison I") | *1* |  |  |  |
| [Admixture](/wiki/Admixture "Admixture") | *2* |  |  |  |
| [Bursting Plague](/wiki/Bursting_Plague "Bursting Plague") | *2* |  |  |  |
| [Deadly Poison I](/wiki/Deadly_Poison_I "Deadly Poison I") | *2* |  |  |  |
| [Poison II](/wiki/Poison_II "Poison II") | *3* |  |  |  |
| [Deadly Poison II](/wiki/Deadly_Poison_II "Deadly Poison II") | *4* |  |  |  |
| [Poison III](/wiki/Poison_III "Poison III") | *5* |  |  |  |

## Related base items

| Item | Base item | Item class |  | Stats |
| --- | --- | --- | --- | --- |
| [Antidote Charm](/wiki/Antidote_Charm "Antidote Charm") | — | *[Charm](/wiki/Charm "Charm")* | 24 | Used when you become Poisoned |
| [Toxic Quiver](/wiki/Toxic_Quiver "Toxic Quiver") | — | *[Quiver](/wiki/Quiver "Quiver")* | 39 | (20-30)% chance to Poison on Hit with [Attacks](/wiki/Attack "Attack") |

## Unique Items

:   **Chance to Poison**

| Item | Base item | Item class |  | Stats |
| --- | --- | --- | --- | --- |
| [Murkshaft](/wiki/Murkshaft "Murkshaft") | [Toxic Quiver](/wiki/Toxic_Quiver "Toxic Quiver") | *[Quiver](/wiki/Quiver "Quiver")* | 39 | (20-30)% chance to Poison on Hit with [Attacks](/wiki/Attack "Attack")Adds (6-10) to (13-17) [Physical](/wiki/Physical "Physical") Damage to [Attacks](/wiki/Attack "Attack") Gain (10-15) Mana per enemy killed (10-20)% increased Poison Duration (20-30)% chance to Poison on Hit with [Attacks](/wiki/Attack "Attack") [Blind](/wiki/Blind "Blind") Targets when you Poison them |

:   **While Poisoned**

No results found

:   **Other Poison-related modifier**

| Item | Base item | Item class |  | Stats |
| --- | --- | --- | --- | --- |
| [Heart of the Well](/wiki/Heart_of_the_Well "Heart of the Well") | [Diamond](/wiki/Diamond "Diamond") | *[Jewel](/wiki/Jewel "Jewel")* | 1 | <Custom Desecrated prefix> <Custom Desecrated prefix> <Custom Desecrated suffix> <Custom Desecrated suffix>   | <List of mods> | | --- | | (5-10)% chance to [Aggravate](/wiki/Aggravate "Aggravate") [Bleeding](/wiki/Bleeding "Bleeding") on targets you [Hit](/wiki/Hit "Hit") with [Attacks](/wiki/Attack "Attack")  ---  (5-8)% increased [Attack](/wiki/Attack "Attack") Speed while a [Rare or Unique](/wiki/Rarity "Rarity") Enemy is in your [Presence](/wiki/Presence "Presence")  ---  (40-60)% increased [Armour](/wiki/Armour "Armour") from Equipped Body Armour  ---  (30-50)% chance to [Pierce](/wiki/Pierce "Pierce") an Enemy  ---  (10-15)% chance when a [Charm](/wiki/Charm "Charm") is used to use another Charm without consuming Charges  ---  [Charms](/wiki/Charm "Charm") applied to you have (15-25)% increased Effect  ---  Recover (5-10)% of maximum Mana when a [Charm](/wiki/Charm "Charm") is used  ---  (15-25)% increased [Culling Strike](/wiki/Culling_Strike "Culling Strike") Threshold  ---  [Gain](/wiki/Gain "Gain") (9-15)% of Damage as Extra [Lightning](/wiki/Lightning "Lightning") Damage  ---  [Gain](/wiki/Gain "Gain") (7-13)% of Damage as Extra [Chaos](/wiki/Chaos "Chaos") Damage  ---  [Gain](/wiki/Gain "Gain") (9-15)% of Damage as Extra [Fire](/wiki/Fire "Fire") Damage  ---  [Gain](/wiki/Gain "Gain") (9-15)% of Damage as Extra [Cold](/wiki/Cold "Cold") Damage  ---  (15-25)% increased Damage while your [Companion](/wiki/Companion "Companion") is in your [Presence](/wiki/Presence "Presence")  ---  (15-25)% increased [Exposure](/wiki/Exposure "Exposure") Effect  ---  (40-60)% increased [Evasion](/wiki/Evasion "Evasion") Rating from Equipped Body Armour  ---  Regenerate (1-1.5)% of maximum Life per Second if you've used a Life [Flask](/wiki/Flask "Flask") in the past 10 seconds  ---  (10-18)% increased [Cooldown Recovery Rate](/wiki/Cooldown_Recovery_Rate "Cooldown Recovery Rate")  ---  (40-60)% increased [Ice Crystal](/wiki/Ice_Crystal "Ice Crystal") Life  ---  (4-8)% increased [Skill Speed](/wiki/Skill_Speed "Skill Speed")  ---  (15-25)% chance for [Lightning](/wiki/Lightning "Lightning") Damage with [Hits](/wiki/Hit "Hit") to be [Lucky](/wiki/Lucky "Lucky")  ---  (8-16)% increased Mana Cost [Efficiency](/wiki/Efficiency "Efficiency")  ---  (20-30)% increased Mana Regeneration Rate while moving  ---  +1% to all [Maximum Elemental Resistances](/wiki/Maximum_Resistance "Maximum Resistance")  ---  (40-60)% increased [Energy Shield](/wiki/Energy_Shield "Energy Shield") from Equipped Body Armour  ---  [Minions](/wiki/Minion "Minion") gain (10-15)% of their maximum Life as Extra maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield")  ---  [Minions](/wiki/Minion "Minion") Regenerate (1-3)% of maximum Life per second  ---  [Minions](/wiki/Minion "Minion") [Revive](/wiki/Reviving_Minions "Reviving Minions") (5-10)% faster  ---  (8-15)% of Leech is Instant  ---  (5-10)% of Physical Damage prevented [Recouped](/wiki/Recoup "Recoup") as Life  ---  (8-14)% increased speed of [Recoup](/wiki/Recoup "Recoup") Effects  ---  Recover (2-4)% of maximum Life on Killing a Poisoned Enemy  ---  (10-15)% increased Skill Effect Duration  ---  +(2-4)% to Thorns [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance  ---  Gain [Physical](/wiki/Physical "Physical") [Thorns](/wiki/Thorns "Thorns") damage equal to (4-6)% of [Item Armour](/wiki/Defences "Defences") on [Equipped](/wiki/Equipped/edit?redlink=1 "Equipped (page does not exist)") Body Armour  ---  (6-12)% chance for [Trigger](/wiki/Trigger "Trigger") skills to refund half of [Energy](/wiki/Energy "Energy") Spent  ---  (4-8)% increased chance to inflict [Ailments](/wiki/Ailments "Ailments")  ---  Gain additional [Ailment Threshold](/wiki/Ailment_Threshold "Ailment Threshold") equal to (4-10)% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield")  ---  (5-10)% chance to inflict [Bleeding](/wiki/Bleeding "Bleeding") on [Hit](/wiki/Hit "Hit")  ---  (5-10)% chance to Poison on [Hit](/wiki/Hit "Hit")  ---  (4-8)% increased [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance  ---  (6-12)% increased [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus")  ---  (2-3)% of Damage is taken from Mana before Life  ---  [Debuffs](/wiki/Debuff "Debuff") on you expire (4-8)% faster  ---  [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") deal damage (2-4)% faster  ---  (4-8)% increased [Flask](/wiki/Flask "Flask") Effect Duration  ---  Gain (1-2) [Rage](/wiki/Rage "Rage") when [Hit](/wiki/Hit "Hit") by an Enemy  ---  (2-3)% increased [Cooldown Recovery Rate](/wiki/Cooldown_Recovery_Rate "Cooldown Recovery Rate")  ---  (6-12)% increased [Elemental Ailment Threshold](/wiki/Ailment "Ailment")  ---  (2-3)% increased [Attack](/wiki/Attack "Attack") Speed  ---  (2-3)% increased Cast Speed  ---  (4-8)% increased [Flask](/wiki/Flask "Flask") Charges gained  ---  (5-10)% increased [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold")  ---  (2-3)% of Skill Mana Costs [Converted](/wiki/Stat_conversion "Stat conversion") to Life Costs  ---  (2-3)% of Damage taken [Recouped](/wiki/Recoup "Recoup") as Life  ---  (6-12)% increased Life Regeneration rate  ---  Recover (1-2)% of maximum Mana on Kill  ---  (4-8)% increased Mana Regeneration Rate  ---  +1% to [Maximum Cold Resistance](/wiki/Maximum_Cold_Resistance "Maximum Cold Resistance")  ---  +1% to [Maximum Fire Resistance](/wiki/Maximum_Fire_Resistance "Maximum Fire Resistance")  ---  Recover (1-2)% of maximum Life on Kill  ---  +1% to [Maximum Lightning Resistance](/wiki/Maximum_Lightning_Resistance "Maximum Lightning Resistance")  ---  [Minions](/wiki/Minion "Minion") have (2-3)% increased [Attack](/wiki/Attack "Attack") and Cast Speed  ---  [Minions](/wiki/Minion "Minion") have (6-12)% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance")  ---  [Minions](/wiki/Minion "Minion") have +(3-4)% to all Elemental [Resistances](/wiki/Resistances "Resistances")  ---  [Minions](/wiki/Minion "Minion") have (3-12)% additional [Physical](/wiki/Physical "Physical") Damage Reduction  ---  (1-2)% increased Movement Speed  ---  Gain 1 [Rage](/wiki/Rage "Rage") on [Melee](/wiki/Melee "Melee") [Hit](/wiki/Hit "Hit")  ---  (3-8)% increased Skill Effect Duration  ---  (10-5)% reduced [Slowing](/wiki/Slow "Slow") Potency of [Debuffs](/wiki/Debuff "Debuff") on You  ---  (4-8)% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for [Spells](/wiki/Spell "Spell")  ---  (6-12)% increased [Critical Spell Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus")  ---  (6-12)% increased [Stun](/wiki/Stun "Stun") Buildup  ---  Gain additional [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") equal to (4-10)% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") | |
| [Splinter of Lorrata](/wiki/Splinter_of_Lorrata "Splinter of Lorrata") | [Hardwood Spear](/wiki/Hardwood_Spear "Hardwood Spear") | *[Spear](/wiki/Spear "Spear")* | 1 | Adds (2-3) to (6-8) [Physical](/wiki/Physical "Physical") Damage Deal no Elemental Damage 20% increased [Melee](/wiki/Melee "Melee") [Strike](/wiki/Strike "Strike") Range with this weapon Any number of Poisons from this Weapon can affect a target at the same time Always Poison on [Hit](/wiki/Hit "Hit") with this weapon |
| [Plaguefinger](/wiki/Plaguefinger "Plaguefinger") | [Gauze Wraps](/wiki/Gauze_Wraps "Gauze Wraps") | *[Gloves](/wiki/Gloves "Gloves")* | 4 | (30-50)% increased [Evasion](/wiki/Evasion "Evasion") and [Energy Shield](/wiki/Energy_Shield "Energy Shield") (4-6)% increased [Attack](/wiki/Attack "Attack") Speed (20-30)% chance to Poison on [Hit](/wiki/Hit "Hit") [All Damage](/wiki/Damage_type "Damage type") from [Hits](/wiki/Hit "Hit") [Contributes](/wiki/Contributes "Contributes") to Poison Magnitude |
| [Arakaali's Gift](/wiki/Arakaali%27s_Gift "Arakaali's Gift") | [Antidote Charm](/wiki/Antidote_Charm "Antidote Charm") | *[Charm](/wiki/Charm "Charm")* | 24 | Used when you become PoisonedRecover Life equal to (15-20)% of Mana [Flask's](/wiki/Flask "Flask") Recovery Amount when used Recover Mana equal to (15-20)% of Life [Flask's](/wiki/Flask "Flask") Recovery Amount when used |
| [Atsak's Sight](/wiki/Atsak%27s_Sight "Atsak's Sight") | [Veiled Mask](/wiki/Veiled_Mask "Veiled Mask") | *[Helmet](/wiki/Helmet "Helmet")* | 28 | (100-150)% increased [Evasion](/wiki/Evasion "Evasion") and [Energy Shield](/wiki/Energy_Shield "Energy Shield") (30-40)% increased [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance +(10-20) to [Dexterity](/wiki/Dexterity "Dexterity") +(10-20) to [Intelligence](/wiki/Intelligence "Intelligence") [Critical Hits](/wiki/Critical_Hit "Critical Hit") Poison the enemy |
| [Lycosidae](/wiki/Lycosidae "Lycosidae") | [Rampart Tower Shield](/wiki/Rampart_Tower_Shield "Rampart Tower Shield") | *[Shield](/wiki/Shield "Shield")* | 28 | (10-15)% increased [Block](/wiki/Block "Block") chance (60-100)% increased [Armour](/wiki/Armour "Armour") [Accuracy](/wiki/Accuracy "Accuracy") Rating is Doubled [Blocking](/wiki/Block "Block") Damage Poisons the Enemy as though dealing 200 Base [Chaos](/wiki/Chaos "Chaos") Damage |
| [Apep's Supremacy](/wiki/Apep%27s_Supremacy "Apep's Supremacy") | [Voodoo Focus](/wiki/Voodoo_Focus "Voodoo Focus") | *[Focus](/wiki/Focus "Focus")* | 33 | (100-200)% increased [Energy Shield](/wiki/Energy_Shield "Energy Shield") (30-50)% increased [Energy Shield Recharge Rate](/wiki/Energy_Shield_Recharge_Rate "Energy Shield Recharge Rate") (30-50)% [faster start of Energy Shield Recharge](/wiki/Energy_Shield "Energy Shield") 20% of [Elemental](/wiki/Elemental "Elemental") damage from [Hits](/wiki/Hit "Hit") taken as [Chaos](/wiki/Chaos "Chaos") damage +25% chance to be Poisoned |
| [Snakebite](/wiki/Snakebite "Snakebite") | [Spined Bracers](/wiki/Spined_Bracers "Spined Bracers") | *[Gloves](/wiki/Gloves "Gloves")* | 33 | (40-60)% increased [Evasion](/wiki/Evasion "Evasion") Rating +(7-17)% to [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance") (6-10) Life Regeneration per second (20-30)% chance to Poison on [Hit](/wiki/Hit "Hit") Targets can be affected by +1 of your Poisons at the same time |
| [Icefang Orbit](/wiki/Icefang_Orbit "Icefang Orbit") | [Iron Ring](/wiki/Iron_Ring "Iron Ring") | *[Ring](/wiki/Ring "Ring")* | 36 | Adds 1 to 4 [Physical](/wiki/Physical "Physical") Damage to [Attacks](/wiki/Attack "Attack")Adds (5-7) to (9-13) [Physical](/wiki/Physical "Physical") Damage to [Attacks](/wiki/Attack "Attack") +(20-30) to [Dexterity](/wiki/Dexterity "Dexterity") (10-20)% chance to Poison on [Hit](/wiki/Hit "Hit") [All Damage](/wiki/Damage_type "Damage type") taken from [Hits](/wiki/Hit "Hit") while Poisoned [Contributes](/wiki/Contributes "Contributes") to [Magnitude](/wiki/Magnitude "Magnitude") of [Chill](/wiki/Chill "Chill") on you [All Damage](/wiki/Damage_type "Damage type") from [Hits](/wiki/Hit "Hit") against Poisoned targets [Contributes](/wiki/Contributes "Contributes") to [Chill](/wiki/Chill "Chill") [Magnitude](/wiki/Magnitude "Magnitude") (15-25)% increased [Magnitude](/wiki/Magnitude "Magnitude") of Poison you inflict |
| [Quatl's Molt](/wiki/Quatl%27s_Molt "Quatl's Molt") | [Serpentscale Coat](/wiki/Serpentscale_Coat "Serpentscale Coat") | *[Body Armour](/wiki/Body_Armour "Body Armour")* | 36 | (60-80)% increased [Evasion](/wiki/Evasion "Evasion") Rating +(60-80) to maximum Life +(17-23)% to [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance") (10-20) Life Regeneration per second Cannot be Poisoned Gain [Deflection Rating](/wiki/Deflect "Deflect") equal to (40-60)% of [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") |
| [Murkshaft](/wiki/Murkshaft "Murkshaft") | [Toxic Quiver](/wiki/Toxic_Quiver "Toxic Quiver") | *[Quiver](/wiki/Quiver "Quiver")* | 39 | (20-30)% chance to Poison on Hit with [Attacks](/wiki/Attack "Attack")Adds (6-10) to (13-17) [Physical](/wiki/Physical "Physical") Damage to [Attacks](/wiki/Attack "Attack") Gain (10-15) Mana per enemy killed (10-20)% increased Poison Duration (20-30)% chance to Poison on Hit with [Attacks](/wiki/Attack "Attack") [Blind](/wiki/Blind "Blind") Targets when you Poison them |
| [Yriel's Fostering](/wiki/Yriel%27s_Fostering "Yriel's Fostering") | [Strider Vest](/wiki/Strider_Vest "Strider Vest") | *[Body Armour](/wiki/Body_Armour "Body Armour")* | 52 | (100-150)% increased [Evasion](/wiki/Evasion "Evasion") Rating +(80-120) to maximum Life +(10-30) to [Spirit](/wiki/Spirit "Spirit") (60-40)% reduced Duration of [Bleeding](/wiki/Bleeding "Bleeding") on You (60-40)% reduced Poison Duration on you You can have two [Companions](/wiki/Companion "Companion") of different types |

## Related passive skills

The following [passive skills](/wiki/Passive_skill "Passive skill") are related to poison:

### Chance to inflict poison

| Name | Stats |
| --- | --- |
| [Poison Chance](/wiki/Poison_Chance/edit?redlink=1 "Poison Chance (page does not exist)") | 8% chance to Poison on [Hit](/wiki/Hit "Hit") [[1]](/wiki/Passive_Skill:Poison10 "Passive Skill:Poison10") [[2]](/wiki/Passive_Skill:Poison11 "Passive Skill:Poison11") [[3]](/wiki/Passive_Skill:Poison12 "Passive Skill:Poison12") [[4]](/wiki/Passive_Skill:Poison20 "Passive Skill:Poison20") [[5]](/wiki/Passive_Skill:Poison21 "Passive Skill:Poison21") [[6]](/wiki/Passive_Skill:Poison22 "Passive Skill:Poison22") [[7]](/wiki/Passive_Skill:Poison32 "Passive Skill:Poison32") [[8]](/wiki/Passive_Skill:Poison33 "Passive Skill:Poison33") |
| [Coated Knife](/wiki/Coated_Knife/edit?redlink=1 "Coated Knife (page does not exist)") | [Critical Hits](/wiki/Critical_Hit "Critical Hit") with [Daggers](/wiki/Dagger "Dagger") have a 25% chance to Poison the Enemy [[1]](/wiki/Passive_Skill:Dagger17 "Passive Skill:Dagger17") |

### Poison magnitude

| Name | Stats |
| --- | --- |
| [Ignite Magnitude and Poison Magnitude](/wiki/Ignite_Magnitude_and_Poison_Magnitude/edit?redlink=1 "Ignite Magnitude and Poison Magnitude (page does not exist)") | 6% increased [Ignite](/wiki/Ignite "Ignite") [Magnitude](/wiki/Magnitude "Magnitude") 6% increased [Magnitude](/wiki/Magnitude "Magnitude") of Poison you inflict [[1]](/wiki/Passive_Skill:Fire53~ "Passive Skill:Fire53~") |
| [Poison Damage](/wiki/Poison_Damage/edit?redlink=1 "Poison Damage (page does not exist)") | 10% increased [Magnitude](/wiki/Magnitude "Magnitude") of Poison you inflict [[1]](/wiki/Passive_Skill:Poison13 "Passive Skill:Poison13") [[2]](/wiki/Passive_Skill:Poison14 "Passive Skill:Poison14") [[3]](/wiki/Passive_Skill:Poison17 "Passive Skill:Poison17") [[4]](/wiki/Passive_Skill:Poison19 "Passive Skill:Poison19") [[5]](/wiki/Passive_Skill:Poison2 "Passive Skill:Poison2") [[6]](/wiki/Passive_Skill:Poison23 "Passive Skill:Poison23") [[7]](/wiki/Passive_Skill:Poison3 "Passive Skill:Poison3") [[8]](/wiki/Passive_Skill:Poison31 "Passive Skill:Poison31") [[9]](/wiki/Passive_Skill:Poison39~ "Passive Skill:Poison39~") [[10]](/wiki/Passive_Skill:Poison4 "Passive Skill:Poison4") [[11]](/wiki/Passive_Skill:Poison40 "Passive Skill:Poison40") |
| [Poison Duration](/wiki/Poison_Duration/edit?redlink=1 "Poison Duration (page does not exist)") | 10% increased [Magnitude](/wiki/Magnitude "Magnitude") of Poison you inflict [[1]](/wiki/Passive_Skill:Poison7 "Passive Skill:Poison7") |
| [Crippling Toxins](/wiki/Crippling_Toxins/edit?redlink=1 "Crippling Toxins (page does not exist)") | 25% increased [Magnitude](/wiki/Magnitude "Magnitude") of Poison you inflict 25% chance for [Attacks](/wiki/Attack "Attack") to [Maim](/wiki/Maim "Maim") on [Hit](/wiki/Hit "Hit") against Poisoned Enemies [[1]](/wiki/Passive_Skill:Poison18 "Passive Skill:Poison18") |
| [Leeching Toxins](/wiki/Leeching_Toxins/edit?redlink=1 "Leeching Toxins (page does not exist)") | 30% increased [Magnitude](/wiki/Magnitude "Magnitude") of Poison you inflict Recover 2% of maximum Life on Killing a Poisoned Enemy [[1]](/wiki/Passive_Skill:Poison27 "Passive Skill:Poison27") |
| [Low Tolerance](/wiki/Low_Tolerance/edit?redlink=1 "Low Tolerance (page does not exist)") | 60% increased Effect of Poison you inflict on targets that are not Poisoned [[1]](/wiki/Passive_Skill:Poison29 "Passive Skill:Poison29") |
| [Stacking Toxins](/wiki/Stacking_Toxins/edit?redlink=1 "Stacking Toxins (page does not exist)") | Targets can be affected by +1 of your Poisons at the same time 20% reduced [Magnitude](/wiki/Magnitude "Magnitude") of Poison you inflict [[1]](/wiki/Passive_Skill:Poison30 "Passive Skill:Poison30") |

### Poison duration

| Name | Stats |
| --- | --- |
| [Poison Duration](/wiki/Poison_Duration/edit?redlink=1 "Poison Duration (page does not exist)") | 10% increased Poison Duration [[1]](/wiki/Passive_Skill:Poison15 "Passive Skill:Poison15") [[2]](/wiki/Passive_Skill:Poison24~ "Passive Skill:Poison24~") [[3]](/wiki/Passive_Skill:Poison25 "Passive Skill:Poison25") [[4]](/wiki/Passive_Skill:Poison36 "Passive Skill:Poison36") [[5]](/wiki/Passive_Skill:Poison37 "Passive Skill:Poison37") [[6]](/wiki/Passive_Skill:Poison6 "Passive Skill:Poison6") [[7]](/wiki/Passive_Skill:Poison8 "Passive Skill:Poison8") |
| [Building Toxins](/wiki/Building_Toxins/edit?redlink=1 "Building Toxins (page does not exist)") | Targets can be affected by +1 of your Poisons at the same time 25% reduced Poison Duration [[1]](/wiki/Passive_Skill:Poison16 "Passive Skill:Poison16") |
| [Escalating Toxins](/wiki/Escalating_Toxins/edit?redlink=1 "Escalating Toxins (page does not exist)") | 10% increased Poison Duration for each Poison you have inflicted Recently, up to a maximum of 100% [[1]](/wiki/Passive_Skill:Poison9 "Passive Skill:Poison9") |
| [Lasting Toxins](/wiki/Lasting_Toxins/edit?redlink=1 "Lasting Toxins (page does not exist)") | 40% increased Poison Duration 10% increased Skill Effect Duration [[1]](/wiki/Passive_Skill:Poison28 "Passive Skill:Poison28") |
| [Toxic Sludge](/wiki/Toxic_Sludge/edit?redlink=1 "Toxic Sludge (page does not exist)") | 40% increased Duration of Poisons you inflict against [Slowed](/wiki/Slow "Slow") Enemies [[1]](/wiki/Passive_Skill:Poison41 "Passive Skill:Poison41") |

### Poison stacks

| Name | Stats |
| --- | --- |
| [Building Toxins](/wiki/Building_Toxins/edit?redlink=1 "Building Toxins (page does not exist)") | Targets can be affected by +1 of your Poisons at the same time 25% reduced Poison Duration [[1]](/wiki/Passive_Skill:Poison16 "Passive Skill:Poison16") |
| [Stacking Toxins](/wiki/Stacking_Toxins/edit?redlink=1 "Stacking Toxins (page does not exist)") | Targets can be affected by +1 of your Poisons at the same time 20% reduced [Magnitude](/wiki/Magnitude "Magnitude") of Poison you inflict [[1]](/wiki/Passive_Skill:Poison30 "Passive Skill:Poison30") |

### Poison mitigation

| Name | Stats |
| --- | --- |
| [Poison Duration on You](/wiki/Poison_Duration_on_You/edit?redlink=1 "Poison Duration on You (page does not exist)") | 10% reduced Poison Duration on you [[1]](/wiki/Passive_Skill:Azmerianimals62 "Passive Skill:Azmerianimals62") |
| [The Ancient Serpent](/wiki/The_Ancient_Serpent/edit?redlink=1 "The Ancient Serpent (page does not exist)") | Life [Flasks](/wiki/Flask "Flask") gain 0.1 charges per Second 40% reduced Poison Duration on you +10 to [Intelligence](/wiki/Intelligence "Intelligence") [[1]](/wiki/Passive_Skill:Azmerianimals66 "Passive Skill:Azmerianimals66") |

### Miscellany

| Name | Stats |
| --- | --- |
| [Crippling Toxins](/wiki/Crippling_Toxins/edit?redlink=1 "Crippling Toxins (page does not exist)") | 25% increased [Magnitude](/wiki/Magnitude "Magnitude") of Poison you inflict 25% chance for [Attacks](/wiki/Attack "Attack") to [Maim](/wiki/Maim "Maim") on [Hit](/wiki/Hit "Hit") against Poisoned Enemies [[1]](/wiki/Passive_Skill:Poison18 "Passive Skill:Poison18") |
| [Dread Engineer's Concoction](/wiki/Dread_Engineer%27s_Concoction/edit?redlink=1 "Dread Engineer's Concoction (page does not exist)") | 35% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Ignite](/wiki/Ignite "Ignite") against Poisoned enemies [[1]](/wiki/Passive_Skill:Fire54 "Passive Skill:Fire54") |
| [Leeching Toxins](/wiki/Leeching_Toxins/edit?redlink=1 "Leeching Toxins (page does not exist)") | 30% increased [Magnitude](/wiki/Magnitude "Magnitude") of Poison you inflict Recover 2% of maximum Life on Killing a Poisoned Enemy [[1]](/wiki/Passive_Skill:Poison27 "Passive Skill:Poison27") |
| [Tolerant Equipment](/wiki/Tolerant_Equipment/edit?redlink=1 "Tolerant Equipment (page does not exist)") | Immune to [Bleeding](/wiki/Bleeding "Bleeding") if Equipped Helmet has higher [Armour](/wiki/Armour "Armour") than [Evasion](/wiki/Evasion "Evasion") Rating Immune to Poison if Equipped Helmet has higher [Evasion](/wiki/Evasion "Evasion") Rating than [Armour](/wiki/Armour "Armour") [[1]](/wiki/Passive_Skill:Armour~and~evasion40 "Passive Skill:Armour~and~evasion40") |
| [Toxic Tolerance](/wiki/Toxic_Tolerance/edit?redlink=1 "Toxic Tolerance (page does not exist)") | Immune to Poison [[1]](/wiki/Passive_Skill:Poison38 "Passive Skill:Poison38") |

### Paths Not Taken passive skills

The following passive skills are exclusive the [Oracle](/wiki/Oracle "Oracle") with [The Unseen Path](/wiki/The_Unseen_Path "The Unseen Path") allocated:

| Name | Stats |
| --- | --- |
| [Chance to Poison and Spell Damage](/wiki/Chance_to_Poison_and_Spell_Damage/edit?redlink=1 "Chance to Poison and Spell Damage (page does not exist)") | 8% chance to Poison on [Hit](/wiki/Hit "Hit") 12% increased [Spell](/wiki/Spell "Spell") Damage [[1]](/wiki/Passive_Skill:Oracle~spell~poison1~ "Passive Skill:Oracle~spell~poison1~") [[2]](/wiki/Passive_Skill:Oracle~spell~poison2 "Passive Skill:Oracle~spell~poison2") [[3]](/wiki/Passive_Skill:Oracle~spell~poison3 "Passive Skill:Oracle~spell~poison3") |
| [Poison Chance](/wiki/Poison_Chance/edit?redlink=1 "Poison Chance (page does not exist)") | 10% chance to Poison on [Hit](/wiki/Hit "Hit") [[1]](/wiki/Passive_Skill:Oracle~poison1 "Passive Skill:Oracle~poison1") [[2]](/wiki/Passive_Skill:Oracle~poison2 "Passive Skill:Oracle~poison2") |
| [Poison Damage](/wiki/Poison_Damage/edit?redlink=1 "Poison Damage (page does not exist)") | 12% increased [Magnitude](/wiki/Magnitude "Magnitude") of Poison you inflict [[1]](/wiki/Passive_Skill:Oracle~poison3 "Passive Skill:Oracle~poison3") [[2]](/wiki/Passive_Skill:Oracle~poison4 "Passive Skill:Oracle~poison4") |
| [First Sting](/wiki/First_Sting "First Sting") | 80% increased Effect of Poison you inflict on targets that are not Poisoned 30% chance to Poison on [Hit](/wiki/Hit "Hit") against Enemies that are not Poisoned [[1]](/wiki/Passive_Skill:Oracle~poison5 "Passive Skill:Oracle~poison5") |

### Ascendancy passive skills

The following [Ascendancy passive skills](/wiki/Ascendancy_passive_skill "Ascendancy passive skill") are related to poison:

| Ascendancy Class | Name | Stats |
| --- | --- | --- |
| [Pathfinder](/wiki/Pathfinder "Pathfinder") | [Acidic Concoction](/wiki/Acidic_Concoction_(passive) "Acidic Concoction (passive)") | Grants Skill: [Acidic Concoction](/wiki/Acidic_Concoction "Acidic Concoction") [[1]](/wiki/Passive_Skill:AscendancyRanger3Notable7~4 "Passive Skill:AscendancyRanger3Notable7~4") |
| [Pathfinder](/wiki/Pathfinder "Pathfinder") | [Poison Effect](/wiki/Poison_Effect/edit?redlink=1 "Poison Effect (page does not exist)") | 12% increased [Magnitude](/wiki/Magnitude "Magnitude") of Poison you inflict [[1]](/wiki/Passive_Skill:AscendancyRanger3Small1 "Passive Skill:AscendancyRanger3Small1") [[2]](/wiki/Passive_Skill:AscendancyRanger3Small2 "Passive Skill:AscendancyRanger3Small2") |
| [Pathfinder](/wiki/Pathfinder "Pathfinder") | [Overwhelming Toxicity](/wiki/Overwhelming_Toxicity "Overwhelming Toxicity") | Double the number of your Poisons that targets can be affected by at the same time 35% less Poison Duration [[1]](/wiki/Passive_Skill:AscendancyRanger3Notable4 "Passive Skill:AscendancyRanger3Notable4") |
