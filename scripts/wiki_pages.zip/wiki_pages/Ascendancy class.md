# Ascendancy class

Ascendancy classes, or simply "ascendancies," are subclasses that allow players to further refine their character's [class](/wiki/Character_class "Character class") by making use of special abilities, skills, and modifiers that enable certain archetypes. Ascendancies can be unlocked by completing [Ascension Trials](/wiki/Ascension_Trial "Ascension Trial") through the campaign and endgame. For more information on each trial and their requirements, see the [Ascension Trials](/wiki/Ascension_Trials "Ascension Trials") page.

## Overview

Currently, there are 20 regular ascendancy classes available. The full release will have at least 3 Ascendancy Classes for each class, for a total of 36.

Choosing an ascendancy class after completing an [Ascension Trial](/wiki/Ascension_Trial "Ascension Trial") for the first time will unlock a unique ascendancy skill tree that functions similarly to the larger [Passive Skill Tree](/wiki/Passive_Skill_Tree "Passive Skill Tree"): the player earns ascendancy skill points which can be spent on allocating nodes granting [passive bonuses](/wiki/Passive "Passive") and in some cases special skills. The tree can be accessed anytime from the center of the [Passive Skill Tree](/wiki/Passive_Skill_Tree "Passive Skill Tree") window. Players can complete 4 tiers of [Ascension Trials](/wiki/Ascension_Trials "Ascension Trials"), each granting 2 ascendancy skill points for a total of 8.

## Alternate ascendancy classes

Alternate versions of existing ascendancy classes can also be unlocked. Currently, the [Abyssal Lich](/wiki/Abyssal_Lich "Abyssal Lich") is the only alternate ascendancy available and is unlocked by defeating the final [Abyss](/wiki/Abyss "Abyss") boss while the player has already ascended into a [Lich](/wiki/Lich "Lich").
