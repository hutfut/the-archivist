# Armour

This article is about the defensive stat. For equipment classified as armour, see [Armour (equipment)](/wiki/Armour_(equipment) "Armour (equipment)").

Armour

Tooltip

Armour reduces [Damage taken from Hits](/wiki/Hit "Hit"). By default, Armour only applies to [Physical](/wiki/Physical "Physical") [Damage](/wiki/Hit "Hit").

Damage reduction from Armour is proportional to the amount of [Damage](/wiki/Hit "Hit"), and is more effective at reducing smaller hits.

**Armour** is a [defence](/wiki/Defence "Defence") that provides [damage reduction](/wiki/Damage_reduction "Damage reduction") to incoming [physical damage](/wiki/Physical_damage "Physical damage") from [hits](/wiki/Hit "Hit"). The % of damage reduced depends on the size of the incoming hit relative to the armour value and cannot exceed 90%. Armour is associated with [strength](/wiki/Strength "Strength").

## Mechanics

Armour grants physical damage reduction, with the exact amount of damage reduction depending on the ratio of armour to the physical damage of the hit. If the armour value is significantly larger than the damage, most of the damage is prevented. If the armour value is similar to or less than the incoming damage, only a small percentage of that damage will be prevented. As a result, armour is more effective against many smaller hits rather than fewer larger hits, even if the total damage dealt would be identical.

Armour never mitigates [damage over time](/wiki/Damage_over_time "Damage over time"), as armour only applies to hits. [Bleed](/wiki/Bleed "Bleed") is an [ailment](/wiki/Ailment "Ailment") that deals physical damage over time that is based on the physical damage dealt by a skill before [mitigation](/wiki/Mitigation "Mitigation"); armour will reduce the hit damage but not the damage over time. However, both the hit damage and the damage over time can be mitigated with sources of #% additional Physical Damage Reduction. The maximum total physical damage reduction from all sources is 90%.

Normally Armour only applies to physical damage; however, it can be made to apply to other damage types through items or passive skills, such as [Blackbraid](/wiki/Blackbraid "Blackbraid") or [Doryani's Prototype](/wiki/Doryani%27s_Prototype "Doryani's Prototype"). In such cases, the armour value applies independently to each [damage type](/wiki/Damage_type "Damage type"). The maximum elemental or chaos damage reduction is also 90%.

Armour cannot reduce an instance of damage to below 1.

### Rule of thumb

* To prevent **one third of damage** (33%), you need armour **5 times** the damage (e.g. 500 armour for 100 damage)
* To prevent **half of damage** (50%), you need armour **10 times** the damage (e.g. 1000 armour for 100 damage)
* To prevent **two thirds of damage** (66%), you need armour **20 times** the damage (e.g. 2000 armour for 100 damage)
* To prevent **three quarters of damage** (75%), you need armour **30 times** the damage (e.g. 3000 armour for 100 damage)
* To prevent **90%** of damage, you need armour **90 times** the damage (e.g. 9000 armour for 100 damage)

When the damage of a hit significantly exceeds Armour, it will never prevent more damage than the armour value divided by 10 (e.g. 1000 armour will never prevent more than 100 damage at its minimum percentage prevention).

## Armour formulas

**This section needs to be updated**.

**Reason:** New graphs for 0.1.1 changes

Please [update this article](https://www.poe2wiki.net/wiki/Armour/edit) to reflect newly available information.

### Relative damage reduction

The following is the base formula that can be used to calculate the damage reduction gained from armour[[1]](#cite_note-1):

D
R
(
A
,

D

r
a
w
)
=

A

A
+
10
∗

D

r
a
w
\color [rgb]{0.6392156862745098,0.5529411764705883,0.42745098039215684}DR(A,D\_{raw})={A \over A+10\*D\_{raw}}

where A is the defender's armour rating and Draw is the raw physical damage.

#### Required armour rating

To calculate the armour rating required to mitigate a given amount of damage at a specific ratio, the following formula can be used:

A
(

D

r
a
w
,
D
R
)
=

D
R
∗
10
∗

D

r
a
w

1
−
D
R
\color [rgb]{0.6392156862745098,0.5529411764705883,0.42745098039215684}A(D\_{raw},DR)={DR\*10\*D\_{raw} \over 1-DR}

### Examples

% Mitigated Damage as a function of Incoming Damage and Armour Rating

## Related mechanics

### Armour Break

Main article: [Armour break](/wiki/Armour_break "Armour break")

[Armour Break](/wiki/Armour_Break "Armour Break") is a [debuff](/wiki/Debuff "Debuff") that reduced Armour by a specified amount. When a target's Armour is broken to 0, it has Fully Broken Armour, which interact with certain mechanics. Enemies (but not players) with Fully Broken Armour also take 20% increased physical damage from hits.

### Bear form

Main article: [Bear](/wiki/Bear "Bear")

While [Shapeshifted](/wiki/Shapeshift "Shapeshift") into a [Bear](/wiki/Bear "Bear"), you gain +10 Armour per character level and +30% of your Armour also applies to elemental damage.

## Related skills

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Raise Shield](/wiki/Raise_Shield "Raise Shield") | *0* |  |  |  |
| [Shield Charge](/wiki/Shield_Charge "Shield Charge") | *3* |  |  |  |
| [Skeletal Frost Mage](/wiki/Skeletal_Frost_Mage "Skeletal Frost Mage") | *5* |  |  |  |
| [Vulnerability](/wiki/Vulnerability "Vulnerability") | *7* |  |  |  |
| [Shield Wall](/wiki/Shield_Wall "Shield Wall") | *7* |  |  |  |

### Persistent skills

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Sorcery Ward](/wiki/Sorcery_Ward "Sorcery Ward") | *0* |  |  |  |
| [Scavenged Plating](/wiki/Scavenged_Plating "Scavenged Plating") | *4* |  |  |  |
| [Barkskin](/wiki/Barkskin "Barkskin") | *8* |  |  |  |
| [Defiance Banner](/wiki/Defiance_Banner "Defiance Banner") | *8* |  |  |  |

## Support gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Refraction I](/wiki/Refraction_I "Refraction I") | *2* |  |  |  |
| [Refraction II](/wiki/Refraction_II "Refraction II") | *3* |  |  |  |
| [Refraction III](/wiki/Refraction_III "Refraction III") | *5* |  |  |  |

## Related base items

| Item | Base item | Item class |  | Stats |
| --- | --- | --- | --- | --- |
| [Plate Belt](/wiki/Plate_Belt "Plate Belt") | — | *[Belt](/wiki/Belt "Belt")* | 25 | Has (1-3) [Charm](/wiki/Charm "Charm") Slots +(100-140) to Armour |
| [Warlord Cuirass](/wiki/Warlord_Cuirass "Warlord Cuirass") | — | *[Body Armour](/wiki/Body_Armour "Body Armour")* | 80 | +(15-25)% of Armour also applies to [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") |

## Related unique items

| Item | Base item | Item class |  | Stats |
| --- | --- | --- | --- | --- |
| [Grip of Kulemak](/wiki/Grip_of_Kulemak "Grip of Kulemak") | [Abyssal Signet](/wiki/Abyssal_Signet "Abyssal Signet") | *[Ring](/wiki/Ring "Ring")* | 1 | Inflict [Abyssal Wasting](/wiki/Abyssal_Wasting/edit?redlink=1 "Abyssal Wasting (page does not exist)") on [Hit](/wiki/Hit "Hit")(30-20)% reduced [Presence](/wiki/Presence "Presence") Area of Effect (30-20)% reduced [Light Radius](/wiki/Light_Radius "Light Radius")   | <Can gain 0-4 custom [Desecrated Modifiers](/wiki/Desecrated_Modifier "Desecrated Modifier")> (Hidden) | | --- | | (60-100)% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Abyssal Wasting](/wiki/Abyssal_Wasting/edit?redlink=1 "Abyssal Wasting (page does not exist)") you inflict  ---  [Abyssal Wasting](/wiki/Abyssal_Wasting/edit?redlink=1 "Abyssal Wasting (page does not exist)") you inflict has Infinite Duration  ---  [Abyssal Wasting](/wiki/Abyssal_Wasting/edit?redlink=1 "Abyssal Wasting (page does not exist)") also applies -(8-6)% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance")  ---  +(20-30)% of Armour also applies to [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage")  ---  [Gain](/wiki/Gain "Gain") (8-12)% of Damage as Extra [Fire](/wiki/Fire "Fire") Damage  ---  (20-10)% faster [Curse](/wiki/Curse "Curse") Activation  ---  +(20-25) to [Spirit](/wiki/Spirit "Spirit") while you have at least 200 [Strength](/wiki/Strength "Strength")  ---  (20-30)% increased [Ignite](/wiki/Ignite "Ignite") [Magnitude](/wiki/Magnitude "Magnitude")  ---  (30-40)% increased Armour  ---  (15-25)% increased Area of Effect of [Curses](/wiki/Curse "Curse")  ---  [Debuffs](/wiki/Debuff "Debuff") you inflict have (12-20)% increased [Slow Magnitude](/wiki/Slow_Magnitude_Modifier/edit?redlink=1 "Slow Magnitude Modifier (page does not exist)")  ---  (6-10)% increased [Spirit](/wiki/Spirit "Spirit")  ---  (4-6)% increased [Strength](/wiki/Strength "Strength")  ---  +1 to Maximum [Endurance Charges](/wiki/Endurance_Charge "Endurance Charge")  ---  Hits against you have (20-30)% reduced [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus")  ---  (20-10)% reduced [Slowing](/wiki/Slow "Slow") Potency of [Debuffs](/wiki/Debuff "Debuff") on You  ---  (10-16)% increased Skill Effect Duration  ---  (6-10)% increased [Spirit](/wiki/Spirit "Spirit") [Reservation](/wiki/Reservation "Reservation") [Efficiency](/wiki/Efficiency "Efficiency") of Skills  ---  (30-50)% increased [Thorns](/wiki/Thorns "Thorns") damage if you've consumed an [Endurance Charge](/wiki/Endurance_Charge "Endurance Charge") [Recently](/wiki/Recently "Recently")  ---  You and [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") have +(17-23)% to [Chaos](/wiki/Chaos "Chaos") Resistance  ---  You and [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") have (10-14)% increased [Cooldown Recovery Rate](/wiki/Cooldown_Recovery_Rate "Cooldown Recovery Rate")  ---  (30-40)% increased [Accuracy](/wiki/Accuracy "Accuracy") Rating against Enemies affected by [Abyssal Wasting](/wiki/Abyssal_Wasting/edit?redlink=1 "Abyssal Wasting (page does not exist)")  ---  (20-30)% of Mana [Leeched](/wiki/Leech "Leech") from targets affected by [Abyssal Wasting](/wiki/Abyssal_Wasting/edit?redlink=1 "Abyssal Wasting (page does not exist)") is Instant  ---  [Abyssal Wasting](/wiki/Abyssal_Wasting/edit?redlink=1 "Abyssal Wasting (page does not exist)") also applies -(8-6)% to [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance")  ---  (20-30)% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Chill](/wiki/Chill "Chill") you inflict  ---  (25-40)% increased [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance  ---  [Gain](/wiki/Gain "Gain") (8-12)% of Damage as Extra [Cold](/wiki/Cold "Cold") Damage  ---  (10-14)% of Damage is taken from Mana before Life  ---  Recover (3-5)% of your maximum Mana when an Enemy dies in your [Presence](/wiki/Presence "Presence")  ---  (15-25)% [faster start of Energy Shield Recharge](/wiki/Energy_Shield "Energy Shield")  ---  +(20-25) to [Spirit](/wiki/Spirit "Spirit") while you have at least 200 [Intelligence](/wiki/Intelligence "Intelligence")  ---  Gain [Arcane Surge](/wiki/Arcane_Surge "Arcane Surge") when a [Minion](/wiki/Minion "Minion") Dies  ---  (30-40)% increased maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield")  ---  (4-6)% increased [Intelligence](/wiki/Intelligence "Intelligence")  ---  [Spell](/wiki/Spell "Spell") Skills have (9-18)% increased Area of Effect  ---  (40-60)% increased Mana Regeneration Rate while [Surrounded](/wiki/Surrounded "Surrounded")  ---  (5-10)% increased maximum Mana  ---  +1 to Maximum [Power Charges](/wiki/Power_Charge "Power Charge")  ---  [Meta](/wiki/Meta "Meta") Skills gain (10-16)% increased [Energy](/wiki/Energy "Energy")  ---  2% increased Cast Speed per 20 [Spirit](/wiki/Spirit "Spirit")  ---  (10-20)% increased Cost [Efficiency](/wiki/Efficiency "Efficiency") of Skills if you've consumed a [Power Charge](/wiki/Power_Charge "Power Charge") [Recently](/wiki/Recently "Recently")  ---  [Triggered](/wiki/Trigger "Trigger") [Spells](/wiki/Spell "Spell") deal (25-40)% increased [Spell](/wiki/Spell "Spell") Damage  ---  You and [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") have (11-16)% increased Cast Speed  ---  (30-40)% increased chance to inflict [Ailments](/wiki/Ailments "Ailments") against Enemies affected by [Abyssal Wasting](/wiki/Abyssal_Wasting/edit?redlink=1 "Abyssal Wasting (page does not exist)")  ---  (20-30)% of Life [Leeched](/wiki/Leech "Leech") from targets affected by [Abyssal Wasting](/wiki/Abyssal_Wasting/edit?redlink=1 "Abyssal Wasting (page does not exist)") is Instant  ---  [Abyssal Wasting](/wiki/Abyssal_Wasting/edit?redlink=1 "Abyssal Wasting (page does not exist)") also applies -(8-6)% to [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance")  ---  Projectiles have (40-50)% chance for an additional Projectile when [Forking](/wiki/Fork "Fork")  ---  (15-25)% increased [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus")  ---  [Gain](/wiki/Gain "Gain") (8-12)% of Damage as Extra [Lightning](/wiki/Lightning "Lightning") Damage  ---  Recover (2-3)% of your maximum Life when an Enemy dies in your [Presence](/wiki/Presence "Presence")  ---  Gain [Deflection Rating](/wiki/Deflect "Deflect") equal to (10-20)% of [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating")  ---  +(20-25) to [Spirit](/wiki/Spirit "Spirit") while you have at least 200 [Dexterity](/wiki/Dexterity "Dexterity")  ---  Gain [Onslaught](/wiki/Onslaught "Onslaught") for 4 seconds when a [Minion](/wiki/Minion "Minion") Dies  ---  (9-18)% increased Area of Effect for [Attacks](/wiki/Attack "Attack")  ---  (4-6)% increased [Dexterity](/wiki/Dexterity "Dexterity")  ---  (30-40)% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating")  ---  (20-30)% increased amount of Life [Leeched](/wiki/Leech "Leech") if you've consumed a [Frenzy Charge](/wiki/Frenzy_Charge "Frenzy Charge") [Recently](/wiki/Recently "Recently")  ---  (30-40)% increased Life Regeneration rate while [Surrounded](/wiki/Surrounded "Surrounded")  ---  +1 to Maximum [Frenzy Charges](/wiki/Frenzy_Charge "Frenzy Charge")  ---  (5-10)% increased maximum Life  ---  1% increased [Attack](/wiki/Attack "Attack") Speed per 20 [Spirit](/wiki/Spirit "Spirit")  ---  [Projectiles](/wiki/Projectile "Projectile") have (10-16)% chance to [Chain](/wiki/Chain "Chain") an additional time from terrain  ---  (15-25)% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Shock](/wiki/Shock "Shock") you inflict  ---  You and [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") have (20-28)% increased [Accuracy](/wiki/Accuracy "Accuracy") Rating  ---  You and [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") have (7-12)% increased [Attack](/wiki/Attack "Attack") Speed | |
| [Blackbraid](/wiki/Blackbraid "Blackbraid") | [Fur Plate](/wiki/Fur_Plate "Fur Plate") | *[Body Armour](/wiki/Body_Armour "Body Armour")* | 4 | +(40-60) to Armour +(5-15) to [Strength](/wiki/Strength "Strength") +(5-15) to [Intelligence](/wiki/Intelligence "Intelligence") +10% to all [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") +(40-60) to [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") +(100-150)% of Armour also applies to [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") |
| [For Utopia](/wiki/For_Utopia "For Utopia") | [Stone Charm](/wiki/Stone_Charm "Stone Charm") | *[Charm](/wiki/Charm "Charm")* | 8 | Used when you become [Stunned](/wiki/Stun "Stun")Defend with 200% of Armour during effect |
| [Goregirdle](/wiki/Goregirdle "Goregirdle") | [Plate Belt](/wiki/Plate_Belt "Plate Belt") | *[Belt](/wiki/Belt "Belt")* | 25 | Has (1-3) [Charm](/wiki/Charm "Charm") Slots +(100-140) to Armour+(20-30) to [Strength](/wiki/Strength "Strength") (10-20) Life Regeneration per second Defend with 200% of Armour Maximum [Physical Damage](/wiki/Physical_Damage "Physical Damage") Reduction is 50% |
| [Doryani's Prototype](/wiki/Doryani%27s_Prototype "Doryani's Prototype") | [Scale Mail](/wiki/Scale_Mail "Scale Mail") | *[Body Armour](/wiki/Body_Armour "Body Armour")* | 37 | (50-100)% increased Armour and [Evasion](/wiki/Evasion "Evasion") +(60-100) to maximum Life +100% of Armour also applies to [Lightning Damage](/wiki/Lightning_Damage "Lightning Damage") Enemies in your [Presence](/wiki/Presence "Presence") have [Lightning Resistance](/wiki/Lightning_Damage "Lightning Damage") equal to yours [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance") does not affect [Lightning](/wiki/Lightning "Lightning") damage taken |

## Related passive skills

The following [passive skills](/wiki/Passive_skill "Passive skill") are related to armour:

### Base armour rating

| Name | Stats |
| --- | --- |
| Armour | +20 to Armour [[1]](/wiki/Passive_Skill:Armour6 "Passive Skill:Armour6") [[2]](/wiki/Passive_Skill:Armour7 "Passive Skill:Armour7") |
| [Armour and Energy Shield](/wiki/Armour_and_Energy_Shield/edit?redlink=1 "Armour and Energy Shield (page does not exist)") | +10 to Armour +5 to maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") [[1]](/wiki/Passive_Skill:Energy~shield~and~armour1 "Passive Skill:Energy~shield~and~armour1") [[2]](/wiki/Passive_Skill:Placeholder1 "Passive Skill:Placeholder1") |
| [Armour and Evasion](/wiki/Armour_and_Evasion/edit?redlink=1 "Armour and Evasion (page does not exist)") | +10 to Armour +8 to [Evasion](/wiki/Evasion "Evasion") Rating [[1]](/wiki/Passive_Skill:Armour~and~evasion1 "Passive Skill:Armour~and~evasion1") [[2]](/wiki/Passive_Skill:Armour~and~evasion2 "Passive Skill:Armour~and~evasion2") |

### Increased armour

| Name | Stats |
| --- | --- |
| Armour | 15% increased Armour [[1]](/wiki/Passive_Skill:Armour1 "Passive Skill:Armour1") [[2]](/wiki/Passive_Skill:Armour10 "Passive Skill:Armour10") [[3]](/wiki/Passive_Skill:Armour11 "Passive Skill:Armour11") [[4]](/wiki/Passive_Skill:Armour14 "Passive Skill:Armour14") [[5]](/wiki/Passive_Skill:Armour18 "Passive Skill:Armour18") [[6]](/wiki/Passive_Skill:Armour19 "Passive Skill:Armour19") [[7]](/wiki/Passive_Skill:Armour20 "Passive Skill:Armour20") [[8]](/wiki/Passive_Skill:Armour21~ "Passive Skill:Armour21~") [[9]](/wiki/Passive_Skill:Armour22 "Passive Skill:Armour22") [[10]](/wiki/Passive_Skill:Armour23 "Passive Skill:Armour23") [[11]](/wiki/Passive_Skill:Armour28~ "Passive Skill:Armour28~") [[12]](/wiki/Passive_Skill:Armour4~ "Passive Skill:Armour4~") [[13]](/wiki/Passive_Skill:Armour5 "Passive Skill:Armour5") [[14]](/wiki/Passive_Skill:Armour8 "Passive Skill:Armour8") [[15]](/wiki/Passive_Skill:Armour9 "Passive Skill:Armour9")  ---  20% increased Armour if you haven't been [Hit](/wiki/Hit "Hit") [Recently](/wiki/Recently "Recently") [[2]](/wiki/Passive_Skill:Armour2~~ "Passive Skill:Armour2~~")  ---  18% increased Armour [[5]](/wiki/Passive_Skill:Armour25 "Passive Skill:Armour25") [[6]](/wiki/Passive_Skill:Armour27 "Passive Skill:Armour27")  ---  20% increased Armour if you have been [Hit](/wiki/Hit "Hit") [Recently](/wiki/Recently "Recently") [[4]](/wiki/Passive_Skill:Armour3 "Passive Skill:Armour3")  ---  10% increased Armour +5% of Armour also applies to [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") [[13]](/wiki/Passive_Skill:Armour46 "Passive Skill:Armour46") [[14]](/wiki/Passive_Skill:Armour47 "Passive Skill:Armour47") [[15]](/wiki/Passive_Skill:Armour48 "Passive Skill:Armour48") |
| [Armour and Applies to Lightning Damage](/wiki/Armour_and_Applies_to_Lightning_Damage/edit?redlink=1 "Armour and Applies to Lightning Damage (page does not exist)") | 10% increased Armour +10% of Armour also applies to [Lightning Damage](/wiki/Lightning_Damage "Lightning Damage") [[1]](/wiki/Passive_Skill:Armour42 "Passive Skill:Armour42") [[2]](/wiki/Passive_Skill:Armour43 "Passive Skill:Armour43") [[3]](/wiki/Passive_Skill:Armour44 "Passive Skill:Armour44") |
| [Armour and Applies to Cold Damage](/wiki/Armour_and_Applies_to_Cold_Damage/edit?redlink=1 "Armour and Applies to Cold Damage (page does not exist)") | 10% increased Armour +10% of Armour also applies to [Cold Damage](/wiki/Cold_Damage "Cold Damage") [[1]](/wiki/Passive_Skill:Armour38 "Passive Skill:Armour38") [[2]](/wiki/Passive_Skill:Armour39 "Passive Skill:Armour39") [[3]](/wiki/Passive_Skill:Armour40 "Passive Skill:Armour40") |
| [Armour and Applies to Fire Damage](/wiki/Armour_and_Applies_to_Fire_Damage/edit?redlink=1 "Armour and Applies to Fire Damage (page does not exist)") | 10% increased Armour +10% of Armour also applies to [Fire Damage](/wiki/Fire_Damage "Fire Damage") [[1]](/wiki/Passive_Skill:Armour13~ "Passive Skill:Armour13~") [[2]](/wiki/Passive_Skill:Armour15 "Passive Skill:Armour15") [[3]](/wiki/Passive_Skill:Armour16 "Passive Skill:Armour16") |
| [Armour and Energy Shield](/wiki/Armour_and_Energy_Shield/edit?redlink=1 "Armour and Energy Shield (page does not exist)") | 12% increased Armour 12% increased maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") [[1]](/wiki/Passive_Skill:Energy~shield~and~armour10 "Passive Skill:Energy~shield~and~armour10") [[2]](/wiki/Passive_Skill:Energy~shield~and~armour16~ "Passive Skill:Energy~shield~and~armour16~") [[3]](/wiki/Passive_Skill:Energy~shield~and~armour17 "Passive Skill:Energy~shield~and~armour17") [[4]](/wiki/Passive_Skill:Energy~shield~and~armour18 "Passive Skill:Energy~shield~and~armour18") [[5]](/wiki/Passive_Skill:Energy~shield~and~armour19 "Passive Skill:Energy~shield~and~armour19") [[6]](/wiki/Passive_Skill:Energy~shield~and~armour2 "Passive Skill:Energy~shield~and~armour2") [[7]](/wiki/Passive_Skill:Energy~shield~and~armour20 "Passive Skill:Energy~shield~and~armour20") [[8]](/wiki/Passive_Skill:Energy~shield~and~armour27 "Passive Skill:Energy~shield~and~armour27") [[9]](/wiki/Passive_Skill:Energy~shield~and~armour3 "Passive Skill:Energy~shield~and~armour3") [[10]](/wiki/Passive_Skill:Energy~shield~and~armour4 "Passive Skill:Energy~shield~and~armour4") [[11]](/wiki/Passive_Skill:Energy~shield~and~armour5 "Passive Skill:Energy~shield~and~armour5") [[12]](/wiki/Passive_Skill:Energy~shield~and~armour6~ "Passive Skill:Energy~shield~and~armour6~") [[13]](/wiki/Passive_Skill:Energy~shield~and~armour7 "Passive Skill:Energy~shield~and~armour7") [[14]](/wiki/Passive_Skill:Energy~shield~and~armour8 "Passive Skill:Energy~shield~and~armour8") [[15]](/wiki/Passive_Skill:Energy~shield~and~armour9 "Passive Skill:Energy~shield~and~armour9")  ---  10% increased Armour 10% increased maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") [[3]](/wiki/Passive_Skill:Energy~shield~and~armour26 "Passive Skill:Energy~shield~and~armour26") [[4]](/wiki/Passive_Skill:Energy~shield~and~armour30 "Passive Skill:Energy~shield~and~armour30") |
| [Armour and Energy Shield Delay](/wiki/Armour_and_Energy_Shield_Delay/edit?redlink=1 "Armour and Energy Shield Delay (page does not exist)") | 12% increased Armour 12% [faster start of Energy Shield Recharge](/wiki/Energy_Shield "Energy Shield") [[1]](/wiki/Passive_Skill:Energy~shield~and~armour32~ "Passive Skill:Energy~shield~and~armour32~") [[2]](/wiki/Passive_Skill:Energy~shield~and~armour34 "Passive Skill:Energy~shield~and~armour34") |
| [Armour and Evasion while Surrounded](/wiki/Armour_and_Evasion_while_Surrounded/edit?redlink=1 "Armour and Evasion while Surrounded (page does not exist)") | 20% increased Armour while [Surrounded](/wiki/Surrounded "Surrounded") 20% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") while [Surrounded](/wiki/Surrounded "Surrounded") [[1]](/wiki/Passive_Skill:Being~surrounded17~ "Passive Skill:Being~surrounded17~") [[2]](/wiki/Passive_Skill:Being~surrounded18 "Passive Skill:Being~surrounded18") [[3]](/wiki/Passive_Skill:Being~surrounded19 "Passive Skill:Being~surrounded19") |
| [Armour Break and Armour](/wiki/Armour_Break_and_Armour/edit?redlink=1 "Armour Break and Armour (page does not exist)") | [Break](/wiki/Break "Break") 15% increased Armour 10% increased Armour [[1]](/wiki/Passive_Skill:Armour~break3~ "Passive Skill:Armour~break3~") [[2]](/wiki/Passive_Skill:Armour~break6 "Passive Skill:Armour~break6") |
| [Armour if Consumed Endurance Charge](/wiki/Armour_if_Consumed_Endurance_Charge/edit?redlink=1 "Armour if Consumed Endurance Charge (page does not exist)") | 20% increased Armour if you've consumed an [Endurance Charge](/wiki/Endurance_Charge "Endurance Charge") [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Endurance~charges10 "Passive Skill:Endurance~charges10") [[2]](/wiki/Passive_Skill:Endurance~charges11 "Passive Skill:Endurance~charges11") [[3]](/wiki/Passive_Skill:Endurance~charges12 "Passive Skill:Endurance~charges12") |
| [Armour if Hit](/wiki/Armour_if_Hit/edit?redlink=1 "Armour if Hit (page does not exist)") | 20% increased Armour if you have been [Hit](/wiki/Hit "Hit") [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Getting~hit1 "Passive Skill:Getting~hit1") [[2]](/wiki/Passive_Skill:Getting~hit2 "Passive Skill:Getting~hit2") |
| [Armour while Surrounded](/wiki/Armour_while_Surrounded/edit?redlink=1 "Armour while Surrounded (page does not exist)") | 30% increased Armour while [Surrounded](/wiki/Surrounded "Surrounded") [[1]](/wiki/Passive_Skill:Being~surrounded1 "Passive Skill:Being~surrounded1") [[2]](/wiki/Passive_Skill:Being~surrounded2 "Passive Skill:Being~surrounded2") |
| [Endurance Charge Duration and Armour](/wiki/Endurance_Charge_Duration_and_Armour/edit?redlink=1 "Endurance Charge Duration and Armour (page does not exist)") | 10% increased [Endurance Charge](/wiki/Endurance_Charge "Endurance Charge") Duration 10% increased Armour if you've consumed an [Endurance Charge](/wiki/Endurance_Charge "Endurance Charge") [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Power~endurance~charges4 "Passive Skill:Power~endurance~charges4") [[2]](/wiki/Passive_Skill:Power~endurance~charges5 "Passive Skill:Power~endurance~charges5") |
| [Fire Damage and Armour](/wiki/Fire_Damage_and_Armour/edit?redlink=1 "Fire Damage and Armour (page does not exist)") | 6% increased [Fire](/wiki/Fire "Fire") Damage 10% increased Armour [[1]](/wiki/Passive_Skill:Fire49~ "Passive Skill:Fire49~") [[2]](/wiki/Passive_Skill:Ignite~mitigation2 "Passive Skill:Ignite~mitigation2") |
| [Life Leech. Armour and Evasion while Leeching](/wiki/Life_Leech._Armour_and_Evasion_while_Leeching/edit?redlink=1 "Life Leech. Armour and Evasion while Leeching (page does not exist)") | 8% increased Armour and [Evasion](/wiki/Evasion "Evasion") Rating while Leeching 8% increased amount of Life [Leeched](/wiki/Leech "Leech") [[1]](/wiki/Passive_Skill:Life~leech1 "Passive Skill:Life~leech1") [[2]](/wiki/Passive_Skill:Life~leech2 "Passive Skill:Life~leech2") |
| [Shapeshifted Armour](/wiki/Shapeshifted_Armour/edit?redlink=1 "Shapeshifted Armour (page does not exist)") | 10% increased Armour while [Shapeshifted](/wiki/Shapeshifting "Shapeshifting") +5% of Armour also applies to [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") while [Shapeshifted](/wiki/Shapeshifting "Shapeshifting") [[1]](/wiki/Passive_Skill:Bear13 "Passive Skill:Bear13") [[2]](/wiki/Passive_Skill:Bear4 "Passive Skill:Bear4") [[3]](/wiki/Passive_Skill:Bear9 "Passive Skill:Bear9") |
| [Ancient Aegis](/wiki/Ancient_Aegis/edit?redlink=1 "Ancient Aegis (page does not exist)") | 60% increased Armour from Equipped Body Armour 60% increased [Energy Shield](/wiki/Energy_Shield "Energy Shield") from Equipped Body Armour [[1]](/wiki/Passive_Skill:Energy~shield~and~armour11 "Passive Skill:Energy~shield~and~armour11") |
| [Backup Plan](/wiki/Backup_Plan/edit?redlink=1 "Backup Plan (page does not exist)") | 50% increased Armour if you haven't been [Hit](/wiki/Hit "Hit") [Recently](/wiki/Recently "Recently") 50% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") if you have been [Hit](/wiki/Hit "Hit") [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Armour~and~evasion13 "Passive Skill:Armour~and~evasion13") |
| [Devoted Protector](/wiki/Devoted_Protector/edit?redlink=1 "Devoted Protector (page does not exist)") | 15% [faster start of Energy Shield Recharge](/wiki/Energy_Shield "Energy Shield") 15% increased Armour +15% of Armour also applies to [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") +5 to [Strength](/wiki/Strength "Strength") and [Intelligence](/wiki/Intelligence "Intelligence") [[1]](/wiki/Passive_Skill:Templar~druid~notable2 "Passive Skill:Templar~druid~notable2") |
| [Fortifying Blood](/wiki/Fortifying_Blood/edit?redlink=1 "Fortifying Blood (page does not exist)") | 40% increased Armour and [Evasion](/wiki/Evasion "Evasion") Rating while Leeching 20% increased amount of Life [Leeched](/wiki/Leech "Leech") [[1]](/wiki/Passive_Skill:Life~leech13 "Passive Skill:Life~leech13") |
| [Hide of the Bear](/wiki/Hide_of_the_Bear/edit?redlink=1 "Hide of the Bear (page does not exist)") | 40% increased Armour while [Shapeshifted](/wiki/Shapeshifting "Shapeshifting") 25% increased [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") while [Shapeshifted](/wiki/Shapeshifting "Shapeshifting") +1% to [Maximum Fire Resistance](/wiki/Maximum_Fire_Resistance "Maximum Fire Resistance") while [Shapeshifted](/wiki/Shapeshifting "Shapeshifting") [[1]](/wiki/Passive_Skill:Bear11 "Passive Skill:Bear11") |
| [Honourless](/wiki/Honourless/edit?redlink=1 "Honourless (page does not exist)") | 50% increased [Melee Damage](/wiki/Melee "Melee") against [Immobilised](/wiki/Immobilised "Immobilised") Enemies 25% increased Armour if you've [Hit](/wiki/Hit "Hit") an Enemy with a [Melee Attack](/wiki/Melee "Melee") [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Melee51~ "Passive Skill:Melee51~") |
| [Made to Last](/wiki/Made_to_Last/edit?redlink=1 "Made to Last (page does not exist)") | 5% of Physical Damage prevented [Recouped](/wiki/Recoup "Recoup") as Life 30% increased Armour [[1]](/wiki/Passive_Skill:Armour34 "Passive Skill:Armour34") |
| [Molten Carapace](/wiki/Molten_Carapace/edit?redlink=1 "Molten Carapace (page does not exist)") | +2% to [Maximum Fire Resistance](/wiki/Maximum_Fire_Resistance "Maximum Fire Resistance") while [Ignited](/wiki/Ignite "Ignite") 50% increased [Fire](/wiki/Fire "Fire") Damage while [Ignited](/wiki/Ignite "Ignite") 50% increased Armour while [Ignited](/wiki/Ignite "Ignite") [[1]](/wiki/Passive_Skill:Ignite~mitigation4 "Passive Skill:Ignite~mitigation4") |
| [Polished Iron](/wiki/Polished_Iron/edit?redlink=1 "Polished Iron (page does not exist)") | Gain additional [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") equal to 30% of [Item Armour](/wiki/Defences "Defences") on [Equipped Armour Items](/wiki/Armour_(equipment) "Armour (equipment)") 25% increased Armour [[1]](/wiki/Passive_Skill:Armour12 "Passive Skill:Armour12") |
| [Projectile Bulwark](/wiki/Projectile_Bulwark/edit?redlink=1 "Projectile Bulwark (page does not exist)") | 30% increased Armour Defend with 120% of Armour against [Projectile](/wiki/Projectile "Projectile") [Attacks](/wiki/Attack "Attack") [[1]](/wiki/Passive_Skill:Armour31 "Passive Skill:Armour31") |
| [Relentless](/wiki/Relentless/edit?redlink=1 "Relentless (page does not exist)") | 15% increased Armour Regenerate 0.5% of maximum Life per second +10 to [Strength](/wiki/Strength "Strength") [[1]](/wiki/Passive_Skill:Marauder~brute~notable2 "Passive Skill:Marauder~brute~notable2") |
| [Spiral into Depression](/wiki/Spiral_into_Depression/edit?redlink=1 "Spiral into Depression (page does not exist)") | 25% increased Armour 25% increased maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") 3% increased Movement Speed [[1]](/wiki/Passive_Skill:Energy~shield~and~armour14 "Passive Skill:Energy~shield~and~armour14") |
| [Sturdy Metal](/wiki/Sturdy_Metal/edit?redlink=1 "Sturdy Metal (page does not exist)") | 80% increased Armour from Equipped Body Armour [[1]](/wiki/Passive_Skill:Armour35 "Passive Skill:Armour35") |
| [Tempered Defences](/wiki/Tempered_Defences/edit?redlink=1 "Tempered Defences (page does not exist)") | 25% increased Armour +15% of Armour also applies to [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") [[1]](/wiki/Passive_Skill:Armour49 "Passive Skill:Armour49") |
| [Vengeful Fury](/wiki/Vengeful_Fury/edit?redlink=1 "Vengeful Fury (page does not exist)") | Gain 5 [Rage](/wiki/Rage "Rage") when [Hit](/wiki/Hit "Hit") by an Enemy Every [Rage](/wiki/Rage "Rage") also grants 1% increased Armour [[1]](/wiki/Passive_Skill:Rage18 "Passive Skill:Rage18") |

### Armour applies to non-physical damage

| Name | Stats |
| --- | --- |
| Armour | 10% increased Armour +5% of Armour also applies to [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") [[1]](/wiki/Passive_Skill:Armour46 "Passive Skill:Armour46") [[2]](/wiki/Passive_Skill:Armour47 "Passive Skill:Armour47") [[3]](/wiki/Passive_Skill:Armour48 "Passive Skill:Armour48") |
| [Armour and Applies to Lightning Damage](/wiki/Armour_and_Applies_to_Lightning_Damage/edit?redlink=1 "Armour and Applies to Lightning Damage (page does not exist)") | 10% increased Armour +10% of Armour also applies to [Lightning Damage](/wiki/Lightning_Damage "Lightning Damage") [[1]](/wiki/Passive_Skill:Armour42 "Passive Skill:Armour42") [[2]](/wiki/Passive_Skill:Armour43 "Passive Skill:Armour43") [[3]](/wiki/Passive_Skill:Armour44 "Passive Skill:Armour44") |
| [Armour and Applies to Cold Damage](/wiki/Armour_and_Applies_to_Cold_Damage/edit?redlink=1 "Armour and Applies to Cold Damage (page does not exist)") | 10% increased Armour +10% of Armour also applies to [Cold Damage](/wiki/Cold_Damage "Cold Damage") [[1]](/wiki/Passive_Skill:Armour38 "Passive Skill:Armour38") [[2]](/wiki/Passive_Skill:Armour39 "Passive Skill:Armour39") [[3]](/wiki/Passive_Skill:Armour40 "Passive Skill:Armour40") |
| [Armour and Applies to Fire Damage](/wiki/Armour_and_Applies_to_Fire_Damage/edit?redlink=1 "Armour and Applies to Fire Damage (page does not exist)") | 10% increased Armour +10% of Armour also applies to [Fire Damage](/wiki/Fire_Damage "Fire Damage") [[1]](/wiki/Passive_Skill:Armour13~ "Passive Skill:Armour13~") [[2]](/wiki/Passive_Skill:Armour15 "Passive Skill:Armour15") [[3]](/wiki/Passive_Skill:Armour16 "Passive Skill:Armour16") |
| [Armour Applies to Cold Damage Hits](/wiki/Armour_Applies_to_Cold_Damage_Hits/edit?redlink=1 "Armour Applies to Cold Damage Hits (page does not exist)") | +15% of Armour also applies to [Cold Damage](/wiki/Cold_Damage "Cold Damage") [[1]](/wiki/Passive_Skill:Maximum~resistances6 "Passive Skill:Maximum~resistances6") [[2]](/wiki/Passive_Skill:Maximum~resistances7~ "Passive Skill:Maximum~resistances7~") |
| [Armour Applies to Fire Damage Hits](/wiki/Armour_Applies_to_Fire_Damage_Hits/edit?redlink=1 "Armour Applies to Fire Damage Hits (page does not exist)") | +15% of Armour also applies to [Fire Damage](/wiki/Fire_Damage "Fire Damage") [[1]](/wiki/Passive_Skill:Maximum~resistances2 "Passive Skill:Maximum~resistances2") [[2]](/wiki/Passive_Skill:Maximum~resistances3~ "Passive Skill:Maximum~resistances3~") |
| [Armour Applies to Lightning Damage Hits](/wiki/Armour_Applies_to_Lightning_Damage_Hits/edit?redlink=1 "Armour Applies to Lightning Damage Hits (page does not exist)") | +15% of Armour also applies to [Lightning Damage](/wiki/Lightning_Damage "Lightning Damage") [[1]](/wiki/Passive_Skill:Maximum~resistances10 "Passive Skill:Maximum~resistances10") [[2]](/wiki/Passive_Skill:Maximum~resistances11 "Passive Skill:Maximum~resistances11") |
| [Energy Shield and Armour applies to Elemental Damage Hits](/wiki/Energy_Shield_and_Armour_applies_to_Elemental_Damage_Hits/edit?redlink=1 "Energy Shield and Armour applies to Elemental Damage Hits (page does not exist)") | +5% of Armour also applies to [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") 12% increased maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") [[1]](/wiki/Passive_Skill:Energy~shield~and~armour31 "Passive Skill:Energy~shield~and~armour31") [[2]](/wiki/Passive_Skill:Energy~shield~and~armour33 "Passive Skill:Energy~shield~and~armour33") |
| [Shapeshifted Armour](/wiki/Shapeshifted_Armour/edit?redlink=1 "Shapeshifted Armour (page does not exist)") | 10% increased Armour while [Shapeshifted](/wiki/Shapeshifting "Shapeshifting") +5% of Armour also applies to [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") while [Shapeshifted](/wiki/Shapeshifting "Shapeshifting") [[1]](/wiki/Passive_Skill:Bear13 "Passive Skill:Bear13") [[2]](/wiki/Passive_Skill:Bear4 "Passive Skill:Bear4") [[3]](/wiki/Passive_Skill:Bear9 "Passive Skill:Bear9") |
| [Shapeshifting Armour applies to Elemental Damage Hits](/wiki/Shapeshifting_Armour_applies_to_Elemental_Damage_Hits/edit?redlink=1 "Shapeshifting Armour applies to Elemental Damage Hits (page does not exist)") | +8% of Armour also applies to [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") while [Shapeshifted](/wiki/Shapeshifting "Shapeshifting") [[1]](/wiki/Passive_Skill:Shapeshifting35 "Passive Skill:Shapeshifting35") |
| [Chillproof](/wiki/Chillproof/edit?redlink=1 "Chillproof (page does not exist)") | +30% of Armour also applies to [Cold Damage](/wiki/Cold_Damage "Cold Damage") 30% reduced Effect of [Chill](/wiki/Chill "Chill") on you 30% increased [Freeze Threshold](/wiki/Freeze_Threshold/edit?redlink=1 "Freeze Threshold (page does not exist)") [[1]](/wiki/Passive_Skill:Armour41 "Passive Skill:Armour41") |
| [Devoted Protector](/wiki/Devoted_Protector/edit?redlink=1 "Devoted Protector (page does not exist)") | 15% [faster start of Energy Shield Recharge](/wiki/Energy_Shield "Energy Shield") 15% increased Armour +15% of Armour also applies to [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") +5 to [Strength](/wiki/Strength "Strength") and [Intelligence](/wiki/Intelligence "Intelligence") [[1]](/wiki/Passive_Skill:Templar~druid~notable2 "Passive Skill:Templar~druid~notable2") |
| [Heatproof](/wiki/Heatproof/edit?redlink=1 "Heatproof (page does not exist)") | +30% of Armour also applies to [Fire Damage](/wiki/Fire_Damage "Fire Damage") 30% reduced [Magnitude](/wiki/Magnitude "Magnitude") of [Ignite](/wiki/Ignite "Ignite") on you [[1]](/wiki/Passive_Skill:Armour17 "Passive Skill:Armour17") |
| [Insulating Hide](/wiki/Insulating_Hide/edit?redlink=1 "Insulating Hide (page does not exist)") | +20% of Armour also applies to [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") while [Shapeshifted](/wiki/Shapeshifting "Shapeshifting") 20% [faster start of Energy Shield Recharge](/wiki/Energy_Shield "Energy Shield") while [Shapeshifted](/wiki/Shapeshifting "Shapeshifting") [[1]](/wiki/Passive_Skill:Shapeshifting37 "Passive Skill:Shapeshifting37") |
| [Prism Guard](/wiki/Prism_Guard/edit?redlink=1 "Prism Guard (page does not exist)") | +30% of Armour also applies to [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") [[1]](/wiki/Passive_Skill:Maximum~resistances21 "Passive Skill:Maximum~resistances21") |
| [Shockproof](/wiki/Shockproof/edit?redlink=1 "Shockproof (page does not exist)") | +30% of Armour also applies to [Lightning Damage](/wiki/Lightning_Damage "Lightning Damage") 30% reduced [effect](/wiki/Buff "Buff") of [Shock](/wiki/Shock "Shock") on you [[1]](/wiki/Passive_Skill:Armour45~ "Passive Skill:Armour45~") |
| [Tempered Defences](/wiki/Tempered_Defences/edit?redlink=1 "Tempered Defences (page does not exist)") | 25% increased Armour +15% of Armour also applies to [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") [[1]](/wiki/Passive_Skill:Armour49 "Passive Skill:Armour49") |

### Miscellany

| Name | Stats |
| --- | --- |
| [Thorns Ignore Armour](/wiki/Thorns_Ignore_Armour/edit?redlink=1 "Thorns Ignore Armour (page does not exist)") | [Thorns Damage](/wiki/Thorns "Thorns") has 25% chance to ignore Enemy Armour [[1]](/wiki/Passive_Skill:Getting~hit16 "Passive Skill:Getting~hit16") [[2]](/wiki/Passive_Skill:Getting~hit18 "Passive Skill:Getting~hit18") |
| [Adamant Recovery](/wiki/Adamant_Recovery/edit?redlink=1 "Adamant Recovery (page does not exist)") | Increases and Reductions to Armour also apply to [Energy Shield](/wiki/Energy_Shield "Energy Shield") [Recharge Rate](/wiki/Energy_Shield "Energy Shield") at 40% of their value [[1]](/wiki/Passive_Skill:Energy~shield~and~armour12 "Passive Skill:Energy~shield~and~armour12") |
| [Blade Catcher](/wiki/Blade_Catcher/edit?redlink=1 "Blade Catcher (page does not exist)") | Defend with 200% of Armour against [Critical Hits](/wiki/Critical_Hit "Critical Hit") +15 to [Strength](/wiki/Strength "Strength") [[1]](/wiki/Passive_Skill:Armour32 "Passive Skill:Armour32") |
| [Breakage](/wiki/Breakage/edit?redlink=1 "Breakage (page does not exist)") | [Break](/wiki/Break "Break") 60% increased Armour 10% chance to Defend with 200% of Armour [[1]](/wiki/Passive_Skill:Armour~break34 "Passive Skill:Armour~break34") |
| [Defiance](/wiki/Defiance/edit?redlink=1 "Defiance (page does not exist)") | 120% increased Armour and [Evasion](/wiki/Evasion "Evasion") Rating when on [Low Life](/wiki/Low_Life "Low Life") [[1]](/wiki/Passive_Skill:Armour~and~evasion12 "Passive Skill:Armour~and~evasion12") |
| [Fortified Location](/wiki/Fortified_Location/edit?redlink=1 "Fortified Location (page does not exist)") | 10% increased Armour and [Evasion](/wiki/Evasion "Evasion") Rating per Summoned [Totem](/wiki/Totem "Totem") in your [Presence](/wiki/Presence "Presence") 10% increased [Attack](/wiki/Attack "Attack") Damage per Summoned [Totem](/wiki/Totem "Totem") in your [Presence](/wiki/Presence "Presence") [[1]](/wiki/Passive_Skill:Ballista17 "Passive Skill:Ballista17") |
| [General's Bindings](/wiki/General%27s_Bindings "General's Bindings") | [Gain](/wiki/Gain "Gain") 8% of [Evasion](/wiki/Evasion "Evasion") Rating as extra Armour [[1]](/wiki/Passive_Skill:Armour37 "Passive Skill:Armour37") |
| [Heavy Armour](/wiki/Heavy_Armour/edit?redlink=1 "Heavy Armour (page does not exist)") | 150% of [Strength](/wiki/Strength "Strength") Requirements from Boots, Gloves and Helmets also added to Armour [[1]](/wiki/Passive_Skill:Armour33 "Passive Skill:Armour33") |
| [Impenetrable Shell](/wiki/Impenetrable_Shell/edit?redlink=1 "Impenetrable Shell (page does not exist)") | Defend with 150% of Armour against [Hits](/wiki/Hit "Hit") from Enemies that are further than 6m away [[1]](/wiki/Passive_Skill:Armour36 "Passive Skill:Armour36") |
| [Insulated Treads](/wiki/Insulated_Treads/edit?redlink=1 "Insulated Treads (page does not exist)") | Gain [Ailment Threshold](/wiki/Ailment_Threshold "Ailment Threshold") equal to the lowest of [Evasion](/wiki/Evasion "Evasion") and Armour on your Boots [[1]](/wiki/Passive_Skill:Armour~and~evasion14~~ "Passive Skill:Armour~and~evasion14~~") |
| [Iron Slippers](/wiki/Iron_Slippers/edit?redlink=1 "Iron Slippers (page does not exist)") | +3 to Armour per 1 [Item Energy Shield](/wiki/Defences "Defences") on Equipped Boots 10% reduced [Slowing](/wiki/Slow "Slow") Potency of [Debuffs](/wiki/Debuff "Debuff") on You [[1]](/wiki/Passive_Skill:Energy~shield~and~armour29~ "Passive Skill:Energy~shield~and~armour29~") |
| [Leather Bound Gauntlets](/wiki/Leather_Bound_Gauntlets/edit?redlink=1 "Leather Bound Gauntlets (page does not exist)") | +1 to [Evasion](/wiki/Evasion "Evasion") Rating per 1 [Item Armour](/wiki/Defences "Defences") on Equipped Gloves [[1]](/wiki/Passive_Skill:Evasion38~ "Passive Skill:Evasion38~") |
| [Polished Iron](/wiki/Polished_Iron/edit?redlink=1 "Polished Iron (page does not exist)") | Gain additional [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") equal to 30% of [Item Armour](/wiki/Defences "Defences") on [Equipped Armour Items](/wiki/Armour_(equipment) "Armour (equipment)") 25% increased Armour [[1]](/wiki/Passive_Skill:Armour12 "Passive Skill:Armour12") |
| [Projectile Bulwark](/wiki/Projectile_Bulwark/edit?redlink=1 "Projectile Bulwark (page does not exist)") | 30% increased Armour Defend with 120% of Armour against [Projectile](/wiki/Projectile "Projectile") [Attacks](/wiki/Attack "Attack") [[1]](/wiki/Passive_Skill:Armour31 "Passive Skill:Armour31") |
| [Reinforced Barrier](/wiki/Reinforced_Barrier/edit?redlink=1 "Reinforced Barrier (page does not exist)") | Defend with 120% of Armour while not on [Low Energy Shield](/wiki/Low_Energy_Shield/edit?redlink=1 "Low Energy Shield (page does not exist)") 20% increased maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") [[1]](/wiki/Passive_Skill:Energy~shield~and~armour13 "Passive Skill:Energy~shield~and~armour13") |
| [Ruinic Helm](/wiki/Ruinic_Helm/edit?redlink=1 "Ruinic Helm (page does not exist)") | +1 to Maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") per 8 [Item Armour](/wiki/Defences "Defences") on Equipped Helmet [[1]](/wiki/Passive_Skill:Energy~shield~and~armour35 "Passive Skill:Energy~shield~and~armour35") |
| [Shredding Contraptions](/wiki/Shredding_Contraptions/edit?redlink=1 "Shredding Contraptions (page does not exist)") | Enemies affected by your [Hazards](/wiki/Hazard "Hazard") [Recently](/wiki/Recently "Recently") have 25% reduced Armour Enemies affected by your [Hazards](/wiki/Hazard "Hazard") [Recently](/wiki/Recently "Recently") have 25% reduced [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") [[1]](/wiki/Passive_Skill:Hazards2 "Passive Skill:Hazards2") |
| [Spiked Armour](/wiki/Spiked_Armour "Spiked Armour") | [Thorns Damage](/wiki/Thorns "Thorns") has 50% chance to ignore Enemy Armour [[1]](/wiki/Passive_Skill:Getting~hit11 "Passive Skill:Getting~hit11") |
| [Strong Chin](/wiki/Strong_Chin/edit?redlink=1 "Strong Chin (page does not exist)") | Gain [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") equal to the lowest of [Evasion](/wiki/Evasion "Evasion") and Armour on your Helmet [[1]](/wiki/Passive_Skill:Armour~and~evasion11 "Passive Skill:Armour~and~evasion11") |
| [Tolerant Equipment](/wiki/Tolerant_Equipment/edit?redlink=1 "Tolerant Equipment (page does not exist)") | Immune to [Bleeding](/wiki/Bleeding "Bleeding") if Equipped Helmet has higher Armour than [Evasion](/wiki/Evasion "Evasion") Rating Immune to [Poison](/wiki/Poison "Poison") if Equipped Helmet has higher [Evasion](/wiki/Evasion "Evasion") Rating than Armour [[1]](/wiki/Passive_Skill:Armour~and~evasion40 "Passive Skill:Armour~and~evasion40") |

### Paths Not Taken passive skills

The following passive skills are exclusive the [Oracle](/wiki/Oracle "Oracle") with [The Unseen Path](/wiki/The_Unseen_Path "The Unseen Path") allocated:

| Name | Stats |
| --- | --- |
| Armour | 30% increased Armour while stationary [[1]](/wiki/Passive_Skill:Oracle~crab~claw2 "Passive Skill:Oracle~crab~claw2") [[2]](/wiki/Passive_Skill:Oracle~crab~claw3 "Passive Skill:Oracle~crab~claw3") [[3]](/wiki/Passive_Skill:Oracle~crab~claw4~~ "Passive Skill:Oracle~crab~claw4~~") |
| [Armour and Block Chance](/wiki/Armour_and_Block_Chance/edit?redlink=1 "Armour and Block Chance (page does not exist)") | 15% increased Armour while stationary 5% increased [Block](/wiki/Block "Block") chance [[1]](/wiki/Passive_Skill:Oracle~crab~claw1 "Passive Skill:Oracle~crab~claw1") |
| [Armour while Bleeding](/wiki/Armour_while_Bleeding/edit?redlink=1 "Armour while Bleeding (page does not exist)") | 30% increased Armour while Bleeding [[1]](/wiki/Passive_Skill:Oracle~iron~blood1 "Passive Skill:Oracle~iron~blood1") [[2]](/wiki/Passive_Skill:Oracle~iron~blood2~ "Passive Skill:Oracle~iron~blood2~") [[3]](/wiki/Passive_Skill:Oracle~iron~blood3 "Passive Skill:Oracle~iron~blood3") |
| [Unmoving Craiceann](/wiki/Unmoving_Craiceann "Unmoving Craiceann") | 30% increased Armour while stationary 30% increased Life Regeneration Rate while stationary [[1]](/wiki/Passive_Skill:Oracle~crab~claw5 "Passive Skill:Oracle~crab~claw5") |
| [Vale Dweller](/wiki/Vale_Dweller "Vale Dweller") | 50% increased Armour while Bleeding 50% reduced [Magnitude](/wiki/Magnitude "Magnitude") of [Bleeding](/wiki/Bleeding "Bleeding") on You [[1]](/wiki/Passive_Skill:Oracle~iron~blood4 "Passive Skill:Oracle~iron~blood4") |

### Ascendancy passive skills

The following [Ascendancy passive skills](/wiki/Ascendancy_passive_skill "Ascendancy passive skill") are related to armour:

| Ascendancy Class | Name | Stats |
| --- | --- | --- |
| [Disciple of Varashta](/wiki/Disciple_of_Varashta "Disciple of Varashta") | [Sacred Rituals](/wiki/Sacred_Rituals "Sacred Rituals") | 60% of your current [Energy Shield](/wiki/Energy_Shield "Energy Shield") is added to your Armour for determining your Physical Damage Reduction from Armour [[1]](/wiki/Passive_Skill:AscendancySorceress3Notable1 "Passive Skill:AscendancySorceress3Notable1") |
| [Invoker](/wiki/Invoker "Invoker") | [...and Protect me from Harm](/wiki/...and_Protect_me_from_Harm "...and Protect me from Harm") | 35% less [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") Physical Damage Reduction from Armour is based on your combined Armour and [Evasion](/wiki/Evasion "Evasion") Rating [[1]](/wiki/Passive_Skill:AscendancyMonk2Notable2~ "Passive Skill:AscendancyMonk2Notable2~") |
| [Tactician](/wiki/Tactician "Tactician") | [Armour and Evasion](/wiki/Armour_and_Evasion/edit?redlink=1 "Armour and Evasion (page does not exist)") | 15% increased Armour and [Evasion](/wiki/Evasion "Evasion") Rating [[1]](/wiki/Passive_Skill:AscendancyMercenary1Small6 "Passive Skill:AscendancyMercenary1Small6") [[2]](/wiki/Passive_Skill:AscendancyMercenary1Small7~ "Passive Skill:AscendancyMercenary1Small7~") [[3]](/wiki/Passive_Skill:AscendancyMercenary2Small5 "Passive Skill:AscendancyMercenary2Small5") [[4]](/wiki/Passive_Skill:AscendancyMercenary2Small6 "Passive Skill:AscendancyMercenary2Small6") |
| [Tactician](/wiki/Tactician "Tactician") | [Polish That Gear](/wiki/Polish_That_Gear "Polish That Gear") | Gain [Deflection Rating](/wiki/Deflect "Deflect") equal to 20% of Armour [Gain](/wiki/Gain "Gain") 100% of [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") as extra [Ailment Threshold](/wiki/Ailment_Threshold "Ailment Threshold") [[1]](/wiki/Passive_Skill:AscendancyMercenary1Notable6 "Passive Skill:AscendancyMercenary1Notable6") |
| [Tactician](/wiki/Tactician "Tactician") | [Stay Light, Use Cover](/wiki/Stay_Light,_Use_Cover "Stay Light, Use Cover") | Defend with 200% of Armour Enemies have an [Accuracy](/wiki/Accuracy "Accuracy") Penalty against you based on Distance Maximum Chance to [Evade](/wiki/Evasion "Evasion") is 50% Maximum [Physical Damage](/wiki/Physical_Damage "Physical Damage") Reduction is 50% [[1]](/wiki/Passive_Skill:AscendancyMercenary1Notable7 "Passive Skill:AscendancyMercenary1Notable7") |
| [Titan](/wiki/Titan "Titan") | Armour | 20% increased Armour [[1]](/wiki/Passive_Skill:AscendancyWarrior1Small8 "Passive Skill:AscendancyWarrior1Small8") [[2]](/wiki/Passive_Skill:AscendancyWarrior2Small3 "Passive Skill:AscendancyWarrior2Small3") |
| [Witchhunter](/wiki/Witchhunter "Witchhunter") | [Obsessive Rituals](/wiki/Obsessive_Rituals "Obsessive Rituals") | Grants Skill: [Sorcery Ward](/wiki/Sorcery_Ward "Sorcery Ward") 35% less Armour and [Evasion](/wiki/Evasion "Evasion") Rating [[1]](/wiki/Passive_Skill:AscendancyMercenary2Notable5 "Passive Skill:AscendancyMercenary2Notable5") |

### Keystones

The following [Keystones](/wiki/Keystone "Keystone") are related to armour:

| Name | Stats |
| --- | --- |
| [Circular Teachings](/wiki/Circular_Teachings "Circular Teachings") | Gain no inherent bonus from [Dexterity](/wiki/Dexterity "Dexterity") 1% increased Armour per 2 Dexterity [[1]](/wiki/Passive_Skill:Kalguur~keystone~2 "Passive Skill:Kalguur~keystone~2") |
| [Hollow Palm Technique](/wiki/Hollow_Palm_Technique "Hollow Palm Technique") | Can [Attack](/wiki/Attack "Attack") as though using a [Quarterstaff](/wiki/Quarterstaff "Quarterstaff") while both of your hand slots are empty Unarmed [Attacks](/wiki/Attack "Attack") that would use your [Quarterstaff](/wiki/Quarterstaff "Quarterstaff")'s damage gain: • [Physical](/wiki/Physical "Physical") damage based on their Skill Level • 1% more [Attack](/wiki/Attack "Attack") Speed per 75 [Item Evasion Rating](/wiki/Defences "Defences") on [Equipped Armour Items](/wiki/Armour_(equipment) "Armour (equipment)") • +0.1% to [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") per 10 [Item Energy Shield](/wiki/Defences "Defences") on [Equipped Armour Items](/wiki/Armour_(equipment) "Armour (equipment)") [[1]](/wiki/Passive_Skill:Passive~keystone~hollow~palm~technique "Passive Skill:Passive~keystone~hollow~palm~technique") |
| [Iron Reflexes](/wiki/Iron_Reflexes "Iron Reflexes") | [Converts](/wiki/Stat_conversion "Stat conversion") all [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") to Armour [[1]](/wiki/Passive_Skill:Passive~keystone~iron~reflexes~ "Passive Skill:Passive~keystone~iron~reflexes~") |
| [Scarred Faith](/wiki/Scarred_Faith "Scarred Faith") | 5% of [Physical](/wiki/Physical "Physical") Damage prevented [Recouped](/wiki/Recoup "Recoup") as [Energy Shield](/wiki/Energy_Shield "Energy Shield") per enemy [Power](/wiki/Power "Power") [Energy Shield](/wiki/Energy_Shield "Energy Shield") does not [Recharge](/wiki/Energy_Shield "Energy Shield") You cannot Recover [Energy Shield](/wiki/Energy_Shield "Energy Shield") from Regeneration You cannot Recover [Energy Shield](/wiki/Energy_Shield "Energy Shield") to above Armour [[1]](/wiki/Passive_Skill:Passive~keystone~alternate~es~recovery "Passive Skill:Passive~keystone~alternate~es~recovery") |
