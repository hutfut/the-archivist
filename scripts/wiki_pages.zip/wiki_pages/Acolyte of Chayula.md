# Acolyte of Chayula

Acolyte of Chayula

[Monk](/wiki/Monk "Monk")

|  |  |
| --- | --- |
|  | **The truth of your faith threatens to break your very soul... but in that struggle lies power beyond belief.** |

Official artwork of the Acolyte of Chayula.

**Acolyte of Chayula** is an [Ascendancy class](/wiki/Ascendancy_class "Ascendancy class") for the [Monk](/wiki/Monk "Monk").

## Overview

The Acolyte of Chayula calls upon the power of the Breachlord Chayula. With [Embrace the Darkness](/wiki/Embrace_the_Darkness "Embrace the Darkness"), he can give up his [Spirit](/wiki/Spirit "Spirit") in exchange for Darkness that absorbs damage. [Waking Dream](/wiki/Waking_Dream "Waking Dream") causes Flames of Chayula remnants to spawn around him, which can be picked up for recovery or buffs. [Lucid Dreaming](/wiki/Lucid_Dreaming "Lucid Dreaming") offers the ability to select a specific type of flame and improves the ability to collect [remnants](/wiki/Remnant "Remnant"). The Acolyte has a number of passives that grant or enhance [chaos damage](/wiki/Chaos_damage "Chaos damage"), such as [Sap of Nightmares](/wiki/Sap_of_Nightmares "Sap of Nightmares") to gain chaos damage [leech](/wiki/Leech "Leech"), [Inner Turmoil](/wiki/Inner_Turmoil "Inner Turmoil") to build up and maintain [Volatility](/wiki/Volatility "Volatility") more easily, and [Unravelling](/wiki/Unravelling "Unravelling") to cause chaos damage to inflict an elemental ailment. In addition, he can learn [Void Illusion](/wiki/Void_Illusion "Void Illusion") that leave chaotic explosive illusions on dodge roll, and [Chayula's Gift](/wiki/Chayula%27s_Gift "Chayula's Gift") to build up chaos resistance.

## Passive skills

### Minor skills

This class has the following minor passive skills:

| Name | Stats |
| --- | --- |
| [Chaos Damage](/wiki/Chaos_Damage "Chaos Damage") | 11% increased [Chaos](/wiki/Chaos "Chaos") Damage [[1]](/wiki/Passive_Skill:AscendancyMonk3Small2 "Passive Skill:AscendancyMonk3Small2") |
| [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance") | +7% to [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance") [[1]](/wiki/Passive_Skill:AscendancyMonk3Small4~ "Passive Skill:AscendancyMonk3Small4~") |
| [Damage as Chaos](/wiki/Damage_as_Chaos/edit?redlink=1 "Damage as Chaos (page does not exist)") | [Gain](/wiki/Gain "Gain") 4% of Damage as Extra [Chaos](/wiki/Chaos "Chaos") Damage [[1]](/wiki/Passive_Skill:AscendancyMonk3Small8 "Passive Skill:AscendancyMonk3Small8") |
| [Darkness](/wiki/Darkness "Darkness") | 10% increased maximum Darkness [[1]](/wiki/Passive_Skill:AscendancyMonk3Small7~ "Passive Skill:AscendancyMonk3Small7~") [[2]](/wiki/Passive_Skill:AscendancyMonk3Small9 "Passive Skill:AscendancyMonk3Small9") |
| [Leech](/wiki/Leech "Leech") | 11% increased amount of Life [Leeched](/wiki/Leech "Leech") 11% increased amount of Mana [Leeched](/wiki/Leech "Leech") [[1]](/wiki/Passive_Skill:AscendancyMonk3Small3 "Passive Skill:AscendancyMonk3Small3") |
| [Skill Speed](/wiki/Skill_Speed "Skill Speed") | 4% increased [Skill Speed](/wiki/Skill_Speed "Skill Speed") [[1]](/wiki/Passive_Skill:AscendancyMonk3Small5 "Passive Skill:AscendancyMonk3Small5") [[2]](/wiki/Passive_Skill:AscendancyMonk3Small6 "Passive Skill:AscendancyMonk3Small6") |
| [Volatility](/wiki/Volatility "Volatility") | 10% chance to gain [Volatility](/wiki/Volatility "Volatility") on Kill [[1]](/wiki/Passive_Skill:AscendancyMonk3Small1 "Passive Skill:AscendancyMonk3Small1") |

### Notable skills

This class has the following notable passive skills:

| Skill | | Modifiers | Prerequisite | Preceding Passive |
| --- | --- | --- | --- | --- |
| [Inner Turmoil](/wiki/Inner_Turmoil "Inner Turmoil") | | Gain 1 [Volatility](/wiki/Volatility "Volatility") on inflicting an [Elemental Ailment](/wiki/Elemental_Ailment "Elemental Ailment") Take no Damage from [Volatility](/wiki/Volatility "Volatility") | — | Volatility |
| [Unravelling](/wiki/Unravelling "Unravelling") | | Grants [Unravelling](/wiki/Unravelling "Unravelling") | [Inner Turmoil](/wiki/Inner_Turmoil "Inner Turmoil") | [Chaos Damage](/wiki/Chaos_Damage_(ascendancy_passive_skill) "Chaos Damage (ascendancy passive skill)") |
| [Chayula's Gift](/wiki/Chayula%27s_Gift "Chayula's Gift") | | [Chaos](/wiki/Chaos "Chaos") Resistance is doubled +10% to [Maximum Chaos Resistance](/wiki/Maximum_Chaos_Resistance/edit?redlink=1 "Maximum Chaos Resistance (page does not exist)") | — | [Chaos Resistance](/wiki/Chaos_Resistance_(ascendancy_passive_skill) "Chaos Resistance (ascendancy passive skill)") |
| [Sap of Nightmares](/wiki/Sap_of_Nightmares "Sap of Nightmares") | | [Leech](/wiki/Leech "Leech") recovers based on [Chaos](/wiki/Chaos "Chaos") Damage as well as [Physical](/wiki/Physical "Physical") Damage | — | Leech |
| [Waking Dream](/wiki/Waking_Dream "Waking Dream") | | Grants Skill: [Into the Breach](/wiki/Into_the_Breach "Into the Breach") | — | [Skill Speed](/wiki/Skill_Speed_(ascendancy_passive_skill) "Skill Speed (ascendancy passive skill)") |
| [Lucid Dreaming](/wiki/Lucid_Dreaming "Lucid Dreaming") | [Choice of Life](/wiki/Choice_of_Life "Choice of Life") | All [Flames of Chayula](/wiki/Flames_of_Chayula "Flames of Chayula") that you manifest are [Red](/wiki/Red_Flame_of_Chayula "Red Flame of Chayula") [Remnants](/wiki/Remnant "Remnant") have 50% increased effect [Remnants](/wiki/Remnant "Remnant") can be collected from 50% further away | [Waking Dream](/wiki/Waking_Dream "Waking Dream") | [Skill Speed](/wiki/Skill_Speed_(ascendancy_passive_skill) "Skill Speed (ascendancy passive skill)") |
| [Choice of Mana](/wiki/Choice_of_Mana "Choice of Mana") | All [Flames of Chayula](/wiki/Flames_of_Chayula "Flames of Chayula") that you manifest are [Blue](/wiki/Blue_Flame_of_Chayula "Blue Flame of Chayula") [Remnants](/wiki/Remnant "Remnant") have 50% increased effect [Remnants](/wiki/Remnant "Remnant") can be collected from 50% further away |
| [Choice of Power](/wiki/Choice_of_Power "Choice of Power") | All [Flames of Chayula](/wiki/Flames_of_Chayula "Flames of Chayula") that you manifest are [Purple](/wiki/Purple_Flame_of_Chayula "Purple Flame of Chayula") [Remnants](/wiki/Remnant "Remnant") have 50% increased effect [Remnants](/wiki/Remnant "Remnant") can be collected from 50% further away |
| [Grasp of the Void](/wiki/Grasp_of_the_Void "Grasp of the Void") | | Grants Skill: [Void Illusion](/wiki/Void_Illusion "Void Illusion") | — | Damage as Chaos |
| [Embrace the Darkness](/wiki/Embrace_the_Darkness "Embrace the Darkness") | | +10 to Maximum Darkness per Level Darkness [Reservation](/wiki/Reservation "Reservation") lasts for 5 seconds You have no [Spirit](/wiki/Spirit "Spirit") Base Maximum Darkness is 100 Damage taken is Reserved from Darkness before being taken from Life or [Energy Shield](/wiki/Energy_Shield "Energy Shield") | — | [Darkness](/wiki/Darkness_(ascendancy_passive_skill) "Darkness (ascendancy passive skill)") |
| [Deepening Shadows](/wiki/Deepening_Shadows "Deepening Shadows") | | 1% increased maximum Darkness per 1% [Chaos Resistance](/wiki/Chaos_Damage "Chaos Damage") | [Embrace the Darkness](/wiki/Embrace_the_Darkness "Embrace the Darkness") | [Darkness](/wiki/Darkness_(ascendancy_passive_skill) "Darkness (ascendancy passive skill)") |
