# Ascendancy Class

Redirect to:

* [Ascendancy class](/wiki/Ascendancy_class "Ascendancy class")
