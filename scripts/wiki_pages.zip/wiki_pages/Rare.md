# Rare

Redirect to:

* [Rarity#Rare](/wiki/Rarity#Rare "Rarity")
