# Electrocute

Electrocution

Tooltip

Electrocution is an [Ailment](/wiki/Ailment "Ailment") that interrupts the target's actions and prevents them performing any action, and lasts 5 seconds by default.

Only [Lightning](/wiki/Lightning_Damage "Lightning Damage") damage from [Hits](/wiki/Hit "Hit") with specific skills or effects [Contributes](/wiki/Damage_Contributing_to_Ailments "Damage Contributing to Ailments") to Electrocution Buildup on enemies until they become Electrocuted. Other sources of [Lightning](/wiki/Lightning_Damage "Lightning Damage") damage will not build up towards Electrocution.

**Electrocute** is a non-damaging [ailment](/wiki/Ailment "Ailment") that sets [action speed](/wiki/Action_speed "Action speed") to 0, [immobilising](/wiki/Immobilise "Immobilise") a target. Electrocute is usually inflicted by [lightning damage](/wiki/Lightning_damage "Lightning damage"), but lightning damage cannot inflict electrocute by default.

## Related skills

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Enervating Nova](/wiki/Enervating_Nova "Enervating Nova") | *0* |  |  |  |
| [Moment of Vulnerability](/wiki/Moment_of_Vulnerability "Moment of Vulnerability") | *0* |  |  |  |
| [Electrocuting Arrow](/wiki/Electrocuting_Arrow "Electrocuting Arrow") | *5* |  |  |  |
| [Voltaic Mark](/wiki/Voltaic_Mark "Voltaic Mark") | *7* |  |  |  |
| [Voltaic Grenade](/wiki/Voltaic_Grenade "Voltaic Grenade") | *7* |  |  |  |
| [Shockchain Arrow](/wiki/Shockchain_Arrow "Shockchain Arrow") | *11* |  |  |  |

### Persistent skills

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Combat Frenzy](/wiki/Combat_Frenzy "Combat Frenzy") | *8* |  |  |  |

## Related support gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Electrocute](/wiki/Electrocute_(support_gem) "Electrocute (support gem)") | *2* |  |  |  |
| [Neural Overload](/wiki/Neural_Overload "Neural Overload") | *3* |  |  |  |

## Related unique items

| Item | Base item |  | Stats |
| --- | --- | --- | --- |
| [Brain Rattler](/wiki/Brain_Rattler "Brain Rattler") | [Studded Greatclub](/wiki/Studded_Greatclub "Studded Greatclub") | 16 | Adds (18-22) to (24-28) [Physical](/wiki/Physical "Physical") Damage Adds 1 to (50-55) [Lightning](/wiki/Lightning "Lightning") Damage (10-15)% increased [Attack](/wiki/Attack "Attack") Speed All damage with this Weapon causes [Electrocution](/wiki/Electrocution "Electrocution") buildup |
| [Kitoko's Current](/wiki/Kitoko%27s_Current "Kitoko's Current") | [Jewelled Gloves](/wiki/Jewelled_Gloves "Jewelled Gloves") | 26 | (30-50)% increased [Energy Shield](/wiki/Energy_Shield "Energy Shield") +(10-20) to [Dexterity](/wiki/Dexterity "Dexterity") (15-10)% reduced [Attack](/wiki/Attack "Attack") and Cast Speed [Lightning](/wiki/Lightning "Lightning") damage from [Hits](/wiki/Hit "Hit") [Contributes](/wiki/Contributes "Contributes") to [Electrocution](/wiki/Electrocution "Electrocution") Buildup |
| [Beyond Reach](/wiki/Beyond_Reach "Beyond Reach") | [Visceral Quiver](/wiki/Visceral_Quiver "Visceral Quiver") | 65 | (20-30)% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for [Attacks](/wiki/Attack "Attack")(15-10)% reduced [Attack](/wiki/Attack "Attack") Speed [Chaos](/wiki/Chaos "Chaos") Damage from [Hits](/wiki/Hit "Hit") also [Contributes](/wiki/Contributes "Contributes") to [Freeze](/wiki/Freeze "Freeze") Buildup [Chaos](/wiki/Chaos "Chaos") Damage from [Hits](/wiki/Hit "Hit") also [Contributes](/wiki/Contributes "Contributes") to Electrocute Buildup [Attacks](/wiki/Attack "Attack") [Gain](/wiki/Gain "Gain") (10-20)% of [Physical](/wiki/Physical "Physical") Damage as extra [Chaos](/wiki/Chaos "Chaos") Damage |

## Related passive skills

The following [passive skills](/wiki/Passive_skill "Passive skill") are related to electrocution:

| Name | Stats |
| --- | --- |
| [Electrocute Buildup](/wiki/Electrocute_Buildup/edit?redlink=1 "Electrocute Buildup (page does not exist)") | 15% increased Electrocute Buildup [[1]](/wiki/Passive_Skill:Lightning15 "Passive Skill:Lightning15") [[2]](/wiki/Passive_Skill:Shock~mitigation2 "Passive Skill:Shock~mitigation2") [[3]](/wiki/Passive_Skill:Shock~mitigation3 "Passive Skill:Shock~mitigation3") [[4]](/wiki/Passive_Skill:Shock~mitigation5 "Passive Skill:Shock~mitigation5") [[5]](/wiki/Passive_Skill:Shock~mitigation6~ "Passive Skill:Shock~mitigation6~") [[6]](/wiki/Passive_Skill:Shock~mitigation7 "Passive Skill:Shock~mitigation7") |
| [Lightning Damage and Electrocute Buildup](/wiki/Lightning_Damage_and_Electrocute_Buildup "Lightning Damage and Electrocute Buildup") | 8% increased [Lightning](/wiki/Lightning "Lightning") Damage 10% increased Electrocute Buildup [[1]](/wiki/Passive_Skill:Lightning47 "Passive Skill:Lightning47") [[2]](/wiki/Passive_Skill:Lightning49 "Passive Skill:Lightning49") |
| [Coursing Energy](/wiki/Coursing_Energy/edit?redlink=1 "Coursing Energy (page does not exist)") | 40% increased Electrocute Buildup 30% increased [Shock](/wiki/Shock "Shock") Chance against Electrocuted Enemies [[1]](/wiki/Passive_Skill:Shock~mitigation8~ "Passive Skill:Shock~mitigation8~") |
| [Electrocuting Exposure](/wiki/Electrocuting_Exposure/edit?redlink=1 "Electrocuting Exposure (page does not exist)") | [Gain](/wiki/Gain "Gain") 25% of [Physical](/wiki/Physical "Physical") Damage as Extra [Lightning](/wiki/Lightning "Lightning") Damage against Electrocuted Enemies [[1]](/wiki/Passive_Skill:Shock~mitigation12 "Passive Skill:Shock~mitigation12") |
| [Electrocution](/wiki/Electrocution "Electrocution") | Enemies you Electrocute have 20% increased Damage taken [[1]](/wiki/Passive_Skill:Shock~mitigation4~ "Passive Skill:Shock~mitigation4~") |
| [Electrotherapy](/wiki/Electrotherapy "Electrotherapy") | 30% increased Electrocute Buildup 5% increased [Skill Speed](/wiki/Skill_Speed "Skill Speed") [[1]](/wiki/Passive_Skill:Lightning~penetration29 "Passive Skill:Lightning~penetration29") |
| [Emboldened Avatar](/wiki/Emboldened_Avatar/edit?redlink=1 "Emboldened Avatar (page does not exist)") | 25% increased chance to [Shock](/wiki/Shock "Shock") 50% increased [Flammability](/wiki/Flammability "Flammability") [Magnitude](/wiki/Magnitude "Magnitude") 25% increased [Freeze](/wiki/Freeze "Freeze") Buildup 25% increased Electrocute Buildup [[1]](/wiki/Passive_Skill:Elemental~attacks11 "Passive Skill:Elemental~attacks11") |
| [Thunderstruck](/wiki/Thunderstruck/edit?redlink=1 "Thunderstruck (page does not exist)") | 50% increased Electrocute Buildup against [Shocked](/wiki/Shock "Shock") Enemies 50% increased [Shock](/wiki/Shock "Shock") Chance against Electrocuted Enemies [[1]](/wiki/Passive_Skill:Lightning36 "Passive Skill:Lightning36") |
