# Vendor

A **vendor** or **merchant** is an NPC in any of the main towns across Path of Exile 2's Acts. They offer various items for sale with [item levels](/wiki/Item_level "Item level") comparable to the player's level, up to a cap. The player may also sell items to a vendor for [Gold](/wiki/Gold "Gold") or disenchant items for currency shards.

## Vendor types

Each town area has three types of vendors:

* Weapon/armour vendor: A vendor that sells [martial weapons](/wiki/Martial_weapon "Martial weapon") and [armour](/wiki/Armour "Armour")
* Caster/trinket vendor/Disenchanter: A vendor that sells magical weapons, [jewellery](/wiki/Jewellery "Jewellery"), [flasks](/wiki/Flask "Flask"), [charms](/wiki/Charm "Charm"), and [Scrolls of Wisdom](/wiki/Scroll_of_Wisdom "Scroll of Wisdom") and can disenchant items into currency shards
* Gambler: A vendor that sells equipment with random [base type](/wiki/Base_type/edit?redlink=1 "Base type (page does not exist)") and [rarity](/wiki/Rarity "Rarity")

Some vendors may need to be unlocked through quest or story progression for them to appear in a new playthrough.

Some non-town areas also contain special vendors who may have a modified selection of items to sell.

Recently sold items sold for Gold can be re-purchased from the Buyback tab in case an item was accidentally sold. Items that are disenchanted or [salvaged](/wiki/Salvage_bench "Salvage bench") cannot be reobtained.

Vendors will refresh a portion of their stock whenever you level up. The Gambler gains additional chances to purchase items when you defeat [unique](/wiki/Unique "Unique") monsters.

## Locations

### Act 1

In [Clearfell Encampment](/wiki/Clearfell_Encampment "Clearfell Encampment"):

* [Renly](/wiki/Renly "Renly") - Weapon/armour vendor
* [Una](/wiki/Una "Una") - Caster/trinket vendor & Disenchanter
* [Finn](/wiki/Finn "Finn") - Gambler

### Act 2

In [the Ardura Caravan](/wiki/The_Ardura_Caravan "The Ardura Caravan"):

* [Shambrin](/wiki/Shambrin "Shambrin") - Weapon/armour vendor
* [Zarka](/wiki/Zarka "Zarka") - Caster/trinket vendor & Disenchanter
* [Risu](/wiki/Risu "Risu") - Gambler (available after defeating [Rudja, the Dread Engineer](/wiki/Rudja,_the_Dread_Engineer "Rudja, the Dread Engineer"))

### Act 3

In the [Ziggurat Encampment](/wiki/Ziggurat_Encampment "Ziggurat Encampment"):

* [Oswald](/wiki/Oswald "Oswald") - Weapon/armour vendor
* [Servi](/wiki/Servi "Servi") - Caster/trinket vendor & Disenchanter
* [Alva](/wiki/Alva "Alva") - Gambler

Other vendors that can be found in Act 3 are:

* [Gwendolyn Albright](/wiki/Gwendolyn_Albright "Gwendolyn Albright") ([Jungle Ruins](/wiki/Jungle_Ruins "Jungle Ruins")) - Random vendor
* [Sebastian Carroway](/wiki/Sebastian_Carroway "Sebastian Carroway") ([Infested Barrens](/wiki/Infested_Barrens "Infested Barrens")) - Random vendor
* [Cauldron Keeper](/wiki/Cauldron_Keeper "Cauldron Keeper") ([Apex of Filth](/wiki/Apex_of_Filth "Apex of Filth")) - Caster/trinket vendor

### Act 4

In [Kingsmarch](/wiki/Kingsmarch "Kingsmarch"):

* [Dannig](/wiki/Dannig "Dannig") - Weapon/armour vendor
* [Rog](/wiki/Rog "Rog") - Caster/trinket vendor & Disenchanter
* [Tujen](/wiki/Tujen "Tujen") - Gambler

Other vendors that can be found in Act 4 are:

* [Ruhaki](/wiki/Ruhaki "Ruhaki") ([Ngakanu](/wiki/Ngakanu "Ngakanu")) - Martial weapon vendor (available after rescuing [Matiki](/wiki/Matiki "Matiki"); not available after clearing [The Excavation](/wiki/The_Excavation "The Excavation"))

### Interlude 1

In [The Refuge](/wiki/The_Refuge "The Refuge"):

* [Renly](/wiki/Renly "Renly") - Weapon/armour vendor
* [Una](/wiki/Una "Una") - Caster/trinket vendor & Disenchanter
* [Finn](/wiki/Finn "Finn") - Gambler

Other vendors that can be found in Interlude 1 are:

* [Soul of the Ferryman](/wiki/Soul_of_the_Ferryman "Soul of the Ferryman") - Sells Greater [Runes](/wiki/Rune "Rune")

### Interlude 2

In [The Khari Bazaar](/wiki/The_Khari_Bazaar "The Khari Bazaar"):

* [Sekhema Asala](/wiki/Sekhema_Asala "Sekhema Asala") - Weapon/armour vendor
* [Zarka](/wiki/Zarka "Zarka") - Caster/trinket vendor & Disenchanter
* [Risu](/wiki/Risu "Risu") - Gambler

Other vendors that can be found in Interlude 2 are:

* [Torbik](/wiki/Torbik "Torbik") - Caster/trinket vendor

### Interlude 3

In [The Glade](/wiki/The_Glade "The Glade"):

* [Doryani](/wiki/Doryani "Doryani") - Weapon/armour vendor
* [Delwyn](/wiki/Delwyn "Delwyn") - Caster/trinket vendor & Disenchanter
* [Hilda](/wiki/Hilda "Hilda") - Gambler

### Epilogue

In [the Ziggurat Refuge](/wiki/The_Ziggurat_Refuge "The Ziggurat Refuge"):

* [Zelina](/wiki/Zelina "Zelina") - Weapon/armour vendor
* [Zolin](/wiki/Zolin "Zolin") - Caster/trinket vendor & Disenchanter
* [Alva](/wiki/Alva "Alva") - Gambler
* [Gwennen](/wiki/Gwennen "Gwennen") - specially crafted [weapons](/wiki/Weapon "Weapon"), [quivers](/wiki/Quiver "Quiver"), and [foci](/wiki/Foci "Foci") for [Broken Circle Artifacts](/wiki/Broken_Circle_Artifact "Broken Circle Artifact")
* [Rog](/wiki/Rog "Rog") - specially crafted [armour](/wiki/Armour_(equipment) "Armour (equipment)") and [shields](/wiki/Shield "Shield") for [Order Artifacts](/wiki/Order_Artifact "Order Artifact")
* [Tujen](/wiki/Tujen "Tujen") - specially crafted [jewellery](/wiki/Jewellery "Jewellery") for [Black Scythe Artifacts](/wiki/Black_Scythe_Artifact "Black Scythe Artifact")

## Disenchanting

Any non-Normal rarity items can be destroyed and disenchanted for crafting [currency shards](/wiki/Currency_shard "Currency shard"). This process is irreversible. The resulting currency shard is solely based on the disenchanted item's rarity:

* Magic items give one [Transmutation Shard](/wiki/Transmutation_Shard "Transmutation Shard")
* Rare items give one [Regal Shard](/wiki/Regal_Shard "Regal Shard"), or two if it has 6+ modifiers
* Unique items give one [Chance Shard](/wiki/Chance_Shard "Chance Shard")

Disenchanting can also be used to convert basic [currencies](/wiki/Currency "Currency") into three currencies of a lesser tier (Perfect into 3 Greaters, Greater into 3 regular).

You can also disenchant a [Bind Spectre](/wiki/Bind_Spectre "Bind Spectre") or [Tame Beast](/wiki/Tame_Beast "Tame Beast") gem with a bound monster to unbind it, restoring the gem to its unbound state with the same level and sockets.

## Gambling

Gambling lets you buy an item base of a random rarity, from a choice of a random weapon, armour of each primary/hybrid attributes, or jewelery. During main campaign you can only buy a limited number of items in each Act from gambling vendors. This amount increases by 1 whenever you kill a unique monster in an Act and can store up to 100 purchases. This limit only applies to Gambling Vendors available before reaching [Endgame](/wiki/Endgame "Endgame").

### Merchant maximum item level

The cost of gambling is based on the item class and highest possible item level of the item bought. The item level will be the same as or lower than your character level until hitting the merchant's maximum limit. The exact formula is unknown but non-linear.

Maximum Item Level per vendor

| Act | Vendor | Maximum Item Level |
| --- | --- | --- |
| [Act 1](/wiki/Act_1 "Act 1") | [Finn](/wiki/Finn "Finn") | 15 |
| [Act 2](/wiki/Act_2 "Act 2") | [Risu](/wiki/Risu "Risu") | 32 |
| [Act 3](/wiki/Act_3 "Act 3") | [Alva](/wiki/Alva "Alva") | 44 |
| [Act 4](/wiki/Act_4 "Act 4") | [Tujen](/wiki/Tujen "Tujen") | 53 |
| [Interludes](/wiki/Interlude "Interlude") | [Finn](/wiki/Finn "Finn")/[Risu](/wiki/Risu "Risu")/[Hilda](/wiki/Hilda "Hilda") | 64 |
| [Endgame](/wiki/Endgame "Endgame") | [Ange](/wiki/Ange "Ange") | 82 |

### Item class costs

There are eight different cost tiers. Note that quivers and jewellery have a different formula to armour and weapons. This is most stark when comparing belts to two-handed weapons.

Example costs

| 15 ilvl cost | Quiver-ratio | 71 ilvl cost | Quiver-ratio | Item Classes |
| --- | --- | --- | --- | --- |
| 1512 | 1.00 | 7917 | 1.00 | [Quivers](/wiki/Quivers "Quivers") |
| 771 | 0.51 | 9067 | 1.15 | [Gloves](/wiki/Gloves "Gloves"), [Boots](/wiki/Boots "Boots") |
| 785 | 0.52 | 9123 | 1.15 | [Shields](/wiki/Shields "Shields"), [Foci](/wiki/Foci "Foci"), [Helmets](/wiki/Helmets "Helmets") |
| 867 | 0.57 | 10081 | 1.27 | [Wands](/wiki/Wands "Wands"), [One Hand Maces](/wiki/One_Hand_Maces "One Hand Maces"), [Sceptres](/wiki/Sceptres "Sceptres"), [Bows](/wiki/Bows "Bows"), [Spears](/wiki/Spears "Spears") |
| 1099 | 0.73 | 12897 | 1.63 | [Staves](/wiki/Staves "Staves"), [Two Hand Maces](/wiki/Two_Hand_Maces "Two Hand Maces"), [Quarterstaves](/wiki/Quarterstaves "Quarterstaves"), [Crossbows](/wiki/Crossbows "Crossbows"), [Body Armours](/wiki/Body_Armours "Body Armours") |
| 2420 | 1.60 | 12668 | 1.60 | [Belts](/wiki/Belts "Belts") |
| 3025 | 2.00 | 15835 | 2.00 | [Rings](/wiki/Rings "Rings") |
| 4537 | 3.00 | 23753 | 3.00 | [Amulets](/wiki/Amulets "Amulets") |
