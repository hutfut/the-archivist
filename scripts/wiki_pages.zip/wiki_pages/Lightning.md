# Lightning

Lightning Damage

Tooltip

Lightning damage is one of the five [Damage Types](/wiki/Damage_type "Damage type"). It is reduced by [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance"). Lightning hits have a chance to [Shock](/wiki/Shock "Shock") based on how much Lightning damage is dealt.

**Lightning** [damage](/wiki/Damage "Damage") is one of the five [damage types](/wiki/Damage_type "Damage type"), and one of the three types of [elemental damage](/wiki/Elemental_damage "Elemental damage"). It can be mitigated by lightning [resistance](/wiki/Resistance "Resistance"). Lightning damage can inflict [shock](/wiki/Shock "Shock") and can be made to inflict [electrocute](/wiki/Electrocute "Electrocute") buildup.

Lightning is not usually associated with [damage over time](/wiki/Damage_over_time "Damage over time").

## Mechanics

Lightning damage modifiers usually have an extreme range, with the minimum damage often in the one or two-digit range, but the maximum damage significantly higher than all other damage types. This makes it use the [lucky](/wiki/Lucky "Lucky") mechanic most effectively.

Lightning damage inherently can inflict [shock](/wiki/Shock "Shock"), which increases [damage taken](/wiki/Damage_taken "Damage taken"), and can also be made to inflict electrocute buildup, a [crowd control](/wiki/Crowd_control "Crowd control") effect.

## Gems

A list of [gems](/wiki/Gem "Gem") with the [gem tag](/wiki/Gem_tag "Gem tag"): [Category:Lightning (gem tag)](/wiki/Category:Lightning_(gem_tag) "Category:Lightning (gem tag)")

### Skill gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Lightning Arrow](/wiki/Lightning_Arrow "Lightning Arrow") | *1* |  |  |  |
| [Lightning Rod](/wiki/Lightning_Rod "Lightning Rod") | *1* |  |  |  |
| [Spark](/wiki/Spark "Spark") | *1* |  |  |  |
| [Falling Thunder](/wiki/Falling_Thunder "Falling Thunder") | *1* |  |  |  |
| [Lightning Spear](/wiki/Lightning_Spear "Lightning Spear") | *3* |  |  |  |
| [Stormcaller Arrow](/wiki/Stormcaller_Arrow "Stormcaller Arrow") | *3* |  |  |  |
| [Orb of Storms](/wiki/Orb_of_Storms "Orb of Storms") | *3* |  |  |  |
| [Electrocuting Arrow](/wiki/Electrocuting_Arrow "Electrocuting Arrow") | *5* |  |  |  |
| [Storm Lance](/wiki/Storm_Lance "Storm Lance") | *5* |  |  |  |
| [Arc](/wiki/Arc "Arc") | *5* |  |  |  |
| [Snap](/wiki/Snap "Snap") | *5* |  |  |  |
| [Galvanic Shards](/wiki/Galvanic_Shards "Galvanic Shards") | *5* |  |  |  |
| [Tempest Flurry](/wiki/Tempest_Flurry "Tempest Flurry") | *5* |  |  |  |
| [Thunderstorm](/wiki/Thunderstorm "Thunderstorm") | *5* |  |  |  |
| [Primal Strikes](/wiki/Primal_Strikes "Primal Strikes") | *7* |  |  |  |
| [Voltaic Mark](/wiki/Voltaic_Mark "Voltaic Mark") | *7* |  |  |  |
| [Elemental Weakness](/wiki/Elemental_Weakness "Elemental Weakness") | *7* |  |  |  |
| [Mana Tempest](/wiki/Mana_Tempest "Mana Tempest") | *7* |  |  |  |
| [Siphoning Strike](/wiki/Siphoning_Strike "Siphoning Strike") | *7* |  |  |  |
| [Storm Wave](/wiki/Storm_Wave "Storm Wave") | *7* |  |  |  |
| [Voltaic Grenade](/wiki/Voltaic_Grenade "Voltaic Grenade") | *7* |  |  |  |
| [Thunderous Leap](/wiki/Thunderous_Leap "Thunderous Leap") | *9* |  |  |  |
| [Lightning Warp](/wiki/Lightning_Warp "Lightning Warp") | *9* |  |  |  |
| [Charged Staff](/wiki/Charged_Staff "Charged Staff") | *9* |  |  |  |
| [Stormblast Bolts](/wiki/Stormblast_Bolts "Stormblast Bolts") | *9* |  |  |  |
| [Elemental Sundering](/wiki/Elemental_Sundering "Elemental Sundering") | *11* |  |  |  |
| [Shockchain Arrow](/wiki/Shockchain_Arrow "Shockchain Arrow") | *11* |  |  |  |
| [Ball Lightning](/wiki/Ball_Lightning "Ball Lightning") | *11* |  |  |  |
| [Skeletal Storm Mage](/wiki/Skeletal_Storm_Mage "Skeletal Storm Mage") | *11* |  |  |  |
| [Shockburst Rounds](/wiki/Shockburst_Rounds "Shockburst Rounds") | *11* |  |  |  |
| [Magnetic Salvo](/wiki/Magnetic_Salvo "Magnetic Salvo") | *13* |  |  |  |
| [Lightning Conduit](/wiki/Lightning_Conduit "Lightning Conduit") | *13* |  |  |  |
| [Gathering Storm](/wiki/Gathering_Storm "Gathering Storm") | *13* |  |  |  |
| [Plasma Blast](/wiki/Plasma_Blast "Plasma Blast") | *13* |  |  |  |

### Spirit gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Herald of Thunder](/wiki/Herald_of_Thunder "Herald of Thunder") | *4* |  |  |  |
| [Siphon Elements](/wiki/Siphon_Elements "Siphon Elements") | *8* |  |  |  |
| [Elemental Invocation](/wiki/Elemental_Invocation "Elemental Invocation") | *8* |  |  |  |
| [Shard Scavenger](/wiki/Shard_Scavenger "Shard Scavenger") | *8* |  |  |  |
| [Archmage](/wiki/Archmage "Archmage") | *14* |  |  |  |
| [Cast on Elemental Ailment](/wiki/Cast_on_Elemental_Ailment "Cast on Elemental Ailment") | *14* |  |  |  |
| [Elemental Conflux](/wiki/Elemental_Conflux "Elemental Conflux") | *14* |  |  |  |
| [Trinity](/wiki/Trinity "Trinity") | *14* |  |  |  |

### Support gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Esh's Radiance](/wiki/Esh%27s_Radiance "Esh's Radiance") | *0* |  |  |  |
| [Hayoxi's Fulmination](/wiki/Hayoxi%27s_Fulmination "Hayoxi's Fulmination") | *0* |  |  |  |
| [Innervate](/wiki/Innervate "Innervate") | *1* |  |  |  |
| [Lightning Attunement](/wiki/Lightning_Attunement "Lightning Attunement") | *1* |  |  |  |
| [Shock](/wiki/Shock_(support_gem) "Shock (support gem)") | *1* |  |  |  |
| [Coursing Current](/wiki/Coursing_Current "Coursing Current") | *1* |  |  |  |
| [Thrill of the Kill I](/wiki/Thrill_of_the_Kill_I "Thrill of the Kill I") | *1* |  |  |  |
| [Electrocute](/wiki/Electrocute_(support_gem) "Electrocute (support gem)") | *2* |  |  |  |
| [Lasting Shock](/wiki/Lasting_Shock "Lasting Shock") | *2* |  |  |  |
| [Lightning Penetration](/wiki/Lightning_Penetration "Lightning Penetration") | *2* |  |  |  |
| [Volt](/wiki/Volt "Volt") | *2* |  |  |  |
| [Crackling Barrier](/wiki/Crackling_Barrier "Crackling Barrier") | *2* |  |  |  |
| [Living Lightning I](/wiki/Living_Lightning_I "Living Lightning I") | *2* |  |  |  |
| [Shock Conduction I](/wiki/Shock_Conduction_I "Shock Conduction I") | *2* |  |  |  |
| [Neural Overload](/wiki/Neural_Overload "Neural Overload") | *3* |  |  |  |
| [Electromagnetism](/wiki/Electromagnetism "Electromagnetism") | *3* |  |  |  |
| [Elemental Discharge](/wiki/Elemental_Discharge "Elemental Discharge") | *3* |  |  |  |
| [Static Shocks](/wiki/Static_Shocks "Static Shocks") | *3* |  |  |  |
| [Stormfire](/wiki/Stormfire "Stormfire") | *3* |  |  |  |
| [Thrill of the Kill II](/wiki/Thrill_of_the_Kill_II "Thrill of the Kill II") | *3* |  |  |  |
| [Lightning Exposure](/wiki/Lightning_Exposure "Lightning Exposure") | *4* |  |  |  |
| [Overcharge](/wiki/Overcharge "Overcharge") | *4* |  |  |  |
| [Living Lightning II](/wiki/Living_Lightning_II "Living Lightning II") | *4* |  |  |  |
| [Catalysing Elements](/wiki/Catalysing_Elements "Catalysing Elements") | *5* |  |  |  |
| [Lightning Mastery](/wiki/Lightning_Mastery "Lightning Mastery") | *5* |  |  |  |
| [Shock Conduction II](/wiki/Shock_Conduction_II "Shock Conduction II") | *5* |  |  |  |

## Base items

The following base items are related to lightning damage:

| Item |  | Stats |
| --- | --- | --- |
| [Crackling Quarterstaff](/wiki/Crackling_Quarterstaff "Crackling Quarterstaff") | 16 | Adds 1 to 35 Lightning Damage (Hidden) |
| [Voltfang Talisman](/wiki/Voltfang_Talisman "Voltfang Talisman") | 46 | (15-25)% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Shock](/wiki/Shock "Shock") you inflict 30% of this Weapon's base Physical Damage Converted to Lightning Damage (Hidden) |
| [Thunder Talisman](/wiki/Thunder_Talisman "Thunder Talisman") | 77 | (15-25)% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Shock](/wiki/Shock "Shock") you inflict 30% of this Weapon's base Physical Damage Converted to Lightning Damage (Hidden) |
| [Bolting Quarterstaff](/wiki/Bolting_Quarterstaff "Bolting Quarterstaff") | 78 | Adds 1 to 100 Lightning Damage (Hidden) |

## Unique items

The following unique items are related to lightning damage:

| Item | Stats |
| --- | --- |
| [Hand of Wisdom and Action](/wiki/Hand_of_Wisdom_and_Action "Hand of Wisdom and Action") | +(15-25) to [Dexterity](/wiki/Dexterity "Dexterity") +(15-25) to [Intelligence](/wiki/Intelligence "Intelligence") 1% increased [Attack](/wiki/Attack "Attack") Speed per 20 [Dexterity](/wiki/Dexterity "Dexterity") Adds 1 to 10 Lightning Damage to [Attacks](/wiki/Attack "Attack") per 20 [Intelligence](/wiki/Intelligence "Intelligence") |
| [Doryani's Prototype](/wiki/Doryani%27s_Prototype "Doryani's Prototype") | (50-100)% increased [Armour](/wiki/Armour "Armour") and [Evasion](/wiki/Evasion "Evasion") +(60-100) to maximum Life +100% of [Armour](/wiki/Armour "Armour") also applies to [Lightning Damage](/wiki/Lightning_Damage "Lightning Damage") Enemies in your [Presence](/wiki/Presence "Presence") have [Lightning Resistance](/wiki/Lightning_Damage "Lightning Damage") equal to yours [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance") does not affect Lightning damage taken |
| [Thunderfist](/wiki/Thunderfist "Thunderfist") | (1-111)% increased [Evasion](/wiki/Evasion "Evasion") and [Energy Shield](/wiki/Energy_Shield "Energy Shield") (1-11)% increased [Attack](/wiki/Attack "Attack") Speed +(1-33)% to [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance") Adds 1 to (77-111) Lightning Damage to Unarmed [Melee](/wiki/Melee "Melee") Hits +(0.1-1.1)% to Unarmed [Melee](/wiki/Melee "Melee") [Attack](/wiki/Attack "Attack") [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance |

## Passive skills

### Base passive skills

The following [passive skills](/wiki/Passive_skill "Passive skill") are related to lightning damage:
No results found for the given query.

### Keystone passive skills

The following [keystone](/wiki/Keystone "Keystone") passive skills are related to lightning damage:
No results found for the given query.

### Ascendancy passive skills

The following [Ascendancy passive skills](/wiki/Ascendancy_passive_skill "Ascendancy passive skill") are related to lightning damage:
No results found for the given query.
