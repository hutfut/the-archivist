# Warbringer

Warbringer

[Warrior](/wiki/Warrior "Warrior")

|  |  |
| --- | --- |
|  | **Your home has been threatened. A good man must be roused to war.** |

Official artwork of the Warbringer.

**Warbringer** is an [Ascendancy class](/wiki/Ascendancy_class "Ascendancy class") for the [Warrior](/wiki/Warrior "Warrior").

## Overview

The Warbringer draws strength from his Karui and Ezomyte ancestry. The class improves his ability to [block](/wiki/Block "Block") attacks and [Break Armour](/wiki/Break_Armour "Break Armour"), making them more vulnerable to physical damage and other damage types. He has the ability to enhance his totems to summon [Ancestral Spirits](/wiki/Ancestral_Spirits "Ancestral Spirits") and redirect incoming damage towards it, encase himself with jade to absorb damage from hits, and unleash [warcries](/wiki/Warcry "Warcry") that explode corpses while ignoring their cooldowns.

## Passive skills

### Minor skills

This class has the following minor passive skills:

| Name | Stats |
| --- | --- |
| [Armour](/wiki/Armour "Armour") | 20% increased [Armour](/wiki/Armour "Armour") [[1]](/wiki/Passive_Skill:AscendancyWarrior2Small3 "Passive Skill:AscendancyWarrior2Small3") |
| [Armour Break](/wiki/Armour_Break "Armour Break") | [Break](/wiki/Break "Break") 25% increased [Armour](/wiki/Armour "Armour") [[1]](/wiki/Passive_Skill:AscendancyWarrior2Small1 "Passive Skill:AscendancyWarrior2Small1") [[2]](/wiki/Passive_Skill:AscendancyWarrior2Small2 "Passive Skill:AscendancyWarrior2Small2") |
| [Block Chance](/wiki/Block_Chance/edit?redlink=1 "Block Chance (page does not exist)") | 6% increased [Block](/wiki/Block "Block") chance [[1]](/wiki/Passive_Skill:AscendancyWarrior2Small8 "Passive Skill:AscendancyWarrior2Small8") [[2]](/wiki/Passive_Skill:AscendancyWarrior2Small9 "Passive Skill:AscendancyWarrior2Small9") |
| [Totem Life](/wiki/Totem_Life/edit?redlink=1 "Totem Life (page does not exist)") | 20% increased [Totem](/wiki/Totem "Totem") Life [[1]](/wiki/Passive_Skill:AscendancyWarrior2Small6 "Passive Skill:AscendancyWarrior2Small6") [[2]](/wiki/Passive_Skill:AscendancyWarrior2Small7~ "Passive Skill:AscendancyWarrior2Small7~") |
| [Warcry Speed](/wiki/Warcry_Speed/edit?redlink=1 "Warcry Speed (page does not exist)") | 20% increased [Warcry](/wiki/Warcry "Warcry") Speed [[1]](/wiki/Passive_Skill:AscendancyWarrior2Small4 "Passive Skill:AscendancyWarrior2Small4") [[2]](/wiki/Passive_Skill:AscendancyWarrior2Small5 "Passive Skill:AscendancyWarrior2Small5") |

### Notable skills

This class has the following notable passive skills:

| Skill | Modifiers | Prerequisite | Preceding Passive |
| --- | --- | --- | --- |
| [Anvil's Weight](/wiki/Anvil%27s_Weight "Anvil's Weight") | [Break Armour](/wiki/Break_Armour "Break Armour") equal to 10% of [Hit Damage](/wiki/Hit_Damage "Hit Damage") dealt | — | [Armour Break](/wiki/Armour_Break_(ascendancy_passive_skill) "Armour Break (ascendancy passive skill)") |
| [Imploding Impacts](/wiki/Imploding_Impacts "Imploding Impacts") | You can [Break Enemy Armour to below 0](/wiki/Armour_Break "Armour Break") [Fully Broken Armour](/wiki/Fully_Broken_Armour "Fully Broken Armour") you inflict increases all Damage Taken from [Hits](/wiki/Hit "Hit") instead | [Anvil's Weight](/wiki/Anvil%27s_Weight "Anvil's Weight") | [Armour Break](/wiki/Armour_Break_(ascendancy_passive_skill) "Armour Break (ascendancy passive skill)") |
| [Jade Heritage](/wiki/Jade_Heritage "Jade Heritage") | Grants Skill: [Encase in Jade](/wiki/Encase_in_Jade "Encase in Jade") Gain a stack of [Jade](/wiki/Jade "Jade") every second | — | [Armour](/wiki/Armour_(ascendancy_passive_skill) "Armour (ascendancy passive skill)") |
| [Answered Call](/wiki/Answered_Call "Answered Call") | Grants Skill: [Ancestral Spirits](/wiki/Ancestral_Spirits "Ancestral Spirits") Trigger Ancestral Spirits when you Summon a [Totem](/wiki/Totem "Totem") +1 to maximum number of Summoned [Totems](/wiki/Totem "Totem") | — | [Totem Life](/wiki/Totem_Life_(ascendancy_passive_skill) "Totem Life (ascendancy passive skill)") |
| [Wooden Wall](/wiki/Wooden_Wall "Wooden Wall") | 20% of Damage from [Hits](/wiki/Hit "Hit") is taken from your nearest [Totem's](/wiki/Totem "Totem") Life before you | [Answered Call](/wiki/Answered_Call "Answered Call") | [Totem Life](/wiki/Totem_Life_(ascendancy_passive_skill) "Totem Life (ascendancy passive skill)") |
| [Renly's Training](/wiki/Renly%27s_Training "Renly's Training") | Gain 35% Base Chance to [Block](/wiki/Block "Block") from [Equipped](/wiki/Equipped/edit?redlink=1 "Equipped (page does not exist)") [Shield](/wiki/Shield "Shield") instead of the Shield's value | — | [Block Chance](/wiki/Block_Chance_(ascendancy_passive_skill) "Block Chance (ascendancy passive skill)") |
| [Turtle Charm](/wiki/Turtle_Charm "Turtle Charm") | You take 20% of damage from [Blocked](/wiki/Block "Block") [Hits](/wiki/Hit "Hit") Maximum [Block](/wiki/Block "Block") chance is 75% | [Renly's Training](/wiki/Renly%27s_Training "Renly's Training") | [Block Chance](/wiki/Block_Chance_(ascendancy_passive_skill) "Block Chance (ascendancy passive skill)") |
| [Warcaller's Bellow](/wiki/Warcaller%27s_Bellow "Warcaller's Bellow") | [Warcries](/wiki/Warcries "Warcries") Explode [Corpses](/wiki/Corpse "Corpse") dealing 25% of their Life as [Physical](/wiki/Physical "Physical") Damage Ignore [Warcry](/wiki/Warcry "Warcry") Cooldowns | — | [Warcry Speed](/wiki/Warcry_Speed_(ascendancy_passive_skill) "Warcry Speed (ascendancy passive skill)") |
