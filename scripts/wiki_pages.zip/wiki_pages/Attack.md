# Attack

Attacks

Tooltip

Attacks are skills that directly use your equipped weapon to damage enemies. [Spells](/wiki/Spell "Spell") are not Attacks.

The base damage, attack speed and [critical hit](/wiki/Critical_hit "Critical hit") chance of an attack are determined using your weapon's stats unless a skill says otherwise.

Attacks do not necessarily deal [Physical](/wiki/Physical "Physical") damage — they can deal any damage type.

**Attacks** are [skills](/wiki/Skill "Skill") that directly use your equipped weapon to [damage](/wiki/Damage "Damage") enemies. [Spells](/wiki/Spell "Spell") are not attacks.

The base damage, attack speed and [critical](/wiki/Critical "Critical") hit chance of an attack are determined using your weapon's stats unless a skill says otherwise.

Attacks do not necessarily deal [physical](/wiki/Physical "Physical") damage, they can deal any [damage type](/wiki/Damage_type "Damage type").

## Gems

A list of [gems](/wiki/Gem "Gem") with the Attack [gem tag](/wiki/Gem_tag "Gem tag"):

### Skill gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Bow Shot](/wiki/Bow_Shot "Bow Shot") | *0* |  |  |  |
| [Parry](/wiki/Parry "Parry") | *0* |  |  |  |
| [Raise Shield](/wiki/Raise_Shield "Raise Shield") | *0* |  |  |  |
| [Disengage](/wiki/Disengage "Disengage") | *1* |  |  |  |
| [Escape Shot](/wiki/Escape_Shot "Escape Shot") | *1* |  |  |  |
| [Explosive Spear](/wiki/Explosive_Spear "Explosive Spear") | *1* |  |  |  |
| [Lightning Arrow](/wiki/Lightning_Arrow "Lightning Arrow") | *1* |  |  |  |
| [Lightning Rod](/wiki/Lightning_Rod "Lightning Rod") | *1* |  |  |  |
| [Poisonburst Arrow](/wiki/Poisonburst_Arrow "Poisonburst Arrow") | *1* |  |  |  |
| [Twister](/wiki/Twister "Twister") | *1* |  |  |  |
| [Whirling Slash](/wiki/Whirling_Slash "Whirling Slash") | *1* |  |  |  |
| [Armour Piercing Rounds](/wiki/Armour_Piercing_Rounds "Armour Piercing Rounds") | *1* |  |  |  |
| [Explosive Grenade](/wiki/Explosive_Grenade "Explosive Grenade") | *1* |  |  |  |
| [Falling Thunder](/wiki/Falling_Thunder "Falling Thunder") | *1* |  |  |  |
| [Fragmentation Rounds](/wiki/Fragmentation_Rounds "Fragmentation Rounds") | *1* |  |  |  |
| [Frozen Locus](/wiki/Frozen_Locus "Frozen Locus") | *1* |  |  |  |
| [Furious Slam](/wiki/Furious_Slam "Furious Slam") | *1* |  |  |  |
| [Glacial Cascade](/wiki/Glacial_Cascade "Glacial Cascade") | *1* |  |  |  |
| [Killing Palm](/wiki/Killing_Palm "Killing Palm") | *1* |  |  |  |
| [Lunar Assault](/wiki/Lunar_Assault "Lunar Assault") | *1* |  |  |  |
| [Permafrost Bolts](/wiki/Permafrost_Bolts "Permafrost Bolts") | *1* |  |  |  |
| [Boneshatter](/wiki/Boneshatter "Boneshatter") | *1* |  |  |  |
| [Earthquake](/wiki/Earthquake "Earthquake") | *1* |  |  |  |
| [Rolling Slam](/wiki/Rolling_Slam "Rolling Slam") | *1* |  |  |  |
| [Cull The Weak](/wiki/Cull_The_Weak "Cull The Weak") | *3* |  |  |  |
| [Fangs of Frost](/wiki/Fangs_of_Frost "Fangs of Frost") | *3* |  |  |  |
| [Freezing Salvo](/wiki/Freezing_Salvo "Freezing Salvo") | *3* |  |  |  |
| [Lightning Spear](/wiki/Lightning_Spear "Lightning Spear") | *3* |  |  |  |
| [Rake](/wiki/Rake "Rake") | *3* |  |  |  |
| [Snipe](/wiki/Snipe "Snipe") | *3* |  |  |  |
| [Stormcaller Arrow](/wiki/Stormcaller_Arrow "Stormcaller Arrow") | *3* |  |  |  |
| [Vine Arrow](/wiki/Vine_Arrow "Vine Arrow") | *3* |  |  |  |
| [Flash Grenade](/wiki/Flash_Grenade "Flash Grenade") | *3* |  |  |  |
| [High Velocity Rounds](/wiki/High_Velocity_Rounds "High Velocity Rounds") | *3* |  |  |  |
| [Incendiary Shot](/wiki/Incendiary_Shot "Incendiary Shot") | *3* |  |  |  |
| [Pounce](/wiki/Pounce "Pounce") | *3* |  |  |  |
| [Rolling Magma](/wiki/Rolling_Magma "Rolling Magma") | *3* |  |  |  |
| [Staggering Palm](/wiki/Staggering_Palm "Staggering Palm") | *3* |  |  |  |
| [Tempest Bell](/wiki/Tempest_Bell "Tempest Bell") | *3* |  |  |  |
| [Wind Blast](/wiki/Wind_Blast "Wind Blast") | *3* |  |  |  |
| [Wing Blast](/wiki/Wing_Blast "Wing Blast") | *3* |  |  |  |
| [Armour Breaker](/wiki/Armour_Breaker "Armour Breaker") | *3* |  |  |  |
| [Shield Charge](/wiki/Shield_Charge "Shield Charge") | *3* |  |  |  |
| [Shockwave Totem](/wiki/Shockwave_Totem "Shockwave Totem") | *3* |  |  |  |
| [Electrocuting Arrow](/wiki/Electrocuting_Arrow "Electrocuting Arrow") | *5* |  |  |  |
| [Ice-Tipped Arrows](/wiki/Ice-Tipped_Arrows "Ice-Tipped Arrows") | *5* |  |  |  |
| [Rapid Assault](/wiki/Rapid_Assault "Rapid Assault") | *5* |  |  |  |
| [Spearfield](/wiki/Spearfield "Spearfield") | *5* |  |  |  |
| [Storm Lance](/wiki/Storm_Lance "Storm Lance") | *5* |  |  |  |
| [Toxic Growth](/wiki/Toxic_Growth "Toxic Growth") | *5* |  |  |  |
| [Devour](/wiki/Devour "Devour") | *5* |  |  |  |
| [Fury of the Mountain](/wiki/Fury_of_the_Mountain "Fury of the Mountain") | *5* |  |  |  |
| [Galvanic Shards](/wiki/Galvanic_Shards "Galvanic Shards") | *5* |  |  |  |
| [Gas Grenade](/wiki/Gas_Grenade "Gas Grenade") | *5* |  |  |  |
| [Ice Shards](/wiki/Ice_Shards "Ice Shards") | *5* |  |  |  |
| [Ice Strike](/wiki/Ice_Strike "Ice Strike") | *5* |  |  |  |
| [Rapid Shot](/wiki/Rapid_Shot "Rapid Shot") | *5* |  |  |  |
| [Tempest Flurry](/wiki/Tempest_Flurry "Tempest Flurry") | *5* |  |  |  |
| [Vaulting Impact](/wiki/Vaulting_Impact "Vaulting Impact") | *5* |  |  |  |
| [Molten Blast](/wiki/Molten_Blast "Molten Blast") | *5* |  |  |  |
| [Perfect Strike](/wiki/Perfect_Strike "Perfect Strike") | *5* |  |  |  |
| [Resonating Shield](/wiki/Resonating_Shield "Resonating Shield") | *5* |  |  |  |
| [Blood Hunt](/wiki/Blood_Hunt "Blood Hunt") | *7* |  |  |  |
| [Gas Arrow](/wiki/Gas_Arrow "Gas Arrow") | *7* |  |  |  |
| [Glacial Lance](/wiki/Glacial_Lance "Glacial Lance") | *7* |  |  |  |
| [Primal Strikes](/wiki/Primal_Strikes "Primal Strikes") | *7* |  |  |  |
| [Artillery Ballista](/wiki/Artillery_Ballista "Artillery Ballista") | *7* |  |  |  |
| [Cross Slash](/wiki/Cross_Slash "Cross Slash") | *7* |  |  |  |
| [Explosive Shot](/wiki/Explosive_Shot "Explosive Shot") | *7* |  |  |  |
| [Glacial Bolt](/wiki/Glacial_Bolt "Glacial Bolt") | *7* |  |  |  |
| [Siphoning Strike](/wiki/Siphoning_Strike "Siphoning Strike") | *7* |  |  |  |
| [Storm Wave](/wiki/Storm_Wave "Storm Wave") | *7* |  |  |  |
| [Voltaic Grenade](/wiki/Voltaic_Grenade "Voltaic Grenade") | *7* |  |  |  |
| [Wave of Frost](/wiki/Wave_of_Frost "Wave of Frost") | *7* |  |  |  |
| [Earthshatter](/wiki/Earthshatter "Earthshatter") | *7* |  |  |  |
| [Leap Slam](/wiki/Leap_Slam "Leap Slam") | *7* |  |  |  |
| [Shield Wall](/wiki/Shield_Wall "Shield Wall") | *7* |  |  |  |
| [Volcanic Fissure](/wiki/Volcanic_Fissure "Volcanic Fissure") | *7* |  |  |  |
| [Bloodhound's Mark](/wiki/Bloodhound%27s_Mark "Bloodhound's Mark") | *9* |  |  |  |
| [Detonating Arrow](/wiki/Detonating_Arrow "Detonating Arrow") | *9* |  |  |  |
| [Ice Shot](/wiki/Ice_Shot "Ice Shot") | *9* |  |  |  |
| [Rain of Arrows](/wiki/Rain_of_Arrows "Rain of Arrows") | *9* |  |  |  |
| [Thunderous Leap](/wiki/Thunderous_Leap "Thunderous Leap") | *9* |  |  |  |
| [Charged Staff](/wiki/Charged_Staff "Charged Staff") | *9* |  |  |  |
| [Hand of Chayula](/wiki/Hand_of_Chayula "Hand of Chayula") | *9* |  |  |  |
| [Oil Barrage](/wiki/Oil_Barrage "Oil Barrage") | *9* |  |  |  |
| [Oil Grenade](/wiki/Oil_Grenade "Oil Grenade") | *9* |  |  |  |
| [Siege Ballista](/wiki/Siege_Ballista "Siege Ballista") | *9* |  |  |  |
| [Stormblast Bolts](/wiki/Stormblast_Bolts "Stormblast Bolts") | *9* |  |  |  |
| [Forge Hammer](/wiki/Forge_Hammer "Forge Hammer") | *9* |  |  |  |
| [Fortifying Cry](/wiki/Fortifying_Cry "Fortifying Cry") | *9* |  |  |  |
| [Sunder](/wiki/Sunder "Sunder") | *9* |  |  |  |
| [Elemental Sundering](/wiki/Elemental_Sundering "Elemental Sundering") | *11* |  |  |  |
| [Shockchain Arrow](/wiki/Shockchain_Arrow "Shockchain Arrow") | *11* |  |  |  |
| [Tornado Shot](/wiki/Tornado_Shot "Tornado Shot") | *11* |  |  |  |
| [Whirlwind Lance](/wiki/Whirlwind_Lance "Whirlwind Lance") | *11* |  |  |  |
| [Hailstorm Rounds](/wiki/Hailstorm_Rounds "Hailstorm Rounds") | *11* |  |  |  |
| [Rampage](/wiki/Rampage "Rampage") | *11* |  |  |  |
| [Shattering Palm](/wiki/Shattering_Palm "Shattering Palm") | *11* |  |  |  |
| [Shockburst Rounds](/wiki/Shockburst_Rounds "Shockburst Rounds") | *11* |  |  |  |
| [Whirling Assault](/wiki/Whirling_Assault "Whirling Assault") | *11* |  |  |  |
| [Stampede](/wiki/Stampede "Stampede") | *11* |  |  |  |
| [Supercharged Slam](/wiki/Supercharged_Slam "Supercharged Slam") | *11* |  |  |  |
| [Magnetic Salvo](/wiki/Magnetic_Salvo "Magnetic Salvo") | *13* |  |  |  |
| [Spear of Solaris](/wiki/Spear_of_Solaris "Spear of Solaris") | *13* |  |  |  |
| [Spiral Volley](/wiki/Spiral_Volley "Spiral Volley") | *13* |  |  |  |
| [Toxic Domain](/wiki/Toxic_Domain "Toxic Domain") | *13* |  |  |  |
| [Wind Serpent's Fury](/wiki/Wind_Serpent%27s_Fury "Wind Serpent's Fury") | *13* |  |  |  |
| [Cluster Grenade](/wiki/Cluster_Grenade "Cluster Grenade") | *13* |  |  |  |
| [Flame Breath](/wiki/Flame_Breath "Flame Breath") | *13* |  |  |  |
| [Flicker Strike](/wiki/Flicker_Strike "Flicker Strike") | *13* |  |  |  |
| [Gathering Storm](/wiki/Gathering_Storm "Gathering Storm") | *13* |  |  |  |
| [Lunar Blessing](/wiki/Lunar_Blessing "Lunar Blessing") | *13* |  |  |  |
| [Plasma Blast](/wiki/Plasma_Blast "Plasma Blast") | *13* |  |  |  |
| [Siege Cascade](/wiki/Siege_Cascade "Siege Cascade") | *13* |  |  |  |
| [Walking Calamity](/wiki/Walking_Calamity "Walking Calamity") | *13* |  |  |  |
| [Ancestral Cry](/wiki/Ancestral_Cry "Ancestral Cry") | *13* |  |  |  |
| [Ancestral Warrior Totem](/wiki/Ancestral_Warrior_Totem "Ancestral Warrior Totem") | *13* |  |  |  |
| [Hammer of the Gods](/wiki/Hammer_of_the_Gods "Hammer of the Gods") | *13* |  |  |  |

### Spirit gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Herald of Thunder](/wiki/Herald_of_Thunder "Herald of Thunder") | *4* |  |  |  |
| [Wind Dancer](/wiki/Wind_Dancer "Wind Dancer") | *4* |  |  |  |
| [Herald of Blood](/wiki/Herald_of_Blood "Herald of Blood") | *4* |  |  |  |
| [Herald of Ice](/wiki/Herald_of_Ice "Herald of Ice") | *4* |  |  |  |
| [Magma Barrier](/wiki/Magma_Barrier "Magma Barrier") | *4* |  |  |  |
| [Trail of Caltrops](/wiki/Trail_of_Caltrops "Trail of Caltrops") | *8* |  |  |  |

### Support gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Garukhan's Resolve](/wiki/Garukhan%27s_Resolve "Garukhan's Resolve") | *0* |  |  |  |
| [Rigwald's Ferocity](/wiki/Rigwald%27s_Ferocity "Rigwald's Ferocity") | *0* |  |  |  |
| [Bhatair's Vengeance](/wiki/Bhatair%27s_Vengeance "Bhatair's Vengeance") | *0* |  |  |  |
| [Einhar's Beastrite](/wiki/Einhar%27s_Beastrite "Einhar's Beastrite") | *0* |  |  |  |
| [Kaom's Madness](/wiki/Kaom%27s_Madness "Kaom's Madness") | *0* |  |  |  |
| [Combo Finisher I](/wiki/Combo_Finisher_I "Combo Finisher I") | *1* |  |  |  |
| [Heightened Accuracy I](/wiki/Heightened_Accuracy_I "Heightened Accuracy I") | *1* |  |  |  |
| [Innervate](/wiki/Innervate "Innervate") | *1* |  |  |  |
| [Lightning Attunement](/wiki/Lightning_Attunement "Lightning Attunement") | *1* |  |  |  |
| [Pursuit I](/wiki/Pursuit_I "Pursuit I") | *1* |  |  |  |
| [Rapid Attacks I](/wiki/Rapid_Attacks_I "Rapid Attacks I") | *1* |  |  |  |
| [Cold Attunement](/wiki/Cold_Attunement "Cold Attunement") | *1* |  |  |  |
| [Crescendo I](/wiki/Crescendo_I "Crescendo I") | *1* |  |  |  |
| [Ice Bite I](/wiki/Ice_Bite_I "Ice Bite I") | *1* |  |  |  |
| [Thrill of the Kill I](/wiki/Thrill_of_the_Kill_I "Thrill of the Kill I") | *1* |  |  |  |
| [Armour Explosion](/wiki/Armour_Explosion "Armour Explosion") | *1* |  |  |  |
| [Elemental Armament I](/wiki/Elemental_Armament_I "Elemental Armament I") | *1* |  |  |  |
| [Fire Attunement](/wiki/Fire_Attunement "Fire Attunement") | *1* |  |  |  |
| [Fist of War I](/wiki/Fist_of_War_I "Fist of War I") | *1* |  |  |  |
| [Impact Shockwave](/wiki/Impact_Shockwave "Impact Shockwave") | *1* |  |  |  |
| [Rage I](/wiki/Rage_I "Rage I") | *1* |  |  |  |
| [Stomping Ground](/wiki/Stomping_Ground "Stomping Ground") | *1* |  |  |  |
| [Cadence](/wiki/Cadence "Cadence") | *2* |  |  |  |
| [Frenzied Riposte](/wiki/Frenzied_Riposte "Frenzied Riposte") | *2* |  |  |  |
| [Longshot I](/wiki/Longshot_I "Longshot I") | *2* |  |  |  |
| [Maim](/wiki/Maim_(support_gem) "Maim (support gem)") | *2* |  |  |  |
| [Overextend](/wiki/Overextend "Overextend") | *2* |  |  |  |
| [Overreach](/wiki/Overreach "Overreach") | *2* |  |  |  |
| [Volt](/wiki/Volt "Volt") | *2* |  |  |  |
| [Mana Leech](/wiki/Mana_Leech "Mana Leech") | *2* |  |  |  |
| [Aftershock I](/wiki/Aftershock_I "Aftershock I") | *2* |  |  |  |
| [Behead I](/wiki/Behead_I "Behead I") | *2* |  |  |  |
| [Brink I](/wiki/Brink_I "Brink I") | *2* |  |  |  |
| [Crater](/wiki/Crater "Crater") | *2* |  |  |  |
| [Defy I](/wiki/Defy_I "Defy I") | *2* |  |  |  |
| [Elemental Armament II](/wiki/Elemental_Armament_II "Elemental Armament II") | *2* |  |  |  |
| [Fan The Flames I](/wiki/Fan_The_Flames_I "Fan The Flames I") | *2* |  |  |  |
| [Jagged Ground I](/wiki/Jagged_Ground_I "Jagged Ground I") | *2* |  |  |  |
| [Life Leech I](/wiki/Life_Leech_I "Life Leech I") | *2* |  |  |  |
| [Retaliate I](/wiki/Retaliate_I "Retaliate I") | *2* |  |  |  |
| [Tectonic Slams](/wiki/Tectonic_Slams "Tectonic Slams") | *2* |  |  |  |
| [Volcanic Eruption](/wiki/Volcanic_Eruption "Volcanic Eruption") | *2* |  |  |  |
| [Alignment I](/wiki/Alignment_I "Alignment I") | *3* |  |  |  |
| [Caltrops](/wiki/Caltrops "Caltrops") | *3* |  |  |  |
| [Charged Shots I](/wiki/Charged_Shots_I "Charged Shots I") | *3* |  |  |  |
| [Close Combat I](/wiki/Close_Combat_I "Close Combat I") | *3* |  |  |  |
| [Combo Finisher II](/wiki/Combo_Finisher_II "Combo Finisher II") | *3* |  |  |  |
| [Culmination I](/wiki/Culmination_I "Culmination I") | *3* |  |  |  |
| [Heightened Accuracy II](/wiki/Heightened_Accuracy_II "Heightened Accuracy II") | *3* |  |  |  |
| [Longshot II](/wiki/Longshot_II "Longshot II") | *3* |  |  |  |
| [Poison Spores](/wiki/Poison_Spores "Poison Spores") | *3* |  |  |  |
| [Practiced Combo](/wiki/Practiced_Combo "Practiced Combo") | *3* |  |  |  |
| [Punch Through](/wiki/Punch_Through "Punch Through") | *3* |  |  |  |
| [Pursuit II](/wiki/Pursuit_II "Pursuit II") | *3* |  |  |  |
| [Salvo](/wiki/Salvo "Salvo") | *3* |  |  |  |
| [Chaos Attunement](/wiki/Chaos_Attunement "Chaos Attunement") | *3* |  |  |  |
| [Ice Bite II](/wiki/Ice_Bite_II "Ice Bite II") | *3* |  |  |  |
| [Thrill of the Kill II](/wiki/Thrill_of_the_Kill_II "Thrill of the Kill II") | *3* |  |  |  |
| [Barbs I](/wiki/Barbs_I "Barbs I") | *3* |  |  |  |
| [Behead II](/wiki/Behead_II "Behead II") | *3* |  |  |  |
| [Brink II](/wiki/Brink_II "Brink II") | *3* |  |  |  |
| [Clash](/wiki/Clash "Clash") | *3* |  |  |  |
| [Deadly Resolve](/wiki/Deadly_Resolve "Deadly Resolve") | *3* |  |  |  |
| [Fist of War II](/wiki/Fist_of_War_II "Fist of War II") | *3* |  |  |  |
| [Haemocrystals](/wiki/Haemocrystals "Haemocrystals") | *3* |  |  |  |
| [Life Leech II](/wiki/Life_Leech_II "Life Leech II") | *3* |  |  |  |
| [Quill Burst](/wiki/Quill_Burst "Quill Burst") | *3* |  |  |  |
| [Rending Apex](/wiki/Rending_Apex "Rending Apex") | *3* |  |  |  |
| [Rip](/wiki/Rip "Rip") | *3* |  |  |  |
| [Tear](/wiki/Tear "Tear") | *3* |  |  |  |
| [Alignment II](/wiki/Alignment_II "Alignment II") | *4* |  |  |  |
| [Culling Strike I](/wiki/Culling_Strike_I "Culling Strike I") | *4* |  |  |  |
| [Hit and Run](/wiki/Hit_and_Run "Hit and Run") | *4* |  |  |  |
| [Impale](/wiki/Impale_(support_gem) "Impale (support gem)") | *4* |  |  |  |
| [Rapid Attacks II](/wiki/Rapid_Attacks_II "Rapid Attacks II") | *4* |  |  |  |
| [Spectral Volley](/wiki/Spectral_Volley "Spectral Volley") | *4* |  |  |  |
| [Blazing Critical](/wiki/Blazing_Critical "Blazing Critical") | *4* |  |  |  |
| [Crescendo II](/wiki/Crescendo_II "Crescendo II") | *4* |  |  |  |
| [Aftershock II](/wiki/Aftershock_II "Aftershock II") | *4* |  |  |  |
| [Ancestral Call I](/wiki/Ancestral_Call_I "Ancestral Call I") | *4* |  |  |  |
| [Fan The Flames II](/wiki/Fan_The_Flames_II "Fan The Flames II") | *4* |  |  |  |
| [Heavy Swing](/wiki/Heavy_Swing "Heavy Swing") | *4* |  |  |  |
| [Incision](/wiki/Incision_(support_gem) "Incision (support gem)") | *4* |  |  |  |
| [Rage II](/wiki/Rage_II "Rage II") | *4* |  |  |  |
| [Retaliate II](/wiki/Retaliate_II "Retaliate II") | *4* |  |  |  |
| [Syzygy](/wiki/Syzygy "Syzygy") | *4* |  |  |  |
| [Alignment III](/wiki/Alignment_III "Alignment III") | *5* |  |  |  |
| [Charged Shots II](/wiki/Charged_Shots_II "Charged Shots II") | *5* |  |  |  |
| [Close Combat II](/wiki/Close_Combat_II "Close Combat II") | *5* |  |  |  |
| [Culling Strike II](/wiki/Culling_Strike_II "Culling Strike II") | *5* |  |  |  |
| [Culmination II](/wiki/Culmination_II "Culmination II") | *5* |  |  |  |
| [Pursuit III](/wiki/Pursuit_III "Pursuit III") | *5* |  |  |  |
| [Rapid Attacks III](/wiki/Rapid_Attacks_III "Rapid Attacks III") | *5* |  |  |  |
| [Crescendo III](/wiki/Crescendo_III "Crescendo III") | *5* |  |  |  |
| [Ancestral Call II](/wiki/Ancestral_Call_II "Ancestral Call II") | *5* |  |  |  |
| [Barbs II](/wiki/Barbs_II "Barbs II") | *5* |  |  |  |
| [Barbs III](/wiki/Barbs_III "Barbs III") | *5* |  |  |  |
| [Brambleslam](/wiki/Brambleslam "Brambleslam") | *5* |  |  |  |
| [Defy II](/wiki/Defy_II "Defy II") | *5* |  |  |  |
| [Elemental Armament III](/wiki/Elemental_Armament_III "Elemental Armament III") | *5* |  |  |  |
| [Fist of War III](/wiki/Fist_of_War_III "Fist of War III") | *5* |  |  |  |
| [Jagged Ground II](/wiki/Jagged_Ground_II "Jagged Ground II") | *5* |  |  |  |
| [Life Leech III](/wiki/Life_Leech_III "Life Leech III") | *5* |  |  |  |
| [Rage III](/wiki/Rage_III "Rage III") | *5* |  |  |  |

## Related passive skills

### Attack damage

| Name | Stats |
| --- | --- |
| [Accuracy and Attack Damage](/wiki/Accuracy_and_Attack_Damage/edit?redlink=1 "Accuracy and Attack Damage (page does not exist)") | 8% increased [Accuracy](/wiki/Accuracy "Accuracy") Rating 8% increased Attack Damage [[1]](/wiki/Passive_Skill:Accuracy21 "Passive Skill:Accuracy21") [[2]](/wiki/Passive_Skill:Accuracy22 "Passive Skill:Accuracy22") |
| [Attack and Minion Damage](/wiki/Attack_and_Minion_Damage/edit?redlink=1 "Attack and Minion Damage (page does not exist)") | 8% increased Attack Damage [Minions](/wiki/Minion "Minion") deal 8% increased Damage [[1]](/wiki/Passive_Skill:Minion~attack1 "Passive Skill:Minion~attack1") [[2]](/wiki/Passive_Skill:Minion~attack2 "Passive Skill:Minion~attack2") |
| [Attack and Spell Damage](/wiki/Attack_and_Spell_Damage/edit?redlink=1 "Attack and Spell Damage (page does not exist)") | 8% increased Attack Damage 8% increased [Spell](/wiki/Spell "Spell") Damage [[1]](/wiki/Passive_Skill:Attacks~and~spells10 "Passive Skill:Attacks~and~spells10") [[2]](/wiki/Passive_Skill:Attacks~and~spells11 "Passive Skill:Attacks~and~spells11") [[3]](/wiki/Passive_Skill:Attacks~and~spells5~ "Passive Skill:Attacks~and~spells5~") [[4]](/wiki/Passive_Skill:Attacks~and~spells6 "Passive Skill:Attacks~and~spells6") [[5]](/wiki/Passive_Skill:Attacks~and~spells7 "Passive Skill:Attacks~and~spells7") [[6]](/wiki/Passive_Skill:Attacks~and~spells8 "Passive Skill:Attacks~and~spells8") [[7]](/wiki/Passive_Skill:Attacks~and~spells9 "Passive Skill:Attacks~and~spells9") |
| [Attack Cold Damage](/wiki/Attack_Cold_Damage/edit?redlink=1 "Attack Cold Damage (page does not exist)") | 12% increased Attack Cold Damage [[1]](/wiki/Passive_Skill:Cold44 "Passive Skill:Cold44") [[2]](/wiki/Passive_Skill:Cold45 "Passive Skill:Cold45") |
| [Attack Cold Damage and Freeze Buildup](/wiki/Attack_Cold_Damage_and_Freeze_Buildup/edit?redlink=1 "Attack Cold Damage and Freeze Buildup (page does not exist)") | 8% increased Attack Cold Damage 8% increased [Freeze](/wiki/Freeze "Freeze") Buildup [[1]](/wiki/Passive_Skill:Cold41 "Passive Skill:Cold41") [[2]](/wiki/Passive_Skill:Cold42~ "Passive Skill:Cold42~") |
| [Attack Damage](/wiki/Attack_Damage/edit?redlink=1 "Attack Damage (page does not exist)") | 10% increased Attack Damage [[1]](/wiki/Passive_Skill:Attack13~ "Passive Skill:Attack13~") [[2]](/wiki/Passive_Skill:Attack14 "Passive Skill:Attack14") [[3]](/wiki/Passive_Skill:Attack17 "Passive Skill:Attack17") [[4]](/wiki/Passive_Skill:Attack18 "Passive Skill:Attack18") [[5]](/wiki/Passive_Skill:Attack22 "Passive Skill:Attack22") [[6]](/wiki/Passive_Skill:Attack23~ "Passive Skill:Attack23~") [[7]](/wiki/Passive_Skill:Attack24 "Passive Skill:Attack24") [[8]](/wiki/Passive_Skill:Attack35 "Passive Skill:Attack35") [[9]](/wiki/Passive_Skill:Attack36 "Passive Skill:Attack36") [[10]](/wiki/Passive_Skill:Attack41~~ "Passive Skill:Attack41~~") [[11]](/wiki/Passive_Skill:Attack42 "Passive Skill:Attack42") [[12]](/wiki/Passive_Skill:Attack43 "Passive Skill:Attack43") [[13]](/wiki/Passive_Skill:Attack50 "Passive Skill:Attack50") [[14]](/wiki/Passive_Skill:Attack6 "Passive Skill:Attack6") [[15]](/wiki/Passive_Skill:Attack8 "Passive Skill:Attack8") [[16]](/wiki/Passive_Skill:Glory17~ "Passive Skill:Glory17~") [[17]](/wiki/Passive_Skill:Glory3 "Passive Skill:Glory3") [[18]](/wiki/Passive_Skill:Life~leech6 "Passive Skill:Life~leech6") [[19]](/wiki/Passive_Skill:Life~leech7 "Passive Skill:Life~leech7") [[20]](/wiki/Passive_Skill:Melee5 "Passive Skill:Melee5") [[21]](/wiki/Passive_Skill:Unarmed4~ "Passive Skill:Unarmed4~") [[22]](/wiki/Passive_Skill:Unarmed3 "Passive Skill:Unarmed3") [[23]](/wiki/Passive_Skill:Ranged22 "Passive Skill:Ranged22")  ---  8% increased Attack Damage [[3]](/wiki/Passive_Skill:Attack~damage1 "Passive Skill:Attack~damage1") [[4]](/wiki/Passive_Skill:Attack~damage3 "Passive Skill:Attack~damage3")  ---  16% increased Attack Damage against [Rare or Unique](/wiki/Rarity "Rarity") Enemies [[7]](/wiki/Passive_Skill:Boss~slaying2~ "Passive Skill:Boss~slaying2~") [[8]](/wiki/Passive_Skill:Boss~slaying6 "Passive Skill:Boss~slaying6") [[9]](/wiki/Passive_Skill:Boss~slaying7 "Passive Skill:Boss~slaying7")  ---  5% increased Attack Damage 8% increased [Immobilisation](/wiki/Immobilised "Immobilised") buildup [[4]](/wiki/Passive_Skill:Melee7 "Passive Skill:Melee7")  ---  12% increased Attack Damage [[13]](/wiki/Passive_Skill:Slow~attacks2~ "Passive Skill:Slow~attacks2~") [[14]](/wiki/Passive_Skill:Slow~attacks3 "Passive Skill:Slow~attacks3") [[15]](/wiki/Passive_Skill:Slow~attacks5 "Passive Skill:Slow~attacks5") |
| [Attack Damage and Accuracy](/wiki/Attack_Damage_and_Accuracy/edit?redlink=1 "Attack Damage and Accuracy (page does not exist)") | 6% increased [Accuracy](/wiki/Accuracy "Accuracy") Rating 5% increased Attack Damage [[1]](/wiki/Passive_Skill:Accuracy41 "Passive Skill:Accuracy41") [[2]](/wiki/Passive_Skill:Accuracy42 "Passive Skill:Accuracy42") [[3]](/wiki/Passive_Skill:Accuracy43~ "Passive Skill:Accuracy43~") [[4]](/wiki/Passive_Skill:Accuracy44 "Passive Skill:Accuracy44")  ---  6% increased Attack Damage 5% increased [Accuracy](/wiki/Accuracy "Accuracy") Rating [[4]](/wiki/Passive_Skill:Attack31 "Passive Skill:Attack31") [[5]](/wiki/Passive_Skill:Attack32~ "Passive Skill:Attack32~") [[6]](/wiki/Passive_Skill:Attack34 "Passive Skill:Attack34") |
| [Attack Damage and Combo](/wiki/Attack_Damage_and_Combo/edit?redlink=1 "Attack Damage and Combo (page does not exist)") | 5% increased Attack Damage 5% Chance to build an additional [Combo](/wiki/Combo "Combo") on [Hit](/wiki/Hit "Hit") [[1]](/wiki/Passive_Skill:Unarmed1 "Passive Skill:Unarmed1") |
| [Attack Damage and Movement Speed](/wiki/Attack_Damage_and_Movement_Speed/edit?redlink=1 "Attack Damage and Movement Speed (page does not exist)") | 8% increased Attack Damage 2% increased Movement Speed [[1]](/wiki/Passive_Skill:Attack2 "Passive Skill:Attack2") |
| [Attack Damage and Presence Area](/wiki/Attack_Damage_and_Presence_Area/edit?redlink=1 "Attack Damage and Presence Area (page does not exist)") | 6% increased Attack Damage 10% increased [Presence](/wiki/Presence "Presence") Area of Effect [[1]](/wiki/Passive_Skill:Glory10 "Passive Skill:Glory10") [[2]](/wiki/Passive_Skill:Glory9 "Passive Skill:Glory9") |
| [Attack Damage and Skill Duration](/wiki/Attack_Damage_and_Skill_Duration/edit?redlink=1 "Attack Damage and Skill Duration (page does not exist)") | 8% increased Attack Damage 8% increased Skill Effect Duration [[1]](/wiki/Passive_Skill:Attack10 "Passive Skill:Attack10") [[2]](/wiki/Passive_Skill:Attack7 "Passive Skill:Attack7") |
| [Attack Damage and Slow Effect](/wiki/Attack_Damage_and_Slow_Effect/edit?redlink=1 "Attack Damage and Slow Effect (page does not exist)") | 8% increased Attack Damage [Debuffs](/wiki/Debuff "Debuff") you inflict have 4% increased [Slow Magnitude](/wiki/Slow_Magnitude_Modifier/edit?redlink=1 "Slow Magnitude Modifier (page does not exist)") [[1]](/wiki/Passive_Skill:Attack3 "Passive Skill:Attack3") |
| [Attack Damage and Speed](/wiki/Attack_Damage_and_Speed/edit?redlink=1 "Attack Damage and Speed (page does not exist)") | 5% increased Attack Damage 2% increased Attack Speed [[1]](/wiki/Passive_Skill:Attack51 "Passive Skill:Attack51") |
| [Attack Damage if Stunned Recently](/wiki/Attack_Damage_if_Stunned_Recently/edit?redlink=1 "Attack Damage if Stunned Recently (page does not exist)") | 20% increased Attack Damage if you have been [Heavy Stunned](/wiki/Heavy_Stun "Heavy Stun") [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Attack39 "Passive Skill:Attack39") |
| [Attack Damage on Low Life](/wiki/Attack_Damage_on_Low_Life/edit?redlink=1 "Attack Damage on Low Life (page does not exist)") | 20% increased Attack Damage while on [Low Life](/wiki/Low_Life "Low Life") [[1]](/wiki/Passive_Skill:Attack37 "Passive Skill:Attack37") |
| [Attack Damage vs Bleeding Enemies](/wiki/Attack_Damage_vs_Bleeding_Enemies/edit?redlink=1 "Attack Damage vs Bleeding Enemies (page does not exist)") | 16% increased Attack Damage against Bleeding Enemies [[1]](/wiki/Passive_Skill:Bleed11~~ "Passive Skill:Bleed11~~") [[2]](/wiki/Passive_Skill:Bleed16 "Passive Skill:Bleed16") |
| [Attack Damage while Moving](/wiki/Attack_Damage_while_Moving/edit?redlink=1 "Attack Damage while Moving (page does not exist)") | 12% increased Attack Damage while moving [[1]](/wiki/Passive_Skill:Slow~mitigation10~ "Passive Skill:Slow~mitigation10~") [[2]](/wiki/Passive_Skill:Slow~mitigation12 "Passive Skill:Slow~mitigation12") [[3]](/wiki/Passive_Skill:Slow~mitigation9 "Passive Skill:Slow~mitigation9") |
| [Attack Damage while no remaining Life Flasks](/wiki/Attack_Damage_while_no_remaining_Life_Flasks/edit?redlink=1 "Attack Damage while no remaining Life Flasks (page does not exist)") | 20% increased Attack Damage while you have no Life [Flask](/wiki/Flask "Flask") uses left [[1]](/wiki/Passive_Skill:Attack40 "Passive Skill:Attack40") |
| [Attack Damage while Surrounded](/wiki/Attack_Damage_while_Surrounded/edit?redlink=1 "Attack Damage while Surrounded (page does not exist)") | 20% increased Attack Damage while [Surrounded](/wiki/Surrounded "Surrounded") [[1]](/wiki/Passive_Skill:Attack38~ "Passive Skill:Attack38~")  ---  25% increased Attack Damage while [Surrounded](/wiki/Surrounded "Surrounded") [[6]](/wiki/Passive_Skill:Being~surrounded13 "Passive Skill:Being~surrounded13") [[7]](/wiki/Passive_Skill:Being~surrounded14 "Passive Skill:Being~surrounded14") [[8]](/wiki/Passive_Skill:Being~surrounded15 "Passive Skill:Being~surrounded15") [[9]](/wiki/Passive_Skill:Being~surrounded6 "Passive Skill:Being~surrounded6") [[10]](/wiki/Passive_Skill:Being~surrounded7 "Passive Skill:Being~surrounded7") |
| [Attack Damage with Ally](/wiki/Attack_Damage_with_Ally/edit?redlink=1 "Attack Damage with Ally (page does not exist)") | [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") deal 8% increased Damage 8% increased Attack Damage while you have an [Ally](/wiki/Ally "Ally") in your [Presence](/wiki/Presence "Presence") [[1]](/wiki/Passive_Skill:Auras20 "Passive Skill:Auras20") [[2]](/wiki/Passive_Skill:Auras25 "Passive Skill:Auras25")  ---  16% increased Attack Damage while you have an [Ally](/wiki/Ally "Ally") in your [Presence](/wiki/Presence "Presence") [[2]](/wiki/Passive_Skill:Auras22 "Passive Skill:Auras22") |
| [Attack Damage with nearby Ally](/wiki/Attack_Damage_with_nearby_Ally/edit?redlink=1 "Attack Damage with nearby Ally (page does not exist)") | 16% increased Attack Damage while you have an [Ally](/wiki/Ally "Ally") in your [Presence](/wiki/Presence "Presence") [[1]](/wiki/Passive_Skill:Attack26 "Passive Skill:Attack26") [[2]](/wiki/Passive_Skill:Attack30 "Passive Skill:Attack30") |
| [Attack Elemental Damage](/wiki/Attack_Elemental_Damage/edit?redlink=1 "Attack Elemental Damage (page does not exist)") | 12% increased [Elemental](/wiki/Elemental "Elemental") Damage with Attacks [[1]](/wiki/Passive_Skill:Accuracy52 "Passive Skill:Accuracy52") [[2]](/wiki/Passive_Skill:Accuracy53 "Passive Skill:Accuracy53") |
| [Elemental Attack Damage](/wiki/Elemental_Attack_Damage/edit?redlink=1 "Elemental Attack Damage (page does not exist)") | 12% increased [Elemental](/wiki/Elemental "Elemental") Damage with Attacks [[1]](/wiki/Passive_Skill:Elemental54 "Passive Skill:Elemental54") [[2]](/wiki/Passive_Skill:Elemental55 "Passive Skill:Elemental55") [[3]](/wiki/Passive_Skill:Elemental~attacks1 "Passive Skill:Elemental~attacks1") [[4]](/wiki/Passive_Skill:Elemental~attacks12 "Passive Skill:Elemental~attacks12") [[5]](/wiki/Passive_Skill:Elemental~attacks2 "Passive Skill:Elemental~attacks2") [[6]](/wiki/Passive_Skill:Elemental~attacks3 "Passive Skill:Elemental~attacks3") [[7]](/wiki/Passive_Skill:Elemental~attacks4 "Passive Skill:Elemental~attacks4") [[8]](/wiki/Passive_Skill:Elemental~attacks5 "Passive Skill:Elemental~attacks5") [[9]](/wiki/Passive_Skill:Elemental~attacks6 "Passive Skill:Elemental~attacks6") [[10]](/wiki/Passive_Skill:Elemental~attacks7 "Passive Skill:Elemental~attacks7") |
| [Fire Damage and Attack Damage](/wiki/Fire_Damage_and_Attack_Damage/edit?redlink=1 "Fire Damage and Attack Damage (page does not exist)") | 8% increased [Fire](/wiki/Fire "Fire") Damage 8% increased Attack Damage [[1]](/wiki/Passive_Skill:Fire55 "Passive Skill:Fire55") [[2]](/wiki/Passive_Skill:Fire56 "Passive Skill:Fire56") |
| [Glory Generation and Attack Damage](/wiki/Glory_Generation_and_Attack_Damage/edit?redlink=1 "Glory Generation and Attack Damage (page does not exist)") | 5% increased Attack Damage 8% increased [Glory](/wiki/Glory "Glory") generation [[1]](/wiki/Passive_Skill:Glory1 "Passive Skill:Glory1") [[2]](/wiki/Passive_Skill:Glory11 "Passive Skill:Glory11") [[3]](/wiki/Passive_Skill:Glory12 "Passive Skill:Glory12") [[4]](/wiki/Passive_Skill:Glory2 "Passive Skill:Glory2") |
| [Physical Attack Damage](/wiki/Physical_Attack_Damage/edit?redlink=1 "Physical Attack Damage (page does not exist)") | 12% increased Attack [Physical](/wiki/Physical "Physical") Damage [[1]](/wiki/Passive_Skill:Physical27~ "Passive Skill:Physical27~") [[2]](/wiki/Passive_Skill:Physical38 "Passive Skill:Physical38") |
| [Reduced Movement Penalty and Attack Damage while Moving](/wiki/Reduced_Movement_Penalty_and_Attack_Damage_while_Moving/edit?redlink=1 "Reduced Movement Penalty and Attack Damage while Moving (page does not exist)") | 2% reduced Movement Speed Penalty from using Skills while moving 8% increased Attack Damage while moving [[1]](/wiki/Passive_Skill:Slow~mitigation11 "Passive Skill:Slow~mitigation11") [[2]](/wiki/Passive_Skill:Slow~mitigation13 "Passive Skill:Slow~mitigation13") |
| [Shapeshifting Attack Damage](/wiki/Shapeshifting_Attack_Damage/edit?redlink=1 "Shapeshifting Attack Damage (page does not exist)") | 15% increased Attack Damage if you have [Shapeshifted](/wiki/Shapeshifting "Shapeshifting") to an Animal form [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Shapeshifting23 "Passive Skill:Shapeshifting23") [[2]](/wiki/Passive_Skill:Shapeshifting24~ "Passive Skill:Shapeshifting24~") |
| [Shield Damage](/wiki/Shield_Damage/edit?redlink=1 "Shield Damage (page does not exist)") | Attack Skills deal 10% increased Damage while holding a [Shield](/wiki/Shield "Shield") [[1]](/wiki/Passive_Skill:Shield1 "Passive Skill:Shield1") [[2]](/wiki/Passive_Skill:Shield2 "Passive Skill:Shield2") [[3]](/wiki/Passive_Skill:Shield24 "Passive Skill:Shield24") [[4]](/wiki/Passive_Skill:Shield3 "Passive Skill:Shield3") [[5]](/wiki/Passive_Skill:Shield4 "Passive Skill:Shield4") |
| [Spell and Attack Damage](/wiki/Spell_and_Attack_Damage/edit?redlink=1 "Spell and Attack Damage (page does not exist)") | 10% increased Attack Damage 10% increased [Spell](/wiki/Spell "Spell") Damage [[1]](/wiki/Passive_Skill:Placeholder2 "Passive Skill:Placeholder2") |
| [Among the Hordes](/wiki/Among_the_Hordes/edit?redlink=1 "Among the Hordes (page does not exist)") | [Minions](/wiki/Minion "Minion") have 10% increased Movement Speed 15% increased Attack Damage 3% increased Movement Speed [[1]](/wiki/Passive_Skill:Minion~offence59 "Passive Skill:Minion~offence59") |
| [Blazing Arms](/wiki/Blazing_Arms/edit?redlink=1 "Blazing Arms (page does not exist)") | 16% increased [Fire](/wiki/Fire "Fire") Damage 16% increased Attack Damage 30% increased [Flammability](/wiki/Flammability "Flammability") [Magnitude](/wiki/Magnitude "Magnitude") [[1]](/wiki/Passive_Skill:Fire57 "Passive Skill:Fire57") |
| [Blinding Strike](/wiki/Blinding_Strike/edit?redlink=1 "Blinding Strike (page does not exist)") | 24% increased Attack Damage 10% chance to [Blind](/wiki/Blind "Blind") Enemies on [Hit](/wiki/Hit "Hit") with Attacks [[1]](/wiki/Passive_Skill:Attack16 "Passive Skill:Attack16") |
| [Catalysis](/wiki/Catalysis/edit?redlink=1 "Catalysis (page does not exist)") | 20% increased [Elemental](/wiki/Elemental "Elemental") Damage with Attacks 5% of [Physical](/wiki/Physical "Physical") Damage from [Hits](/wiki/Hit "Hit") taken as Damage of a Random [Element](/wiki/Elemental_damage "Elemental damage") [[1]](/wiki/Passive_Skill:Elemental~attacks8 "Passive Skill:Elemental~attacks8") |
| [Chakra of Impact](/wiki/Chakra_of_Impact/edit?redlink=1 "Chakra of Impact (page does not exist)") | Skills deal 8% increased Damage per [Combo](/wiki/Combo "Combo") consumed, up to 40% 20% increased Attack Damage [[1]](/wiki/Passive_Skill:Unarmed5 "Passive Skill:Unarmed5") |
| [Concussive Attack](/wiki/Concussive_Attack/edit?redlink=1 "Concussive Attack (page does not exist)") | 25% increased Attack Damage 5% chance to [Daze](/wiki/Daze "Daze") on [Hit](/wiki/Hit "Hit") [[1]](/wiki/Passive_Skill:Attack45 "Passive Skill:Attack45") |
| [Crushing Verdict](/wiki/Crushing_Verdict/edit?redlink=1 "Crushing Verdict (page does not exist)") | 50% increased Attack Damage 30% increased [Stun](/wiki/Stun "Stun") Buildup 5% reduced Attack Speed [[1]](/wiki/Passive_Skill:Slow~attacks10 "Passive Skill:Slow~attacks10") |
| [Emboldening Casts](/wiki/Emboldening_Casts/edit?redlink=1 "Emboldening Casts (page does not exist)") | 12% increased Attack Damage for each different Non-Instant [Spell](/wiki/Spell "Spell") you've used in the past 8 seconds [[1]](/wiki/Passive_Skill:Attacks~and~spells12 "Passive Skill:Attacks~and~spells12") |
| [Equilibrium](/wiki/Equilibrium/edit?redlink=1 "Equilibrium (page does not exist)") | 30% increased Attack Damage if you've Cast a [Spell](/wiki/Spell "Spell") [Recently](/wiki/Recently "Recently") 10% increased Cast Speed if you've Attacked [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Attacks~and~spells20 "Passive Skill:Attacks~and~spells20") |
| [Fortified Location](/wiki/Fortified_Location/edit?redlink=1 "Fortified Location (page does not exist)") | 10% increased [Armour](/wiki/Armour "Armour") and [Evasion](/wiki/Evasion "Evasion") Rating per Summoned [Totem](/wiki/Totem "Totem") in your [Presence](/wiki/Presence "Presence") 10% increased Attack Damage per Summoned [Totem](/wiki/Totem "Totem") in your [Presence](/wiki/Presence "Presence") [[1]](/wiki/Passive_Skill:Ballista17 "Passive Skill:Ballista17") |
| [Frantic Fighter](/wiki/Frantic_Fighter/edit?redlink=1 "Frantic Fighter (page does not exist)") | 30% reduced [Accuracy](/wiki/Accuracy "Accuracy") Rating while [Surrounded](/wiki/Surrounded "Surrounded") 100% increased Attack Damage while [Surrounded](/wiki/Surrounded "Surrounded") [[1]](/wiki/Passive_Skill:Being~surrounded24 "Passive Skill:Being~surrounded24") |
| [Greatest Defence](/wiki/Greatest_Defence/edit?redlink=1 "Greatest Defence (page does not exist)") | 4% increased Attack Damage per 75 [Item Armour and Evasion Rating](/wiki/Defences "Defences") on Equipped Shield [[1]](/wiki/Passive_Skill:Shield9 "Passive Skill:Shield9") |
| [Killer Instinct](/wiki/Killer_Instinct "Killer Instinct") | 40% increased Attack Damage while on Full Life 60% increased Attack Damage while on [Low Life](/wiki/Low_Life "Low Life") [[1]](/wiki/Passive_Skill:Attack27 "Passive Skill:Attack27") |
| [Last Stand](/wiki/Last_Stand/edit?redlink=1 "Last Stand (page does not exist)") | 25% increased Attack Damage while on [Low Life](/wiki/Low_Life "Low Life") 25% increased Attack Damage while [Surrounded](/wiki/Surrounded "Surrounded") 25% increased Attack Damage if you have been [Heavy Stunned](/wiki/Heavy_Stun "Heavy Stun") [Recently](/wiki/Recently "Recently") 25% increased Attack Damage while you have no Life [Flask](/wiki/Flask "Flask") uses left [[1]](/wiki/Passive_Skill:Attack21 "Passive Skill:Attack21") |
| [Lockdown](/wiki/Lockdown "Lockdown") | Enemies are [Maimed](/wiki/Maim "Maim") for 4 seconds after becoming [Unpinned](/wiki/Pinned "Pinned") 40% increased Attack Damage against Maimed Enemies [[1]](/wiki/Passive_Skill:Pin11 "Passive Skill:Pin11") |
| [Maiming Strike](/wiki/Maiming_Strike/edit?redlink=1 "Maiming Strike (page does not exist)") | 25% increased Attack Damage Attacks have 25% chance to [Maim](/wiki/Maim "Maim") on [Hit](/wiki/Hit "Hit") [[1]](/wiki/Passive_Skill:Attack5 "Passive Skill:Attack5") |
| [Nimble Strength](/wiki/Nimble_Strength/edit?redlink=1 "Nimble Strength (page does not exist)") | Gain [Accuracy](/wiki/Accuracy "Accuracy") Rating equal to your [Strength](/wiki/Strength "Strength") 10% increased Attack Damage [[1]](/wiki/Passive_Skill:Accuracy45~ "Passive Skill:Accuracy45~") |
| [Personal Touch](/wiki/Personal_Touch/edit?redlink=1 "Personal Touch (page does not exist)") | 20% increased Attack Damage 12% increased [Immobilisation](/wiki/Immobilised "Immobilised") buildup [[1]](/wiki/Passive_Skill:Melee32 "Passive Skill:Melee32") |
| [Presence Present](/wiki/Presence_Present/edit?redlink=1 "Presence Present (page does not exist)") | 35% increased Attack Damage while you have an [Ally](/wiki/Ally "Ally") in your [Presence](/wiki/Presence "Presence") [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") have +100 to [Accuracy](/wiki/Accuracy "Accuracy") Rating [[1]](/wiki/Passive_Skill:Attack29 "Passive Skill:Attack29") |
| [Prolonged Assault](/wiki/Prolonged_Assault/edit?redlink=1 "Prolonged Assault (page does not exist)") | 16% increased Attack Damage 16% increased Skill Effect Duration [Buffs](/wiki/Buffs "Buffs") on you expire 10% slower [[1]](/wiki/Passive_Skill:Attack11 "Passive Skill:Attack11") |
| [Saqawal's Guidance](/wiki/Saqawal%27s_Guidance/edit?redlink=1 "Saqawal's Guidance (page does not exist)") | 20% increased [Elemental](/wiki/Elemental "Elemental") Damage with Attacks 15% increased [Accuracy](/wiki/Accuracy "Accuracy") Rating +10 to [Dexterity](/wiki/Dexterity "Dexterity") [[1]](/wiki/Passive_Skill:Accuracy54~ "Passive Skill:Accuracy54~") |
| [Serrated Edges](/wiki/Serrated_Edges/edit?redlink=1 "Serrated Edges (page does not exist)") | 30% increased Attack Damage against [Rare or Unique](/wiki/Rarity "Rarity") Enemies 10% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for Attacks [[1]](/wiki/Passive_Skill:Melee31 "Passive Skill:Melee31") |
| [Shifted Strikes](/wiki/Shifted_Strikes/edit?redlink=1 "Shifted Strikes (page does not exist)") | 30% increased Attack Damage if you have [Shapeshifted](/wiki/Shapeshifting "Shapeshifting") to an Animal form [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Shapeshifting26 "Passive Skill:Shapeshifting26") |
| [Spiked Shield](/wiki/Spiked_Shield "Spiked Shield") | 50% increased [Defences](/wiki/Defences "Defences") from Equipped [Shield](/wiki/Shield "Shield") 2% increased Attack Damage per 75 [Item Armour and Evasion Rating](/wiki/Defences "Defences") on Equipped Shield [[1]](/wiki/Passive_Skill:Block17 "Passive Skill:Block17") |
| [Spray and Pray](/wiki/Spray_and_Pray/edit?redlink=1 "Spray and Pray (page does not exist)") | 50% increased Attack Damage while moving 20% reduced [Accuracy](/wiki/Accuracy "Accuracy") Rating while moving 5% reduced Movement Speed Penalty from using Skills while moving [[1]](/wiki/Passive_Skill:Slow~mitigation15 "Passive Skill:Slow~mitigation15") |
| [Unexpected Finesse](/wiki/Unexpected_Finesse/edit?redlink=1 "Unexpected Finesse (page does not exist)") | 10% increased Attack Damage 30% increased [Accuracy](/wiki/Accuracy "Accuracy") Rating while moving [[1]](/wiki/Passive_Skill:Attack33~ "Passive Skill:Attack33~") |

### Attack speed

| Name | Stats |
| --- | --- |
| [Accuracy and Attack Speed](/wiki/Accuracy_and_Attack_Speed/edit?redlink=1 "Accuracy and Attack Speed (page does not exist)") | 5% increased [Accuracy](/wiki/Accuracy "Accuracy") Rating 2% increased Attack Speed [[1]](/wiki/Passive_Skill:Accuracy37 "Passive Skill:Accuracy37") [[2]](/wiki/Passive_Skill:Accuracy38 "Passive Skill:Accuracy38") [[3]](/wiki/Passive_Skill:Accuracy39 "Passive Skill:Accuracy39") |
| [Attack Damage and Speed](/wiki/Attack_Damage_and_Speed/edit?redlink=1 "Attack Damage and Speed (page does not exist)") | 5% increased Attack Damage 2% increased Attack Speed [[1]](/wiki/Passive_Skill:Attack51 "Passive Skill:Attack51") |
| [Attack Speed](/wiki/Attack_Speed "Attack Speed") | 3% increased Attack Speed [[1]](/wiki/Passive_Skill:Attack25 "Passive Skill:Attack25") [[2]](/wiki/Passive_Skill:Attack48 "Passive Skill:Attack48") [[3]](/wiki/Passive_Skill:Attack~speed1 "Passive Skill:Attack~speed1") [[4]](/wiki/Passive_Skill:Attack~speed10 "Passive Skill:Attack~speed10") [[5]](/wiki/Passive_Skill:Attack~speed13~ "Passive Skill:Attack~speed13~") [[6]](/wiki/Passive_Skill:Attack~speed14 "Passive Skill:Attack~speed14") [[7]](/wiki/Passive_Skill:Attack~speed2~ "Passive Skill:Attack~speed2~") [[8]](/wiki/Passive_Skill:Attack~speed26 "Passive Skill:Attack~speed26") [[9]](/wiki/Passive_Skill:Attack~speed28 "Passive Skill:Attack~speed28") [[10]](/wiki/Passive_Skill:Attack~speed29 "Passive Skill:Attack~speed29") [[11]](/wiki/Passive_Skill:Attack~speed3 "Passive Skill:Attack~speed3") [[12]](/wiki/Passive_Skill:Attack~speed4 "Passive Skill:Attack~speed4") [[13]](/wiki/Passive_Skill:Attack~speed41 "Passive Skill:Attack~speed41") [[14]](/wiki/Passive_Skill:Attack~speed42 "Passive Skill:Attack~speed42") [[15]](/wiki/Passive_Skill:Attack~speed45 "Passive Skill:Attack~speed45") [[16]](/wiki/Passive_Skill:Attack~speed5 "Passive Skill:Attack~speed5") [[17]](/wiki/Passive_Skill:Attack~speed57 "Passive Skill:Attack~speed57") [[18]](/wiki/Passive_Skill:Attack~speed58 "Passive Skill:Attack~speed58") [[19]](/wiki/Passive_Skill:Attack~speed7 "Passive Skill:Attack~speed7") [[20]](/wiki/Passive_Skill:Attack~speed9 "Passive Skill:Attack~speed9") [[21]](/wiki/Passive_Skill:Duration~spells8 "Passive Skill:Duration~spells8") [[22]](/wiki/Passive_Skill:Duration~spells9 "Passive Skill:Duration~spells9") [[23]](/wiki/Passive_Skill:Melee6 "Passive Skill:Melee6")  ---  4% increased Attack Speed while a [Rare or Unique](/wiki/Rarity "Rarity") Enemy is in your [Presence](/wiki/Presence "Presence") [[4]](/wiki/Passive_Skill:Boss~slaying3 "Passive Skill:Boss~slaying3") [[5]](/wiki/Passive_Skill:Boss~slaying4 "Passive Skill:Boss~slaying4") [[6]](/wiki/Passive_Skill:Boss~slaying5 "Passive Skill:Boss~slaying5") |
| [Attack Speed and Accuracy](/wiki/Attack_Speed_and_Accuracy/edit?redlink=1 "Attack Speed and Accuracy (page does not exist)") | 2% increased Attack Speed 5% increased [Accuracy](/wiki/Accuracy "Accuracy") Rating [[1]](/wiki/Passive_Skill:Attack~speed23 "Passive Skill:Attack~speed23") [[2]](/wiki/Passive_Skill:Attack~speed24 "Passive Skill:Attack~speed24") |
| [Attack Speed and Dexterity](/wiki/Attack_Speed_and_Dexterity/edit?redlink=1 "Attack Speed and Dexterity (page does not exist)") | 2% increased Attack Speed +5 to [Dexterity](/wiki/Dexterity "Dexterity") [[1]](/wiki/Passive_Skill:Attack~speed18 "Passive Skill:Attack~speed18") [[2]](/wiki/Passive_Skill:Attack~speed19 "Passive Skill:Attack~speed19") [[3]](/wiki/Passive_Skill:Attack~speed21~ "Passive Skill:Attack~speed21~") [[4]](/wiki/Passive_Skill:Attack~speed22 "Passive Skill:Attack~speed22") |
| [Attack Speed and Flask Duration](/wiki/Attack_Speed_and_Flask_Duration/edit?redlink=1 "Attack Speed and Flask Duration (page does not exist)") | 2% increased Attack Speed 5% increased [Flask](/wiki/Flask "Flask") Effect Duration [[1]](/wiki/Passive_Skill:Attack~speed15 "Passive Skill:Attack~speed15") [[2]](/wiki/Passive_Skill:Attack~speed16 "Passive Skill:Attack~speed16") [[3]](/wiki/Passive_Skill:Attack~speed17 "Passive Skill:Attack~speed17") |
| [Attack Speed and Minion Attack Speed](/wiki/Attack_Speed_and_Minion_Attack_Speed/edit?redlink=1 "Attack Speed and Minion Attack Speed (page does not exist)") | Minions have 3% increased Attack Speed 3% increased Attack Speed [[1]](/wiki/Passive_Skill:Minion~offence57 "Passive Skill:Minion~offence57") [[2]](/wiki/Passive_Skill:Minion~offence58 "Passive Skill:Minion~offence58") |
| [Attack Speed with Companion in Presence](/wiki/Attack_Speed_with_Companion_in_Presence/edit?redlink=1 "Attack Speed with Companion in Presence (page does not exist)") | 4% increased Attack Speed while your [Companion](/wiki/Companion "Companion") is in your [Presence](/wiki/Presence "Presence") [[1]](/wiki/Passive_Skill:Companions31~ "Passive Skill:Companions31~") [[2]](/wiki/Passive_Skill:Companions32 "Passive Skill:Companions32") |
| [Dual Wielding Speed](/wiki/Dual_Wielding_Speed/edit?redlink=1 "Dual Wielding Speed (page does not exist)") | 3% increased Attack Speed while [Dual Wielding](/wiki/Dual_Wielding "Dual Wielding") [[1]](/wiki/Passive_Skill:Dual~wielding6~ "Passive Skill:Dual~wielding6~") [[2]](/wiki/Passive_Skill:Dual~wielding7 "Passive Skill:Dual~wielding7") [[3]](/wiki/Passive_Skill:Dual~wielding9 "Passive Skill:Dual~wielding9") |
| [Elemental](/wiki/Elemental "Elemental") | 3% increased Attack and Cast Speed with Elemental Skills [[1]](/wiki/Passive_Skill:Elemental10 "Passive Skill:Elemental10") |
| [Lightning Skill Speed](/wiki/Lightning_Skill_Speed/edit?redlink=1 "Lightning Skill Speed (page does not exist)") | 3% increased Attack and Cast Speed with [Lightning](/wiki/Lightning "Lightning") Skills [[1]](/wiki/Passive_Skill:Lightning10 "Passive Skill:Lightning10") [[2]](/wiki/Passive_Skill:Lightning16 "Passive Skill:Lightning16") [[3]](/wiki/Passive_Skill:Lightning7 "Passive Skill:Lightning7") [[4]](/wiki/Passive_Skill:Lightning9 "Passive Skill:Lightning9") |
| [Mana Regeneration and Attack Speed](/wiki/Mana_Regeneration_and_Attack_Speed/edit?redlink=1 "Mana Regeneration and Attack Speed (page does not exist)") | 5% increased Mana Regeneration Rate 2% increased Attack Speed [[1]](/wiki/Passive_Skill:Monkchakra2~ "Passive Skill:Monkchakra2~") [[2]](/wiki/Passive_Skill:Monkchakra3 "Passive Skill:Monkchakra3") |
| [Shield Attack Speed](/wiki/Shield_Attack_Speed/edit?redlink=1 "Shield Attack Speed (page does not exist)") | 3% increased Attack Speed while holding a Shield [[1]](/wiki/Passive_Skill:Shield27 "Passive Skill:Shield27") |
| [Slow Effect on You and Attack Speed](/wiki/Slow_Effect_on_You_and_Attack_Speed/edit?redlink=1 "Slow Effect on You and Attack Speed (page does not exist)") | 4% reduced [Slowing](/wiki/Slow "Slow") Potency of [Debuffs](/wiki/Debuff "Debuff") on You 2% increased Attack Speed [[1]](/wiki/Passive_Skill:Duration~spells7 "Passive Skill:Duration~spells7") |
| [Speed with Elemental Skills](/wiki/Speed_with_Elemental_Skills/edit?redlink=1 "Speed with Elemental Skills (page does not exist)") | 3% increased Attack and Cast Speed with Elemental Skills [[1]](/wiki/Passive_Skill:Elemental6 "Passive Skill:Elemental6") [[2]](/wiki/Passive_Skill:Elemental7 "Passive Skill:Elemental7") |
| [Adrenaline Rush](/wiki/Adrenaline_Rush/edit?redlink=1 "Adrenaline Rush (page does not exist)") | 4% increased Movement Speed if you've Killed [Recently](/wiki/Recently "Recently") 8% increased Attack Speed if you've killed [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Movement~speed11 "Passive Skill:Movement~speed11") |
| [Agile Succession](/wiki/Agile_Succession/edit?redlink=1 "Agile Succession (page does not exist)") | 6% increased Attack Speed 30% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") if you have Hit an Enemy [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Attack~speed60~ "Passive Skill:Attack~speed60~") |
| [Ancestral Alacrity](/wiki/Ancestral_Alacrity/edit?redlink=1 "Ancestral Alacrity (page does not exist)") | 30% increased [Totem](/wiki/Totem "Totem") Placement speed 8% increased Attack and Cast Speed if you've summoned a [Totem](/wiki/Totem "Totem") [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Totems28 "Passive Skill:Totems28") |
| [Ancestral Conduits](/wiki/Ancestral_Conduits/edit?redlink=1 "Ancestral Conduits (page does not exist)") | 12% increased Attack and Cast Speed if you've summoned a [Totem](/wiki/Totem "Totem") [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Totems33~ "Passive Skill:Totems33~") |
| [Blade Flurry](/wiki/Blade_Flurry/edit?redlink=1 "Blade Flurry (page does not exist)") | 6% increased Attack Speed while [Dual Wielding](/wiki/Dual_Wielding "Dual Wielding") 15% increased Attack [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") while [Dual Wielding](/wiki/Dual_Wielding "Dual Wielding") [[1]](/wiki/Passive_Skill:Dual~wielding8 "Passive Skill:Dual~wielding8") |
| [Blurred Motion](/wiki/Blurred_Motion/edit?redlink=1 "Blurred Motion (page does not exist)") | 5% increased Attack Speed 10% increased [Accuracy](/wiki/Accuracy "Accuracy") Rating 5% increased [Dexterity](/wiki/Dexterity "Dexterity") [[1]](/wiki/Passive_Skill:Attack~speed20 "Passive Skill:Attack~speed20") |
| [Carved Earth](/wiki/Carved_Earth/edit?redlink=1 "Carved Earth (page does not exist)") | 20% increased [Totem](/wiki/Totem "Totem") Damage 6% increased Attack and Cast Speed if you've summoned a [Totem](/wiki/Totem "Totem") [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Totems8 "Passive Skill:Totems8") |
| [Chakra of Rhythm](/wiki/Chakra_of_Rhythm/edit?redlink=1 "Chakra of Rhythm (page does not exist)") | 6% increased Attack Speed 20% Chance to build an additional [Combo](/wiki/Combo "Combo") on [Hit](/wiki/Hit "Hit") [[1]](/wiki/Passive_Skill:Unarmed11 "Passive Skill:Unarmed11") |
| [Chakra of Thought](/wiki/Chakra_of_Thought/edit?redlink=1 "Chakra of Thought (page does not exist)") | 15% increased Attack Speed while not on Low Mana 8% of Damage is taken from Mana before Life [[1]](/wiki/Passive_Skill:Monkchakra6 "Passive Skill:Monkchakra6") |
| [Crushing Verdict](/wiki/Crushing_Verdict/edit?redlink=1 "Crushing Verdict (page does not exist)") | 50% increased Attack Damage 30% increased [Stun](/wiki/Stun "Stun") Buildup 5% reduced Attack Speed [[1]](/wiki/Passive_Skill:Slow~attacks10 "Passive Skill:Slow~attacks10") |
| [Deep Trance](/wiki/Deep_Trance/edit?redlink=1 "Deep Trance (page does not exist)") | 8% increased Attack Speed 15% increased Cost [Efficiency](/wiki/Efficiency "Efficiency") [[1]](/wiki/Passive_Skill:Attack~speed36 "Passive Skill:Attack~speed36") |
| [Falcon Dive](/wiki/Falcon_Dive "Falcon Dive") | 4% increased Attack Speed 1% increased Attack Speed per 400 [Accuracy](/wiki/Accuracy "Accuracy") Rating, up to 20% [[1]](/wiki/Passive_Skill:Accuracy20 "Passive Skill:Accuracy20") |
| [Falcon Technique](/wiki/Falcon_Technique "Falcon Technique") | 1% increased Attack Speed per 25 [Dexterity](/wiki/Dexterity "Dexterity") [[1]](/wiki/Passive_Skill:Attack~speed34 "Passive Skill:Attack~speed34") |
| [Flow Like Water](/wiki/Flow_Like_Water/edit?redlink=1 "Flow Like Water (page does not exist)") | 8% increased Attack and Cast Speed +5 to [Dexterity](/wiki/Dexterity "Dexterity") and [Intelligence](/wiki/Intelligence "Intelligence") [[1]](/wiki/Passive_Skill:Shadow~monk~notable1 "Passive Skill:Shadow~monk~notable1") |
| [General Electric](/wiki/General_Electric/edit?redlink=1 "General Electric (page does not exist)") | 40% increased chance to [Shock](/wiki/Shock "Shock") 5% increased Attack and Cast Speed with [Lightning](/wiki/Lightning "Lightning") Skills [[1]](/wiki/Passive_Skill:Shock12 "Passive Skill:Shock12") |
| [Heavy Ammunition](/wiki/Heavy_Ammunition/edit?redlink=1 "Heavy Ammunition (page does not exist)") | 40% increased [Projectile](/wiki/Projectile "Projectile") [Stun Buildup](/wiki/Stun "Stun") 5% reduced Attack Speed 40% increased [Projectile](/wiki/Projectile "Projectile") Damage [[1]](/wiki/Passive_Skill:Ranged32 "Passive Skill:Ranged32") |
| [Honed Instincts](/wiki/Honed_Instincts/edit?redlink=1 "Honed Instincts (page does not exist)") | 8% increased Attack Speed 8% increased [Projectile](/wiki/Projectile "Projectile") Speed +10 to [Dexterity](/wiki/Dexterity "Dexterity") [[1]](/wiki/Passive_Skill:Ranger~huntress~notable2 "Passive Skill:Ranger~huntress~notable2") |
| [Imbibed Power](/wiki/Imbibed_Power/edit?redlink=1 "Imbibed Power (page does not exist)") | 25% increased Damage during any [Flask](/wiki/Flask "Flask") Effect 6% increased Attack Speed during any [Flask](/wiki/Flask "Flask") Effect [[1]](/wiki/Passive_Skill:Attack46 "Passive Skill:Attack46") |
| [Initiative](/wiki/Initiative "Initiative") | 30% increased [Melee](/wiki/Melee "Melee") Damage when on Full Life 16% increased Attack Speed if you haven't Attacked [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Melee40 "Passive Skill:Melee40") |
| [Lasting Trauma](/wiki/Lasting_Trauma/edit?redlink=1 "Lasting Trauma (page does not exist)") | 30% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Ailments](/wiki/Ailments "Ailments") you inflict 20% increased Duration of [Damaging Ailments](/wiki/Damaging_Ailment "Damaging Ailment") on Enemies 5% reduced Attack Speed [[1]](/wiki/Passive_Skill:Slow~attacks11 "Passive Skill:Slow~attacks11") |
| [Lightning Quick](/wiki/Lightning_Quick/edit?redlink=1 "Lightning Quick (page does not exist)") | 14% increased [Lightning](/wiki/Lightning "Lightning") Damage 8% increased Attack and Cast Speed with [Lightning](/wiki/Lightning "Lightning") Skills [[1]](/wiki/Passive_Skill:Lightning39 "Passive Skill:Lightning39") |
| [Mass Hysteria](/wiki/Mass_Hysteria/edit?redlink=1 "Mass Hysteria (page does not exist)") | 6% increased Attack Speed [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") have 6% increased Attack Speed [[1]](/wiki/Passive_Skill:Attack~speed33 "Passive Skill:Attack~speed33") |
| [Overwhelm](/wiki/Overwhelm/edit?redlink=1 "Overwhelm (page does not exist)") | 40% increased Damage with Two Handed Weapons 5% reduced Attack Speed 20% increased [Stun](/wiki/Stun "Stun") Buildup [[1]](/wiki/Passive_Skill:Two~handed18 "Passive Skill:Two~handed18") |
| [Precision Salvo](/wiki/Precision_Salvo/edit?redlink=1 "Precision Salvo (page does not exist)") | 12% increased [Accuracy](/wiki/Accuracy "Accuracy") Rating 6% increased Attack Speed 8% increased [Projectile](/wiki/Projectile "Projectile") Speed [[1]](/wiki/Passive_Skill:Accuracy40 "Passive Skill:Accuracy40") |
| [Sand in the Eyes](/wiki/Sand_in_the_Eyes/edit?redlink=1 "Sand in the Eyes (page does not exist)") | 10% increased Attack Speed 15% chance to [Blind](/wiki/Blind "Blind") Enemies on [Hit](/wiki/Hit "Hit") with Attacks [[1]](/wiki/Passive_Skill:Attack~speed35 "Passive Skill:Attack~speed35") |
| [Sharp Sight](/wiki/Sharp_Sight/edit?redlink=1 "Sharp Sight (page does not exist)") | 30% increased [Accuracy](/wiki/Accuracy "Accuracy") Rating against [Rare or Unique](/wiki/Rarity "Rarity") Enemies 5% increased Attack Speed [[1]](/wiki/Passive_Skill:Accuracy30 "Passive Skill:Accuracy30") |
| [Singular Purpose](/wiki/Singular_Purpose/edit?redlink=1 "Singular Purpose (page does not exist)") | 40% increased Damage with Two Handed Weapons 5% reduced Attack Speed 20% increased [Stun](/wiki/Stun "Stun") Buildup [[1]](/wiki/Passive_Skill:Two~handed8 "Passive Skill:Two~handed8") |
| [Stimulants](/wiki/Stimulants/edit?redlink=1 "Stimulants (page does not exist)") | 16% increased Attack Speed during any [Flask](/wiki/Flask "Flask") Effect [[1]](/wiki/Passive_Skill:Attack~speed31 "Passive Skill:Attack~speed31") |
| [Tenfold Attacks](/wiki/Tenfold_Attacks/edit?redlink=1 "Tenfold Attacks (page does not exist)") | 4% increased Attack Speed 6% increased Attack Speed if you've been Hit [Recently](/wiki/Recently "Recently") +10 to [Strength](/wiki/Strength "Strength") [[1]](/wiki/Passive_Skill:Attack~speed30 "Passive Skill:Attack~speed30") |
| [Thrill of Battle](/wiki/Thrill_of_Battle/edit?redlink=1 "Thrill of Battle (page does not exist)") | 20% increased Attack Speed while [Surrounded](/wiki/Surrounded "Surrounded") [[1]](/wiki/Passive_Skill:Being~surrounded10 "Passive Skill:Being~surrounded10") |
| [Unyielding](/wiki/Unyielding_(passive)/edit?redlink=1 "Unyielding (passive) (page does not exist)") | 15% increased Attack Speed if you've been Hit [Recently](/wiki/Recently "Recently") 8% reduced [Slowing](/wiki/Slow "Slow") Potency of [Debuffs](/wiki/Debuff "Debuff") on You [[1]](/wiki/Passive_Skill:Duration~spells11 "Passive Skill:Duration~spells11") |
| [Viciousness](/wiki/Viciousness/edit?redlink=1 "Viciousness (page does not exist)") | 3% increased Attack Speed per Enemy in [Close Range](/wiki/Close_Range/edit?redlink=1 "Close Range (page does not exist)") +10 to [Dexterity](/wiki/Dexterity "Dexterity") [[1]](/wiki/Passive_Skill:Melee34 "Passive Skill:Melee34") |
| [Wellspring](/wiki/Wellspring/edit?redlink=1 "Wellspring (page does not exist)") | 30% increased Mana Recovery from [Flasks](/wiki/Flask "Flask") 8% increased Attack and Cast Speed during Effect of any Mana [Flask](/wiki/Flask "Flask") [[1]](/wiki/Passive_Skill:Mana~flasks11 "Passive Skill:Mana~flasks11") |

### Attack area damage

| Name | Stats |
| --- | --- |
| [Area Damage](/wiki/Area_Damage/edit?redlink=1 "Area Damage (page does not exist)") | 10% increased Attack Area Damage [[1]](/wiki/Passive_Skill:Area~attacks10 "Passive Skill:Area~attacks10") [[2]](/wiki/Passive_Skill:Area~attacks12 "Passive Skill:Area~attacks12") [[3]](/wiki/Passive_Skill:Area~attacks14 "Passive Skill:Area~attacks14") [[4]](/wiki/Passive_Skill:Area~attacks24 "Passive Skill:Area~attacks24") [[5]](/wiki/Passive_Skill:Area~attacks25~ "Passive Skill:Area~attacks25~") [[6]](/wiki/Passive_Skill:Area~attacks6~~ "Passive Skill:Area~attacks6~~") [[7]](/wiki/Passive_Skill:Area~attacks9 "Passive Skill:Area~attacks9") [[8]](/wiki/Passive_Skill:Slam~area4 "Passive Skill:Slam~area4") |
| [Area Damage and Armour Break](/wiki/Area_Damage_and_Armour_Break/edit?redlink=1 "Area Damage and Armour Break (page does not exist)") | 6% increased Attack Area Damage [Break](/wiki/Break "Break") 10% increased [Armour](/wiki/Armour "Armour") [[1]](/wiki/Passive_Skill:Area~attacks16~ "Passive Skill:Area~attacks16~") [[2]](/wiki/Passive_Skill:Area~attacks18 "Passive Skill:Area~attacks18") |
| [Attack Area Damage](/wiki/Attack_Area_Damage/edit?redlink=1 "Attack Area Damage (page does not exist)") | 10% increased Attack Area Damage [[1]](/wiki/Passive_Skill:Area~attacks47 "Passive Skill:Area~attacks47") [[2]](/wiki/Passive_Skill:Area~attacks48 "Passive Skill:Area~attacks48") |
| [Attack Area Damage and Area](/wiki/Attack_Area_Damage_and_Area/edit?redlink=1 "Attack Area Damage and Area (page does not exist)") | 6% increased Attack Area Damage 4% increased Area of Effect for Attacks [[1]](/wiki/Passive_Skill:Area~attacks20 "Passive Skill:Area~attacks20") [[2]](/wiki/Passive_Skill:Area~attacks21 "Passive Skill:Area~attacks21") [[3]](/wiki/Passive_Skill:Area~attacks22 "Passive Skill:Area~attacks22") [[4]](/wiki/Passive_Skill:Slam~area1 "Passive Skill:Slam~area1")  ---  4% increased Area of Effect for Attacks 6% increased Attack Area Damage [[2]](/wiki/Passive_Skill:Area~attacks44 "Passive Skill:Area~attacks44")  ---  8% increased Attack Area Damage 4% increased Area of Effect for Attacks [[5]](/wiki/Passive_Skill:Slams1 "Passive Skill:Slams1") [[6]](/wiki/Passive_Skill:Slams4 "Passive Skill:Slams4") |
| [Crushing Judgement](/wiki/Crushing_Judgement/edit?redlink=1 "Crushing Judgement (page does not exist)") | 25% increased Attack Area Damage 25% increased [Armour Break](/wiki/Armour_Break "Armour Break") Duration [[1]](/wiki/Passive_Skill:Area~attacks31 "Passive Skill:Area~attacks31") |
| [Devastation](/wiki/Devastation/edit?redlink=1 "Devastation (page does not exist)") | 12% increased Area of Effect for Attacks 15% increased Attack Area Damage [[1]](/wiki/Passive_Skill:Area~attacks28 "Passive Skill:Area~attacks28") |
| [Dizzying Sweep](/wiki/Dizzying_Sweep/edit?redlink=1 "Dizzying Sweep (page does not exist)") | 15% increased Attack Area Damage 5% chance to [Daze](/wiki/Daze "Daze") on [Hit](/wiki/Hit "Hit") 10% increased Area of Effect for Attacks [[1]](/wiki/Passive_Skill:Area~attacks58 "Passive Skill:Area~attacks58") |
| [Impact Force](/wiki/Impact_Force/edit?redlink=1 "Impact Force (page does not exist)") | 25% increased Attack Area Damage 20% increased [Stun](/wiki/Stun "Stun") Buildup [[1]](/wiki/Passive_Skill:Area~attacks29 "Passive Skill:Area~attacks29") |

### Attack area of effect

| Name | Stats |
| --- | --- |
| [Attack Area](/wiki/Attack_Area/edit?redlink=1 "Attack Area (page does not exist)") | 6% increased Area of Effect for Attacks [[1]](/wiki/Passive_Skill:Area~attacks1 "Passive Skill:Area~attacks1") [[2]](/wiki/Passive_Skill:Area~attacks11 "Passive Skill:Area~attacks11") [[3]](/wiki/Passive_Skill:Area~attacks13 "Passive Skill:Area~attacks13") [[4]](/wiki/Passive_Skill:Area~attacks15 "Passive Skill:Area~attacks15") [[5]](/wiki/Passive_Skill:Area~attacks17 "Passive Skill:Area~attacks17") [[6]](/wiki/Passive_Skill:Area~attacks19 "Passive Skill:Area~attacks19") [[7]](/wiki/Passive_Skill:Area~attacks2 "Passive Skill:Area~attacks2") [[8]](/wiki/Passive_Skill:Area~attacks33 "Passive Skill:Area~attacks33") [[9]](/wiki/Passive_Skill:Area~attacks34 "Passive Skill:Area~attacks34") [[10]](/wiki/Passive_Skill:Area~attacks35 "Passive Skill:Area~attacks35") [[11]](/wiki/Passive_Skill:Area~attacks4 "Passive Skill:Area~attacks4") [[12]](/wiki/Passive_Skill:Area~attacks5~ "Passive Skill:Area~attacks5~") [[13]](/wiki/Passive_Skill:Area~attacks51 "Passive Skill:Area~attacks51") [[14]](/wiki/Passive_Skill:Area~attacks52 "Passive Skill:Area~attacks52") [[15]](/wiki/Passive_Skill:Area~attacks53 "Passive Skill:Area~attacks53") [[16]](/wiki/Passive_Skill:Area~attacks54 "Passive Skill:Area~attacks54") [[17]](/wiki/Passive_Skill:Area~attacks55 "Passive Skill:Area~attacks55") [[18]](/wiki/Passive_Skill:Area~attacks7 "Passive Skill:Area~attacks7") [[19]](/wiki/Passive_Skill:Area~attacks8 "Passive Skill:Area~attacks8") [[20]](/wiki/Passive_Skill:Ranged14 "Passive Skill:Ranged14") [[21]](/wiki/Passive_Skill:Ranged16 "Passive Skill:Ranged16") [[22]](/wiki/Passive_Skill:Slam~area2 "Passive Skill:Slam~area2") [[23]](/wiki/Passive_Skill:Slam~area3 "Passive Skill:Slam~area3") |
| [Attack Area and Combo](/wiki/Attack_Area_and_Combo/edit?redlink=1 "Attack Area and Combo (page does not exist)") | 4% increased Area of Effect for Attacks 5% Chance to build an additional [Combo](/wiki/Combo "Combo") on [Hit](/wiki/Hit "Hit") [[1]](/wiki/Passive_Skill:Area~attacks45~~ "Passive Skill:Area~attacks45~~") [[2]](/wiki/Passive_Skill:Area~attacks46 "Passive Skill:Area~attacks46") [[3]](/wiki/Passive_Skill:Area~attacks49 "Passive Skill:Area~attacks49") |
| [Attack Area and Flammability Magnitude](/wiki/Attack_Area_and_Flammability_Magnitude/edit?redlink=1 "Attack Area and Flammability Magnitude (page does not exist)") | 4% increased Area of Effect for Attacks 15% increased [Flammability](/wiki/Flammability "Flammability") [Magnitude](/wiki/Magnitude "Magnitude") [[1]](/wiki/Passive_Skill:Area~attacks60 "Passive Skill:Area~attacks60") [[2]](/wiki/Passive_Skill:Area~attacks61 "Passive Skill:Area~attacks61") [[3]](/wiki/Passive_Skill:Area~attacks62 "Passive Skill:Area~attacks62") |
| [Attack Area Damage and Area](/wiki/Attack_Area_Damage_and_Area/edit?redlink=1 "Attack Area Damage and Area (page does not exist)") | 6% increased Attack Area Damage 4% increased Area of Effect for Attacks [[1]](/wiki/Passive_Skill:Area~attacks20 "Passive Skill:Area~attacks20") [[2]](/wiki/Passive_Skill:Area~attacks21 "Passive Skill:Area~attacks21") [[3]](/wiki/Passive_Skill:Area~attacks22 "Passive Skill:Area~attacks22") [[4]](/wiki/Passive_Skill:Slam~area1 "Passive Skill:Slam~area1")  ---  4% increased Area of Effect for Attacks 6% increased Attack Area Damage [[2]](/wiki/Passive_Skill:Area~attacks44 "Passive Skill:Area~attacks44")  ---  8% increased Attack Area Damage 4% increased Area of Effect for Attacks [[5]](/wiki/Passive_Skill:Slams1 "Passive Skill:Slams1") [[6]](/wiki/Passive_Skill:Slams4 "Passive Skill:Slams4") |
| [Authority](/wiki/Authority/edit?redlink=1 "Authority (page does not exist)") | 15% increased Area of Effect for Attacks 10% increased [Cooldown Recovery Rate](/wiki/Cooldown_Recovery_Rate "Cooldown Recovery Rate") [[1]](/wiki/Passive_Skill:Area~attacks30 "Passive Skill:Area~attacks30") |
| [Behemoth](/wiki/Behemoth/edit?redlink=1 "Behemoth (page does not exist)") | 3% increased maximum Life 8% increased Area of Effect for Attacks 5% chance for [Slam](/wiki/Slam "Slam") Skills you use yourself to cause an additional [Aftershock](/wiki/Aftershock "Aftershock") [[1]](/wiki/Passive_Skill:Slam~area5 "Passive Skill:Slam~area5") |
| [Catapult](/wiki/Catapult/edit?redlink=1 "Catapult (page does not exist)") | 12% increased Area of Effect for Attacks 15% increased [Projectile](/wiki/Projectile "Projectile") Speed [[1]](/wiki/Passive_Skill:Ranged36 "Passive Skill:Ranged36") |
| [Colossal Weapon](/wiki/Colossal_Weapon/edit?redlink=1 "Colossal Weapon (page does not exist)") | 12% increased Area of Effect for Attacks +10 to [Strength](/wiki/Strength "Strength") [[1]](/wiki/Passive_Skill:Two~handed14 "Passive Skill:Two~handed14") |
| [Devastation](/wiki/Devastation/edit?redlink=1 "Devastation (page does not exist)") | 12% increased Area of Effect for Attacks 15% increased Attack Area Damage [[1]](/wiki/Passive_Skill:Area~attacks28 "Passive Skill:Area~attacks28") |
| [Disciplined Training](/wiki/Disciplined_Training/edit?redlink=1 "Disciplined Training (page does not exist)") | [Combo](/wiki/Combo "Combo") count loss occurs 20% slower 10% increased Area of Effect for Attacks 10% increased Skill Effect Duration [[1]](/wiki/Passive_Skill:Area~attacks59 "Passive Skill:Area~attacks59") |
| [Dizzying Sweep](/wiki/Dizzying_Sweep/edit?redlink=1 "Dizzying Sweep (page does not exist)") | 15% increased Attack Area Damage 5% chance to [Daze](/wiki/Daze "Daze") on [Hit](/wiki/Hit "Hit") 10% increased Area of Effect for Attacks [[1]](/wiki/Passive_Skill:Area~attacks58 "Passive Skill:Area~attacks58") |
| [Engineered Blaze](/wiki/Engineered_Blaze/edit?redlink=1 "Engineered Blaze (page does not exist)") | 4% increased Area of Effect for Attacks per Enemy you've [Ignited](/wiki/Ignite "Ignite") in the last 8 seconds, up to 40% [[1]](/wiki/Passive_Skill:Fire61 "Passive Skill:Fire61") |
| [Frantic Reach](/wiki/Frantic_Reach/edit?redlink=1 "Frantic Reach (page does not exist)") | 18% increased Area of Effect for Attacks 20% reduced [Accuracy](/wiki/Accuracy "Accuracy") Rating [[1]](/wiki/Passive_Skill:Area~attacks56 "Passive Skill:Area~attacks56") |
| [Impact Area](/wiki/Impact_Area/edit?redlink=1 "Impact Area (page does not exist)") | 12% increased Area of Effect for Attacks 12% increased Area of Effect if you have [Stunned](/wiki/Stun "Stun") an Enemy [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Area~attacks27 "Passive Skill:Area~attacks27") |
| [Primal Growth](/wiki/Primal_Growth/edit?redlink=1 "Primal Growth (page does not exist)") | 8% increased Area of Effect for Attacks 15% increased Area of Effect if you've Killed [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Area~attacks26 "Passive Skill:Area~attacks26") |
| [Primal Sundering](/wiki/Primal_Sundering/edit?redlink=1 "Primal Sundering (page does not exist)") | Damage [Penetrates](/wiki/Resistance_Penetration "Resistance Penetration") 12% [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") 8% increased Area of Effect for Attacks [[1]](/wiki/Passive_Skill:Elemental56 "Passive Skill:Elemental56") |
| [Resolute Reach](/wiki/Resolute_Reach/edit?redlink=1 "Resolute Reach (page does not exist)") | 18% increased Area of Effect for Attacks 20% reduced [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") [[1]](/wiki/Passive_Skill:Area~attacks57~ "Passive Skill:Area~attacks57~") |
| [Reverberating Impact](/wiki/Reverberating_Impact/edit?redlink=1 "Reverberating Impact (page does not exist)") | 12% increased Area of Effect for Attacks [Break](/wiki/Break "Break") 25% increased [Armour](/wiki/Armour "Armour") [[1]](/wiki/Passive_Skill:Area~attacks32 "Passive Skill:Area~attacks32") |

### Attack critical hit chance

| Name | Stats |
| --- | --- |
| [Accuracy and Attack Critical Chance](/wiki/Accuracy_and_Attack_Critical_Chance/edit?redlink=1 "Accuracy and Attack Critical Chance (page does not exist)") | 6% increased [Accuracy](/wiki/Accuracy "Accuracy") Rating 8% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for Attacks [[1]](/wiki/Passive_Skill:Accuracy32 "Passive Skill:Accuracy32") [[2]](/wiki/Passive_Skill:Accuracy33 "Passive Skill:Accuracy33") [[3]](/wiki/Passive_Skill:Accuracy34 "Passive Skill:Accuracy34") |
| [Accuracy and Critical Chance](/wiki/Accuracy_and_Critical_Chance/edit?redlink=1 "Accuracy and Critical Chance (page does not exist)") | 8% increased [Accuracy](/wiki/Accuracy "Accuracy") Rating 8% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for Attacks [[1]](/wiki/Passive_Skill:Accuracy10 "Passive Skill:Accuracy10") [[2]](/wiki/Passive_Skill:Accuracy11 "Passive Skill:Accuracy11") |
| [Attack Critical Chance](/wiki/Attack_Critical_Chance/edit?redlink=1 "Attack Critical Chance (page does not exist)") | 10% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for Attacks [[1]](/wiki/Passive_Skill:Criticals59 "Passive Skill:Criticals59") [[2]](/wiki/Passive_Skill:Criticals60 "Passive Skill:Criticals60") [[3]](/wiki/Passive_Skill:Criticals63 "Passive Skill:Criticals63") [[4]](/wiki/Passive_Skill:Criticals75~ "Passive Skill:Criticals75~") [[5]](/wiki/Passive_Skill:Criticals76 "Passive Skill:Criticals76") [[6]](/wiki/Passive_Skill:Criticals77 "Passive Skill:Criticals77") [[7]](/wiki/Passive_Skill:Criticals78 "Passive Skill:Criticals78") |
| [Locked On](/wiki/Locked_On/edit?redlink=1 "Locked On (page does not exist)") | 15% increased [Accuracy](/wiki/Accuracy "Accuracy") Rating 15% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for Attacks [[1]](/wiki/Passive_Skill:Accuracy19 "Passive Skill:Accuracy19") |
| [Near Sighted](/wiki/Near_Sighted/edit?redlink=1 "Near Sighted (page does not exist)") | 30% increased penalty to [Accuracy](/wiki/Accuracy "Accuracy") Rating at range 30% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for Attacks [[1]](/wiki/Passive_Skill:Accuracy28 "Passive Skill:Accuracy28") |
| [Overwhelming Strike](/wiki/Overwhelming_Strike/edit?redlink=1 "Overwhelming Strike (page does not exist)") | 15% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for Attacks 20% increased [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus") for Attack Damage 20% more [Stun](/wiki/Stun "Stun") Buildup with [Critical Hits](/wiki/Critical_Hit "Critical Hit") [[1]](/wiki/Passive_Skill:Criticals64 "Passive Skill:Criticals64") |
| [Serrated Edges](/wiki/Serrated_Edges/edit?redlink=1 "Serrated Edges (page does not exist)") | 30% increased Attack Damage against [Rare or Unique](/wiki/Rarity "Rarity") Enemies 10% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for Attacks [[1]](/wiki/Passive_Skill:Melee31 "Passive Skill:Melee31") |
| [Tainted Strike](/wiki/Tainted_Strike/edit?redlink=1 "Tainted Strike (page does not exist)") | 30% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Non-Damaging Ailments](/wiki/Non-Damaging_Ailment "Non-Damaging Ailment") you inflict with [Critical Hits](/wiki/Critical_Hit "Critical Hit") 20% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for Attacks [[1]](/wiki/Passive_Skill:Criticals79 "Passive Skill:Criticals79") |

### Attack critical damage bonus

| Name | Stats |
| --- | --- |
| [Attack Critical Damage](/wiki/Attack_Critical_Damage/edit?redlink=1 "Attack Critical Damage (page does not exist)") | 15% increased [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus") for Attack Damage [[1]](/wiki/Passive_Skill:Criticals57~ "Passive Skill:Criticals57~") [[2]](/wiki/Passive_Skill:Criticals61 "Passive Skill:Criticals61") [[3]](/wiki/Passive_Skill:Criticals65 "Passive Skill:Criticals65") [[4]](/wiki/Passive_Skill:Criticals66 "Passive Skill:Criticals66") [[5]](/wiki/Passive_Skill:Criticals67~~ "Passive Skill:Criticals67~~") |
| [Overwhelming Strike](/wiki/Overwhelming_Strike/edit?redlink=1 "Overwhelming Strike (page does not exist)") | 15% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") for Attacks 20% increased [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus") for Attack Damage 20% more [Stun](/wiki/Stun "Stun") Buildup with [Critical Hits](/wiki/Critical_Hit "Critical Hit") [[1]](/wiki/Passive_Skill:Criticals64 "Passive Skill:Criticals64") |
| [Sundering](/wiki/Sundering/edit?redlink=1 "Sundering (page does not exist)") | 25% increased [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus") for Attack Damage +25% to [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus") against Stunned Enemies [[1]](/wiki/Passive_Skill:Criticals51~ "Passive Skill:Criticals51~") |

### Miscellany

| Name | Stats |
| --- | --- |
| [Bleeding Chance on Critical](/wiki/Bleeding_Chance_on_Critical/edit?redlink=1 "Bleeding Chance on Critical (page does not exist)") | 10% chance to inflict Bleeding on [Critical Hit](/wiki/Critical_Hit "Critical Hit") with Attacks [[1]](/wiki/Passive_Skill:Bleed8~ "Passive Skill:Bleed8~") [[2]](/wiki/Passive_Skill:Bleed9 "Passive Skill:Bleed9") |
| [Blind Chance](/wiki/Blind_Chance/edit?redlink=1 "Blind Chance (page does not exist)") | 8% chance to [Blind](/wiki/Blind "Blind") Enemies on [Hit](/wiki/Hit "Hit") with Attacks [[1]](/wiki/Passive_Skill:Attack~speed43 "Passive Skill:Attack~speed43") [[2]](/wiki/Passive_Skill:Attack~speed44 "Passive Skill:Attack~speed44") |
| [Incision Chance](/wiki/Incision_Chance/edit?redlink=1 "Incision Chance (page does not exist)") | 20% chance for Attack [Hits](/wiki/Hit "Hit") to apply [Incision](/wiki/Incision "Incision") [[1]](/wiki/Passive_Skill:Bleed35 "Passive Skill:Bleed35") [[2]](/wiki/Passive_Skill:Bleed36 "Passive Skill:Bleed36") [[3]](/wiki/Passive_Skill:Bleed39 "Passive Skill:Bleed39") [[4]](/wiki/Passive_Skill:Bleed40 "Passive Skill:Bleed40") [[5]](/wiki/Passive_Skill:Bleed42 "Passive Skill:Bleed42") [[6]](/wiki/Passive_Skill:Bleed43 "Passive Skill:Bleed43") |
| [Mark Effect and Blind Chance](/wiki/Mark_Effect_and_Blind_Chance/edit?redlink=1 "Mark Effect and Blind Chance (page does not exist)") | 8% increased Effect of your [Mark](/wiki/Mark "Mark") Skills 5% chance to [Blind](/wiki/Blind "Blind") Enemies on [Hit](/wiki/Hit "Hit") with Attacks [[1]](/wiki/Passive_Skill:Marks30 "Passive Skill:Marks30") |
| [Melee Damage if Projectile Hit](/wiki/Melee_Damage_if_Projectile_Hit/edit?redlink=1 "Melee Damage if Projectile Hit (page does not exist)") | 15% increased [Melee](/wiki/Melee "Melee") Damage if you've dealt a [Projectile](/wiki/Projectile "Projectile") Attack [Hit](/wiki/Hit "Hit") in the past eight seconds [[1]](/wiki/Passive_Skill:Ranged19~ "Passive Skill:Ranged19~") [[2]](/wiki/Passive_Skill:Ranged20 "Passive Skill:Ranged20") |
| [One Handed Ailment Chance](/wiki/One_Handed_Ailment_Chance/edit?redlink=1 "One Handed Ailment Chance (page does not exist)") | Attacks with [One-Handed](/wiki/One-Handed "One-Handed") [Weapons](/wiki/Martial_Weapons "Martial Weapons") have 15% increased Chance to inflict [Ailments](/wiki/Ailments "Ailments") [[1]](/wiki/Passive_Skill:One~handed24 "Passive Skill:One~handed24") [[2]](/wiki/Passive_Skill:One~handed25~ "Passive Skill:One~handed25~") |
| [Adaptable Assault](/wiki/Adaptable_Assault/edit?redlink=1 "Adaptable Assault (page does not exist)") | [Projectiles](/wiki/Projectile "Projectile") have 25% chance to [Fork](/wiki/Fork "Fork") if you've dealt a [Melee](/wiki/Melee "Melee") [Hit](/wiki/Hit "Hit") in the past eight seconds +4 to [Melee](/wiki/Melee "Melee") Strike Range if you've dealt a [Projectile](/wiki/Projectile "Projectile") Attack [Hit](/wiki/Hit "Hit") in the past eight seconds [[1]](/wiki/Passive_Skill:Ranged21 "Passive Skill:Ranged21") |
| [Aggravation](/wiki/Aggravation/edit?redlink=1 "Aggravation (page does not exist)") | 10% chance to [Aggravate](/wiki/Aggravate "Aggravate") [Bleeding](/wiki/Bleeding "Bleeding") on targets you [Hit](/wiki/Hit "Hit") with Attacks [[1]](/wiki/Passive_Skill:Bleed13 "Passive Skill:Bleed13") |
| [Ancestral Artifice](/wiki/Ancestral_Artifice "Ancestral Artifice") | [Melee](/wiki/Melee "Melee") Attack Skills have +1 to maximum number of Summoned [Totems](/wiki/Totem "Totem") 20% increased [Totem](/wiki/Totem "Totem") Placement range [[1]](/wiki/Passive_Skill:Totems14 "Passive Skill:Totems14") |
| [Artillery Strike](/wiki/Artillery_Strike/edit?redlink=1 "Artillery Strike (page does not exist)") | Attack Skills have +1 to maximum number of Summoned [Ballista](/wiki/Ballista "Ballista") [Totems](/wiki/Totem "Totem") 15% increased Area of Effect while you have a Totem [[1]](/wiki/Passive_Skill:Ballista16 "Passive Skill:Ballista16") |
| [Blinding Strike](/wiki/Blinding_Strike/edit?redlink=1 "Blinding Strike (page does not exist)") | 24% increased Attack Damage 10% chance to [Blind](/wiki/Blind "Blind") Enemies on [Hit](/wiki/Hit "Hit") with Attacks [[1]](/wiki/Passive_Skill:Attack16 "Passive Skill:Attack16") |
| [Coated Arms](/wiki/Coated_Arms/edit?redlink=1 "Coated Arms (page does not exist)") | 25% increased Damage with One Handed Weapons Attacks with [One-Handed](/wiki/One-Handed "One-Handed") [Weapons](/wiki/Martial_Weapons "Martial Weapons") have 20% increased Chance to inflict [Ailments](/wiki/Ailments "Ailments") [[1]](/wiki/Passive_Skill:One~handed26 "Passive Skill:One~handed26") |
| [Counterstancing](/wiki/Counterstancing/edit?redlink=1 "Counterstancing (page does not exist)") | Successfully [Parrying](/wiki/Parry "Parry") a [Melee](/wiki/Melee "Melee") [Hit](/wiki/Hit "Hit") grants 40% increased Damage to your next Ranged Attack Successfully [Parrying](/wiki/Parry "Parry") a [Projectile](/wiki/Projectile "Projectile") [Hit](/wiki/Hit "Hit") grants 40% increased Damage to your next [Melee](/wiki/Melee "Melee") Attack [[1]](/wiki/Passive_Skill:Deflect12 "Passive Skill:Deflect12") |
| [Crystal Elixir](/wiki/Crystal_Elixir/edit?redlink=1 "Crystal Elixir (page does not exist)") | 40% increased Elemental Damage with Attack Skills during any [Flask](/wiki/Flask "Flask") Effect [[1]](/wiki/Passive_Skill:Elemental~attacks9 "Passive Skill:Elemental~attacks9") |
| [Engineered Blaze](/wiki/Engineered_Blaze/edit?redlink=1 "Engineered Blaze (page does not exist)") | 4% increased Area of Effect for Attacks per Enemy you've [Ignited](/wiki/Ignite "Ignite") in the last 8 seconds, up to 40% [[1]](/wiki/Passive_Skill:Fire61 "Passive Skill:Fire61") |
| [Enhancing Attacks](/wiki/Enhancing_Attacks/edit?redlink=1 "Enhancing Attacks (page does not exist)") | 12% increased [Spell](/wiki/Spell "Spell") Damage for each different Non-Instant Attack you've used in the past 8 seconds [[1]](/wiki/Passive_Skill:Attacks~and~spells13 "Passive Skill:Attacks~and~spells13") |
| [Equilibrium](/wiki/Equilibrium/edit?redlink=1 "Equilibrium (page does not exist)") | 30% increased Attack Damage if you've Cast a [Spell](/wiki/Spell "Spell") [Recently](/wiki/Recently "Recently") 10% increased Cast Speed if you've Attacked [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Attacks~and~spells20 "Passive Skill:Attacks~and~spells20") |
| [Guided Hand](/wiki/Guided_Hand/edit?redlink=1 "Guided Hand (page does not exist)") | On [Heavy Stunning](/wiki/Heavy_Stun "Heavy Stun") a [Rare or Unique](/wiki/Rarity "Rarity") Enemy, your next Attack within 4 seconds will be [Ancestrally Boosted](/wiki/Ancestrally_Boosted "Ancestrally Boosted") [Ancestrally Boosted](/wiki/Ancestrally_Boosted "Ancestrally Boosted") Attacks deal 30% increased Damage [[1]](/wiki/Passive_Skill:Melee65 "Passive Skill:Melee65") |
| [Honourless](/wiki/Honourless/edit?redlink=1 "Honourless (page does not exist)") | 50% increased [Melee Damage](/wiki/Melee "Melee") against [Immobilised](/wiki/Immobilised "Immobilised") Enemies 25% increased [Armour](/wiki/Armour "Armour") if you've [Hit](/wiki/Hit "Hit") an Enemy with a [Melee Attack](/wiki/Melee "Melee") [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:Melee51~ "Passive Skill:Melee51~") |
| [Inevitable Rupture](/wiki/Inevitable_Rupture/edit?redlink=1 "Inevitable Rupture (page does not exist)") | 10% chance for Attack [Hits](/wiki/Hit "Hit") to apply ten [Incision](/wiki/Incision "Incision") [[1]](/wiki/Passive_Skill:Bleed31 "Passive Skill:Bleed31") |
| [Inherited Strength](/wiki/Inherited_Strength/edit?redlink=1 "Inherited Strength (page does not exist)") | [Warcries](/wiki/Warcries "Warcries") have 15% chance to [Empower](/wiki/Empower "Empower") 3 additional Attacks [[1]](/wiki/Passive_Skill:Warcries49 "Passive Skill:Warcries49") |
| [Internal Bleeding](/wiki/Internal_Bleeding/edit?redlink=1 "Internal Bleeding (page does not exist)") | [Empowered Attacks](/wiki/Empowered_skill "Empowered skill") deal 30% increased Damage 20% chance to [Aggravate](/wiki/Aggravate "Aggravate") [Bleeding](/wiki/Bleeding "Bleeding") on targets you [Hit](/wiki/Hit "Hit") with [Empowered](/wiki/Empowered "Empowered") Attacks [[1]](/wiki/Passive_Skill:Warcries14~ "Passive Skill:Warcries14~") |
| [Lavianga's Brew](/wiki/Lavianga%27s_Brew/edit?redlink=1 "Lavianga's Brew (page does not exist)") | 30% increased Mana Cost [Efficiency](/wiki/Efficiency "Efficiency") of Attacks during any Mana [Flask](/wiki/Flask "Flask") Effect [[1]](/wiki/Passive_Skill:Life~flasks42 "Passive Skill:Life~flasks42") |
| [Left Hand of Darkness](/wiki/Left_Hand_of_Darkness/edit?redlink=1 "Left Hand of Darkness (page does not exist)") | [Minions](/wiki/Minion "Minion") have 20% additional [Physical](/wiki/Physical "Physical") Damage Reduction [Minions](/wiki/Minion "Minion") have +23% to [Chaos](/wiki/Chaos "Chaos") [Resistance](/wiki/Resistance "Resistance") Attacks [Gain](/wiki/Gain "Gain") 5% of Damage as extra [Chaos](/wiki/Chaos "Chaos") Damage [[1]](/wiki/Passive_Skill:Minion~defence16 "Passive Skill:Minion~defence16") |
| [Perfectly Placed Knife](/wiki/Perfectly_Placed_Knife/edit?redlink=1 "Perfectly Placed Knife (page does not exist)") | 25% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") against [Bleeding](/wiki/Bleeding "Bleeding") Enemies 20% chance to [Aggravate](/wiki/Aggravate "Aggravate") [Bleeding](/wiki/Bleeding "Bleeding") on targets you [Critically Hit](/wiki/Critically_Hit "Critically Hit") with Attacks [[1]](/wiki/Passive_Skill:Bleed12 "Passive Skill:Bleed12") |
| [Pinpoint Shot](/wiki/Pinpoint_Shot/edit?redlink=1 "Pinpoint Shot (page does not exist)") | Attacks gain increased [Accuracy Rating](/wiki/Accuracy "Accuracy") equal to their [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") [[1]](/wiki/Passive_Skill:Accuracy35 "Passive Skill:Accuracy35") |
| [Price of Freedom](/wiki/Price_of_Freedom/edit?redlink=1 "Price of Freedom (page does not exist)") | 18% of Skill Mana Costs [Converted](/wiki/Stat_conversion "Stat conversion") to Life Costs 15% increased Cost [Efficiency](/wiki/Efficiency "Efficiency") of Attacks [[1]](/wiki/Passive_Skill:Reduced~attack~cost4 "Passive Skill:Reduced~attack~cost4") |
| [Projectile Bulwark](/wiki/Projectile_Bulwark/edit?redlink=1 "Projectile Bulwark (page does not exist)") | 30% increased [Armour](/wiki/Armour "Armour") Defend with 120% of [Armour](/wiki/Armour "Armour") against [Projectile](/wiki/Projectile "Projectile") Attacks [[1]](/wiki/Passive_Skill:Armour31 "Passive Skill:Armour31") |
| [Run and Gun](/wiki/Run_and_Gun/edit?redlink=1 "Run and Gun (page does not exist)") | [Projectile](/wiki/Projectile "Projectile") Attacks have a 12% chance to fire two additional [Projectiles](/wiki/Projectile "Projectile") while moving 5% reduced Movement Speed Penalty from using Skills while moving [[1]](/wiki/Passive_Skill:Slow~mitigation16 "Passive Skill:Slow~mitigation16") |
| [Sand in the Eyes](/wiki/Sand_in_the_Eyes/edit?redlink=1 "Sand in the Eyes (page does not exist)") | 10% increased Attack Speed 15% chance to [Blind](/wiki/Blind "Blind") Enemies on [Hit](/wiki/Hit "Hit") with Attacks [[1]](/wiki/Passive_Skill:Attack~speed35 "Passive Skill:Attack~speed35") |
| [Sitting Duck](/wiki/Sitting_Duck/edit?redlink=1 "Sitting Duck (page does not exist)") | Your Hits cannot be [Evaded](/wiki/Evasion "Evasion") by [Pinned](/wiki/Pinned "Pinned") Enemies 35% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") against [Immobilised](/wiki/Immobilised "Immobilised") enemies [[1]](/wiki/Passive_Skill:Pin9 "Passive Skill:Pin9") |
| [Struck Through](/wiki/Struck_Through/edit?redlink=1 "Struck Through (page does not exist)") | Attacks have +1% to [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") [[1]](/wiki/Passive_Skill:Criticals55~ "Passive Skill:Criticals55~") |

### Paths Not Taken passive skills

The following passive skills are exclusive the [Oracle](/wiki/Oracle "Oracle") with [The Unseen Path](/wiki/The_Unseen_Path "The Unseen Path") allocated:

| Name | Stats |
| --- | --- |
| [Ally Attack and Cast Speed](/wiki/Ally_Attack_and_Cast_Speed/edit?redlink=1 "Ally Attack and Cast Speed (page does not exist)") | 3% reduced [Skill Speed](/wiki/Skill_Speed "Skill Speed") [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") have 6% increased Attack Speed [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") have 6% increased Cast Speed [[1]](/wiki/Passive_Skill:Oracle~self~sacrificing3 "Passive Skill:Oracle~self~sacrificing3") [[2]](/wiki/Passive_Skill:Oracle~self~sacrificing4 "Passive Skill:Oracle~self~sacrificing4") |
| [Attack Added Lighting Damage](/wiki/Attack_Added_Lighting_Damage/edit?redlink=1 "Attack Added Lighting Damage (page does not exist)") | Adds 1 to 7 [Lightning](/wiki/Lightning "Lightning") damage to Attacks [[1]](/wiki/Passive_Skill:Oracle~flat~lightning1 "Passive Skill:Oracle~flat~lightning1") [[2]](/wiki/Passive_Skill:Oracle~flat~lightning2 "Passive Skill:Oracle~flat~lightning2") |
| [Bleed Duration](/wiki/Bleed_Duration/edit?redlink=1 "Bleed Duration (page does not exist)") | 10% increased Bleeding Duration 20% chance for Attack [Hits](/wiki/Hit "Hit") to apply [Incision](/wiki/Incision "Incision") [[1]](/wiki/Passive_Skill:Oracle~bleed1 "Passive Skill:Oracle~bleed1") [[2]](/wiki/Passive_Skill:Oracle~bleed2 "Passive Skill:Oracle~bleed2") |
| [Bow Attack Speed](/wiki/Bow_Attack_Speed/edit?redlink=1 "Bow Attack Speed (page does not exist)") | 5% increased Attack Speed with Bows [[1]](/wiki/Passive_Skill:Oracle~bow~movement6 "Passive Skill:Oracle~bow~movement6") [[2]](/wiki/Passive_Skill:Oracle~bow~movement7~ "Passive Skill:Oracle~bow~movement7~") [[3]](/wiki/Passive_Skill:Oracle~bow~movement8 "Passive Skill:Oracle~bow~movement8") |
| [Her Final Bite](/wiki/Her_Final_Bite "Her Final Bite") | [Bow](/wiki/Bow "Bow") Attacks have [Culling Strike](/wiki/Culling_Strike "Culling Strike") 20% increased Physical Damage with Bows [[1]](/wiki/Passive_Skill:Oracle~bow~movement9 "Passive Skill:Oracle~bow~movement9") |
| [Innate Rune](/wiki/Innate_Rune "Innate Rune") | Adds 1 to 37 [Lightning](/wiki/Lightning "Lightning") damage to Attacks [[1]](/wiki/Passive_Skill:Oracle~flat~lightning3~ "Passive Skill:Oracle~flat~lightning3~") |
| [Scent of Blood](/wiki/Scent_of_Blood "Scent of Blood") | 20% increased Bleeding Duration 40% chance for Attack [Hits](/wiki/Hit "Hit") to apply [Incision](/wiki/Incision "Incision") 3% increased Movement Speed [[1]](/wiki/Passive_Skill:Oracle~bleed3 "Passive Skill:Oracle~bleed3") |

### Ascendancy passive skills

The following [Ascendancy passive skills](/wiki/Ascendancy_passive_skill "Ascendancy passive skill") are related to attacks:

| Ascendancy Class | Name | Stats |
| --- | --- | --- |
| [Amazon](/wiki/Amazon "Amazon") | [Penetrate](/wiki/Penetrate "Penetrate") | Attacks using your Weapons have Added [Physical](/wiki/Physical "Physical") Damage equal to 25% of the [Accuracy](/wiki/Accuracy "Accuracy") Rating on the Weapon [[1]](/wiki/Passive_Skill:AscendancyHuntress1Notable2 "Passive Skill:AscendancyHuntress1Notable2") |
| [Invoker](/wiki/Invoker "Invoker") | [...and Scatter Them to the Winds](/wiki/...and_Scatter_Them_to_the_Winds "...and Scatter Them to the Winds") | Grants Skill: [Elemental Expression](/wiki/Elemental_Expression "Elemental Expression") Trigger Elemental Expression on [Melee](/wiki/Melee "Melee") [Critical Hit](/wiki/Critical_Hit "Critical Hit") [[1]](/wiki/Passive_Skill:AscendancyMonk2Notable7~ "Passive Skill:AscendancyMonk2Notable7~") |
| [Tactician](/wiki/Tactician "Tactician") | [Cannons, Ready!](/wiki/Cannons,_Ready! "Cannons, Ready!") | Skills used by [Totems](/wiki/Totem "Totem") have 30% more [Skill Speed](/wiki/Skill_Speed "Skill Speed") [Totems](/wiki/Totem "Totem") only use Skills when you fire an Attack [Projectile](/wiki/Projectile "Projectile") +1 to maximum number of Summoned [Totems](/wiki/Totem "Totem") [[1]](/wiki/Passive_Skill:AscendancyMercenary1Notable8 "Passive Skill:AscendancyMercenary1Notable8") |
| [Tactician](/wiki/Tactician "Tactician") | [Watch How I Do It](/wiki/Watch_How_I_Do_It "Watch How I Do It") | [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") gain added Attack Damage equal to 25% of your main hand Weapon's Damage [[1]](/wiki/Passive_Skill:AscendancyMercenary1Notable2 "Passive Skill:AscendancyMercenary1Notable2") |
