# Unique item

For the rarity tier, see [Rarity#Unique](/wiki/Rarity#Unique "Rarity").

A **unique item** is an [item](/wiki/Item "Item") with a unique rarity, with a distinct and specific name, different artwork from the base item, and a predetermined list of [modifiers](/wiki/Modifier "Modifier"). They can be identified by a distinct orange-brown banner on the item's tooltip,

Currently there are **406** released unique items in Path of Exile 2, including modifier variants.

This list does not include unique [maps](/wiki/Map "Map") and [strongboxes](/wiki/Strongbox "Strongbox").

## Mechanics

Unique items usually inherit the [implicit modifiers](/wiki/Implicit_modifier "Implicit modifier") of their base item if one exists.

Unique items generally provide one or more exclusive modifiers not available in the regular affix pool that can sometimes even enable completely new builds.

Most [currency](/wiki/Currency "Currency") items that reforge, add, or remove modifiers do not work on unique items.

## Unique item types

|  |  |
| --- | --- |
|  | [Armour](/wiki/List_of_unique_armour "List of unique armour") * [Body armours](/wiki/List_of_unique_body_armours "List of unique body armours") * [Boots](/wiki/List_of_unique_boots "List of unique boots") * [Gloves](/wiki/List_of_unique_gloves "List of unique gloves") * [Helmets](/wiki/List_of_unique_helmets "List of unique helmets") * [Shields](/wiki/List_of_unique_shields "List of unique shields") * [Bucklers](/wiki/List_of_unique_bucklers "List of unique bucklers") * [Foci](/wiki/List_of_unique_foci "List of unique foci") |
|  | [Weapons](/wiki/List_of_unique_weapons "List of unique weapons") * [Axes](/wiki/List_of_unique_axes "List of unique axes") * [Bows](/wiki/List_of_unique_bows "List of unique bows") * [Crossbows](/wiki/List_of_unique_crossbows "List of unique crossbows") * [Daggers](/wiki/List_of_unique_daggers "List of unique daggers") * [Flails](/wiki/List_of_unique_flails "List of unique flails") * [Maces](/wiki/List_of_unique_maces "List of unique maces") * [Quarterstaves](/wiki/List_of_unique_quarterstaves "List of unique quarterstaves") * [Sceptres](/wiki/List_of_unique_sceptres "List of unique sceptres") * [Spears](/wiki/List_of_unique_spears "List of unique spears") * [Staves](/wiki/List_of_unique_staves "List of unique staves") * [Swords](/wiki/List_of_unique_swords "List of unique swords") * [Talismans](/wiki/List_of_unique_talismans "List of unique talismans") * [Traps](/wiki/List_of_unique_traps "List of unique traps") * [Wands](/wiki/List_of_unique_wands "List of unique wands") |
|  | [Off-hands](/wiki/List_of_unique_off-hands "List of unique off-hands") * [Shields](/wiki/List_of_unique_shields "List of unique shields") * [Bucklers](/wiki/List_of_unique_bucklers "List of unique bucklers") * [Foci](/wiki/List_of_unique_foci "List of unique foci") * [Quivers](/wiki/List_of_unique_quivers "List of unique quivers") |
|  | [Jewellery](/wiki/List_of_unique_jewellery "List of unique jewellery") * [Amulets](/wiki/List_of_unique_amulets "List of unique amulets") * [Belts](/wiki/List_of_unique_belts "List of unique belts") * [Rings](/wiki/List_of_unique_rings "List of unique rings") |
|  | [Trinkets](/wiki/List_of_unique_trinkets "List of unique trinkets") * [Life Flasks](/wiki/List_of_unique_life_flasks "List of unique life flasks") * [Mana Flasks](/wiki/List_of_unique_mana_flasks "List of unique mana flasks") * [Charms](/wiki/List_of_unique_charms "List of unique charms") |
|  | [Jewels](/wiki/List_of_unique_jewels "List of unique jewels") |
|  | [Tablets](/wiki/List_of_unique_tablets "List of unique tablets") |

## Obtaining unique items

The following is a non-exhaustive list of ways that unique items can be obtained.

* **Global drops:** Unique items can drop randomly from killed [monsters](/wiki/Monster "Monster") or from [chests](/wiki/Chest "Chest") and other environemental loot containers. They have different [tiers](/wiki/Unique_item_tier "Unique item tier") of rarity that affect their drop rates. Additionally, their drop rates are influence by [item rarity](/wiki/Rarity "Rarity") and [item quantity](/wiki/Item_quantity/edit?redlink=1 "Item quantity (page does not exist)").
* **[Orb of Chance](/wiki/Orb_of_Chance "Orb of Chance"):** Global uniques can rarely be obtained by using an [Orb of Chance](/wiki/Orb_of_Chance "Orb of Chance") on a normal item.
* **[Gambling](/wiki/Gambling "Gambling"):** Global uniques can sometimes be obtained when purchasing items from the [Gambler](/wiki/Gambler "Gambler").
* **Drop-restricted uniques:** Certain unique items can be obtained deterministically from [bosses](/wiki/Boss "Boss") or various game mechanics.

Unique items are classified within four distinct rarities or tiers: "Common", "Uncommon", "Rare", and "Mythic". When a unique item is generated, tier is determined first, then a unique item is chosen within that tier. [Rarity](/wiki/Rarity "Rarity") increases the chance for an item to drop as unique, and as rarity increases, the relative chance for it to be a common unique will become lower, while the chance for it to be an uncommon, rare, or mythic unique will be higher.

## Legacy variants

Like all items, when modifiers are updated between [versions](/wiki/Version_history "Version history") but existing items are not retroactively changed, unique items can have [legacy variants](/wiki/Legacy_variant "Legacy variant"). This means that for some uniques, there are better, worse, or completely different versions that can no longer be obtained outside of being traded for in [permanent leagues](/wiki/Permanent_league "Permanent league").

Rerolling the item's modifier values with a [Divine Orb](/wiki/Divine_Orb "Divine Orb") *may* change a modifier's values to match the current version of the unique item, though this is not always consistent. This method will not add new modifiers or remove old modifiers.

## Unique items designed by users

See also: [Category:Unique items created by users](/wiki/Category:Unique_items_created_by_users "Category:Unique items created by users")

Prior to the release of [Early Access](/wiki/Early_Access "Early Access") for [Path of Exile 2](/wiki/Path_of_Exile_2 "Path of Exile 2"), several content creators/streamers received a "real-life" [Valdo's Puzzle Box](https://www.poewiki.net/wiki/Valdo%27s_Puzzle_Box "poewiki:Valdo's Puzzle Box")[[1]](#cite_note-1)[[2]](#cite_note-2). Completing the puzzle revealed a key that could be redeemed on the official website for an opportunity to design either a unique item (10% chance) or a [divination card](/wiki/Divination_card "Divination card") (90% chance), assigned randomly[[3]](#cite_note-3). This reward can be redeemed some time after the release of Early Access, which involves a process of the user working with developers at [Grinding Gear Games](/wiki/Grinding_Gear_Games "Grinding Gear Games") to design an item.
