# Infernalist

Infernalist

[Witch](/wiki/Witch "Witch")

|  |  |
| --- | --- |
|  | **You seek power at any cost... and there is no price too high to pay.** |

Official artwork of the Infernalist.

**Infernalist** is an [Ascendancy class](/wiki/Ascendancy_class "Ascendancy class") for the [Witch](/wiki/Witch "Witch").

## Overview

The Infernalist calls upon demonic forces to unleash hellish flames and gain great power at a cost. [Pyromantic Pact](/wiki/Pyromantic_Pact "Pyromantic Pact") trades Mana for Infernal Flame, where paying mana cost instead fills up a meter which causes her to take fire damage when filled. It can then be enhanced to grant the Elemental [Archon](/wiki/Archon "Archon") buff while Infernal Flame is kept high but not full. [Altered Flesh](/wiki/Altered_Flesh "Altered Flesh") grants [damage taken](/wiki/Damage_taken "Damage taken") conversion and opens up three contracts with Beidat, reserving a quarter of your life in exchange for more Mana, Energy shield, or Spirit based on maximum Life. The Infernalist can [shapeshift](/wiki/Shapeshift "Shapeshift") into a powerful spellcasting demon with [Demonic Possession](/wiki/Demonic_Possession "Demonic Possession"), at the cost of ramping life degen. She also has access to a loyal [Hellhound](/wiki/Summon_Infernal_Hound "Summon Infernal Hound") companion, a powerful boost to [critical hits](/wiki/Critical_hit "Critical hit") that inflict self-ignite, and the ability to have all damage types inflict [Ignite](/wiki/Ignite "Ignite").

## Passive skills

### Minor skills

This class has the following minor passive skills:

| Name | Stats |
| --- | --- |
| [Critical Chance](/wiki/Critical_Chance/edit?redlink=1 "Critical Chance (page does not exist)") | 12% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") [[1]](/wiki/Passive_Skill:AscendancyWitch1Small9 "Passive Skill:AscendancyWitch1Small9") |
| [Flammability Magnitude](/wiki/Flammability_Magnitude/edit?redlink=1 "Flammability Magnitude (page does not exist)") | 40% increased [Flammability](/wiki/Flammability "Flammability") [Magnitude](/wiki/Magnitude "Magnitude") [[1]](/wiki/Passive_Skill:AscendancyWitch1Small8 "Passive Skill:AscendancyWitch1Small8") |
| [Life](/wiki/Life_(passive_skill) "Life (passive skill)") | 3% increased maximum Life [[1]](/wiki/Passive_Skill:AscendancyWitch1Small1 "Passive Skill:AscendancyWitch1Small1") [[2]](/wiki/Passive_Skill:AscendancyWitch1Small2 "Passive Skill:AscendancyWitch1Small2") [[3]](/wiki/Passive_Skill:AscendancyWitch1Small3 "Passive Skill:AscendancyWitch1Small3") [[4]](/wiki/Passive_Skill:AscendancyWitch1Small4 "Passive Skill:AscendancyWitch1Small4") |
| [Mana](/wiki/Mana_(passive_skill) "Mana (passive skill)") | 3% increased maximum Mana [[1]](/wiki/Passive_Skill:AscendancyWitch1Small11 "Passive Skill:AscendancyWitch1Small11") [[2]](/wiki/Passive_Skill:AscendancyWitch1Small7 "Passive Skill:AscendancyWitch1Small7") |
| [Minion Life](/wiki/Minion_Life "Minion Life") | [Minions](/wiki/Minion "Minion") have 12% increased maximum Life [[1]](/wiki/Passive_Skill:AscendancyWitch1Small10 "Passive Skill:AscendancyWitch1Small10") |
| [Spell Damage](/wiki/Spell_Damage_(passive_skill) "Spell Damage (passive skill)") | 12% increased [Spell](/wiki/Spell "Spell") Damage [[1]](/wiki/Passive_Skill:AscendancyWitch1Small5 "Passive Skill:AscendancyWitch1Small5") [[2]](/wiki/Passive_Skill:AscendancyWitch1Small6 "Passive Skill:AscendancyWitch1Small6") |

### Notable skills

This class has the following notable passive skills:

| Skill | Modifiers | Prerequisite | Preceding Passive |
| --- | --- | --- | --- |
| [Altered Flesh](/wiki/Altered_Flesh "Altered Flesh") | 20% of [Physical Damage](/wiki/Physical_Damage "Physical Damage") taken as [Chaos Damage](/wiki/Chaos_Damage "Chaos Damage") 20% of [Cold Damage](/wiki/Cold_Damage "Cold Damage") taken as [Fire Damage](/wiki/Fire_Damage "Fire Damage") 20% of [Lightning Damage](/wiki/Lightning_Damage "Lightning Damage") taken as [Fire Damage](/wiki/Fire_Damage "Fire Damage") | — | [Life](/wiki/Life_(ascendancy_passive_skill) "Life (ascendancy passive skill)") |
| [Beidat's Gaze](/wiki/Beidat%27s_Gaze "Beidat's Gaze") | +1 to Maximum Mana per 6 Maximum Life [Reserves](/wiki/Reservation "Reservation") 25% of Life | [Altered Flesh](/wiki/Altered_Flesh "Altered Flesh") | [Life](/wiki/Life_(ascendancy_passive_skill) "Life (ascendancy passive skill)") |
| [Beidat's Hand](/wiki/Beidat%27s_Hand "Beidat's Hand") | +1 to Maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") per 8 Maximum Life [Reserves](/wiki/Reservation "Reservation") 25% of Life | [Altered Flesh](/wiki/Altered_Flesh "Altered Flesh") | [Life](/wiki/Life_(ascendancy_passive_skill) "Life (ascendancy passive skill)") |
| [Beidat's Will](/wiki/Beidat%27s_Will "Beidat's Will") | +1 to Maximum [Spirit](/wiki/Spirit "Spirit") per 25 Maximum Life [Reserves](/wiki/Reservation "Reservation") 25% of Life | [Altered Flesh](/wiki/Altered_Flesh "Altered Flesh") | [Life](/wiki/Life_(ascendancy_passive_skill) "Life (ascendancy passive skill)") |
| [Demonic Possession](/wiki/Demonic_Possession "Demonic Possession") | Grants Skill: [Demon Form](/wiki/Demon_Form "Demon Form") | — | [Spell Damage](/wiki/Spell_Damage_(ascendancy_passive_skill) "Spell Damage (ascendancy passive skill)") |
| [Mastered Darkness](/wiki/Mastered_Darkness "Mastered Darkness") | Demonflame has no maximum | [Demonic Possession](/wiki/Demonic_Possession "Demonic Possession") | [Spell Damage](/wiki/Spell_Damage_(ascendancy_passive_skill) "Spell Damage (ascendancy passive skill)") |
| [Bringer of Flame](/wiki/Bringer_of_Flame "Bringer of Flame") | All Damage from you and [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") [contributes](/wiki/Damage_Contributing_to_Ailments "Damage Contributing to Ailments") to [Flammability](/wiki/Flammability "Flammability") and [Ignite](/wiki/Ignite "Ignite") [Magnitudes](/wiki/Magnitude "Magnitude") | — | [Mana](/wiki/Mana_(ascendancy_passive_skill) "Mana (ascendancy passive skill)") |
| [Pyromantic Pact](/wiki/Pyromantic_Pact "Pyromantic Pact") | Maximum Mana is replaced by twice as much Maximum Infernal Flame Gain Infernal Flame instead of spending Mana for Skill costs 25% of Infernal Flame lost per second if none was gained in the past 2 seconds Take maximum Life and Energy Shield as [Fire](/wiki/Fire "Fire") Damage when Infernal Flame reaches maximum Lose all Infernal Flame on reaching maximum Infernal Flame | — | [Mana](/wiki/Mana_(ascendancy_passive_skill) "Mana (ascendancy passive skill)") |
| [Seething Body](/wiki/Seething_Body "Seething Body") | Gain [Elemental Archon](/wiki/Elemental_Archon "Elemental Archon") when you cast a [Spell](/wiki/Spell "Spell") while on [High Infernal Flame](/wiki/High_Infernal_Flame "High Infernal Flame") [Elemental Archon](/wiki/Elemental_Archon "Elemental Archon") does not expire while on [High Infernal Flame](/wiki/High_Infernal_Flame "High Infernal Flame") Lose [Elemental Archon](/wiki/Elemental_Archon "Elemental Archon") on reaching maximum Infernal Flame | [Pyromantic Pact](/wiki/Pyromantic_Pact "Pyromantic Pact") | [Mana](/wiki/Mana_(ascendancy_passive_skill) "Mana (ascendancy passive skill)") |
| [Loyal Hellhound](/wiki/Loyal_Hellhound "Loyal Hellhound") | Grants Skill: [Summon Infernal Hound](/wiki/Summon_Infernal_Hound "Summon Infernal Hound") | — | [Minion Life](/wiki/Minion_Life_(ascendancy_passive_skill) "Minion Life (ascendancy passive skill)") |
| [Grinning Immolation](/wiki/Grinning_Immolation "Grinning Immolation") | 50% more [Critical Damage Bonus](/wiki/Critical_Damage_Bonus "Critical Damage Bonus") Become [Ignited](/wiki/Ignite "Ignite") when you deal a [Critical Hit](/wiki/Critical_Hit "Critical Hit"), taking 15% of your maximum Life and [Energy Shield](/wiki/Energy_Shield "Energy Shield") as [Fire](/wiki/Fire "Fire") Damage per second | — | [Critical Chance](/wiki/Critical_Chance_(ascendancy_passive_skill) "Critical Chance (ascendancy passive skill)") |
