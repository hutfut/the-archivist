# Invoker

Invoker

[Monk](/wiki/Monk "Monk")

|  |  |
| --- | --- |
|  | **True strength lies within. One must only focus... and believe.** |

Official artwork of the Invoker.

**Invoker** is an [Ascendancy class](/wiki/Ascendancy_class "Ascendancy class") for the [Monk](/wiki/Monk "Monk").

## Overview

The Invoker is attuned to nature, providing mastery over the elements. He can empower his elemental attacks with critical hits that ignore resistances and trigger [Elemental Expression](/wiki/Elemental_Expression "Elemental Expression") to wipe out enemies, or unleash [Unbound Avatar](/wiki/Unbound_Avatar "Unbound Avatar") to gain a massive boost to his elemental offense after applying elemental ailments enough times. The Invoker has access to [Meta](/wiki/Meta "Meta") skill synergies, with [Lead me through Grace...](/wiki/Lead_me_through_Grace... "Lead me through Grace...") to gain [Spirit](/wiki/Spirit "Spirit") from his body armour defences and [The Soul Springs Eternal](/wiki/The_Soul_Springs_Eternal "The Soul Springs Eternal") to trigger them faster and have more efficient reservations. The Invoker can also has the ability to gain [physical damage reduction](/wiki/Physical_damage_reduction/edit?redlink=1 "Physical damage reduction (page does not exist)") from his [Evasion](/wiki/Evasion "Evasion") rating and [Meditate](/wiki/Meditate "Meditate") to overcharge his [energy shield](/wiki/Energy_shield "Energy shield").

## Passive skills

### Minor skills

This class has the following minor passive skills:

| Name | Stats |
| --- | --- |
| [Chill Effect](/wiki/Chill_Effect/edit?redlink=1 "Chill Effect (page does not exist)") | 15% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Chill](/wiki/Chill "Chill") you inflict [[1]](/wiki/Passive_Skill:AscendancyMonk2Small4 "Passive Skill:AscendancyMonk2Small4") |
| [Critical Chance](/wiki/Critical_Chance/edit?redlink=1 "Critical Chance (page does not exist)") | 12% increased [Critical Hit Chance](/wiki/Critical_Hit_Chance "Critical Hit Chance") [[1]](/wiki/Passive_Skill:AscendancyMonk2Small7 "Passive Skill:AscendancyMonk2Small7") [[2]](/wiki/Passive_Skill:AscendancyMonk2Small8 "Passive Skill:AscendancyMonk2Small8") |
| [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") | 12% increased [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") [[1]](/wiki/Passive_Skill:AscendancyMonk2Small5 "Passive Skill:AscendancyMonk2Small5") [[2]](/wiki/Passive_Skill:AscendancyMonk2Small6 "Passive Skill:AscendancyMonk2Small6") |
| [Energy Shield Recharge Rate](/wiki/Energy_Shield_Recharge_Rate "Energy Shield Recharge Rate") | 20% increased [Energy Shield Recharge Rate](/wiki/Energy_Shield_Recharge_Rate "Energy Shield Recharge Rate") [[1]](/wiki/Passive_Skill:AscendancyMonk2Small9 "Passive Skill:AscendancyMonk2Small9") |
| [Evasion](/wiki/Evasion_(passive_skill) "Evasion (passive skill)") | 20% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") [[1]](/wiki/Passive_Skill:AscendancyMonk2Small2 "Passive Skill:AscendancyMonk2Small2") |
| [Evasion and Energy Shield](/wiki/Evasion_and_Energy_Shield/edit?redlink=1 "Evasion and Energy Shield (page does not exist)") | 15% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") 15% increased maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") [[1]](/wiki/Passive_Skill:AscendancyMonk2Small1 "Passive Skill:AscendancyMonk2Small1") |
| [Shock Effect](/wiki/Shock_Effect/edit?redlink=1 "Shock Effect (page does not exist)") | 15% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Shock](/wiki/Shock "Shock") you inflict [[1]](/wiki/Passive_Skill:AscendancyMonk2Small3 "Passive Skill:AscendancyMonk2Small3") |
| [Triggered Spell Damage](/wiki/Triggered_Spell_Damage/edit?redlink=1 "Triggered Spell Damage (page does not exist)") | [Triggered](/wiki/Trigger "Trigger") [Spells](/wiki/Spell "Spell") deal 16% increased [Spell](/wiki/Spell "Spell") Damage [[1]](/wiki/Passive_Skill:AscendancyMonk2Small10~ "Passive Skill:AscendancyMonk2Small10~") |

### Notable skills

This class has the following notable passive skills:

| Skill | Modifiers | Prerequisite | Preceding Passive |
| --- | --- | --- | --- |
| [Lead me through Grace...](/wiki/Lead_me_through_Grace... "Lead me through Grace...") | Cannot gain [Spirit](/wiki/Spirit "Spirit") from Equipment +1 to [Spirit](/wiki/Spirit "Spirit") for every 20 [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") on Equipped Body Armour +1 to [Spirit](/wiki/Spirit "Spirit") for every 8 [Item Energy Shield](/wiki/Defences "Defences") on Equipped Body Armour | — | [Evasion and Energy Shield](/wiki/Evasion_and_Energy_Shield_(ascendancy_passive_skill) "Evasion and Energy Shield (ascendancy passive skill)") |
| [...and Protect me from Harm](/wiki/...and_Protect_me_from_Harm "...and Protect me from Harm") | 35% less [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") Physical Damage Reduction from [Armour](/wiki/Armour "Armour") is based on your combined [Armour](/wiki/Armour "Armour") and [Evasion](/wiki/Evasion "Evasion") Rating | [Lead me through Grace...](/wiki/Lead_me_through_Grace... "Lead me through Grace...") | [Evasion](/wiki/Evasion_(ascendancy_passive_skill) "Evasion (ascendancy passive skill)") |
| [Faith is a Choice](/wiki/Faith_is_a_Choice "Faith is a Choice") | Grants Skill: [Meditate](/wiki/Meditate "Meditate") | — | [Energy Shield Recharge](/wiki/Energy_Shield_Recharge_(ascendancy_passive_skill) "Energy Shield Recharge (ascendancy passive skill)") |
| [I am the Blizzard...](/wiki/I_am_the_Blizzard... "I am the Blizzard...") | On [Freezing](/wiki/Freezing "Freezing") Enemies create [Chilled Ground](/wiki/Chilled_Ground "Chilled Ground") [Gain](/wiki/Gain "Gain") 10% of Damage as Extra [Cold](/wiki/Cold "Cold") Damage | — | [Chill Effect](/wiki/Chill_Effect_(ascendancy_passive_skill) "Chill Effect (ascendancy passive skill)") |
| [I am the Thunder...](/wiki/I_am_the_Thunder... "I am the Thunder...") | 25% chance on [Shocking](/wiki/Shock "Shock") Enemies to created [Shocked Ground](/wiki/Shocked_Ground "Shocked Ground") [Gain](/wiki/Gain "Gain") 10% of Damage as Extra [Lightning](/wiki/Lightning "Lightning") Damage | — | [Shock Effect](/wiki/Shock_Effect_(ascendancy_passive_skill) "Shock Effect (ascendancy passive skill)") |
| [...and I Shall Rage](/wiki/...and_I_Shall_Rage "...and I Shall Rage") | Grants Skill: [Unbound Avatar](/wiki/Unbound_Avatar "Unbound Avatar") | [I am the Blizzard...](/wiki/I_am_the_Blizzard... "I am the Blizzard...") or [I am the Thunder...](/wiki/I_am_the_Thunder... "I am the Thunder...") | [Elemental Damage](/wiki/Elemental_Damage_(ascendancy_passive_skill) "Elemental Damage (ascendancy passive skill)") |
| [The Soul Springs Eternal](/wiki/The_Soul_Springs_Eternal "The Soul Springs Eternal") | [Meta](/wiki/Meta "Meta") Skills gain 35% more [Energy](/wiki/Energy "Energy") [Meta](/wiki/Meta "Meta") Skills have 50% increased [Reservation](/wiki/Reservation "Reservation") [Efficiency](/wiki/Efficiency "Efficiency") | — | [Triggered Spell Damage](/wiki/Triggered_Spell_Damage_(ascendancy_passive_skill) "Triggered Spell Damage (ascendancy passive skill)") |
| [Sunder my Enemies...](/wiki/Sunder_my_Enemies... "Sunder my Enemies...") | [Critical Hits](/wiki/Critical_Hit "Critical Hit") ignore non-negative Enemy Monster [Elemental Resistances](/wiki/Elemental_Resistance/edit?redlink=1 "Elemental Resistance (page does not exist)") | — | [Critical Chance](/wiki/Critical_Chance_(ascendancy_passive_skill) "Critical Chance (ascendancy passive skill)") |
| [...and Scatter Them to the Winds](/wiki/...and_Scatter_Them_to_the_Winds "...and Scatter Them to the Winds") | Grants Skill: [Elemental Expression](/wiki/Elemental_Expression "Elemental Expression") Trigger Elemental Expression on [Melee](/wiki/Melee "Melee") [Critical Hit](/wiki/Critical_Hit "Critical Hit") | [Sunder my Enemies...](/wiki/Sunder_my_Enemies... "Sunder my Enemies...") | [Critical Chance](/wiki/Critical_Chance_(ascendancy_passive_skill) "Critical Chance (ascendancy passive skill)") |
