# Mercenary

The Mercenary

Gender: M
[Strength](/wiki/Strength "Strength"): 11
[Dexterity](/wiki/Dexterity "Dexterity"): 11
[Intelligence](/wiki/Intelligence "Intelligence"): 7
[Weapon](/wiki/Weapon "Weapon"): [Crossbow](/wiki/Gemcutting#Crossbow "Gemcutting")

* [Makeshift Crossbow](/wiki/Makeshift_Crossbow "Makeshift Crossbow")
* [Fragmentation Rounds](/wiki/Fragmentation_Rounds "Fragmentation Rounds")

[Ascendancies](/wiki/Ascendancy_class "Ascendancy class"):

[Witchhunter](/wiki/Witchhunter "Witchhunter")
 [Gemling Legionnaire](/wiki/Gemling_Legionnaire "Gemling Legionnaire")
 [Tactician](/wiki/Tactician "Tactician")

> You've got a weapon. I'll wield it. Just tell me where to point it. I've seen the highs and horrors of war, and I'll do whatever it takes to survive. If you've got coin, I'm your man.

The **Mercenary** is a [strength](/wiki/Strength "Strength")/[dexterity](/wiki/Dexterity "Dexterity")-oriented [class](/wiki/Character_class "Character class") that specializes in [crossbow](/wiki/Crossbow "Crossbow") and [grenade](/wiki/Grenade "Grenade") skills. He is of [Trarthan](/wiki/Trarthus/edit?redlink=1 "Trarthus (page does not exist)") heritage.

The Mercenary obtains a [Makeshift Crossbow](/wiki/Makeshift_Crossbow "Makeshift Crossbow") and [Fragmentation Rounds](/wiki/Fragmentation_Rounds "Fragmentation Rounds") as his default starting weapon and skill in [The Riverbank](/wiki/The_Riverbank "The Riverbank").

## Ascendancy classes

Mercenaries can specialize into one of these three [Ascendancy classes](/wiki/Ascendancy_classes "Ascendancy classes"):

* [Witchhunter](/wiki/Witchhunter "Witchhunter")
* [Gemling Legionnaire](/wiki/Gemling_Legionnaire "Gemling Legionnaire")
* [Tactician](/wiki/Tactician "Tactician")

## Trivia

In the official Path of Exile 2 Artbook, the Mercenary is described as "a veteran of Oriathan's secular military". However, in-game the Mercenary is Trarthan.
