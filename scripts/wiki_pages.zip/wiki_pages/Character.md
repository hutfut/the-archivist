# Character

Redirect to:

* [Character class](/wiki/Character_class "Character class")
