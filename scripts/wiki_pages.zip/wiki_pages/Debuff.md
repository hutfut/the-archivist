# Debuff

Debuffs

Tooltip

Debuffs are negative effects that deal damage or penalise an entity's stats, either for a set duration or when a condition is met.

Unless otherwise stated, Debuffs of the same type do not stack — only the copy with the strongest effect applies.

**Debuffs** are negative effects that deal [damage](/wiki/Damage "Damage") or penalise an entity's stats, either for a set [duration](/wiki/Duration "Duration") or when a condition is met. Unless otherwise stated, debuffs of the same type do not stack - only the copy with the strongest effect applies.

## Unaffected

Unaffected

Tooltip

Debuffs you are Unaffected by can still be placed on you, but will not actually apply their effect.

If you are **unaffected** by a debuff, it can still be applied to you but does not apply its effect to you. This can be useful in combination with [Unique items](/wiki/Unique_item "Unique item") which give a benefit for having a specific debuff on you.

## Related skills

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Chaos Bolt](/wiki/Chaos_Bolt "Chaos Bolt") | *0* |  |  |  |
| [His Vile Intrusion](/wiki/His_Vile_Intrusion "His Vile Intrusion") | *0* |  |  |  |
| [Inevitable Agony](/wiki/Inevitable_Agony "Inevitable Agony") | *0* |  |  |  |
| [Parry](/wiki/Parry "Parry") | *0* |  |  |  |
| [Disengage](/wiki/Disengage "Disengage") | *1* |  |  |  |
| [Contagion](/wiki/Contagion "Contagion") | *1* |  |  |  |
| [Fangs of Frost](/wiki/Fangs_of_Frost "Fangs of Frost") | *3* |  |  |  |
| [Essence Drain](/wiki/Essence_Drain "Essence Drain") | *3* |  |  |  |
| [Profane Ritual](/wiki/Profane_Ritual "Profane Ritual") | *7* |  |  |  |
| [Voltaic Grenade](/wiki/Voltaic_Grenade "Voltaic Grenade") | *7* |  |  |  |
| [Dark Effigy](/wiki/Dark_Effigy "Dark Effigy") | *9* |  |  |  |
| [Lightning Warp](/wiki/Lightning_Warp "Lightning Warp") | *9* |  |  |  |
| [Tornado](/wiki/Tornado "Tornado") | *11* |  |  |  |

### Persistent skills

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |

## Related support gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Paquate's Pact](/wiki/Paquate%27s_Pact "Paquate's Pact") | *0* |  |  |  |
| [Slow Potency](/wiki/Slow_Potency "Slow Potency") | *1* |  |  |  |
| [Frenzied Riposte](/wiki/Frenzied_Riposte "Frenzied Riposte") | *2* |  |  |  |
| [Acrimony](/wiki/Acrimony "Acrimony") | *2* |  |  |  |
| [Intense Agony](/wiki/Intense_Agony "Intense Agony") | *2* |  |  |  |
| [Chaotic Freeze](/wiki/Chaotic_Freeze "Chaotic Freeze") | *3* |  |  |  |
| [Drain Ailments](/wiki/Drain_Ailments "Drain Ailments") | *3* |  |  |  |
| [Refraction III](/wiki/Refraction_III "Refraction III") | *5* |  |  |  |

## Related unique items

The table below lists [unique items](/wiki/Unique_item "Unique item") that are related to debuffs in general:

No results found

## Related passive skills

The following [passive skills](/wiki/Passive_skill "Passive skill") are related to debuffs:

| Name | Stats |
| --- | --- |
| [Ailment Threshold and Slow Effect on You](/wiki/Ailment_Threshold_and_Slow_Effect_on_You/edit?redlink=1 "Ailment Threshold and Slow Effect on You (page does not exist)") | 10% increased [Elemental Ailment Threshold](/wiki/Ailment "Ailment") 5% reduced [Slowing](/wiki/Slow "Slow") Potency of Debuffs on You [[1]](/wiki/Passive_Skill:Slow~mitigation17 "Passive Skill:Slow~mitigation17") [[2]](/wiki/Passive_Skill:Slow~mitigation18 "Passive Skill:Slow~mitigation18") |
| [Attack Damage and Slow Effect](/wiki/Attack_Damage_and_Slow_Effect/edit?redlink=1 "Attack Damage and Slow Effect (page does not exist)") | 8% increased [Attack](/wiki/Attack "Attack") Damage Debuffs you inflict have 4% increased [Slow Magnitude](/wiki/Slow_Magnitude_Modifier/edit?redlink=1 "Slow Magnitude Modifier (page does not exist)") [[1]](/wiki/Passive_Skill:Attack3 "Passive Skill:Attack3") |
| [Debuff Expiry](/wiki/Debuff_Expiry/edit?redlink=1 "Debuff Expiry (page does not exist)") | Debuffs on you expire 10% faster [[1]](/wiki/Passive_Skill:Slowed~enemies1 "Passive Skill:Slowed~enemies1") [[2]](/wiki/Passive_Skill:Slowed~enemies2 "Passive Skill:Slowed~enemies2") [[3]](/wiki/Passive_Skill:Slowed~enemies7 "Passive Skill:Slowed~enemies7") |
| [Debuff Expiry Rate](/wiki/Debuff_Expiry_Rate/edit?redlink=1 "Debuff Expiry Rate (page does not exist)") | Debuffs on you expire 10% faster [[1]](/wiki/Passive_Skill:Slowed~enemies20 "Passive Skill:Slowed~enemies20") [[2]](/wiki/Passive_Skill:Slowed~enemies21 "Passive Skill:Slowed~enemies21") |
| [Exposure Effect and Slow Effect](/wiki/Exposure_Effect_and_Slow_Effect/edit?redlink=1 "Exposure Effect and Slow Effect (page does not exist)") | 7% increased [Exposure](/wiki/Exposure "Exposure") Effect Debuffs you inflict have 7% increased [Slow Magnitude](/wiki/Slow_Magnitude_Modifier/edit?redlink=1 "Slow Magnitude Modifier (page does not exist)") [[1]](/wiki/Passive_Skill:Slowed~enemies28 "Passive Skill:Slowed~enemies28") [[2]](/wiki/Passive_Skill:Slowed~enemies29 "Passive Skill:Slowed~enemies29") |
| [Movement Speed and Slow Effect on You](/wiki/Movement_Speed_and_Slow_Effect_on_You/edit?redlink=1 "Movement Speed and Slow Effect on You (page does not exist)") | 1% increased Movement Speed 4% reduced [Slowing](/wiki/Slow "Slow") Potency of Debuffs on You [[1]](/wiki/Passive_Skill:Slow~mitigation5 "Passive Skill:Slow~mitigation5") |
| [Slow Effect](/wiki/Slow_Effect/edit?redlink=1 "Slow Effect (page does not exist)") | Debuffs you inflict have 5% increased [Slow Magnitude](/wiki/Slow_Magnitude_Modifier/edit?redlink=1 "Slow Magnitude Modifier (page does not exist)") [[1]](/wiki/Passive_Skill:Slowed~enemies3~ "Passive Skill:Slowed~enemies3~") [[2]](/wiki/Passive_Skill:Slowed~enemies4 "Passive Skill:Slowed~enemies4") [[3]](/wiki/Passive_Skill:Slowed~enemies5 "Passive Skill:Slowed~enemies5") |
| [Slow Effect and Hinder Duration](/wiki/Slow_Effect_and_Hinder_Duration/edit?redlink=1 "Slow Effect and Hinder Duration (page does not exist)") | Debuffs you inflict have 4% increased [Slow Magnitude](/wiki/Slow_Magnitude_Modifier/edit?redlink=1 "Slow Magnitude Modifier (page does not exist)") 20% increased [Hinder](/wiki/Hinder "Hinder") Duration [[1]](/wiki/Passive_Skill:Slowed~enemies13 "Passive Skill:Slowed~enemies13") [[2]](/wiki/Passive_Skill:Slowed~enemies14~ "Passive Skill:Slowed~enemies14~") |
| [Slow Effect on You](/wiki/Slow_Effect_on_You/edit?redlink=1 "Slow Effect on You (page does not exist)") | 8% reduced [Slowing](/wiki/Slow "Slow") Potency of Debuffs on You [[1]](/wiki/Passive_Skill:Duration~spells10 "Passive Skill:Duration~spells10") [[2]](/wiki/Passive_Skill:Duration~spells2 "Passive Skill:Duration~spells2") [[3]](/wiki/Passive_Skill:Duration~spells3 "Passive Skill:Duration~spells3") [[4]](/wiki/Passive_Skill:Energy~shield~and~armour28~~ "Passive Skill:Energy~shield~and~armour28~~") [[5]](/wiki/Passive_Skill:Evasion19 "Passive Skill:Evasion19") [[6]](/wiki/Passive_Skill:Evasion20 "Passive Skill:Evasion20") [[7]](/wiki/Passive_Skill:Slowed~enemies16 "Passive Skill:Slowed~enemies16") [[8]](/wiki/Passive_Skill:Slowed~enemies17 "Passive Skill:Slowed~enemies17") [[9]](/wiki/Passive_Skill:Slow~mitigation1 "Passive Skill:Slow~mitigation1") [[10]](/wiki/Passive_Skill:Slow~mitigation2 "Passive Skill:Slow~mitigation2") [[11]](/wiki/Passive_Skill:Spell~suppression11%2B "Passive Skill:Spell~suppression11+") [[12]](/wiki/Passive_Skill:Spell~suppression35 "Passive Skill:Spell~suppression35") [[13]](/wiki/Passive_Skill:Spell~suppression7 "Passive Skill:Spell~suppression7") |
| [Slow Effect on You and Attack Speed](/wiki/Slow_Effect_on_You_and_Attack_Speed/edit?redlink=1 "Slow Effect on You and Attack Speed (page does not exist)") | 4% reduced [Slowing](/wiki/Slow "Slow") Potency of Debuffs on You 2% increased [Attack](/wiki/Attack "Attack") Speed [[1]](/wiki/Passive_Skill:Duration~spells7 "Passive Skill:Duration~spells7") |
| [Slow Effect on You and Debuff Expiry Rate](/wiki/Slow_Effect_on_You_and_Debuff_Expiry_Rate/edit?redlink=1 "Slow Effect on You and Debuff Expiry Rate (page does not exist)") | Debuffs on you expire 3% faster 4% reduced [Slowing](/wiki/Slow "Slow") Potency of Debuffs on You [[1]](/wiki/Passive_Skill:Slowed~enemies24 "Passive Skill:Slowed~enemies24") |
| [Against the Elements](/wiki/Against_the_Elements/edit?redlink=1 "Against the Elements (page does not exist)") | 30% increased [Elemental Ailment Threshold](/wiki/Ailment "Ailment") 15% reduced [Slowing](/wiki/Slow "Slow") Potency of Debuffs on You [[1]](/wiki/Passive_Skill:Slow~mitigation19~ "Passive Skill:Slow~mitigation19~") |
| [Chronomancy](/wiki/Chronomancy/edit?redlink=1 "Chronomancy (page does not exist)") | Debuffs you inflict have 10% increased [Slow Magnitude](/wiki/Slow_Magnitude_Modifier/edit?redlink=1 "Slow Magnitude Modifier (page does not exist)") 20% increased Skill Effect Duration [[1]](/wiki/Passive_Skill:Slowed~enemies10 "Passive Skill:Slowed~enemies10") |
| [Constricting](/wiki/Constricting/edit?redlink=1 "Constricting (page does not exist)") | 25% increased [Physical](/wiki/Physical "Physical") Damage Debuffs you inflict have 5% increased [Slow Magnitude](/wiki/Slow_Magnitude_Modifier/edit?redlink=1 "Slow Magnitude Modifier (page does not exist)") [[1]](/wiki/Passive_Skill:Physical54 "Passive Skill:Physical54") |
| [Freedom of Movement](/wiki/Freedom_of_Movement "Freedom of Movement") | 20% increased [Evasion Rating](/wiki/Evasion_Rating "Evasion Rating") 5% reduced Movement Speed Penalty from using Skills while moving 10% reduced [Slowing](/wiki/Slow "Slow") Potency of Debuffs on You [[1]](/wiki/Passive_Skill:Evasion30 "Passive Skill:Evasion30") |
| [Hindered Capabilities](/wiki/Hindered_Capabilities/edit?redlink=1 "Hindered Capabilities (page does not exist)") | 30% increased Damage with [Hits](/wiki/Hit "Hit") against [Hindered](/wiki/Hinder "Hinder") Enemies Debuffs you inflict have 10% increased [Slow Magnitude](/wiki/Slow_Magnitude_Modifier/edit?redlink=1 "Slow Magnitude Modifier (page does not exist)") [[1]](/wiki/Passive_Skill:Slowed~enemies15 "Passive Skill:Slowed~enemies15") |
| [Iron Slippers](/wiki/Iron_Slippers/edit?redlink=1 "Iron Slippers (page does not exist)") | +3 to [Armour](/wiki/Armour "Armour") per 1 [Item Energy Shield](/wiki/Defences "Defences") on Equipped Boots 10% reduced [Slowing](/wiki/Slow "Slow") Potency of Debuffs on You [[1]](/wiki/Passive_Skill:Energy~shield~and~armour29~ "Passive Skill:Energy~shield~and~armour29~") |
| [Lasting Boons](/wiki/Lasting_Boons/edit?redlink=1 "Lasting Boons (page does not exist)") | [Buffs](/wiki/Buffs "Buffs") on you expire 10% slower 20% reduced [Slowing](/wiki/Slow "Slow") Potency of Debuffs on You [[1]](/wiki/Passive_Skill:Slowed~enemies18 "Passive Skill:Slowed~enemies18") |
| [Momentum](/wiki/Momentum "Momentum") | Ignore all [Movement Penalties](/wiki/Armour_Movement_Penalties/edit?redlink=1 "Armour Movement Penalties (page does not exist)") from [Armour](/wiki/Armour_(equipment) "Armour (equipment)") 5% reduced [Slowing](/wiki/Slow "Slow") Potency of Debuffs on You [[1]](/wiki/Passive_Skill:Slow~mitigation7~ "Passive Skill:Slow~mitigation7~") |
| [Near at Hand](/wiki/Near_at_Hand/edit?redlink=1 "Near at Hand (page does not exist)") | 16% reduced Skill Effect Duration 10% reduced [Slowing](/wiki/Slow "Slow") Potency of Debuffs on You [[1]](/wiki/Passive_Skill:Duration~spells6 "Passive Skill:Duration~spells6") |
| [Time Manipulation](/wiki/Time_Manipulation/edit?redlink=1 "Time Manipulation (page does not exist)") | Debuffs you inflict have 10% increased [Slow Magnitude](/wiki/Slow_Magnitude_Modifier/edit?redlink=1 "Slow Magnitude Modifier (page does not exist)") Debuffs on you expire 20% faster [[1]](/wiki/Passive_Skill:Slowed~enemies9 "Passive Skill:Slowed~enemies9") |
| [Unhindered](/wiki/Unhindered "Unhindered") | 20% reduced [Slowing](/wiki/Slow "Slow") Potency of Debuffs on You 6% reduced Movement Speed Penalty from using Skills while moving [[1]](/wiki/Passive_Skill:Spell~suppression12 "Passive Skill:Spell~suppression12") |
| [Unimpeded](/wiki/Unimpeded/edit?redlink=1 "Unimpeded (page does not exist)") | 24% reduced [Slowing](/wiki/Slow "Slow") Potency of Debuffs on You [[1]](/wiki/Passive_Skill:Duration~spells4 "Passive Skill:Duration~spells4") |
| [Unstoppable Barrier](/wiki/Unstoppable_Barrier/edit?redlink=1 "Unstoppable Barrier (page does not exist)") | 10% increased [Block](/wiki/Block "Block") chance 15% reduced [Slowing](/wiki/Slow "Slow") Potency of Debuffs on You [[1]](/wiki/Passive_Skill:Block12 "Passive Skill:Block12") |
| [Unyielding](/wiki/Unyielding_(passive)/edit?redlink=1 "Unyielding (passive) (page does not exist)") | 15% increased [Attack](/wiki/Attack "Attack") Speed if you've been Hit [Recently](/wiki/Recently "Recently") 8% reduced [Slowing](/wiki/Slow "Slow") Potency of Debuffs on You [[1]](/wiki/Passive_Skill:Duration~spells11 "Passive Skill:Duration~spells11") |
| [Waning Hindrances](/wiki/Waning_Hindrances/edit?redlink=1 "Waning Hindrances (page does not exist)") | Debuffs on you expire 25% faster [[1]](/wiki/Passive_Skill:Slowed~enemies19 "Passive Skill:Slowed~enemies19") |

### Ascendancy passive skills

The following [Ascendancy passive skills](/wiki/Ascendancy_passive_skill "Ascendancy passive skill") are related to debuffs:

| Ascendancy Class | Name | Stats |
| --- | --- | --- |
| [Chronomancer](/wiki/Chronomancer "Chronomancer") | [Slow Effect](/wiki/Slow_Effect/edit?redlink=1 "Slow Effect (page does not exist)") | Debuffs you inflict have 6% increased [Slow Magnitude](/wiki/Slow_Magnitude_Modifier/edit?redlink=1 "Slow Magnitude Modifier (page does not exist)") [[1]](/wiki/Passive_Skill:AscendancySorceress2Small7 "Passive Skill:AscendancySorceress2Small7") |
