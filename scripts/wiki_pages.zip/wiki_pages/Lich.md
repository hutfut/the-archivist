# Lich

Lich

[Witch](/wiki/Witch "Witch")

|  |  |
| --- | --- |
|  | **Death if your domain, your flesh merely a material to be mastered.** |

Official artwork of the Lich.

**Lich** is an [Ascendancy class](/wiki/Ascendancy_class "Ascendancy class") for the [Witch](/wiki/Witch "Witch").

## Overview

The Lich is a class who has become one with death, unlocking the potential to acquire great power at a price. She can apply everlasting [curses](/wiki/Curse "Curse") to her enemies that make them explode on death, grant herself and her minions [Unholy Might](/wiki/Unholy_Might "Unholy Might") as long as she can prevent her Mana from running low, or empower her spells by consuming [power charges](/wiki/Power_charge "Power charge") or sacrificing [energy shield](/wiki/Energy_shield "Energy shield"). [Crystalline Phylactery](/wiki/Crystalline_Phylactery "Crystalline Phylactery") grants her an extra [jewel](/wiki/Jewel "Jewel") socket with that gives the jewel enhanced power, for a price. [Soulless Form](/wiki/Soulless_Form "Soulless Form") gives Life/ES hybrid builds a new way to scale Mana regeneration, while [Eternal Life](/wiki/Eternal_Life "Eternal Life") freezes their Life value while having Energy Shield.

## Passive skills

### Minor skills

This class has the following minor passive skills:

| Name | Stats |
| --- | --- |
| [Curse Area](/wiki/Curse_Area/edit?redlink=1 "Curse Area (page does not exist)") | 15% increased Area of Effect of [Curses](/wiki/Curse "Curse") [[1]](/wiki/Passive_Skill:AscendancyWitch3Small1 "Passive Skill:AscendancyWitch3Small1") [[2]](/wiki/Passive_Skill:AscendancyWitch3Small2 "Passive Skill:AscendancyWitch3Small2") |
| [Energy Shield](/wiki/Energy_Shield "Energy Shield") | 20% increased maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") [[1]](/wiki/Passive_Skill:AscendancyWitch3Small7 "Passive Skill:AscendancyWitch3Small7") [[2]](/wiki/Passive_Skill:AscendancyWitch3Small9 "Passive Skill:AscendancyWitch3Small9") |
| [Energy Shield if Consumed Power Charge](/wiki/Energy_Shield_if_Consumed_Power_Charge/edit?redlink=1 "Energy Shield if Consumed Power Charge (page does not exist)") | 30% increased maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") if you've consumed a [Power Charge](/wiki/Power_Charge "Power Charge") [Recently](/wiki/Recently "Recently") [[1]](/wiki/Passive_Skill:AscendancyWitch3Small8 "Passive Skill:AscendancyWitch3Small8") |
| [Life](/wiki/Life_(passive_skill) "Life (passive skill)") | 3% increased maximum Life [[1]](/wiki/Passive_Skill:AscendancyWitch3Small5 "Passive Skill:AscendancyWitch3Small5") [[2]](/wiki/Passive_Skill:AscendancyWitch3Small6~ "Passive Skill:AscendancyWitch3Small6~") |
| [Mana](/wiki/Mana_(passive_skill) "Mana (passive skill)") | 3% increased maximum Mana [[1]](/wiki/Passive_Skill:AscendancyWitch3Small3 "Passive Skill:AscendancyWitch3Small3") [[2]](/wiki/Passive_Skill:AscendancyWitch3Small4 "Passive Skill:AscendancyWitch3Small4") |

### Notable skills

This class has the following notable passive skills:

| Skill | Modifiers | Prerequisite | Preceding Passive |
| --- | --- | --- | --- |
| [Necromantic Conduit](/wiki/Necromantic_Conduit "Necromantic Conduit") | While you are not on [Low Mana](/wiki/Low_Mana "Low Mana"), you and [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence") have [Unholy Might](/wiki/Unholy_Might "Unholy Might") Lose 5% of maximum Mana per Second | — | Mana |
| [Blackened Heart](/wiki/Blackened_Heart "Blackened Heart") | 4% increased [Magnitude](/wiki/Magnitude "Magnitude") of [Unholy Might](/wiki/Unholy_Might "Unholy Might") [Buffs](/wiki/Buffs "Buffs") you grant per 100 maximum Mana | [Necromantic Conduit](/wiki/Necromantic_Conduit "Necromantic Conduit") | Mana |
| [Rupture the Soul](/wiki/Rupture_the_Soul "Rupture the Soul") | [Cursed](/wiki/Curse "Curse") Enemies killed by you, or by [Allies](/wiki/Allies "Allies") in your [Presence](/wiki/Presence "Presence"), have a 33% chance to explode, dealing a quarter of their maximum Life as [Chaos](/wiki/Chaos "Chaos") damage | — | Curse Area |
| [Incessant Cacophony](/wiki/Incessant_Cacophony "Incessant Cacophony") | You can apply an additional [Curse](/wiki/Curse "Curse") [Curses](/wiki/Curse "Curse") you inflict have infinite Duration | [Rupture the Soul](/wiki/Rupture_the_Soul "Rupture the Soul") | Curse Area |
| [Crystalline Phylactery](/wiki/Crystalline_Phylactery "Crystalline Phylactery") | 100% increased Effect of the Socketed [Jewel](/wiki/Jewel "Jewel") Can Socket a [non-Unique](/wiki/Rarity "Rarity") [Basic Jewel](/wiki/Basic_Jewel/edit?redlink=1 "Basic Jewel (page does not exist)") into the Phylactery 50% more Mana Cost of Skills if you have no [Energy Shield](/wiki/Energy_Shield "Energy Shield") | — | Energy Shield |
| [Eldritch Empowerment](/wiki/Eldritch_Empowerment "Eldritch Empowerment") | [Sacrifice](/wiki/Sacrifice_(keyword) "Sacrifice (keyword)") 5% of maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") when you Cast a [Spell](/wiki/Spell "Spell") [Spells](/wiki/Spell "Spell") for which this [Sacrifice](/wiki/Sacrifice_(keyword) "Sacrifice (keyword)") was fully made deal 30% more Damage [Sacrificing](/wiki/Sacrifice_(keyword) "Sacrifice (keyword)") [Energy Shield](/wiki/Energy_Shield "Energy Shield") does not interrupt [Recharge](/wiki/Energy_Shield "Energy Shield") | — | Energy Shield |
| [Price of Power](/wiki/Price_of_Power "Price of Power") | [Spells](/wiki/Spell "Spell") consume a [Power Charge](/wiki/Power_Charge "Power Charge") if able to deal 40% more Damage | — | Energy Shield if Consumed Power Charge |
| [Soulless Form](/wiki/Soulless_Form "Soulless Form") | Regenerate Mana equal to 6% of maximum Life per second No inherent Mana Regeneration 10% of Damage taken bypasses [Energy Shield](/wiki/Energy_Shield "Energy Shield") | — | Life |
| [Eternal Life](/wiki/Eternal_Life "Eternal Life") | Your Life cannot change while you have [Energy Shield](/wiki/Energy_Shield "Energy Shield") | [Soulless Form](/wiki/Soulless_Form "Soulless Form") | Life |
