# Monster

**Monsters** are the primary enemies encountered by the player. Killed monsters may grant [experience](/wiki/Experience "Experience") and drop [items](/wiki/Item "Item") and [gold](/wiki/Gold "Gold").
Monsters can belong to four rarity types:

* [Normal](/wiki/Rarity#Normal "Rarity"): This is the weakest and most common rarity of monsters, but such enemies appear in larger numbers, often forming 'monster packs'. They can have some innate abilities but do not have any modifiers by default (though they can have properties granted to them by nearby rare monsters).
* [Magic](/wiki/Rarity#Magic "Rarity"): These monsters are more powerful and less common. They will randomly generate with one or two modifiers that empower them and improve their drops.
* [Rare](/wiki/Rarity#Rare "Rarity"): These are the least common and most powerful type of randomly generated monsters. They can have multiple modifiers which can significantly increase their difficulty. Certain monster types have different base abilities and stats when they appear as rare monsters, beyond the random modifiers affecting them. Some of the modifiers that can affect a rare monster can take the form of auras or other buffs that empower other nearby monsters, and the combination of modifiers that affect any specific rare monster can make it more dangerous than a similarly levelled unique monster.
* [Unique](/wiki/Rarity#Unique "Rarity"): These monsters are not randomly generated. Specific unique monsters are guaranteed to appear in specific campaign areas and [maps](/wiki/Maps "Maps") when they are inhabited by a boss, as well as certain Atlas [encounters](/wiki/Encounter "Encounter") such as [rogue exiles](/wiki/Rogue_exile "Rogue exile"). These monsters have carefully constructed abilities and move sets to provide a challenging and rewarding fight, and many in the campaign are required to be killed to complete [Quests](/wiki/Quests "Quests").

## Boss

**Bosses** are [unique](/wiki/Rarity#Unique "Rarity") monsters typically encountered in **boss arenas**. Boss arenas are usually preceded by [checkpoints](/wiki/Checkpoint "Checkpoint"). [Dying](/wiki/Dying "Dying") against a boss will reset the encounter.

### Mechanics

Unblockable attacks

Many bosses are capable of using deadly attacks that ignore [block](/wiki/Block "Block") and [evasion](/wiki/Evasion "Evasion"), indicated by the boss flashing red and giving a sound cue before unleashing the attack.

Anti-burst damage

Bosses take less damage when they first spawn in. This damage reduction gradually tapers away over time, and tapers off faster while the boss is moving. Bosses which cannot or barely move have a shorter damage reduction period.
