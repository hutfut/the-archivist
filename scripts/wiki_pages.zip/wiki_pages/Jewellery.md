# Jewellery

**Jewellery** are a category of [equipment](/wiki/Equipment "Equipment") that are worn to give a variety of different bonuses.

* [Amulets](/wiki/Amulet "Amulet")
* [Rings](/wiki/Ring "Ring")
* [Belts](/wiki/Belt "Belt")
