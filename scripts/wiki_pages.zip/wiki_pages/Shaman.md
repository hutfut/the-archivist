# Shaman

Shaman

[Druid](/wiki/Druid "Druid")

|  |  |
| --- | --- |
|  | **Wraeclast has suffered for too long. You are vengeance incarnate.** |

Official artwork of the Shaman.

**Shaman** is an [Ascendancy class](/wiki/Ascendancy_class "Ascendancy class") for the [Druid](/wiki/Druid "Druid").

## Overview

The Shaman unleashes the force of nature upon his foes. [Druidic Champion](/wiki/Druidic_Champion "Druidic Champion") causes his [rage](/wiki/Rage "Rage") to benefit spellcasting power, and [Furious Wellspring](/wiki/Furious_Wellspring "Furious Wellspring") lets him passively regenerate rage at the cost of adding a rage cost to his skills. The Shaman gains access to passives that grant [Adaptation](/wiki/Adaptation/edit?redlink=1 "Adaptation (page does not exist)") to help defend him against elemental damage that was previously dealt to him. With [Turning of the Season](/wiki/Turning_of_the_Season/edit?redlink=1 "Turning of the Season (page does not exist)"), the Shaman gains improved elemental damage and [exposure](/wiki/Exposure "Exposure") effect, and [Bringer of the Apocalypse](/wiki/Bringer_of_the_Apocalypse "Bringer of the Apocalypse") lets the Shaman unleash an elemental [Apocalypse](/wiki/Apocalypse "Apocalypse") onto the battlefield after dealing enough elemental damage. [Sacred Flow](/wiki/Sacred_Flow "Sacred Flow") grants additional [spirit](/wiki/Spirit "Spirit") for each empty [charm](/wiki/Charm "Charm") slot, and [Wisdom of the Maji](/wiki/Wisdom_of_the_Maji "Wisdom of the Maji") unlocks hidden powers within in [Runes](/wiki/Rune "Rune") and [Idols](/wiki/Idol "Idol").

## Passive skills

### Minor skills

This class has the following minor passive skills:

| Name | Stats |
| --- | --- |
| [Defences](/wiki/Defences "Defences") | 10% increased [Defences](/wiki/Defences "Defences") [[1]](/wiki/Passive_Skill:AscendancyDruid2Small8 "Passive Skill:AscendancyDruid2Small8") |
| [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") | 12% increased [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") [[1]](/wiki/Passive_Skill:AscendancyDruid2Small1 "Passive Skill:AscendancyDruid2Small1") [[2]](/wiki/Passive_Skill:AscendancyDruid2Small2 "Passive Skill:AscendancyDruid2Small2") |
| [Elemental Resistances](/wiki/Elemental_Resistances "Elemental Resistances") | +3% to all [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") [[1]](/wiki/Passive_Skill:AscendancyDruid2Small4~ "Passive Skill:AscendancyDruid2Small4~") [[2]](/wiki/Passive_Skill:AscendancyDruid2Small5 "Passive Skill:AscendancyDruid2Small5") |
| [Flask Recovery](/wiki/Flask_Recovery/edit?redlink=1 "Flask Recovery (page does not exist)") | 12% increased Life and Mana Recovery from [Flasks](/wiki/Flask "Flask") [[1]](/wiki/Passive_Skill:AscendancyDruid2Small7 "Passive Skill:AscendancyDruid2Small7") |
| [Maximum Rage](/wiki/Maximum_Rage/edit?redlink=1 "Maximum Rage (page does not exist)") | +3 to Maximum [Rage](/wiki/Rage "Rage") [[1]](/wiki/Passive_Skill:AscendancyDruid2Small3 "Passive Skill:AscendancyDruid2Small3") [[2]](/wiki/Passive_Skill:AscendancyDruid2Small6 "Passive Skill:AscendancyDruid2Small6") |

### Notable skills

This class has the following notable passive skills:

| Skill | Modifiers | Prerequisite | Preceding Passive |
| --- | --- | --- | --- |
| [Druidic Champion](/wiki/Druidic_Champion "Druidic Champion") | Every 2 [Rage](/wiki/Rage "Rage") also grants 1% more [Spell](/wiki/Spell "Spell") damage | — | Maximum Rage |
| [Furious Wellspring](/wiki/Furious_Wellspring "Furious Wellspring") | Regenerate 6% of your maximum [Rage](/wiki/Rage "Rage") per second Increases and Reductions to Mana Regeneration Rate also apply to [Rage](/wiki/Rage "Rage") Regeneration Rate Skills have +5 to [Rage](/wiki/Rage "Rage") cost +7 to Maximum [Rage](/wiki/Rage "Rage") No Inherent loss of [Rage](/wiki/Rage "Rage") | [Druidic Champion](/wiki/Druidic_Champion "Druidic Champion") | Maximum Rage |
| [Reactive Growth](/wiki/Reactive_Growth "Reactive Growth") | [Adapt](/wiki/Adaptation/edit?redlink=1 "Adaptation (page does not exist)") to the highest [Elemental Damage Type](/wiki/Elemental_damage "Elemental damage") of each [Hit](/wiki/Hit "Hit") you take 10% less Damage taken of each [Elemental Damage Type](/wiki/Elemental_damage "Elemental damage") per matching [Adaptation](/wiki/Adaptation/edit?redlink=1 "Adaptation (page does not exist)") 10% less [Elemental Damage](/wiki/Elemental_Damage "Elemental Damage") taken | — | Elemental Resistances |
| [Avatar of Evolution](/wiki/Avatar_of_Evolution "Avatar of Evolution") | [Adaptations](/wiki/Adaptation/edit?redlink=1 "Adaptation (page does not exist)") have a duration of 5 seconds 5% of [Physical](/wiki/Physical "Physical") Damage taken as [Lightning](/wiki/Lightning "Lightning") Damage 5% of [Physical](/wiki/Physical "Physical") Damage taken as [Cold](/wiki/Cold "Cold") Damage 5% of [Physical](/wiki/Physical "Physical") Damage taken as [Fire](/wiki/Fire "Fire") Damage Double [Adaptation](/wiki/Adaptation/edit?redlink=1 "Adaptation (page does not exist)") Effect | [Reactive Growth](/wiki/Reactive_Growth "Reactive Growth") | Elemental Resistances |
| [Turning of the Seasons](/wiki/Turning_of_the_Seasons "Turning of the Seasons") | Enemies in your [Presence](/wiki/Presence "Presence") have [Exposure](/wiki/Exposure "Exposure") [Gain](/wiki/Gain "Gain") 10% of Damage as Extra Damage of a random [Element](/wiki/Elemental_damage "Elemental damage") | — | Elemental Damage |
| [Bringer of the Apocalypse](/wiki/Bringer_of_the_Apocalypse "Bringer of the Apocalypse") | Grants Skill: [Apocalypse](/wiki/Apocalypse "Apocalypse") | [Turning of the Seasons](/wiki/Turning_of_the_Seasons "Turning of the Seasons") | Elemental Damage |
| [Sacred Flow](/wiki/Sacred_Flow "Sacred Flow") | +40 to [Spirit](/wiki/Spirit "Spirit") for each of your empty [Charm](/wiki/Charm "Charm") slots | — | Flask Recovery |
| [Wisdom of the Maji](/wiki/Wisdom_of_the_Maji "Wisdom of the Maji") | Gain the benefits of [Bonded](/wiki/Bonded_Modifiers "Bonded Modifiers") modifiers on [Runes](/wiki/Rune "Rune") and [Idols](/wiki/Idol "Idol") | — | Defenses |
