# Ritualist

Ritualist

[Huntress](/wiki/Huntress "Huntress")

|  |  |
| --- | --- |
|  | **Corruption cost you your home, but taught you so much more...** |

Official artwork of the Ritualist.

**Ritualist** is an [Ascendancy class](/wiki/Ascendancy_class "Ascendancy class") for the [Huntress](/wiki/Huntress "Huntress").

## Overview

The Ritualist has adopted the darker arts of the Azmeri. With [Corrupted Lifeforce](/wiki/Corrupted_Lifeforce "Corrupted Lifeforce"), she afflicts enemies with [Blood Boils](/wiki/Blood_Boil "Blood Boil") that spread [Corrupted Blood](/wiki/Corrupted_Blood "Corrupted Blood") on the victim's death and deals more damage against afflicted targets. With [Wildwood Persistance](/wiki/Wildwood_Persistance "Wildwood Persistance"), she can rapidly heal herself back from the brink. She can perform [Ritual Sacrifice](/wiki/Ritual_Sacrifice "Ritual Sacrifice") on slain monsters to steal their modifiers, or offer her own blood to gain a random monster modifier. The Ritualist can also specialize in items, enhancing her [charms](/wiki/Charm "Charm") with [Intricate Sigils](/wiki/Intricate_Sigils "Intricate Sigils") and [Mind Phylacteries](/wiki/Mind_Phylacteries "Mind Phylacteries"), enhancing the effects of jewelry with [Mystic Attunement](/wiki/Mystic_Attunement "Mystic Attunement"), and even gain a third ring slot with [Unfurled Finger](/wiki/Unfurled_Finger "Unfurled Finger").

## Passive skills

### Minor skills

This class has the following minor passive skills:

| Name | Stats |
| --- | --- |
| [Attributes](/wiki/Attributes_(ascendancy_passive_skill) "Attributes (ascendancy passive skill)") | 3% increased [Attributes](/wiki/Attributes "Attributes") [[1]](/wiki/Passive_Skill:AscendancyHuntress3Small2 "Passive Skill:AscendancyHuntress3Small2") |
| [Charm Charges](/wiki/Charm_Charges/edit?redlink=1 "Charm Charges (page does not exist)") | 15% increased [Charm](/wiki/Charm "Charm") Charges gained [[1]](/wiki/Passive_Skill:AscendancyHuntress3Small3 "Passive Skill:AscendancyHuntress3Small3") [[2]](/wiki/Passive_Skill:AscendancyHuntress3Small4 "Passive Skill:AscendancyHuntress3Small4") |
| [Life Recovery Rate](/wiki/Life_Recovery_Rate/edit?redlink=1 "Life Recovery Rate (page does not exist)") | 10% increased Life Recovery rate [[1]](/wiki/Passive_Skill:AscendancyHuntress3Small5 "Passive Skill:AscendancyHuntress3Small5") |
| [Movement Speed](/wiki/Movement_Speed "Movement Speed") | 3% increased Movement Speed [[1]](/wiki/Passive_Skill:AscendancyHuntress3Small7 "Passive Skill:AscendancyHuntress3Small7") [[2]](/wiki/Passive_Skill:AscendancyHuntress3Small8 "Passive Skill:AscendancyHuntress3Small8") |
| [Physical Damage](/wiki/Physical_Damage "Physical Damage") | 15% increased [Physical](/wiki/Physical "Physical") Damage [[1]](/wiki/Passive_Skill:AscendancyHuntress3Small6 "Passive Skill:AscendancyHuntress3Small6") |
| [Reduced Mana](/wiki/Reduced_Mana/edit?redlink=1 "Reduced Mana (page does not exist)") | 30% reduced maximum Mana [[1]](/wiki/Passive_Skill:AscendancyHuntress3Small1~1 "Passive Skill:AscendancyHuntress3Small1~1") |
| [Reduced Resistances](/wiki/Reduced_Resistances/edit?redlink=1 "Reduced Resistances (page does not exist)") | -20% to all [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") [[1]](/wiki/Passive_Skill:AscendancyHuntress3Small1~3 "Passive Skill:AscendancyHuntress3Small1~3") |
| [Reduced Spirit](/wiki/Reduced_Spirit/edit?redlink=1 "Reduced Spirit (page does not exist)") | 25% reduced [Spirit](/wiki/Spirit "Spirit") [[1]](/wiki/Passive_Skill:AscendancyHuntress3Small1~2~ "Passive Skill:AscendancyHuntress3Small1~2~") |

### Notable skills

This class has the following notable passive skills:

| Skill | Modifiers | Prerequisite | Preceding Passive |
| --- | --- | --- | --- |
| [Corrupted Lifeforce](/wiki/Corrupted_Lifeforce "Corrupted Lifeforce") | Grants Skill: [Blood Boil](/wiki/Blood_Boil "Blood Boil") 15% more Damage against Enemies affected by Blood Boils | — | Physical Damage |
| [As the Whispers Demand](/wiki/As_the_Whispers_Demand "As the Whispers Demand") | Grants Skill: [Ritual Sacrifice](/wiki/Ritual_Sacrifice "Ritual Sacrifice") Ritual Sacrifice can be used on yourself to remove 20% of maximum Life and grant a random [Monster Modifier](/wiki/Monster_Modifier "Monster Modifier") A maximum of one Modifer can be granted this way | — | Movement Speed |
| [Intricate Sigils](/wiki/Intricate_Sigils "Intricate Sigils") | 20% more [Charm](/wiki/Charm "Charm") Charges gained +1 [Charm](/wiki/Charm "Charm") Slot | — | Charm Charges |
| [Mind Phylacteries](/wiki/Mind_Phylacteries "Mind Phylacteries") | Can instead consume 25% of maximum Mana to trigger [Charms](/wiki/Charm "Charm") with insufficient charges | [Intricate Sigils](/wiki/Intricate_Sigils "Intricate Sigils") | Charm Charges |
| [Wildwood Persistence](/wiki/Wildwood_Persistence "Wildwood Persistence") | 10% increased Life Recovery rate per 5% missing Unreserved Life | — | Life Recovery Rate |
| [Unfurled Finger](/wiki/Unfurled_Finger "Unfurled Finger") | +1 Ring Slot | — | Reduced Resistances Reduced Spirit Reduced Mana |
| [Mystic Attunement](/wiki/Mystic_Attunement "Mystic Attunement") | 25% increased bonuses gained from Equipped Rings and Amulets | [Unfurled Finger](/wiki/Unfurled_Finger "Unfurled Finger") | Attributes |
