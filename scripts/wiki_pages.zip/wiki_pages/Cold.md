# Cold

Cold Damage

Tooltip

Cold damage is one of the five [Damage Types](/wiki/Damage_type "Damage type"). It is reduced by [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance"). Cold hits apply [Chill](/wiki/Chill "Chill") and build up [Freeze](/wiki/Freeze "Freeze"), but cannot build up [Heavy Stun](/wiki/Heavy_Stun "Heavy Stun").

**Cold** [damage](/wiki/Damage "Damage") is one of the five [damage types](/wiki/Damage_type "Damage type"), and one of the three types of [elemental damage](/wiki/Elemental_damage "Elemental damage"). It can be mitigated by cold [resistance](/wiki/Resistance "Resistance"). Cold damage can inflict [chill](/wiki/Chill "Chill") and inflict [freeze](/wiki/Freeze "Freeze") buildup.

Cold [damage over time](/wiki/Damage_over_time "Damage over time") is usually inflicted by ground effects such as vortexes.

## Mechanics

Cold damage modifiers usually deals lower average damage compared to [fire](/wiki/Fire "Fire") damage, but typically has a higher [critical hit](/wiki/Critical_hit "Critical hit") chance, and can inherently inflict [chill](/wiki/Chill "Chill") and [freeze](/wiki/Freeze "Freeze") buildup, two [slow](/wiki/Slow "Slow") and [crowd control](/wiki/Crowd_control "Crowd control") effects.

## Gems

A list of [gems](/wiki/Gem "Gem") with the [gem tag](/wiki/Gem_tag "Gem tag"): [Category:Cold (gem tag)](/wiki/Category:Cold_(gem_tag) "Category:Cold (gem tag)")

### Skill gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Escape Shot](/wiki/Escape_Shot "Escape Shot") | *1* |  |  |  |
| [Frost Bomb](/wiki/Frost_Bomb "Frost Bomb") | *1* |  |  |  |
| [Ice Nova](/wiki/Ice_Nova "Ice Nova") | *1* |  |  |  |
| [Frozen Locus](/wiki/Frozen_Locus "Frozen Locus") | *1* |  |  |  |
| [Glacial Cascade](/wiki/Glacial_Cascade "Glacial Cascade") | *1* |  |  |  |
| [Lunar Assault](/wiki/Lunar_Assault "Lunar Assault") | *1* |  |  |  |
| [Permafrost Bolts](/wiki/Permafrost_Bolts "Permafrost Bolts") | *1* |  |  |  |
| [Fangs of Frost](/wiki/Fangs_of_Frost "Fangs of Frost") | *3* |  |  |  |
| [Freezing Salvo](/wiki/Freezing_Salvo "Freezing Salvo") | *3* |  |  |  |
| [Snipe](/wiki/Snipe "Snipe") | *3* |  |  |  |
| [Frost Darts](/wiki/Frost_Darts "Frost Darts") | *3* |  |  |  |
| [Ice-Tipped Arrows](/wiki/Ice-Tipped_Arrows "Ice-Tipped Arrows") | *5* |  |  |  |
| [Frostbolt](/wiki/Frostbolt "Frostbolt") | *5* |  |  |  |
| [Skeletal Frost Mage](/wiki/Skeletal_Frost_Mage "Skeletal Frost Mage") | *5* |  |  |  |
| [Snap](/wiki/Snap "Snap") | *5* |  |  |  |
| [Arctic Howl](/wiki/Arctic_Howl "Arctic Howl") | *5* |  |  |  |
| [Ice Shards](/wiki/Ice_Shards "Ice Shards") | *5* |  |  |  |
| [Ice Strike](/wiki/Ice_Strike "Ice Strike") | *5* |  |  |  |
| [Glacial Lance](/wiki/Glacial_Lance "Glacial Lance") | *7* |  |  |  |
| [Elemental Weakness](/wiki/Elemental_Weakness "Elemental Weakness") | *7* |  |  |  |
| [Freezing Mark](/wiki/Freezing_Mark "Freezing Mark") | *7* |  |  |  |
| [Glacial Bolt](/wiki/Glacial_Bolt "Glacial Bolt") | *7* |  |  |  |
| [Wave of Frost](/wiki/Wave_of_Frost "Wave of Frost") | *7* |  |  |  |
| [Ice Shot](/wiki/Ice_Shot "Ice Shot") | *9* |  |  |  |
| [Frost Wall](/wiki/Frost_Wall "Frost Wall") | *9* |  |  |  |
| [Elemental Sundering](/wiki/Elemental_Sundering "Elemental Sundering") | *11* |  |  |  |
| [Comet](/wiki/Comet "Comet") | *11* |  |  |  |
| [Hailstorm Rounds](/wiki/Hailstorm_Rounds "Hailstorm Rounds") | *11* |  |  |  |
| [Shattering Palm](/wiki/Shattering_Palm "Shattering Palm") | *11* |  |  |  |
| [Eye of Winter](/wiki/Eye_of_Winter "Eye of Winter") | *13* |  |  |  |
| [Lunar Blessing](/wiki/Lunar_Blessing "Lunar Blessing") | *13* |  |  |  |

### Spirit gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Arctic Armour](/wiki/Arctic_Armour "Arctic Armour") | *4* |  |  |  |
| [Herald of Ice](/wiki/Herald_of_Ice "Herald of Ice") | *4* |  |  |  |
| [Siphon Elements](/wiki/Siphon_Elements "Siphon Elements") | *8* |  |  |  |
| [Elemental Invocation](/wiki/Elemental_Invocation "Elemental Invocation") | *8* |  |  |  |
| [Shard Scavenger](/wiki/Shard_Scavenger "Shard Scavenger") | *8* |  |  |  |
| [Cast on Elemental Ailment](/wiki/Cast_on_Elemental_Ailment "Cast on Elemental Ailment") | *14* |  |  |  |
| [Elemental Conflux](/wiki/Elemental_Conflux "Elemental Conflux") | *14* |  |  |  |
| [Trinity](/wiki/Trinity "Trinity") | *14* |  |  |  |

### Support gems

| Gem | Tier |  |  |  |
| --- | --- | --- | --- | --- |
| [Tul's Stillness](/wiki/Tul%27s_Stillness "Tul's Stillness") | *0* |  |  |  |
| [Bhatair's Vengeance](/wiki/Bhatair%27s_Vengeance "Bhatair's Vengeance") | *0* |  |  |  |
| [Hayoxi's Fulmination](/wiki/Hayoxi%27s_Fulmination "Hayoxi's Fulmination") | *0* |  |  |  |
| [Cold Attunement](/wiki/Cold_Attunement "Cold Attunement") | *1* |  |  |  |
| [Creeping Chill](/wiki/Creeping_Chill "Creeping Chill") | *1* |  |  |  |
| [Deep Freeze](/wiki/Deep_Freeze "Deep Freeze") | *1* |  |  |  |
| [Ice Bite I](/wiki/Ice_Bite_I "Ice Bite I") | *1* |  |  |  |
| [Frozen Spite](/wiki/Frozen_Spite "Frozen Spite") | *2* |  |  |  |
| [Cold Penetration](/wiki/Cold_Penetration "Cold Penetration") | *2* |  |  |  |
| [Embitter](/wiki/Embitter "Embitter") | *2* |  |  |  |
| [Freeze](/wiki/Freeze_(support_gem) "Freeze (support gem)") | *2* |  |  |  |
| [Frost Nexus](/wiki/Frost_Nexus "Frost Nexus") | *2* |  |  |  |
| [Biting Frost I](/wiki/Biting_Frost_I "Biting Frost I") | *3* |  |  |  |
| [Brittle Armour](/wiki/Brittle_Armour "Brittle Armour") | *3* |  |  |  |
| [Elemental Discharge](/wiki/Elemental_Discharge "Elemental Discharge") | *3* |  |  |  |
| [Frostfire](/wiki/Frostfire "Frostfire") | *3* |  |  |  |
| [Ice Bite II](/wiki/Ice_Bite_II "Ice Bite II") | *3* |  |  |  |
| [Verglas](/wiki/Verglas "Verglas") | *3* |  |  |  |
| [Cold Exposure](/wiki/Cold_Exposure "Cold Exposure") | *4* |  |  |  |
| [Biting Frost II](/wiki/Biting_Frost_II "Biting Frost II") | *5* |  |  |  |
| [Catalysing Elements](/wiki/Catalysing_Elements "Catalysing Elements") | *5* |  |  |  |
| [Cold Mastery](/wiki/Cold_Mastery "Cold Mastery") | *5* |  |  |  |

## Base items

The following base items are related to cold damage:

| Item |  | Stats |
| --- | --- | --- |
| [Icicle Flail](/wiki/Icicle_Flail "Icicle Flail") | 47 | 100% of this Weapon's base Physical Damage Converted to Cold Damage (Hidden) |

## Unique items

The following unique items are related to cold damage:
No results found

## Passive skills

### Base passive skills

The following [passive skills](/wiki/Passive_skill "Passive skill") are related to cold damage:
No results found for the given query.

### Keystone passive skills

The following [keystone](/wiki/Keystone "Keystone") passive skills are related to cold damage:
No results found for the given query.

### Ascendancy passive skills

The following [Ascendancy passive skills](/wiki/Ascendancy_passive_skill "Ascendancy passive skill") are related to cold damage:
No results found for the given query.
