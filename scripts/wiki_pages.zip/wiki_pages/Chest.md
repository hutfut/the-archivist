# Chest

A **Chest** is a loot container which can be found in many areas. Clicking on a chest will open it, dropping any [items](/wiki/Item "Item") or [gold](/wiki/Gold "Gold") onto the ground.

Chests can come in a higher [rarity](/wiki/Rarity "Rarity"), improving the chances of better loot. The names will be coloured for normal, magic, or rare chests. Higher rarity chests have more item quantity and rarity and drop at least one item of the chest's rarity or higher.

Some chests at a [Point of interest](/wiki/Point_of_interest "Point of interest") can have specific loot drops. In this case, the loot will drop for each [party](/wiki/Party "Party") member present, but only happen the first time this chest is opened for a given [character](/wiki/Character "Character").

The loot from chests is not affected by rarity modifiers from your gear, though they are affected by chest-specific modifiers. Chests innately gain 50% more item quantity and rarity starting from [Act 4](/wiki/Act_4 "Act 4"), and 100% more in [endgame](/wiki/Endgame "Endgame").
