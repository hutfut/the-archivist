# Rarity

✍️This article is a [stub](/wiki/Category:Stubs "Category:Stubs"). Please help [improve the article](https://www.poe2wiki.net/wiki/Rarity/edit) by expanding it.

Rarity

Tooltip

Item or monster rarity can be Normal (grey), Magic (blue), Rare (yellow) or Unique (brown). As a general rule, monsters increase in difficulty depending on their Rarity.

All monsters, strongboxes and most items can have one of four different **rarities**. The common rarity is normal, followed by magic, rare and unique. Some items such as [currency](/wiki/Currency "Currency") do not have rarity; however, they do have internal measures of "valuable"-ness or "rarity" through weights which affects their drop rates.

Sources of #% increased Item Rarity and #% increased Rarity of Items found (also known as **IIR**) affect both the rarity of items dropped, as well improving the random modifiers that can roll when an item is identified through "unidentified tier" items. This effect is known as the "item rarity tier system" and is explained further below. Some sources of IIR have diminishing returns. Different sources of IIR (e.g. items vs area modifiers vs monster IIR multipliers) are multiplicative with each other. The combined effect of IIR, IIQ (increased item quantity), and [party](/wiki/Party "Party") bonuses is colloquially referred to as **magic find**/**MF**.

## Item rarity

Item Rarity

Tooltip

Items can be Normal (grey), Magic (blue), Rare (yellow) or Unique (brown). Item Classes which do not have these rarities, such as Currency, have individual rarity for each item.
Magic items can have 2 Modifiers; a Prefix and a Suffix.
Rare items can have up to 6 Modifiers; 3 Prefixes and 3 Suffixes.
More powerful and dangerous enemies are more likely to drop rarer Items.

Most craftable items rolls with a random rarity - normal items being the most common and unique items the least common.

Magic, rare and unique items found on the ground are **unidentified** and you must use [Scroll of Wisdom](/wiki/Scroll_of_Wisdom "Scroll of Wisdom") to discover their properties.

### Rarities

#### Normal

Normal items (also called base items) are the "default" state of items without any [explicit modifiers](/wiki/Explicit_modifier "Explicit modifier")/[affixes](/wiki/Affixes "Affixes"). Some specific base types have [implicit modifiers](/wiki/Implicit_modifier "Implicit modifier").

A normal item can be upgraded into a magic item using an [Orb of Transmutation](/wiki/Orb_of_Transmutation "Orb of Transmutation"), guaranteeing one affix, or a rare item using an [Orb of Alchemy](/wiki/Orb_of_Alchemy "Orb of Alchemy") guaranteeing four affixes - 2 prefixes and 2 suffixes. An [Orb of Chance](/wiki/Orb_of_Chance "Orb of Chance") can upgrade a normal item into a unique if a unique of that base type exists and the item being chanced is at least the required item level.

#### Magic

Magic are the upgraded versions of normal items with magical properties given by [affixes](/wiki/Affixes "Affixes"), base item is the same as in normal rarity, but now you can have up to one [prefix](/wiki/Prefix "Prefix") and one [suffix](/wiki/Suffix "Suffix").

Upgrading a normal item with [Orb of Transmutation](/wiki/Orb_of_Transmutation "Orb of Transmutation") will give it only one affix, either prefix or suffix, [Orb of Augmentation](/wiki/Orb_of_Augmentation "Orb of Augmentation") is needed to add missing second property from the item.

Unlike Path of Exile 1 you can't reroll those affixes with another orb but you can remove one random modifier using [Orb of Annulment](/wiki/Orb_of_Annulment "Orb of Annulment") or by using a [Chaos Orb](/wiki/Chaos_Orb "Chaos Orb") which also remove one random modifier, but it replaces it with another random affix.

A magic item can be upgraded into a rare item using a [Regal Orb](/wiki/Regal_Orb "Regal Orb"). It will retain its current affixes and one new affix will be added making it an item with three affixes rather than four like in case of using an [Orb of Alchemy](/wiki/Orb_of_Alchemy "Orb of Alchemy") on normal item.

#### Rare

Rare items can have up to six [affixes](/wiki/Affixes "Affixes"), having maximum three [prefixes](/wiki/Prefixes "Prefixes") and three [suffixes](/wiki/Suffixes "Suffixes").

If item have less than six affixes, it can gain an additional mod with an [Exalted Orb](/wiki/Exalted_Orb "Exalted Orb") up to the maximum number of affixes on item.

As in magic items, there is a way to remove one affix by using [Orb of Annulment](/wiki/Orb_of_Annulment "Orb of Annulment"), or remove one random modifier and replacing it with another one by using a [Chaos Orb](/wiki/Chaos_Orb "Chaos Orb").

Rare items are given a [randomly generated name](/wiki/Rare_Item_Name_Index/edit?redlink=1 "Rare Item Name Index (page does not exist)").

Unidentifed rare items generate with 4, 5, or 6 modifiers with a ratio of 8:3:1 respectively.

[Flasks](/wiki/Flask "Flask") and [Charms](/wiki/Charm "Charm") cannot be of rare rarity.

#### Unique

Main article: [Unique item](/wiki/Unique_item "Unique item")

Unique items have the same base properties as normal item of the same type, but have specific unique name and artwork, as well as their own set lists of modifiers instead of random affixes. While overall it is better to have the highest rarity of item (e.g. rare items are always more powerful than magic items), this is not the case with unique items; most of the time they provide different and specific modifiers that can't be found on other items.

Items of Unique rarity often contain a set of mods which provide build-defining effects and/or quality of life to game play.

Some unique items are [drop-restricted](/wiki/Drop-restricted_item "Drop-restricted item"); these items can only be obtained from specific sources or through specific methods, and cannot normally obtained or be upgraded into using an [Orb of Chance](/wiki/Orb_of_Chance "Orb of Chance"). They are also excluded from pools of rewards containig random unique items.

## Monster rarity

Regular monsters can spawn as normal, magic, or rare. Typically most monsters in a pack will be normal; however, the entire pack can be magic instead. Only one or a few monsters in a pack will appear as rare, and will almost always be a pack leader monster type if applicable.

By default, magic and rare monsters can roll up to 2 or 4 [monster modifiers](/wiki/Monster_modifier "Monster modifier"). The specific pool of monster modifiers it can roll are dependent on the specific monster type; certain combinations of monster types and monster modifiers are not possible for balance purposes.

The rarity and monster modifier(s) provide inherent bonuses to its life, damage, item rarity, and item quantity.

Unique monsters are special, and almost always categorized as a type of [boss](/wiki/Boss "Boss"), found in designated arenas. Unique monsters typically cannot have monster modifiers, though they may have inherent modifiers such as Cannot be Slowed. They may have a unique varied pool of skills. Unique monsters have significantly increased life, damage, item rarity, and item quantity bonuses. They also have certain restrictions, such as disabling the ability to create a [portal](/wiki/Portal "Portal") or preventing changing your character's [equipment](/wiki/Equipment "Equipment").

## Chest/strongbox rarity

[Chests](/wiki/Chest "Chest") and [strongboxes](/wiki/Strongbox "Strongbox") typically have rarities. These rarities do affect the items found in the chest or strongbox. Strongboxes can be crafted with currency; chests typically cannot. Items from both are affected by area IIR multipliers, but not by player IIR multipliers.

## Item rarity multplier mechanics

Item rarity multipliers come in different "buckets" which are multiplicative with each other:

"Buckets" of item rarity multipliers

| "Bucket" | Sources | Diminishing returns? |
| --- | --- | --- |
| Player IIR | [Item](/wiki/Item "Item") modifiers [Buffs](/wiki/Buff "Buff") | Yes |
| Area IIR | [Waystone](/wiki/Waystone "Waystone") modifiers [Tablet](/wiki/Tablet "Tablet") modifiers Coalesced Corruption [modifiers](/wiki/Coalesced_Corruption#List_of_map_corruption_modifiers "Coalesced Corruption") [Cleansed map](/wiki/Cleansed_map "Cleansed map") [modifiers](/wiki/Cleansed_map#List_of_cleansed_map_modifiers "Cleansed map") [Diluted Liquid Greed](/wiki/Diluted_Liquid_Greed "Diluted Liquid Greed") | No |
| Monster IIR | Inherent base multipliers Inherent multipliers from monster rarity [Azmerian wisps](/wiki/Azmerian_wisp "Azmerian wisp") | Unknown (likely no) |
| Deliriousness | [Delirium](/wiki/Delirium "Delirium") mirrors [Instilled maps](/wiki/Distilled_emotion "Distilled emotion") [Simulacrum](/wiki/Simulacrum "Simulacrum") | Unknown |

According to player testing[[1]](#cite_note-1) as well as information shared privately from Path of Exile 2 developers to Kripparrian[[2]](#cite_note-2), player IIR anecdotally has the most noticable benefits between 100-150% with significant diminishing returns and worse opportunity cost after 150%. Area IIR is not affected by diminishing returns at all.

[Minions](/wiki/Minion "Minion") and [companions](/wiki/Companion "Companion") use their owner's player IIR values when they kill enemies. They will not benefit from any IIR granted to them directly (e.g. via [Necromantic Talisman](/wiki/Necromantic_Talisman "Necromantic Talisman")). Other [allies](/wiki/Allies "Allies") (e.g. [NPCs](/wiki/NPC "NPC")) and other players and their minions in a [party](/wiki/Party "Party") use their own player IIR values.

It is possible to achieve -100% IIR (0% item rarity) with 2x [Ventor's Gamble](/wiki/Ventor%27s_Gamble "Ventor's Gamble") and [Ingenuity](/wiki/Ingenuity "Ingenuity"). Although it should theoretically result in random item drops always dropping as normal rarity, it appears to be possible to still drop magic items[[3]](#cite_note-3). It will not affect guaranteed magic or rare item drops from hidden modifiers on certain [bosses](/wiki/Boss "Boss") or items from [chests](/wiki/Chest "Chest").

### Item rarity tier system

Modifiers and stats that influence the rarity of dropped items function using a skewed "10-tier" rarity system. When an item drops, one of these tiers is selected; the item rarity stat increases the chances to select a higher tier.

The "% Increased Rarity of Items Found" modifier generally increases the likelihood of finding higher-rarity items (e.g., magic, rare, unique). However, its impact on currency item drops varies by game mechanics.

How the 10-tier system works is as follows[[4]](#cite_note-4):

**Rarity tier 0**:

* No apparent changes to drops

**Rarity tier 1-5**:

* Increases the chance for an item that can have rarity to drop as magic, rare, or unique.
  + This conversely reduces the chance for dropped items to be converted to [gold](/wiki/Gold "Gold")[[5]](#cite_note-5)
* Decreases the chance for a unique item to be common tier; increases the chance for a unique item to be uncommon, rare, or mythic tier.
* Increases the chance to upgrade [currency](/wiki/Currency "Currency") to "Rare" currency (e.g. [Exalted Orb](/wiki/Exalted_Orb "Exalted Orb"), [Orb of Alchemy](/wiki/Orb_of_Alchemy "Orb of Alchemy"), [Regal Orb](/wiki/Regal_Orb "Regal Orb"), etc.)
* Increases the chance to not drop [base types](/wiki/Base_type/edit?redlink=1 "Base type (page does not exist)") that are significantly lower level requirement than the area's drop level.
* Does not affect the outcomes of modifiers on unidentified items.

**Rarity tier 6-9** / Unidentified (Tier 2-5):

* Implements the unidentified modifier tier system (e.g. Unidentified (Tier 5)).
* Unidentified tiers only begin appearing at certain [drop level](/wiki/Drop_level "Drop level")/[item level](/wiki/Item_level "Item level") thresholds.
  + Unidentified tiers only affect items when they are being identified. It does not affect modifiers added after the item is identified, such as through [crafting](/wiki/Crafting "Crafting").
* Unidentified modifier tiers function differently for magic and rare items:
  + **Magic**: Each Unid tier culls a certain percentage of tiers for each modifier type separately. At least one tier of each modifier can always roll. For example, culling 50% of tiers for a mod with 3 eligible tiers prevents the lowest tier from rolling.
  + **Rare**: Each Unid tier culls all modifiers requiring an item level below a certain value. The modifier's tier itself is not relevant.[[6]](#cite_note-6)

### Unidentified tiers

**This section needs to be updated**.

**Reason:** New values for rare unid tier ilvl culling

Please [update this article](https://www.poe2wiki.net/wiki/Rarity/edit) to reflect newly available information.

Unidentified tiers

| Unid Tier | Minimum item level | Magic mod tier culling | Rare mod ilvl culling |
| --- | --- | --- | --- |
| Unid Tier 2 | ilvl 20 | 50% | < ilvl 11 |
| Unid Tier 3 | ilvl 34 | < 68% | < ilvl 23 |
| Unid Tier 4 | ilvl 52 | #% | < ilvl 35 |
| Unid Tier 5 | ilvl 65 | #% | < ilvl 48 |

Tier culling will not remove the highest possible tier of a modifier type if it would be excluded entirely from being able to roll. In other words, at least one tier of each mod will always be eligible to roll, respecting item level.

## Sources of increased item rarity

### Base items

| Item | Item class |  | Buff effects | Stats | IIR |
| --- | --- | --- | --- | --- | --- |
| [Gold Amulet](/wiki/Gold_Amulet "Gold Amulet") | *[Amulet](/wiki/Amulet "Amulet")* | 35 | — | (12-20)% increased Rarity of Items found | (12-20)% |
| [Gold Ring](/wiki/Gold_Ring "Gold Ring") | *[Ring](/wiki/Ring "Ring")* | 40 | — | (6-15)% increased Rarity of Items found | (6-15)% |
| [Golden Charm](/wiki/Golden_Charm "Golden Charm") | *[Charm](/wiki/Charm "Charm")* | 50 | 15% increased Rarity of Items found | Used when you Kill a [Rare](/wiki/Rare "Rare") or [Unique](/wiki/Unique "Unique") Enemy | 0% |

### Unique items

| Item | Base item |  | Stats | Additional drop restrictions | IIR |
| --- | --- | --- | --- | --- | --- |
| [Demigod's Virtue](/wiki/Demigod%27s_Virtue "Demigod's Virtue") | [Golden Visage](/wiki/Golden_Visage "Golden Visage") | 1 | 25% increased Rarity of Items found Virtuous | *Can only be obtained as an exclusive race reward for top placements in certain [events](/wiki/Event "Event").* | 25% |
| [Horns of Bynden](/wiki/Horns_of_Bynden "Horns of Bynden") | [Rusted Greathelm](/wiki/Rusted_Greathelm "Rusted Greathelm") | 1 | +20 to [Armour](/wiki/Armour "Armour") (5-15)% increased Rarity of Items found +(20-30) to [Strength](/wiki/Strength "Strength") Gain 1 [Rage](/wiki/Rage "Rage") on [Melee](/wiki/Melee "Melee") [Hit](/wiki/Hit "Hit") Every [Rage](/wiki/Rage "Rage") also grants 1% increased [Armour](/wiki/Armour "Armour") | — | (5-15)% |
| [Wings of Caelyn](/wiki/Wings_of_Caelyn "Wings of Caelyn") | [Rusted Greathelm](/wiki/Rusted_Greathelm "Rusted Greathelm") | 1 | +20 to [Armour](/wiki/Armour "Armour") (5-15)% increased Rarity of Items found +(20-30) to [Dexterity](/wiki/Dexterity "Dexterity") Gain 1 [Rage](/wiki/Rage "Rage") on [Melee](/wiki/Melee "Melee") [Hit](/wiki/Hit "Hit") Every [Rage](/wiki/Rage "Rage") also grants 1% increased [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") | — | (5-15)% |
| [Crown of the Victor](/wiki/Crown_of_the_Victor "Crown of the Victor") | [Iron Crown](/wiki/Iron_Crown "Iron Crown") | 5 | (10-15)% increased Rarity of Items found Gain 10 Life per enemy killed Gain 10 Mana per enemy killed +1 to Level of all Skills | — | (10-15)% |
| [Goldrim](/wiki/Goldrim "Goldrim") | [Felt Cap](/wiki/Felt_Cap "Felt Cap") | 10 | +(30-50) to [Evasion](/wiki/Evasion "Evasion") Rating 10% increased Rarity of Items found +(25-35)% to all [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") | — | 10% |
| [Erian's Cobble](/wiki/Erian%27s_Cobble "Erian's Cobble") | [Guarded Helm](/wiki/Guarded_Helm "Guarded Helm") | 11 | +(0-40) to [Armour](/wiki/Armour "Armour") +(0-30) to [Evasion](/wiki/Evasion "Evasion") Rating +(0-20) to maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") +(0-60) to [Accuracy](/wiki/Accuracy "Accuracy") Rating +(0-30) to maximum Life +(0-20) to maximum Mana (0-20)% increased Rarity of Items found (0-30)% increased [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance +(0-10) to [Strength](/wiki/Strength "Strength") +(0-10) to [Dexterity](/wiki/Dexterity "Dexterity") +(0-10) to [Intelligence](/wiki/Intelligence "Intelligence") +(0-10)% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") +(0-10)% to [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance") +(0-10)% to [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance") (0-6) Life Regeneration per second | — | (0-20)% |
| [Aurseize](/wiki/Aurseize "Aurseize") | [Layered Gauntlets](/wiki/Layered_Gauntlets "Layered Gauntlets") | 16 | (40-60)% increased [Armour](/wiki/Armour "Armour") and [Evasion](/wiki/Evasion "Evasion") (40-50)% increased Rarity of Items found [Lose](/wiki/Life_Loss "Life Loss") 2% of maximum Life on Kill | — | (40-50)% |
| [Crown of the Pale King](/wiki/Crown_of_the_Pale_King "Crown of the Pale King") | [Cultist Crown](/wiki/Cultist_Crown "Cultist Crown") | 16 | (50-100)% increased [Armour](/wiki/Armour "Armour") and [Energy Shield](/wiki/Energy_Shield "Energy Shield") +(40-80) to maximum Life 10% increased Rarity of Items found (10-15) to (20-25) [Physical](/wiki/Physical "Physical") [Thorns](/wiki/Thorns "Thorns") damage [Thorns](/wiki/Thorns "Thorns") can [Retaliate against all](/wiki/Retaliate_against_all_Hits/edit?redlink=1 "Retaliate against all Hits (page does not exist)") [Hits](/wiki/Hit "Hit") | — | 10% |
| [Gamblesprint](/wiki/Gamblesprint "Gamblesprint") | [Embossed Boots](/wiki/Embossed_Boots "Embossed Boots") | 16 | (100-140)% increased [Evasion](/wiki/Evasion "Evasion") Rating (10-15)% increased Rarity of Items found +(10-15) to [Dexterity](/wiki/Dexterity "Dexterity") +(15-25)% to [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance") Gain 0% to 40% increased Movement Speed at random when [Hit](/wiki/Hit "Hit"), until [Hit](/wiki/Hit "Hit") again | — | (10-15)% |
| [Visage of Ayah](/wiki/Visage_of_Ayah "Visage of Ayah") | [Beaded Circlet](/wiki/Beaded_Circlet "Beaded Circlet") | 16 | (50-80)% increased [Energy Shield](/wiki/Energy_Shield "Energy Shield") (10-15)% increased Rarity of Items found (20-30)% increased [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance +(10-20)% to [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance") [Eldritch Battery](/wiki/Eldritch_Battery "Eldritch Battery") | — | (10-15)% |
| [Thief's Torment](/wiki/Thief%27s_Torment "Thief's Torment") | [Emerald Ring](/wiki/Emerald_Ring "Emerald Ring") | 26 | +(120-160) to [Accuracy](/wiki/Accuracy "Accuracy") Rating(30-40)% increased Rarity of Items found +(10-15)% to all [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") Gain 25 Life per Enemy Hit with [Attacks](/wiki/Attack "Attack") Can't use other Rings Gain 15 Mana per Enemy Hit with [Attacks](/wiki/Attack "Attack") 50% reduced Duration of [Curses](/wiki/Curse "Curse") on you | — | (30-40)% |
| [Vigilant View](/wiki/Vigilant_View "Vigilant View") | [Emerald Ring](/wiki/Emerald_Ring "Emerald Ring") | 26 | +(120-160) to [Accuracy](/wiki/Accuracy "Accuracy") Rating+(100-150) to [Accuracy](/wiki/Accuracy "Accuracy") Rating +(100-150) to [Evasion](/wiki/Evasion "Evasion") Rating (10-20)% increased Rarity of Items found +(20-30) to [Dexterity](/wiki/Dexterity "Dexterity") Enemies have an [Accuracy](/wiki/Accuracy "Accuracy") Penalty against you based on Distance Maximum Chance to [Evade](/wiki/Evasion "Evasion") is 50% | — | (10-20)% |
| [Cornathaum](/wiki/Cornathaum "Cornathaum") | [Heavy Crown](/wiki/Heavy_Crown "Heavy Crown") | 33 | (10-20)% increased Rarity of Items found +(40-50) to [Intelligence](/wiki/Intelligence "Intelligence") 30% increased [Light Radius](/wiki/Light_Radius "Light Radius") 5% increased Experience gain | — | (10-20)% |
| [Eye of Chayula](/wiki/Eye_of_Chayula "Eye of Chayula") | [Gold Amulet](/wiki/Gold_Amulet "Gold Amulet") | 35 | (12-20)% increased Rarity of Items found(30-20)% reduced maximum Life +(10-15) to all [Attributes](/wiki/Attributes "Attributes") Cannot be [Light Stunned](/wiki/Light_Stun "Light Stun") | — | (12-20)% |
| [Gifts from Above](/wiki/Gifts_from_Above "Gifts from Above") | [Prismatic Ring](/wiki/Prismatic_Ring "Prismatic Ring") | 35 | +(7-10)% to all [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances")(20-30)% increased [Critical Hit](/wiki/Critical_Hit "Critical Hit") Chance (20-30)% increased [Light Radius](/wiki/Light_Radius "Light Radius") (20-30)% increased Rarity of Items Dropped by Enemies killed with a [Critical Hit](/wiki/Critical_Hit "Critical Hit") You have [Consecrated Ground](/wiki/Consecrated_Ground "Consecrated Ground") around you while stationary | — | 0% |
| [Serpent's Egg](/wiki/Serpent%27s_Egg "Serpent's Egg") | [Gold Amulet](/wiki/Gold_Amulet "Gold Amulet") | 35 | (12-20)% increased Rarity of Items found+(10-20) to all [Attributes](/wiki/Attributes "Attributes") +(17-23)% to [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance") (20-30)% increased Mana Regeneration Rate Gain an additional [Charge](/wiki/Charge "Charge") when you gain a [Charge](/wiki/Charge "Charge") | — | (12-20)% |
| [Greed's Embrace](/wiki/Greed%27s_Embrace "Greed's Embrace") | [Vaal Cuirass](/wiki/Vaal_Cuirass "Vaal Cuirass") | 37 | 50% increased [Strength](/wiki/Strength "Strength") Requirement 20% reduced Movement Speed (100-150)% increased [Armour](/wiki/Armour "Armour") (30-50)% increased Rarity of Items found +(20-30)% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") | — | (30-50)% |
| [Andvarius](/wiki/Andvarius "Andvarius") | [Gold Ring](/wiki/Gold_Ring "Gold Ring") | 40 | (6-15)% increased Rarity of Items found(50-70)% increased Rarity of Items found +10 to [Dexterity](/wiki/Dexterity "Dexterity") -20% to all [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") | — | (6-15)% |
| [Atziri's Disdain](/wiki/Atziri%27s_Disdain "Atziri's Disdain") | [Gold Circlet](/wiki/Gold_Circlet "Gold Circlet") | 40 | +(60-100) to maximum Mana (10-20)% increased Rarity of Items found 10% of Damage taken bypasses [Energy Shield](/wiki/Energy_Shield "Energy Shield") [Gain](/wiki/Gain "Gain") (10-15)% of maximum Life as Extra maximum [Energy Shield](/wiki/Energy_Shield "Energy Shield") | — | (10-20)% |
| [Perandus Seal](/wiki/Perandus_Seal "Perandus Seal") | [Gold Ring](/wiki/Gold_Ring "Gold Ring") | 40 | (6-15)% increased Rarity of Items found+(30-50) to maximum Mana +(5-10) to all [Attributes](/wiki/Attributes "Attributes") (10-15)% increased Quantity of Gold Dropped by Slain Enemies | — | (6-15)% |
| [Sekhema's Resolve](/wiki/Sekhema%27s_Resolve_(Fire) "Sekhema's Resolve (Fire)") | [Ring](/wiki/Ring_(base_type) "Ring (base type)") | 40 | (10-20)% increased Rarity of Items found +(10-20) to all [Attributes](/wiki/Attributes "Attributes") [Fire](/wiki/Fire "Fire") Resistance is unaffected by [Area Penalties](/wiki/Resistance "Resistance") You can only Socket Ruby Jewels in this item Has 1 Jewel Socket (Hidden) | *Drops from [Zarokh, the Eternal](/wiki/Zarokh,_the_Eternal "Zarokh, the Eternal") when completing a run using [The Burden of Leadership](/wiki/The_Burden_of_Leadership "The Burden of Leadership").* | (10-20)% |
| [Sekhema's Resolve](/wiki/Sekhema%27s_Resolve_(Lightning) "Sekhema's Resolve (Lightning)") | [Ring](/wiki/Ring_(base_type) "Ring (base type)") | 40 | (10-20)% increased Rarity of Items found +(10-20) to all [Attributes](/wiki/Attributes "Attributes") [Lightning](/wiki/Lightning "Lightning") Resistance is unaffected by [Area Penalties](/wiki/Resistance "Resistance") You can only Socket Emerald Jewels in this item Has 1 Jewel Socket (Hidden) | *Drops from [Zarokh, the Eternal](/wiki/Zarokh,_the_Eternal "Zarokh, the Eternal") when completing a run using [The Burden of Leadership](/wiki/The_Burden_of_Leadership "The Burden of Leadership").* | (10-20)% |
| [Sekhema's Resolve](/wiki/Sekhema%27s_Resolve_(Cold) "Sekhema's Resolve (Cold)") | [Ring](/wiki/Ring_(base_type) "Ring (base type)") | 40 | (10-20)% increased Rarity of Items found +(10-20) to all [Attributes](/wiki/Attributes "Attributes") [Cold](/wiki/Cold "Cold") Resistance is unaffected by [Area Penalties](/wiki/Resistance "Resistance") You can only Socket Sapphire Jewels in this item Has 1 Jewel Socket (Hidden) | *Drops from [Zarokh, the Eternal](/wiki/Zarokh,_the_Eternal "Zarokh, the Eternal") when completing a run using [The Burden of Leadership](/wiki/The_Burden_of_Leadership "The Burden of Leadership").* | (10-20)% |
| [The Black Insignia](/wiki/The_Black_Insignia "The Black Insignia") | [Corsair Cap](/wiki/Corsair_Cap "Corsair Cap") | 45 | (70-100)% increased [Evasion](/wiki/Evasion "Evasion") Rating (10-20)% increased Rarity of Items found +(15-25)% to [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance") Gain [Tailwind](/wiki/Tailwind "Tailwind") on [Critical Hit](/wiki/Critical_Hit "Critical Hit"), no more than once per second Lose all [Tailwind](/wiki/Tailwind "Tailwind") when [Hit](/wiki/Hit "Hit") | — | (10-20)% |
| [Shankgonne](/wiki/Shankgonne "Shankgonne") | [Covered Sabatons](/wiki/Covered_Sabatons "Covered Sabatons") | 46 | (80-100)% increased [Armour](/wiki/Armour "Armour") and [Evasion](/wiki/Evasion "Evasion") (10-20)% increased Rarity of Items found +(15-25)% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") Gain [Deflection Rating](/wiki/Deflect "Deflect") equal to 20% of [Armour](/wiki/Armour "Armour") +(200-300) to [Stun Threshold](/wiki/Stun_Threshold "Stun Threshold") You cannot Sprint Cannon Ball Footsteps (Hidden) | — | (10-20)% |
| [Fireflower](/wiki/Fireflower "Fireflower") | [Solar Amulet](/wiki/Solar_Amulet "Solar Amulet") | 52 | +(10-15) to [Spirit](/wiki/Spirit "Spirit")(10-15)% increased Rarity of Items found (30-40)% increased Mana Regeneration Rate Take 100 [Fire](/wiki/Fire "Fire") Damage when you [Ignite](/wiki/Ignite "Ignite") an Enemy +(1-4) to Level of all [Fire](/wiki/Fire "Fire") Skills | — | (10-15)% |
| [Leopold's Applause](/wiki/Leopold%27s_Applause "Leopold's Applause") | [Embroidered Gloves](/wiki/Embroidered_Gloves "Embroidered Gloves") | 52 | (60-100)% increased [Energy Shield](/wiki/Energy_Shield "Energy Shield") +(60-100) to maximum Mana (10-15)% increased Rarity of Items found Damage [Penetrates](/wiki/Resistance_Penetration "Resistance Penetration") 10% [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") Your [Hits](/wiki/Hit "Hit") can [Penetrate](/wiki/Resistance_Penetration "Resistance Penetration") [Elemental](/wiki/Elemental "Elemental") [Resistances](/wiki/Resistances "Resistances") down to a minimum of -50% | — | (10-15)% |
| [Bursting Decay](/wiki/Bursting_Decay "Bursting Decay") | [Unset Ring](/wiki/Unset_Ring "Unset Ring") | 60 | Grants 1 additional Skill Slot(15-25)% increased Rarity of Items found +(17-23)% to [Chaos Resistance](/wiki/Chaos_Resistance "Chaos Resistance") [Lose](/wiki/Life_Loss "Life Loss") 5% of maximum Life per second [Attacks](/wiki/Attack "Attack") have added [Physical](/wiki/Physical "Physical") damage equal to 3% of maximum Life | *Drops from [The Pale Angel](/wiki/The_Pale_Angel "The Pale Angel") at a [Corrupted Nexus](/wiki/Corrupted_Nexus "Corrupted Nexus").* | (15-25)% |
| [Ventor's Gamble](/wiki/Ventor%27s_Gamble "Ventor's Gamble") | [Gold Ring](/wiki/Gold_Ring "Gold Ring") | 64 | (6-15)% increased Rarity of Items found+(0-80) to maximum Life +(0-20) to [Spirit](/wiki/Spirit "Spirit") (-25-25)% increased Rarity of Items found +(-40-40)% to [Fire Resistance](/wiki/Fire_Resistance "Fire Resistance") +(-40-40)% to [Cold Resistance](/wiki/Cold_Resistance "Cold Resistance") +(-40-40)% to [Lightning Resistance](/wiki/Lightning_Resistance "Lightning Resistance") | — | (6-15)% |

### Item modfiiers

Various modifiers on [waystones](/wiki/Waystone "Waystone") can add area IIR.

### Miscellaneous
